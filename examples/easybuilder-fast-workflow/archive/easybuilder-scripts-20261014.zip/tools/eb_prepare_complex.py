"""Open observed complex creation entry points atomically, avoiding stale Qt menus."""
from eb_object_ui import target,menu,dialog
from eb_extract import ROOT,rows
import json,time
def run(handle,q):
    kind=q['prepare_complex'];page=int(q['page'])
    if not (page==17 and kind in ('DC','SP','AB') or page in (16,200) and kind=='NUM'):raise ValueError('Unreviewed complex creation entry')
    root,w=target(handle,page)
    if q.get('resume'):
        d=dialog(root.process_id(),'新增 数值' if kind=='NUM' else '新增 报警条')
        from eb_native_form import tab
        captured={}
        names=[c.window_text() for c in d.descendants(control_type='TabItem') if c.is_visible()]
        for name in names:
            tab(d,name);captured[name]=rows(d)
        (ROOT/'evidence'/'complex-prepare.json').write_text(json.dumps({'page':page,'kind':kind,'handle':d.handle,'tabs':captured},ensure_ascii=False,indent=2),encoding='utf8')
        return
    if kind=='NUM':
        from eb_ribbon import create
        d=create(root,'NUM','新增 数值')
        (ROOT/'evidence'/'complex-prepare.json').write_text(json.dumps({'page':page,'kind':kind,'handle':d.handle,'title':'新增 数值','controls':rows(d)},ensure_ascii=False,indent=2),encoding='utf8')
        return
    root.set_focus();root.click_input(coords=(427,63))
    if kind=='NUM':root.click_input(coords=(970,103));title='新增 数值'
    elif kind=='DC':menu(root,(1511,173),'日期/时间');title='新增 日期/时间'
    elif kind=='AB':
        root.click_input(coords=(522,63));time.sleep(.3)
        root.click_input(coords=(410,103));title='新增 报警条'
    else:root.click_input(coords=(250,138));title='新增 向量图'
    d=dialog(root.process_id(),title)
    (ROOT/'evidence'/'complex-prepare.json').write_text(json.dumps({'page':page,'kind':kind,'handle':d.handle,'title':title,'controls':rows(d)},ensure_ascii=False,indent=2),encoding='utf8')
