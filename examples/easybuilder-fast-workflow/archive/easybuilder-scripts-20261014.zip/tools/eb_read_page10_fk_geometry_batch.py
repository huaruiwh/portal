import json
from eb_rebuild_page import call
for i in range(6):
 call('uia',2559326,json.dumps({'verify_page10_fk_geometry':'FK_'+str(i),'resume_dialog':i==0}))
 print(i,'verified',flush=True)
