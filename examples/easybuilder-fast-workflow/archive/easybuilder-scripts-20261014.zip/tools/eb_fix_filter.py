from pywinauto import Desktop
from eb_extract import ROOT
import json
def run(handle,q):
    w=Desktop(backend='uia').window(handle=handle).wrapper_object();r=w.rectangle()
    if '组装机_MT8106iP.emtp' not in w.window_text():raise ValueError('Known target only')
    matches=[c for c in w.descendants(control_type='Edit',cache_enable=True) if r.left<=c.rectangle().left and c.rectangle().right<r.left+500 and r.top+190<c.rectangle().top<r.top+270]
    if len(matches)!=1:raise ValueError('Unique tree filter required')
    matches[0].set_edit_text('31 :')
    if matches[0].get_value()!='31 :':raise ValueError('Direct tree filter mismatch')
    (ROOT/'evidence/copy-filter-fix.json').write_text(json.dumps({'page':31,'value':matches[0].get_value(),'direct_value_pattern':True}),encoding='utf8')
