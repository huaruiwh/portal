"""Serial original RGB collection and native saved target readback."""
import json,re
from datetime import datetime
from eb_rebuild_page import ROOT,call

def run():
 lock=ROOT/'tools/batch.lock'
 with lock.open('x'):pass
 path=ROOT/'evidence/page26-color-workflow.json'
 report={'date':datetime.now().isoformat(),'completed':[],'ok':False,'runtime_verified':False}
 def persist():path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 try:
  call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
  def resolve(title):
   candidates=[w for w in ws if w['class']=='EasyBuilderPro' and title in w['title']]
   if len(candidates)!=1:raise ValueError('Unique project required')
   return candidates[0]['handle']
  sh=resolve('组装机2台15工位取消.cmtp');th=resolve('组装机_MT8106iP.emtp')
  inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(p['observed_objects'] for p in inv['pages'] if p['id']==26)
  for n in range(7):
   report['stage']=f'TS_{n}';persist()
   if not (ROOT/f'evidence/page26-TS{n}-source-colors.json').exists():
    name=next(x for x in names if re.match(r'^TS_'+str(n)+r'\s',x))
    call('uia',sh,json.dumps({'extract':{'page':26,'object':name,'keep_open':True}},ensure_ascii=False))
    call('uia',sh,json.dumps({'page26_shapes':'source-colors','n':n,'build_bit_general':n}))
   if not (ROOT/f'evidence/page26-TS{n}-color-correction.json').exists():
    call('uia',th,json.dumps({'page26_shapes':'target-colors','n':n,'build_bit_general':n}))
   report['completed'].append(n);persist();print(f'TS{n} source RGB saved/reopened',flush=True)
  report['ok']=True;report['stage']='completed';persist()
 except Exception as e:report['error']=str(e);persist();raise
 finally:lock.unlink(missing_ok=True)

if __name__=='__main__':run()
