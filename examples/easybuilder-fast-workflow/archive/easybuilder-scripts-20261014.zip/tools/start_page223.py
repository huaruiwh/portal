import json,time,os,subprocess,sys
from eb_rebuild_page import ROOT,call
r=ROOT;lock=r/'tools/later-pages-supervisor.lock';wf=r/'evidence/page223-start-workflow.json'
with lock.open('x',encoding='utf8')as f:f.write(json.dumps({'pid':os.getpid(),'task':'page223-after-cache'}))
d={'page':223,'phase':'waiting-source-cache','finished':False}
def record():wf.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
try:
 record()
 while (r/'tools/batch.lock').exists():time.sleep(2)
 cache=json.loads((r/'evidence/page223-cache-workflow.json').read_text(encoding='utf8'))
 if not cache['finished']:raise ValueError('223 source cache failed; inspect before build')
 call('snapshot');ws=json.loads((r/'evidence/windows.json').read_text(encoding='utf8'));src=next(w['handle']for w in ws if '.cmtp'in w['title']);h=next(w['handle']for w in ws if '组装机_MT8106iP.emtp'in w['title'])
 d['phase']='source-settings';record()
 if not (r/'evidence/source-pages-settings/223.json').exists():call('uia',src,json.dumps({'page_settings':223,'color_probe':True}))
 d['phase']='create';record()
 if not (r/'evidence/target-page-223-created.json').exists():call('uia',h,json.dumps({'create_target_page':223}))
 call('uia',h,json.dumps({'open_target_page':223}))
 if not (r/'evidence/scale-890x469/page-223-initial-height.json').exists():call('uia',h,json.dumps({'scale_post200':{'page':223,'mode':'blank_height'},'build_bit_general':0}))
 d['phase']='whole-page-copy';record()
 journal=r/'evidence/page223-whole-page-copy.json'
 if not journal.exists():call('uia',h,json.dumps({'page223_controls':[],'page223_clone':True,'page215_clone':True,'build_bit_general':0}))
 elif json.loads(journal.read_text(encoding='utf8')).get('stage')!='saved-bindings-pending':raise ValueError('223 copy outcome requires real directory inspection; no repeat paste')
 d['phase']='build';record();p=subprocess.run([sys.executable,str(r/'tools/continue_page223.py')],cwd=r)
 if p.returncode:raise ValueError('223 build stopped; inspect workflow')
 d['finished']=True;record()
except Exception as e:
 d['error']=str(e);record();raise
finally:lock.unlink(missing_ok=True)
