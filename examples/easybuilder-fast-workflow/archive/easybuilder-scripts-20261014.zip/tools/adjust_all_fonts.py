"""Serial font-only queue; saved phases resume without duplicate edits."""
import json,os,time,traceback,re
from datetime import datetime
from eb_rebuild_page import ROOT,call
PROGRESS=ROOT/'evidence/font-adjustment-workflow.json'
def write(d):PROGRESS.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
def document(d):
    block='\n### 2026-10-10 全工程字体适配\n用户指定全部可见文字使用微软正黑体 Light。只修改已有控件字体和字号，保留文字、地址、图片和轮廓。原工程备份 archives/字体调整前_20261010.emtp。脚本 tools/eb_adjust_fonts.py 和 tools/adjust_all_fonts.py；恢复命令：Python tools/adjust_all_fonts.py。以原字号为基准，1024×768到1024×600页按600/768缩放；有宽高时使用 C:\\Windows\\Fonts\\msjhl.ttc 测量行宽和行高，留6px横向、4px纵向边距，不足6pt停止等待布局复核。标题自动尺寸控件无宽高，暂按比例字号，仍待画面复核。每件保存后重开读回字体字号，其它文字设置和轮廓应一致。\n实际进度：'+str(len(d['completed']))+'/'+str(d['total'])+'个有原字体证据的控件；状态 '+d['status']+'，阶段 '+d.get('stage','')+'。当前工程字节数 '+str((ROOT/'output/组装机_MT8106iP.emtp').stat().st_size)+'。测量是布局预检，未声称完整运行或文字截断验收。待处理：剩余控件、无原字体字段的控件目录核查、画面复核、重新编译。旧重建队列保持暂停，只运行此次授权字体调整。\n'
    if d.get('error'):block+='错误原文：\n```\n'+d['error']+'\n```\n'
    marker='<!-- FONT-ADAPTATION-20261010 -->'
    for p in [ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md']:
        s=p.read_text(encoding='utf8');endmarker='<!-- END-FONT-ADAPTATION-20261010 -->'
        start=s.rfind(marker);end=s.find(endmarker,start) if start>=0 else -1
        if start>=0 and end>=0:s=s[:start]+s[end+len(endmarker):]
        p.write_text(s+marker+block+endmarker+'\n',encoding='utf8')
def main():
    lock=ROOT/'tools/batch.lock'
    with lock.open('x',encoding='utf8') as f:json.dump({'pid':os.getpid(),'task':'font-only adjustment'},f)
    d={'date':datetime.now().isoformat(timespec='seconds'),'status':'running','completed':[],'errors':[],'pid':os.getpid()}
    try:
        wins=call('snapshot')['windows'];ts=[w['handle'] for w in wins if '组装机_MT8106iP.emtp' in w['title']]
        if len(ts)!=1:raise ValueError('Exactly one target project required')
        h=ts[0];call('uia',h,json.dumps({'restore_target_window':True,'reviewed_size':True}))
        jobs=[]
        for p in sorted((ROOT/'evidence/source-object-properties').glob('*.json')):
            s=json.loads(p.read_text(encoding='utf8'))
            if any(any(r['type']=='ComboBox' and r['name']=='字体 :' and 'value' in r for r in rs) for rs in s.get('tabs',{}).values()):
                page,key=p.stem.split('_',1);jobs.append((int(page),key))
        jobs.sort(key=lambda item:(item[0]!=16,item[0],{'TX':0,'TS':1,'NE':2,'ND':3}.get(item[1].split('_')[0],4),item[1]))
        d['total']=len(jobs);document(d);write(d)
        active=None
        for page,key in jobs:
            if (ROOT/'tools/font-work-paused.json').exists():d['status']='paused';break
            rp=ROOT/f'evidence/font-adjustments/{page:03d}_{key}.json'
            old=json.loads(rp.read_text(encoding='utf8')) if rp.exists() else {}
            if old.get('verified') and old.get('font')=='微软正黑体 Light' and old.get('fit_policy_version')==2:d['completed'].append(f'{page}:{key}');continue
            if active!=page:
                call('uia',h,json.dumps({'open_target_page':page}))
                title=next(v['title'] for v in call('snapshot')['windows'] if v['handle']==h)
                match=re.search(r'\[\d+ - (.*?)\]$',title)
                if not match:raise ValueError('Active page title must expose page name')
                call('uia',h,json.dumps({'adjust_fonts':True,'directory_probe':True,'directory_filter':match[1].strip(),'ensure_page_directory':True},ensure_ascii=False))
                active=page
            d['stage']=f'{page}:{key}';write(d)
            try:
                if not old.get('save_requested') or old.get('fit_policy_version')!=2 or old.get('layout_needs_recheck'):call('uia',h,json.dumps({'adjust_fonts':True,'page':page,'key':key,'phase':'edit','build_bit_general':0}))
                call('uia',h,json.dumps({'adjust_fonts':True,'page':page,'key':key,'phase':'verify','build_bit_general':0}))
                d['completed'].append(f'{page}:{key}');write(d)
            except Exception:
                d['error']=traceback.format_exc();d['status']='needs-review';raise
            document(d)
        else:d['status']='font-readback-complete'
    except Exception:
        d['status']='needs-review';d['error']=traceback.format_exc()
        print(d['error'],flush=True)
    finally:
        write(d);document(d);lock.unlink(missing_ok=True)
        print(json.dumps({'status':d['status'],'completed':len(d['completed']),'total':d.get('total'),'stage':d.get('stage')},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
