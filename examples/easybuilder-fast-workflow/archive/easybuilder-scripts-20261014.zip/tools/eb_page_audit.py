"""Read current target page tree for a saved-object count audit."""
import json,re,time
from pathlib import Path
from pywinauto import Desktop
ROOT=Path(__file__).resolve().parent.parent
def run(handle,request):
    page=int(request['target_page_audit'])
    w=Desktop(backend='uia').window(handle=handle).wrapper_object()
    if '组装机_MT8106iP.emtp' not in w.window_text() or f'[{page} - ' not in w.window_text():raise ValueError('Expected target page')
    native=Desktop(backend='win32').window(handle=handle).wrapper_object();wr=w.rectangle()
    from eb_directory import scope
    directory=scope(w)
    filters=[c for c in native.descendants(class_name='Edit') if c.is_visible() and wr.left<=c.rectangle().left and c.rectangle().right<wr.left+500 and wr.top+190<c.rectangle().top<wr.top+270]
    if len(filters)!=1:filters=[c for c in directory.descendants(control_type='Edit') if c.is_visible() and wr.left<=c.rectangle().left and c.rectangle().right<wr.left+500 and wr.top+190<c.rectangle().top<wr.top+270]
    if len(filters)!=1:raise ValueError('Unique directory filter required')
    from pywinauto.keyboard import send_keys
    native.set_focus()
    if filters[0].handle and filters[0].class_name()=='Edit':
        from eb_native_messages import put
        put(filters[0].handle,str(page)+' :')
    else:
        if filters[0].get_value()!=str(page)+' :':
            import win32clipboard
            win32clipboard.OpenClipboard()
            try:
                win32clipboard.EmptyClipboard();win32clipboard.SetClipboardText(str(page)+' :',win32clipboard.CF_UNICODETEXT)
            finally:win32clipboard.CloseClipboard()
            filters[0].click_input();filters[0].set_focus()
            send_keys('^a^v',pause=.05)
    time.sleep(.15)
    from eb_native_messages import text
    actual=text(filters[0].handle) if filters[0].handle and filters[0].class_name()=='Edit' else filters[0].get_value()
    if actual!=str(page)+' :':raise ValueError('Exact directory filter readback mismatch')
    trees=[v for v in directory.descendants(control_type='Tree') if v.is_visible()]
    if len(trees)!=1:raise ValueError('Unique directory tree required')
    from pywinauto import mouse
    rect=trees[0].rectangle()
    Desktop(backend='win32').window(handle=handle).set_focus()
    mouse.scroll(coords=((rect.left+rect.right)//2,(rect.top+rect.bottom)//2),wheel_dist=60)
    time.sleep(.15)
    nodes=trees[0].descendants(control_type='TreeItem')
    headers=[i for i,c in enumerate(nodes) if re.match(r'^'+str(page)+r'\s*:',c.window_text())]
    for _ in range(4):
        if len(headers)==1:break
        native.set_focus();mouse.scroll(coords=((rect.left+rect.right)//2,(rect.top+rect.bottom)//2),wheel_dist=80);time.sleep(.2)
        nodes=trees[0].descendants(control_type='TreeItem');headers=[i for i,c in enumerate(nodes) if re.match(r'^'+str(page)+r'\s*:',c.window_text())]
    if len(headers)!=1:raise ValueError('Expected unique page header')
    if headers[0]+1==len(nodes) or re.match(r'^\d+(?:\s*:|$)',nodes[headers[0]+1].window_text()):
        header=nodes[headers[0]]
        try:header.expand()
        except Exception:
            from pywinauto import mouse
            native=Desktop(backend='win32').window(handle=handle).wrapper_object();native.set_focus()
            r=header.rectangle();mouse.click(coords=(r.left-14,(r.top+r.bottom)//2))
        time.sleep(.1)
        nodes=trees[0].descendants(control_type='TreeItem')
        headers=[i for i,c in enumerate(nodes) if re.match(r'^'+str(page)+r'\s*:',c.window_text())]
        if len(headers)!=1:raise ValueError('Page header changed while expanding')
    # Qt exposes only the visible directory rows. Collect overlapping views
    # through the bottom; a single viewport is not the page inventory.
    from pywinauto import mouse
    names=[]
    seen=set()
    for attempt in range(20):
        for c in nodes:
            name=c.window_text()
            if re.match(r'^\d+(?:\s*:|$)',name):continue
            if name and name not in seen:seen.add(name);names.append(name)
        signature=tuple(c.window_text() for c in nodes)
        rect=trees[0].rectangle()
        mouse.scroll(coords=((rect.left+rect.right)//2,(rect.top+rect.bottom)//2),wheel_dist=-8)
        time.sleep(.15)
        nodes=trees[0].descendants(control_type='TreeItem')
        if tuple(c.window_text() for c in nodes)==signature:break
    else:raise ValueError('Directory did not reach a stable bottom')
    inv=json.loads((ROOT/'evidence'/'source-pages-inventory.json').read_text(encoding='utf8'))
    original=next(v['observed_objects'] for v in inv['pages'] if v['id']==page)
    def keys(items):
        result={}
        for name in items:
            key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)(?:\s|$)',name)
            if not key:raise ValueError('Unsupported tree object: '+name)
            if key[1] in result:raise ValueError('Duplicate object key')
            result[key[1]]=re.sub(r'\s*\(最下层\)$','',name)
        return result
    source=keys(original);target=keys(names)
    missing=sorted(set(source)-set(target));unexpected=sorted(set(target)-set(source))
    mismatch=[k for k in source.keys() & target.keys() if source[k]!=target[k]]
    adaptation=[]
    if page==201:
        for key in list(mismatch):
            if not key.startswith('TX_'):continue
            p=ROOT/f'evidence/target-201-{key.replace("_","")}-built.json'
            if p.exists():
                proof=json.loads(p.read_text(encoding='utf8'))
                if (proof.get('saved_reopened_verified') or (page in (231,232,235) and proof.get('property_session_verified') and proof.get('saved')))and proof.get('original_text_preserved')and re.sub(r'\s+\]',']',source[key])==target[key]:
                    mismatch.remove(key);adaptation.append(key+' directory trailing-space presentation; '+('saved literal reopened verified' if proof.get('saved_reopened_verified') else 'literal verified before save; saved directory canonical text equal'))
    if page in (210,212,218,221,224,235):
        for key in list(mismatch):
            if not key.startswith('TX_'):continue
            kind,n=key.split('_')
            p=ROOT/f'evidence/target-{page:03d}-{kind}{int(n)}-built.json'
            if not p.exists():continue
            proof=json.loads(p.read_text(encoding='utf8'))
            caption=(proof.get('expected') or {}).get('caption')
            saved=[r.get('value') for r in proof.get('tabs',{}).get('文字/批注',[]) if r.get('type')=='Edit' and r.get('class')=='RichEdit20W']
            if proof.get('saved_reopened_verified') and caption is not None and saved and saved[0]==caption and re.sub(r'\s+\]',']',source[key])==target[key]:
                mismatch.remove(key);adaptation.append(key+' directory trailing-space presentation; saved caption equals original cache: '+caption)
    if page in (203,205,213,214,215,216,217,219,220,222,223,224,225,226,228,229,230,231,232,235,236,237,302,313):
        for key in list(mismatch):
            if not key.startswith('TX_'):continue
            p=ROOT/(f'evidence/target-{page}-{key}-rewritten.json'if page in (203,215,223,224,225,226)else f'evidence/target-{page}-{key}-built.json')
            if p.exists():
                proof=json.loads(p.read_text(encoding='utf8'))
                if (proof.get('saved_reopened_verified') or (page in (231,232,235) and proof.get('property_session_verified') and proof.get('saved')))and proof.get('original_text_preserved')and re.sub(r'\s+\]',']',source[key])==target[key]:
                    mismatch.remove(key);adaptation.append(key+' directory trailing-space presentation; '+('saved literal reopened verified' if proof.get('saved_reopened_verified') else 'literal verified before save; saved directory canonical text equal'))
    if page==16:
        hp=ROOT/'evidence/page16-alarm-header-adaptation.json'
        if hp.exists():
            h=json.loads(hp.read_text(encoding='utf8'))
            if h.get('ok') and set(h.get('completed',[]))=={'DW_5','TX_31','TX_32'}:
                adaptation=sorted(set(unexpected)&{'DW_5','TX_31','TX_32'})
                unexpected=[k for k in unexpected if k not in adaptation]
    mapping=None
    local_path=ROOT/'evidence'/f'page-{page}-local-reopened.json'
    if page==202 and (ROOT/'evidence/page202-copy-mapping.json').exists():
        verified=json.loads((ROOT/'evidence/page202-copy-mapping.json').read_text(encoding='utf8'))
        m=verified['mapping']
        if not verified.get('bindings_verified') or set(m)!=set(source) or set(m.values())!=set(target):raise ValueError('Page202 copy mapping verification incomplete')
        mapping=m
        mismatch=[k for k,dest in m.items() if target[dest]!=source[k].replace(k,dest,1)]
        if 'TX_2' in mismatch:
            literal=json.loads((ROOT/'evidence/target-202-TX_2-copy-rewritten.json').read_text(encoding='utf8'))
            if literal.get('saved_reopened_verified') and re.sub(r'\s+\]',']',source['TX_2'].replace('TX_2',m['TX_2'],1))==target[m['TX_2']]:
                mismatch.remove('TX_2');adaptation.append('TX_2 directory label trailing-space presentation')
    if page in (48,49) and local_path.exists():
        verified=json.loads(local_path.read_text(encoding='utf8'))
        m=verified.get('mapping',{})
        if verified.get('all_properties_verified') and set(m)==set(source) and set(m.values())==set(target) and len(set(m.values()))==len(m):
            mapping=m
            mismatch=[k for k,dest in m.items() if target[dest]!=source[k].replace(k,dest,1)]
    report={'page':page,'source_count':len(original),'target_count':len(names),'missing':missing,'unexpected':unexpected,'address_name_mismatch':mismatch,'objects':names,'tree_verified':not(missing or unexpected or mismatch),'functional_simulation_verified':False,'verified_object_mapping':mapping}
    report['model_adaptation_objects']=adaptation
    (ROOT/'evidence'/f'target-page{page}-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    if not report['tree_verified']:raise ValueError('Target object audit incomplete')

