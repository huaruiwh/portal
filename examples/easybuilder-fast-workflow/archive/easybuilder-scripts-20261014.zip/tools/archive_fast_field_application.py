"""Persist actual TS_2 production trial and its recovery instructions."""
import json,pathlib,py_compile
ROOT=pathlib.Path(__file__).resolve().parents[1]
r=json.loads((ROOT/'evidence/target-201-TS2-built.json').read_text(encoding='utf8'))
a=json.loads((ROOT/'evidence/target-page201-audit.json').read_text(encoding='utf8'))
assert r['saved_reopened_verified'] and a['target_count']==19 and not a['unexpected']
size=(ROOT/'output/组装机_MT8106iP.emtp').stat().st_size
for name in ('eb_page201_buttons.py','eb_fast_fields_benchmark.py','eb_native_id_fields.py'):
    py_compile.compile(str(ROOT/'tools'/name),doraise=True)
section=f'''

### 2026-10-11：快速字段方法已用于实际按钮——201/TS_2原点

用户要求应用实测结果并查看效果。已将原生class/GetDlgCtrlID/父链定位接入tools/eb_page201_buttons.py的quick_capture：一般属性中已学习的3字段直接原生读，其余地址类型等字段保留eb_live_fields.capture回退；标签两状态文本、字体、字号与轮廓X/Y/宽/高使用已验证schema读回。不是取消保存后必要核对，也没有改工程二进制。保留原先编辑提交，先字体后尺寸，模板安全不同仍单独适配。

真实新增201/TS_2“原点”，DB8Bit-754.0、复归型；两态标签原点，微软正黑体 Light13号；X754/Y170/宽90/高45。图片继承已验证TS_0同源System Button - Flat/index1及RGB128/221/255；标签黑色。原最短按压1秒、权限类别C、取消使用限制0、无权限提示0、无权限隐藏1、寄存器限制0均保存后重开核对通过。report：evidence/target-201-TS2-built.json，phase已verified。

整件耗时{r['elapsed_seconds']:.9f}秒，其中复制{r['copy_seconds']:.9f}秒。本件包含与模板不同的Qt安全适配，不能与前58.2821607秒点动件计算整体加速倍数；新读回路线已在真实保存流程通过，整件明显更快仍待同安全模板对照。实际目录19/52件、剩{len(a['missing'])}、额外0；工程{size}字节，停201页。无新编译/运行验收，不下载PLC/HMI、不执行宏、不点击控制按钮。

关键根因：Qt时间ComboBoxWrapper对象选择后selected_text仍返回旧缓存0.1，导致之前误判输入失败。实测expand展开完整实际ListItem，唯一可见“1”点击后旧对象仍0.1，但重新eb_live_fields.capture返回1且实际selected项为1。已用expand+精确选项+新对象读回替代旧^a键入/旧对象验证；保存重开安全全部通过。证据evidence/duration-selection-probe.json、duration-fields-inspection.json。探针只在原已保存TS_1属性中测试并取消，未保存修改TS_1。

阶段恢复：retry_removed=true仅在历史phase为removed-unverified-preview、目录准确18件、TS_2缺失且无额外对象时允许重建；历史保存在target-201-TS2-removed-phase-history.json。现已verified，重新请求page201_button=2会直接跳过，禁止再贴。下个TS_3“学习”源参数已读缓存，1秒/B权限/无权限提示与本件不同，当前脚本只允许0/1/2，尚未制作TS_3，不能直接批量循环后续件。

关键命令：项目目录Python tools下模块，现有管理员worker call('uia',10488686,json.dumps({{'page201_button':2,'retry_removed':True,'build_bit_general':0}},ensure_ascii=False))；终端控制器持有tools/batch.lock并在finally释放。正常恢复不传retry_removed；已完成报告直接跳过。本次真实终态目录审计通过fast_fields_benchmark=true/final_audit=true调用read_audit，不把整页尚未完成误当控件失败。

排查原文：抽源最初传TS_3而非目录真实名称，报`Object must be observed in source inventory or verified model adaptation`；更正为已观察的`TS_3 (DB8Bit-766.0)`后读缓存成功。探针最初list(RECT)报`TypeError: 'RECT' object is not iterable`；改为left/top/right/bottom显式四值后通过。字体/尺寸schema来自同类型TS_1重开实测；Qt字段继续原路线回退。脚本py_compile通过。下一步在用户看过本件后扩展同类件范围，并测同安全模板的整件耗时，保留真实字段值及权限差异。
'''
for p in (ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md'):
    if '### 2026-10-11：快速字段方法已用于实际按钮——201/TS_2原点'not in p.read_text(encoding='utf8'):
        with p.open('a',encoding='utf8')as f:f.write(section)
cp=ROOT/'evidence/resume-checkpoint.json';d=json.loads(cp.read_text(encoding='utf-8-sig'))
d.update(status='page201-three-buttons-saved-preview-awaiting-user',page201_objects=19,page201_remaining_objects=33,project_bytes=size,target_project_bytes=size,field_speed_production_integrated=True,field_speed_production_scope='same-kind-button-general-native-subset-labels-and-geometry-readback',batch_running=False,next_action='TS_0/1/2 verified, do not duplicate. TS_3 original cached; extend builder deliberately for next index and original B permission. Compare full timing on matching safety template.')
cp.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
(ROOT/'evidence/page201-buttons-preview-workflow.json').write_text(json.dumps({'page':201,'verified':['TS_0','TS_1','TS_2'],'status':'saved-preview-awaiting-user','remaining':33,'elapsed_seconds':r['elapsed_seconds'],'field_read_method':r['field_read_method']},ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'objects':19,'remaining':33,'bytes':size,'TS2_seconds':r['elapsed_seconds'],'docs_updated':2},ensure_ascii=False))
