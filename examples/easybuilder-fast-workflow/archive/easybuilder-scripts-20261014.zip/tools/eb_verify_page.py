"""Compare persisted source and target readback evidence without UI traffic."""
import json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent

def run(page,subset=False):
    inv=json.loads((ROOT/'evidence'/'source-pages-inventory.json').read_text(encoding='utf8'))
    names=next(p['observed_objects'] for p in inv['pages'] if p['id']==page)
    checks=[]
    for name in names:
        if subset and not re.match(r'^(SW|BL)_\d+\s',name):continue
        kind,n=re.match(r'^(SW|BL)_(\d+)\s',name).groups()
        src=json.loads((ROOT/'evidence'/'source-object-properties'/f'{page:03d}_{kind}_{n}.json').read_text(encoding='utf8'))
        dst=json.loads((ROOT/'evidence'/f'target-{page:03d}-{kind}{n}-built.json').read_text(encoding='utf8'))
        def edits(rows):return rows if isinstance(rows,dict) else {c['name']:c['value'] for c in rows if c['type']=='Edit'}
        from eb_layout import geometry as adapt_geometry
        geometry=adapt_geometry(src)
        target_shape=edits(dst['geometry'])
        shape_ok=bool(geometry) and all(target_shape.get(k)==v for k,v in geometry.items())
        g=src['tabs']['一般属性']
        addresses=[c['value'] for c in g if c['type']=='Edit' and c['name']=='Static']
        if kind=='SW':
            d=dst['general']
            constant=next(c['value'] for c in g if c['type']=='Edit' and c['name']=='设置常数 :')
            general_ok=isinstance(d,dict) and d.get('constant')==constant and d.get('addresses')==addresses and d.get('devices')==['Local HMI','Local HMI'] and all(d.get(k)==1 for k in ('notification','on','after_write'))
            labelled=any(c.get('value','').strip() for state in src.get('label_states',{}).values() for c in state if c['type']=='Edit' and c['name']=='')
            labels_ok=not labelled or all(edits(dst.get('labels',{}).get(state,[])).get('')==edits(src['label_states'][state]).get('') for state in ('0','1'))
        else:
            d=dst['general']
            target_addresses=[c['value'] for c in d if c['type']=='Edit' and c['name']=='Static']
            general_ok=target_addresses==addresses and any(c['type']=='RadioButton' and c['name']=='位状态指示灯' and c.get('value')==1 for c in d)
            enabled=next(c['value'] for c in src['tabs']['标签'] if c['type']=='CheckBox' and c['name']=='使用文字标签')
            labels_ok=not enabled or all(edits(dst['labels'].get(state,[])).get('')==edits(src['label_states'][state]).get('') for state in ('0','1'))
        checks.append({'object':f'{kind}_{n}','geometry_verified':shape_ok,'general_verified':general_ok,'text_verified':labels_ok})
    report={'page':page,'object_count':len(checks),'checks':checks,'ok':all(all(c[k] for k in ('geometry_verified','general_verified','text_verified')) for c in checks),'subset_only':subset,'evidence_only':True,'offline_simulation_verified':False,'color_review_pending':True}
    suffix='subset-parameter-audit' if subset else 'parameter-audit'
    (ROOT/'evidence'/f'page-{page}-{suffix}.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    if not report['ok']:raise ValueError('Saved object parameter evidence mismatch')
    return report

if __name__=='__main__':
    import sys
    r=run(int(sys.argv[1]));print(json.dumps({'page':r['page'],'objects':r['object_count'],'ok':r['ok']},ensure_ascii=False))
