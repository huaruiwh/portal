import json
from eb_rebuild_page import ROOT
from eb_object_ui import target
from eb_ribbon import create
from eb_extract import rows
from eb_page26_shapes import cancel
def run(handle,q):
    root,w=target(handle,201);kind=q['page201_other_probe']
    if kind in ('SW','FK','OL_FORM'):
        if kind=='OL_FORM':
            from eb_object_ui import dialog
            observed=json.loads((ROOT/'evidence/page201-ribbon-local-ocr.json').read_text(encoding='utf-8-sig'))['words']
            words=[v for v in observed if 800<v['x']<900 and 130<v['y']<155 and v['text']in ('目','选','单')]
            if len(words)!=3:raise ValueError('Observed project menu ribbon label required')
            root.set_focus();root.click_input(coords=(round(sum(v['x']+v['width']/2 for v in words)/3), round(sum(v['y']+v['height']/2 for v in words)/3)))
            d=dialog(root.process_id(),'新增 项目选单')
        else:d=create(root,kind,'新增 多状态设置'if kind=='SW'else '新增 功能键')
        try:
            if q.get('all_tabs'):
                from eb_native_form import tab
                names=[c.element_info.name for c in d.descendants(control_type='TabItem')if c.is_visible()];r={}
                for name in names:
                    tab(d,name);r[name]=rows(d)
                    if name=='源数据':r['_count_children']=[{'name':c.element_info.name,'value':c.selected_text(),'children':[{'type':v.element_info.control_type,'name':v.element_info.name,'handle':v.element_info.handle,'class':v.element_info.class_name}for v in c.children()]}for c in d.descendants(control_type='ComboBox')if c.is_visible()]
            else:r=rows(d)
        finally:cancel(d)
        (ROOT/f'evidence/page201-{kind}-new-form.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
    elif kind=='OL':
        root.set_focus();root.click_input(coords=(373,52))
        import subprocess
        from PIL import ImageGrab
        box=root.rectangle();img=ROOT/'evidence/page201-ribbon-local.png';out=ROOT/'evidence/page201-ribbon-local-ocr.json'
        ImageGrab.grab(bbox=(box.left,box.top,box.right,box.top+185)).save(img)
        code=(ROOT/'tools/Read-LocalImageText.ps1').read_text(encoding='utf8').replace('param([string]$ImagePath,[string]$OutputPath)',"$ImagePath='"+str(img).replace("'","''")+"';$OutputPath='"+str(out).replace("'","''")+"'")
        result=subprocess.run([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe','-NoProfile','-Command',code],capture_output=True,text=True,timeout=30)
        if result.returncode:raise RuntimeError(result.stderr)
        r=[{'name':c.element_info.name,'type':c.element_info.control_type,'rect':[c.rectangle().left,c.rectangle().top,c.rectangle().right,c.rectangle().bottom]}for c in w.descendants(cache_enable=True)if c.is_visible()and c.element_info.name and c.element_info.control_type in ('Button','MenuItem','SplitButton')]
        (ROOT/'evidence/page201-ribbon-observed.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
    else:raise ValueError('Known native probes only')
