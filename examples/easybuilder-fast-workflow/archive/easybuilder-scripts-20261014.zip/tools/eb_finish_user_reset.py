import json
from pywinauto import Desktop
from eb_extract import ROOT,rows
from eb_native_form import tab,fields,confirm
from eb_object_ui import save
from eb_layout import geometry

def run(handle,q):
 page=int(q['finish_user_reset'])
 if page!=11:raise ValueError('Reviewed interrupted page11 reset only')
 phase=json.loads((ROOT/'evidence/target-011-TS0-copy-phase.json').read_text(encoding='utf8'))
 audit=json.loads((ROOT/'evidence/target-page11-audit.json').read_text(encoding='utf8'))
 if not phase['pasted'] or audit['target_count']!=30 or audit['unexpected'] or 'TS_0' in audit['missing']:raise ValueError('Verified single pasted reset required')
 root=Desktop(backend='win32').window(handle=handle).wrapper_object()
 ds=[d for d in Desktop(backend='win32').windows() if d.process_id()==root.process_id() and d.is_visible() and d.window_text()=='位状态切换开关/位状态指示灯的属性']
 if len(ds)!=1:raise ValueError('One unfinished reset property required')
 d=Desktop(backend='uia').window(handle=ds[0].handle).wrapper_object();source=json.loads((ROOT/'evidence/source-object-properties/011_TS_0.json').read_text(encoding='utf8'))
 tab(d,'轮廓');expected=geometry(source);fields(d,[{'type':'Edit','name':k,'value':v} for k,v in expected.items()]);shape=rows(d)
 if {r['name']:r['value'] for r in shape if r['type']=='Edit' and r['name'] in expected}!=expected:raise ValueError('Reset finish geometry mismatch')
 confirm(d);save(root)
 (ROOT/'evidence/target-011-TS0-built.json').write_text(json.dumps({'page':11,'source':source['object'],'target':'TS_0 (M-26.0)','template':103,'geometry':shape,'saved_requested':True,'user_picture_preserved':True,'count_verified':True,'general_reopened_verified':False,'offline_simulation_verified':False},ensure_ascii=False,indent=2),encoding='utf8')
