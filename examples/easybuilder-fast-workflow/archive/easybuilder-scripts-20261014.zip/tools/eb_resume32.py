"""Resume the observed and saved blank page 32 after color UIA timeout."""
import json
from eb_rebuild_page import ROOT
from eb_continue_flows import run
e=ROOT/'evidence'
colors=json.loads((e/'page32-color-native.json').read_text(encoding='utf8'))
assert [next(c['text'] for c in colors if c['id']==i) for i in (16964,16965,16966)]==['192']*3
settings=json.loads((e/'page32-settings-native.json').read_text(encoding='utf8'))
assert next(c['text'] for c in settings if c['id']==1491)=='[ID:067] 关闭LB142'
ws=json.loads((e/'windows.json').read_text(encoding='utf8'))
assert any('组装机_MT8106iP.emtp' in w['title'] and '[32 - ' in w['title'] for w in ws)
src=json.loads((e/'source-pages-settings/032.json').read_text(encoding='utf8'))
values={c['name']:c['value'] for c in src['controls'] if c['type']=='Edit' and c['name'] in ('窗口名称 :','窗口编号 :','宽度 :','高度 :')}
for suffix,obj in {
 'created':{'page':32,'created_blank_page':True,'fields':values,'saved_requested':True,'dialog_closed_verified':True,'recovery':'native RGB readback and actual page opening after UIA timeout'},
 'size':{'page':32,'after':{k:values[k] for k in ('宽度 :','高度 :')},'saved_requested':True},
 'color':{'page':32,'rgb':[192,192,192],'target_process_id':31304,'saved_requested':True,'native_fields_verified':True,'project_reopened_verified':False}
}.items():
 (e/f'target-page-032-{suffix}.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf8')
run([32])
