"""Read-only exact comparison of EasyBuilder native XLS event exports."""
import sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'tools/python-libs'))
import xlrd
def run(target='evidence/target-events-imported.xls'):
 s=xlrd.open_workbook(str(ROOT/'source/assets/source-events-484.xls')).sheet_by_index(0)
 t=xlrd.open_workbook(str(ROOT/target)).sheet_by_index(0)
 sh=s.row_values(1);th=t.row_values(1)
 def indexed(hs):
  counts={};out={}
  for i,h in enumerate(hs):
   counts[h]=counts.get(h,0)+1;out[(h,counts[h])]=i
  return out
 sm=indexed(sh);tm=indexed(th);common=[h for h in sm if h in tm];diff=[]
 for row in range(2,min(s.nrows,t.nrows)):
  for h in common:
   a=s.cell_value(row,sm[h]);b=t.cell_value(row,tm[h])
   if a!=b:diff.append({'row':row+1,'field':h[0],'occurrence':h[1],'source':a,'target':b})
 r={'source_count':s.nrows-2,'target_count':t.nrows-2,'source_columns':s.ncols,'target_columns':t.ncols,'common_columns':len(common),'source_only_values':{str(h):sorted(set(str(s.cell_value(i,sm[h])) for i in range(2,s.nrows))) for h in sm if h not in tm},'differences':diff,'all_common_fields_equal':not diff and s.nrows==t.nrows,'target_export':target,'offline_simulation_verified':False}
 (ROOT/'evidence/alarm-events-import-comparison.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
 print(json.dumps({k:v for k,v in r.items() if k!='source_only_values'},ensure_ascii=True))
 if not r['all_common_fields_equal']:raise ValueError('Imported event export differs')
 return r
if __name__=='__main__':run(sys.argv[1] if len(sys.argv)>1 else 'evidence/target-events-imported.xls')
