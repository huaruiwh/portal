"""Audit representative page16 values after a real saved-project restart."""
import json,re,sys
from eb_rebuild_page import ROOT,call
from eb_layout import geometry

def selected(rows,names):
    return [(r['type'],r['name'],r['value']) for r in rows if r['name'] in names and 'value' in r]

def run():
    call('snapshot')
    targets=[w for w in json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8')) if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
    previous_pid=int(sys.argv[1]) if len(sys.argv)>1 else 31248
    if len(targets)!=1 or targets[0]['pid']==previous_pid:raise ValueError('Different reopened target process required')
    target=targets[0]
    def ui(q):call('uia',target['handle'],json.dumps(q,ensure_ascii=False))
    ui({'restore_target_window':True,'reviewed_size':True});ui({'open_target_page':16})
    inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
    names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==16)
    sample={'DW_0','DW_1','DW_2','DW_3','GP_0','TS_0','TS_6','NE_0','NE_3','ND_0','TX_0','TX_1'}
    report={'page':16,'previous_pid':previous_pid,'reopened_pid':target['pid'],'sample_only':True,'checks':[],'ok':False,'offline_simulation_verified':False}
    path=ROOT/'evidence/page-16-roundtrip-audit.json'
    for name in names:
        key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)[1]
        if key not in sample:continue
        q={'page':16,'object':name,'target_readonly':True}
        if key.startswith('DW'):q.update(colors=['颜色 :'],color_tab=' 形状')
        if key.startswith('TX'):q.update(colors=['颜色 :'],color_tab='文字/批注')
        ui({'extract':q})
        source=json.loads((ROOT/f'evidence/source-object-properties/016_{key}.json').read_text(encoding='utf8'))
        saved=json.loads((ROOT/f'evidence/target-object-properties/016_{key}.json').read_text(encoding='utf8'))
        actual={r['name']:r['value'] for r in saved['tabs']['轮廓'] if r['type']=='Edit' and r['name'] in geometry(source)}
        check={'object':key,'geometry_verified':geometry(source)==actual}
        if key.startswith(('TS','NE','ND')):
            keep={'读取/写入使用不同的地址','启用输入功能','设备 :','Static',' Down','模式 :','触发宏指令'}
            check['address_behavior_verified']=selected(source['tabs']['一般属性'],keep)==selected(saved['tabs']['一般属性'],keep)
        if key.startswith(('NE','ND')):
            keep={'资料格式 :','类型 :','小数点以上位数 :','小数点以下位数 :','设备下限 :','设备上限 :','输入下限 :','输入上限 :'}
            check['format_limits_verified']=selected(source['tabs']['格式'],keep)==selected(saved['tabs']['格式'],keep)
        if key.startswith(('DW','TX')):check['color_verified']=source['colors']==saved['colors']
        if key=='GP_0':
            texts=[r['name'] for r in saved['tabs']['图片'] if r['type']=='Text']
            check['image_metadata_verified']=all(t in texts for t in ('151','38','235bytes','PNG'))
            check['lowest_layer_verified']='(最下层)' in saved['object'] if '(最下层)' in saved['object'] else None
            # Extract uses the source inventory label; verify ordering via a fresh directory audit separately.
            check.pop('lowest_layer_verified')
        report['checks'].append(check);path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
        print(json.dumps(check,ensure_ascii=False),flush=True)
    report['ok']=len(report['checks'])==len(sample) and all(v for c in report['checks'] for k,v in c.items() if k.endswith('_verified'))
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    if not report['ok']:raise ValueError('Main-page roundtrip mismatch; inspect evidence')

if __name__=='__main__':run()
