import json
from pywinauto import Desktop
from eb_extract import ROOT
from eb_object_ui import properties,dialog,target
from eb_native_form import tab
from eb_native_messages import msg

def run(handle,q):
 page=q['vector_gallery_read']['page'];key='SP_0'
 if page not in (10,11):raise ValueError('Reviewed header vectors only')
 source=json.loads((ROOT/f'evidence/source-object-properties/{page:03d}_{key}.json').read_text(encoding='utf8'))
 root,w=target(handle,page)
 if q.get('resume_gallery'):
  d=dialog(root.process_id(),source['dialog_title'])
 else:
  d,name=properties(root,w,key,source['dialog_title']);tab(d,next(iter(source['tabs'])))
  buttons=[c for c in d.descendants(control_type='Button') if c.window_text()==chr(22270)+chr(24211)+'...' and c.is_visible()]
  if len(buttons)!=1:raise ValueError('One gallery button required')
  buttons[0].click_input()
 title=source['dialog_title'].split(chr(30340))[0]+chr(31649)+chr(29702)
 g=dialog(root.process_id(),title)
 entries=[]
 for c in g.descendants(cache_enable=True):
  e=c.element_info
  if e.control_type not in ('Group','MenuItem','TabItem') or not c.is_visible():continue
  v={'type':e.control_type,'name':e.name}
  try:v['selected']=bool(c.iface_selection_item.CurrentIsSelected)
  except Exception:pass
  try:v['legacy_state']=c.iface_legacy_iaccessible.CurrentState
  except Exception:pass
  entries.append(v)
 (ROOT/f'evidence/vector-gallery-{page}-metadata.json').write_text(json.dumps({'page':page,'entries':entries,'project_modified':False,'shape_identity_verified':False},ensure_ascii=False,indent=2),encoding='utf8')
 for win in (g,d):
  cs=[c for c in win.descendants(control_type='Button') if c.window_text()==chr(21462)+chr(28040) and c.is_visible()]
  if len(cs)!=1:raise ValueError('One gallery/property cancel required')
  msg(cs[0].handle,245)
