import json
from eb_rebuild_page import call,ROOT
req=json.loads((ROOT/'tools/request.json').read_text(encoding='utf8'))
resp=json.loads((ROOT/'evidence/response.json').read_text(encoding='utf8'))
assert req['id']==resp['id']
assert not (ROOT/'tools/batch.lock').exists()
call('uia',198514,json.dumps({'extract':{'page':26,'object':'BL_0 (DB13Bit-248.3)','keep_open':True}},ensure_ascii=False))
call('uia',198514,json.dumps({'page26_shapes':'source-gallery','page':26,'kind':'BL','n':0,'build_bit_general':0},ensure_ascii=False))
print('source BL0 gallery captured; original closed without saving')
