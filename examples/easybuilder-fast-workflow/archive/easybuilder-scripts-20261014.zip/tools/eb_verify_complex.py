"""Independently compare reviewed mixed-page source parameters with target readbacks."""
import json,re,sys
from eb_rebuild_page import ROOT
from eb_layout import geometry
def run(page):
    if page!=17:raise ValueError('Only reviewed mixed page17')
    inv=json.loads((ROOT/'evidence'/'source-pages-inventory.json').read_text(encoding='utf8'))
    names=next(p['observed_objects'] for p in inv['pages'] if p['id']==page)
    checks=[];pending=[]
    def values(rows,skip=(),rename=None,keep=None):
        result=[];rename=rename or {}
        for r in rows:
            if 'value' not in r or (r['type'],r['name']) in skip or (keep is not None and r['name'] not in keep):continue
            value=r['value']
            if r['name']=='字体 :' and isinstance(value,str):value=value.split(' [')[0]
            result.append((r['type'],rename.get(r['name'],r['name']),value))
        return result
    for name in names:
        key=re.search(r'(?:^|\])\s*([A-Z]+)_(\d+)',name);kind,n=key.groups()
        if kind in ('SW','BL'):continue
        path=ROOT/'evidence'/f'target-{page:03d}-{kind}{n}-built.json'
        if not path.exists():pending.append(kind+'_'+n);continue
        source=json.loads((ROOT/'evidence'/'source-object-properties'/f'{page:03d}_{kind}_{n}.json').read_text(encoding='utf8'))
        target=json.loads(path.read_text(encoding='utf8'));expected=geometry(source)
        actual={r['name']:r['value'] for r in target['geometry'] if r['type']=='Edit' and r['name'] in expected}
        c={'object':kind+'_'+n,'geometry_verified':expected==actual}
        if kind=='WP':
            keys={'描述 :','设备 :','Static',' Down','使用窗口编号偏移量'}
            c['general_verified']=values(source['tabs']['一般属性'],keep=keys)==values(target['general'],keep=keys)
        elif kind=='TS':
            c['general_verified']=values(source['tabs']['一般属性'])==values(target['general'])
            c['text_verified']=all(values(source['tabs']['标签'])==values(target['labels'][state],skip=(('ComboBox','状态 :'),)) for state in ('0','1'))
        elif kind=='DC':c['general_verified']=values(source['tabs']['一般属性'])==values(target['general'])
        elif kind=='TX':
            c['text_verified']=values(source['tabs']['文字/批注'],skip=(('CheckBox','使用字符串表'),),rename={'多行 :':'水平 :'})==values(target['text'])
        elif kind=='SP':
            c['picture_flags_verified']=values(source['tabs']['图片'])==values(target['picture'])
            c['colors_verified']=source['colors']==target['colors']
        elif kind=='AB':
            keep={'显示 Down','显示的类别范围','透明'}
            selected=[r for r in source['tabs']['报警'] if r['name'] in keep and r.get('value')!='跑马灯']
            c['alarm_verified']=values(selected)==values(target['tabs']['报警'],keep=keep)
            c['sort_verified']=values(source['tabs']['排序'],skip=(('ComboBox','日期 :'),))==values(target['tabs']['排序'],skip=(('ComboBox','日期 :'),))
            c['font_size_verified']=values(source['tabs']['字体'],keep={'尺寸 :','斜体'})==values(target['tabs']['字体'],keep={'尺寸 :','斜体'})
            c['colors_verified']=source['colors']==target['colors']
        else:raise ValueError('Complex audit requires separate rules: '+kind)
        checks.append(c)
    report={'page':page,'complex_objects':len(checks),'checks':checks,'pending':pending,'parameter_subset_ok':all(all(v for k,v in c.items() if k.endswith('_verified')) for c in checks),'whole_page_complete':False,'offline_simulation_verified':False}
    (ROOT/'evidence'/f'page-{page}-complex-parameter-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    if not report['parameter_subset_ok']:raise ValueError('Mixed-page parameter evidence mismatch')
    print(json.dumps({'page':page,'complex_objects':len(checks),'pending':pending,'ok':True}))
    return report
if __name__=='__main__':run(int(sys.argv[1]))
