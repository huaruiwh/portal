"""Offline dependency audit; never executes macro code."""
import json,re
from pathlib import Path
root=Path(__file__).resolve().parent.parent
rows=[]
for path in (root/'source'/'macros').glob('*.ebm'):
 code=path.read_text(encoding='utf-8-sig')
 mid=int(re.search(r'"id":\s*"(\d+)"',code)[1])
 metadata,body=code.split('macro_definition_end',1)
 calls=re.findall(r'\b(GetDataEx|SetDataEx|GetData|SetData)\s*\([^,]+,\s*"([^"]+)"\s*,\s*([^,]+),\s*([^,\r\n]+)',body)
 rows.append({'id':mid,'devices':sorted({c[1] for c in calls}),
  'address_types':sorted({c[2].strip() for c in calls}),
  'io_call_count':len(calls),'page_constants':re.findall(r'\bpage\s*=\s*(\d+)',body),
  'automatic_execution_enabled':bool(re.search(r'"(?:startup|periodic|interlock)"\s*:\s*(?:\[\s*)?"true"',metadata))})
report={'macro_count':len(rows),'devices':sorted({d for r in rows for d in r['devices']}),
 'io_call_count':sum(r['io_call_count'] for r in rows),
 'automatic_execution_ids':[r['id'] for r in rows if r['automatic_execution_enabled']],
 'macros':sorted(rows,key=lambda r:r['id'])}
(root/'evidence'/'original-macros-dependency-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in report.items() if k!='macros'},ensure_ascii=False))
