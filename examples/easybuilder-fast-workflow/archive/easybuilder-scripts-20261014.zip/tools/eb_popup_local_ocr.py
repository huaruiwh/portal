import json,subprocess
from PIL import ImageGrab
from pywinauto import Desktop
from eb_rebuild_page import ROOT

def observe(pid):
 ps=[w for w in Desktop(backend='win32').windows(process=pid) if w.is_visible() and w.class_name().startswith('Qt5QWindowPopup')]
 if len(ps)!=1:raise ValueError('One live Qt popup required')
 p=ps[0];r=p.rectangle();img=ROOT/'evidence/qt-popup-local.png';out=ROOT/'evidence/qt-popup-local-ocr.json'
 ImageGrab.grab(bbox=(r.left,r.top,r.right,r.bottom)).save(img)
 code=(ROOT/'tools/Read-LocalImageText.ps1').read_text(encoding='utf8').replace('param([string]$ImagePath,[string]$OutputPath)',"$ImagePath='"+str(img).replace("'","''")+"';$OutputPath='"+str(out).replace("'","''")+"'")
 result=subprocess.run([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe','-NoProfile','-Command',code],capture_output=True,text=True,timeout=30)
 if result.returncode:raise RuntimeError(result.stderr)
 return p,json.loads(out.read_text(encoding='utf-8-sig'))

def run(handle,q):
 w=Desktop(backend='win32').window(handle=handle).wrapper_object()
 observe(w.process_id())
