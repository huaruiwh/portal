"""One PLC configuration per request; source read-only, no action execution."""
import json,time,sys
from pathlib import Path
from eb_rebuild_page import call
ROOT=Path(__file__).resolve().parent.parent
lock=ROOT/'tools/batch.lock'
def main():
 with lock.open('x',encoding='utf8')as f:f.write(json.dumps({'task':'PLC control transfer','pid':__import__('os').getpid()}))
 try:
  call('snapshot')
  windows=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
  roots=[w for w in windows if w['class']=='EasyBuilderPro'and '组装机_MT8106iP.emtp'in w['title']]
  if len(roots)!=1:raise ValueError('Unique target project required')
  managers=[w for w in windows if w['pid']==roots[0]['pid']and w['title']=='PLC 控制'and w['class']=='#32770']
  if len(managers)!=1:raise ValueError('Unique observed PLC manager required')
  manager=managers[0]['handle']
  accepted=set(json.loads((ROOT/'evidence/plc-control-transfer-workflow.json').read_text(encoding='utf8'))['accepted'])
  for index in [i for i in range(1,70)if i not in accepted]:
   for attempt in range(3):
    started=time.monotonic()
    try:
     call('uia',manager,json.dumps({'plc_control_config':{'action':'import_target_batch','indices':[index]},'build_bit_general':0}))
     with (ROOT/'evidence/plc-control-timing.jsonl').open('a',encoding='utf8')as f:f.write(json.dumps({'index':index,'seconds':round(time.monotonic()-started,3),'attempt':attempt+1})+'\n')
     break
    except Exception as error:
     (ROOT/'evidence/plc-control-last-error.json').write_text(json.dumps({'index':index,'attempt':attempt+1,'error':str(error)},ensure_ascii=False,indent=2),encoding='utf8')
     if attempt==2:raise
     time.sleep(.3)
  call('uia',manager,json.dumps({'plc_control_config':{'action':'audit_target_manager'}}))
  print('69 definitions manager audit passed')
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':main()
