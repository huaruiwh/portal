import json,time,py_compile
from eb_rebuild_page import ROOT,call
for name in ('eb_page201_buttons.py','eb_page201_batch.py','eb_uia.py'):
    py_compile.compile(str(ROOT/'tools'/name),doraise=True)
lock=ROOT/'tools/batch.lock'
with lock.open('x',encoding='utf8') as f:f.write('page201 TS7 TS8 bounded batch')
t=time.perf_counter()
try:
    call('uia',10488686,json.dumps({'page201_batch':[7,8],'build_bit_general':0},ensure_ascii=False))
    p=ROOT/'evidence/page201-two-button-batch.json'
    d=json.loads(p.read_text(encoding='utf8'));d['controller_wall_seconds']=time.perf_counter()-t
    p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(d,ensure_ascii=False))
finally:lock.unlink()
