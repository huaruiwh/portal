"""Learn native control identities once; resolve fresh HWNDs in each dialog."""
import ctypes
from pywinauto import Desktop
from eb_native_messages import text,combo_text,msg
from eb_live_fields import capture as fallback_capture
U=ctypes.windll.user32

def class_name(h):
    buf=ctypes.create_unicode_buffer(256);U.GetClassNameW(h,buf,256);return buf.value

def fingerprint(h,root):
    result=[]
    while h and h!=root:
        result.append((class_name(h),U.GetDlgCtrlID(h)));h=U.GetParent(h)
    if h!=root:raise ValueError('Native field outside dialog')
    return result

def native_controls(root):
    result=[];callback=ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p)
    @callback
    def visit(h,_):
        if U.IsWindowVisible(h):result.append(int(h))
        return True
    U.EnumChildWindows(root,visit,0);return result

def learn(d,wants):
    wants=list(dict.fromkeys(wants));schema={'title':d.window_text(),'fields':[],'fallback':[]}
    classes={'Edit':('Edit','RichEdit20W','RichEdit20A'),'ComboBox':('ComboBox',),'CheckBox':('Button',),'RadioButton':('Button',)}
    for h in native_controls(d.handle):
        if not any(class_name(h)in classes.get(t,())for t,n in wants):continue
        c=Desktop(backend='uia').window(handle=h).wrapper_object();key=(c.element_info.control_type,c.element_info.name)
        if key in wants and U.GetDlgCtrlID(h)!=0:
            schema['fields'].append({'type':key[0],'name':key[1],'fingerprint':fingerprint(h,d.handle)})
    represented={(v['type'],v['name'])for v in schema['fields']}
    schema['fallback']=[list(key)for key in wants if key not in represented]
    schema['order']=[list(key)for key in wants]
    return schema

def resolve(d,schema):
    if d.window_text()!=schema['title']:raise ValueError('Native form title mismatch')
    handles=native_controls(d.handle);out={}
    # Restrict expensive parent/class queries to IDs learned from the live form.
    wanted_ids={row['fingerprint'][0][1]for row in schema['fields']}
    identities={h:fingerprint(h,d.handle)for h in handles if U.GetDlgCtrlID(h)in wanted_ids}
    for row in schema['fields']:
        fp=[tuple(v)for v in row['fingerprint']];matches=[h for h,v in identities.items()if v==fp]
        if len(matches)!=1:raise ValueError('Learned native control identity no longer unique '+str((row['type'],row['name'])))
        key=(row['type'],row['name'])
        if key in out:raise ValueError('Duplicate learned native field '+str(key))
        out[key]=matches[0]
    return out

def read(d,schema):
    refs=resolve(d,schema);out=[]
    for row in schema['fields']:
        h=refs[(row['type'],row['name'])];typ=row['type']
        value=text(h).rstrip('\r\n')if typ=='Edit'else combo_text(h)if typ=='ComboBox'else msg(h,240)
        out.append({'type':typ,'name':row['name'],'value':value})
    if schema['fallback']:out.extend(fallback_capture(d,[tuple(v)for v in schema['fallback']]))
    return [v for key in schema['order']for v in out if(v['type'],v['name'])==tuple(key)]

def write_edits(d,schema,rows,commit_edits=False,native_messages=False):
    """Only previously learned native Edit fields; all other rows retain old route."""
    import re
    from pywinauto.controls.win32_controls import EditWrapper
    from pywinauto.keyboard import send_keys
    refs=resolve(d,schema);remaining=[]
    for row in rows:
        key=(row['type'],row['name'])
        if row['type']!='Edit' or key not in refs or 'value'not in row:
            remaining.append(row);continue
        h=refs[key];value=str(row['value']);current=text(h).rstrip('\r\n')
        if current==value:continue
        if not U.IsWindowEnabled(h):raise ValueError('Different native value on disabled edit')
        if commit_edits:
            edit=EditWrapper(h)
            if not re.fullmatch(r'[0-9.]+',value):raise ValueError('Native keyboard fast path only for numeric address')
            d.set_focus();edit.set_focus();send_keys('^a'+value+'{TAB}',pause=.01)
        elif native_messages:
            # Same EM_SETSEL/EM_REPLACESEL route as EditWrapper, bounded messages.
            # Unlike WM_SETTEXT, EM_REPLACESEL emits the edit's change notifications.
            b=ctypes.create_unicode_buffer(value)
            msg(h,177,0,-1);msg(h,194,1,ctypes.cast(b,ctypes.c_void_p).value)
        else:EditWrapper(h).set_edit_text(value)
        import time
        for _ in range(20):
            if text(h).rstrip('\r\n')==value:break
            time.sleep(.03)
        else:raise ValueError('Learned native edit readback mismatch: '+repr((value,text(h))))
    return remaining
