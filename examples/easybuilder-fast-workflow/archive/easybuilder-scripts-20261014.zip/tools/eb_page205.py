"""Single-control native203 templates for the different-layout205 page."""
import json,time,re
from pathlib import Path
from pywinauto.keyboard import send_keys
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save
from eb_native_form import tab,fields,confirm,commit_text,typed_children
from eb_page26_shapes import cancel
from eb_layout import geometry
from eb_live_fields import capture
from eb_original_style_existing import verify_fields
from eb_copy_200_style_object import native_clipboard_data,restore_native_clipboard,read_audit
from eb_open_page import run as open_page
from eb_page203_rewrite import plan,TITLES

def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')

def template(source):
 kind=re.search(r'(?:^|\])\s*([A-Z]+)_\d+',source['object'])[1];candidates=[]
 for p in sorted((ROOT/'evidence/source-object-properties').glob(f'203_{kind}_*.json')):
  b=json.loads(p.read_text(encoding='utf8'));edits,unknown=plan(source,b)
  binding=[u for u in unknown if u['scope']=='一般属性'and u['identity']in [('ComboBox',' Down'),('ComboBox','设备 :')]]
  unknown=[u for u in unknown if u not in binding]
  reviewed=[]
  sourcekey=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',source['object'])[1]
  for u in list(unknown):
   ident=u['identity'];scope=u['scope']
   allowed=(sourcekey in ('OL_1','OL_2')and scope=='状态设置'and ident[0]=='Edit'and re.fullmatch(r'Row \d+, Column [123]',ident[1]))or(sourcekey=='OL_2'and scope=='源数据'and ident==('ComboBox','预设 Down')and u['after']==['5'])or(sourcekey in ('TS_17','TS_18')and scope=='安全'and ident==('ComboBox',' Down')and u['before']==['1']and u['after']==['0.1'])or(sourcekey=='SW_0'and scope=='图片'and ident==('CheckBox','调整对象尺寸为图片原尺寸')and u['after']==[0])
   if allowed:
    reviewed.append({'scope':scope,'state':None,'rows':[r for r in source['tabs'][scope]if (r['type'],r['name'])==ident]});unknown.remove(u)
  if unknown:continue
  # Increase item count before editing the generated option table cells.
  edits=sorted(reviewed,key=lambda e:0 if e['scope']=='源数据'else 1)+edits
  for u in binding:edits.insert(0,{'scope':u['scope'],'state':None,'rows':[r for r in source['tabs'][u['scope']]if (r['type'],r['name'])==u['identity']]})
  candidates.append((len(binding),len(edits),int(p.stem.rsplit('_',1)[1]),p,b,edits))
 if not candidates:raise ValueError('No203 template with matching original205 safety/behavior: '+source['object'])
 _,_,_,p,b,edits=min(candidates,key=lambda x:x[:3]);return p.stem.split('_',1)[1],b,edits

def run(handle,q):
 if q.get('page205_safety_probe'):
  root,w=target(handle,205);d,_=properties(root,w,'TS_17',TITLES['TS'])
  try:
   tab(d,'安全');cs=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name==' Down'and c.is_visible()]
   out=[]
   for c in cs:
    children=[]
    for v in c.descendants():
     e=v.element_info;item={'type':e.control_type,'name':e.name,'class':e.class_name,'handle':e.handle,'rect':str(v.rectangle())}
     if e.control_type=='Edit':item['value']=v.get_value()
     children.append(item)
    out.append({'value':c.selected_text(),'rect':str(c.rectangle()),'children':children})
   write(ROOT/'evidence/page205-safety-probe.json',out)
  finally:cancel(d)
  return
 if q.get('page205_count_probe'):
  from pywinauto import Desktop,mouse
  from eb_color_picker import native_window_handles
  root,w=target(handle,205);d,_=properties(root,w,'OL_2',TITLES['OL'])
  try:
   tab(d,'源数据');cs=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name=='预设 Down'and c.is_visible()]
   if len(cs)!=1:raise ValueError('Unique count probe')
   c=cs[0];r=c.rectangle();out={'class':c.element_info.class_name,'handle':c.handle,'value':c.selected_text(),'rect':[r.left,r.top,r.right,r.bottom]}
   mouse.click(coords=(r.right-10,(r.top+r.bottom)//2));time.sleep(.2)
   out['items']=[{'name':v.element_info.name,'type':v.element_info.control_type,'rect':str(v.rectangle()),'visible':v.is_visible()}for v in c.descendants()if v.element_info.control_type=='ListItem'][:12]
   out['windows']=[{'title':v.window_text(),'class':v.class_name(),'rect':str(v.rectangle())}for h in native_window_handles(d.process_id())for v in [Desktop(backend='win32').window(handle=h).wrapper_object()]]
   write(ROOT/'evidence/page205-count-probe.json',out)
  finally:
   import ctypes
   if ctypes.windll.user32.IsWindowVisible(d.handle):cancel(d)
  return
 keys=q['page205_controls']
 if all((ROOT/f'evidence/target-205-{key}-built.json').exists()and json.loads((ROOT/f'evidence/target-205-{key}-built.json').read_text(encoding='utf8')).get('saved_reopened_verified')for key in keys):return
 if not keys or len(keys)>4:raise ValueError('Reviewed205 batch up to4')
 if not json.loads((ROOT/'evidence/page203-rewrite-workflow.json').read_text(encoding='utf8'))['finished']:raise ValueError('Completed203 required')
 inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));observed=[re.search(r'(?:^|\])\s*([A-Z]+_\d+)',s)[1]for s in next(x['observed_objects']for x in inv['pages']if x['id']==205)]
 if not set(keys)<=set(observed)or len(observed)!=87:raise ValueError('Unobserved205 key')
 open_page(handle,{'open_target_page':205})
 # One initial audit per batch, not per individual object.
 actual=read_audit(handle,205);actualkeys={re.search(r'(?:^|\])\s*([A-Z]+_\d+)',n)[1]for n in actual['objects']}
 if actual['unexpected']:raise ValueError('Unexpected205 objects')
 for key in keys:
  rp=ROOT/f'evidence/target-205-{key}-built.json';phase=ROOT/f'evidence/target-205-{key}-copy-phase.json'
  if rp.exists()and json.loads(rp.read_text(encoding='utf8')).get('saved_reopened_verified'):continue
  source=json.loads((ROOT/f'evidence/source-object-properties/205_{key}.json').read_text(encoding='utf8'));basekey,b,edits=template(source);kind,n=key.split('_');n=int(n);g=geometry(source)
  if phase.exists():
   state=json.loads(phase.read_text(encoding='utf8'))
   if state['stage']not in ('pasted','saved-unverified')or key not in actualkeys:raise ValueError('Unknown205 paste phase; inspect, do not repeat: '+key)
   if state['template']!=basekey:raise ValueError('205 recovery template differs')
  else:
   if key in actualkeys:raise ValueError('Existing205 without report; no paste')
   samekind={int(k.split('_')[1])for k in actualkeys if k.startswith(kind+'_')}
   if samekind!=set(range(n)):raise ValueError('Sequential205 destination numbering required '+key)
   cp=ROOT/f'evidence/native203-template-{basekey}-{handle}.bin'
   if cp.exists():data=cp.read_bytes()
   else:
    open_page(handle,{'open_target_page':203});root,w=target(handle,203);d,_=properties(root,w,basekey,TITLES[kind]);cancel(d);root.set_focus();send_keys('^c',pause=.04);time.sleep(.15);data=native_clipboard_data();cp.write_bytes(data)
   open_page(handle,{'open_target_page':205});root,w=target(handle,205);restore_native_clipboard(data);root.click_input(coords=(963,367))
   write(phase,{'page':205,'key':key,'template_page':203,'template':basekey,'stage':'paste-requested'})
   send_keys('^v',pause=.04);time.sleep(.2);root.click_input(coords=(963,367));send_keys('{ESC}',pause=.02)
   # Resolve exact new property identity; do not perform another full-page scan.
   write(phase,{'page':205,'key':key,'template_page':203,'template':basekey,'stage':'pasted'})
  root,w=target(handle,205);d,_=properties(root,w,key,TITLES[kind])
  try:
   for e in edits:
    tab(d,e['scope'])
    if e['state']is not None:
     cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']
     if len(cs)!=1:raise ValueError('Unique205 label state required')
     ComboBoxWrapper(cs[0].handle).select(e['state']);time.sleep(.08)
    rs=e['rows']
    if e['scope']in ('文字/批注','标签'):commit_text(d,rs[0]['name'],rs[0]['value'])
    elif (e['scope']=='源数据'and rs[0]['name']=='预设 Down')or(e['scope']=='安全'and rs[0]['type']=='ComboBox'and rs[0]['name']==' Down'):
     cs=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name==rs[0]['name']and c.is_visible()]
     if len(cs)!=1:raise ValueError('Unique205 option item count required')
     c=cs[0];want=str(rs[0]['value'])
     if c.selected_text()!=want:
      from pywinauto import mouse,Desktop
      from eb_color_picker import native_window_handles
      r=c.rectangle();mouse.click(coords=(r.right-10,(r.top+r.bottom)//2));time.sleep(.2)
      items=[];pops=[]
      for _ in range(20):
       pops=native_window_handles(d.process_id(),class_prefix='Qt5QWindowPopup')
       fresh=[v for v in d.descendants(control_type='ComboBox')if v.element_info.name==rs[0]['name']and v.is_visible()]
       items=[v for v in fresh[0].descendants(control_type='ListItem')if v.element_info.name==want]if len(fresh)==1 else []
       if len(items)==len(pops)==1:break
       time.sleep(.05)
      if len(items)!=1 or len(pops)!=1:raise ValueError('Unique205 physical count popup/item required')
      item=items[0];ir=item.rectangle();pr=Desktop(backend='win32').window(handle=pops[0]).rectangle()
      write(ROOT/f'evidence/page205-combo-selection-{key}.json',{'scope':e['scope'],'name':rs[0]['name'],'wanted':want,'before':c.selected_text(),'item_rect':[ir.left,ir.top,ir.right,ir.bottom],'popup_rect':[pr.left,pr.top,pr.right,pr.bottom],'reported_visible':item.is_visible()})
      if not(pr.left<=ir.left<ir.right<=pr.right and pr.top<=ir.top<ir.bottom<=pr.bottom):raise ValueError('205 count item outside observed popup')
      mouse.click(coords=((ir.left+ir.right)//2,(ir.top+ir.bottom)//2));time.sleep(.2);send_keys('{TAB}',pause=.01)
     if c.selected_text()!=want:raise ValueError('205 option count readback failed')
    else:fields(d,rs,commit_edits=True)
   tab(d,'轮廓');fields(d,[{'type':'Edit','name':k,'value':v}for k,v in g.items()],commit_edits=True);confirm(d);d=None;save(root)
  finally:
   if d is not None:cancel(d)
  report={'page':205,'key':key,'template_page':203,'template':basekey,'geometry':g,'edits':edits,'source_safety_equal_to_template':not any(e['scope']=='安全'for e in edits),'reviewed_safety_changes':[e for e in edits if e['scope']=='安全'],'font_style_from203':True,'saved_reopened_verified':False,'runtime_verified':False}
  write(rp,report);state=json.loads(phase.read_text(encoding='utf8'));state['stage']='saved-unverified';write(phase,state)
  d,_=properties(root,w,key,TITLES[kind])
  try:
   for e in edits:
    tab(d,e['scope'])
    if e['state']is not None:
     cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :'];ComboBoxWrapper(cs[0].handle).select(e['state']);time.sleep(.08)
    verify_fields(capture(d,[(r['type'],r['name'])for r in e['rows']]),e['rows'])
   tab(d,'轮廓');actualg={r['name']:r['value']for r in capture(d,[('Edit',k)for k in g])}
   if actualg!=g:raise ValueError('205 saved geometry differs '+key)
  finally:cancel(d)
  report.update(saved_reopened_verified=True,original_text_preserved=True);write(rp,report);state['stage']='verified';write(phase,state);actualkeys.add(key)
