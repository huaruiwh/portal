"""Preserve page17's 0.1-second minimum press, without enabling user restrictions."""
from pywinauto.controls.win32_controls import ButtonWrapper,ComboBoxWrapper
def apply(d,source):
    if source['page'] not in (11,16,17,*range(26,46),47):return
    expected=[c for c in source['tabs']['安全'] if c['type']=='CheckBox' and c['name']=='最短按压时间']
    if not expected:return # Passive lamps expose no minimum-press option.
    tab=[c for c in d.descendants(control_type='TabItem') if c.window_text()=='安全' and c.is_visible()]
    if len(tab)!=1:raise ValueError('Unique safety tab required')
    tab[0].select()
    if len(expected)!=1:raise ValueError('Source press duration flag missing')
    controls=[c for c in d.descendants(control_type='CheckBox') if c.window_text()=='最短按压时间' and c.is_visible()]
    if len(controls)!=1:raise ValueError('Target press duration flag missing')
    c=controls[0]
    if c.element_info.handle:
        button=ButtonWrapper(c.element_info.handle)
        if button.get_check_state()!=expected[0]['value']:button.send_message_timeout(0x00F5,timeout=2)
        actual=button.get_check_state()
    else:
        if c.get_toggle_state()!=expected[0]['value']:c.toggle()
        actual=c.get_toggle_state()
    if actual!=expected[0]['value']:raise ValueError('Minimum press checkbox mismatch')
    if expected[0]['value']:
        durations=[r['value'] for r in source['tabs']['安全'] if r['type']=='ComboBox' and r['name']==' Down']
        if len(durations)!=1:raise ValueError('Exact source minimum press duration required')
        duration=durations[0]
        combos=[c for c in d.descendants(control_type='ComboBox') if c.window_text()==' Down' and c.is_visible()]
        if len(combos)!=1:raise ValueError('Unique minimum press duration required')
        c=combos[0]
        if c.element_info.class_name=='ComboBox':
            native=ComboBoxWrapper(c.element_info.handle)
            if native.selected_text()!=duration:native.select(duration)
            actual=native.selected_text()
        else:
            actual=c.selected_text()
            if actual!=duration:
                c.select(duration);actual=c.selected_text()
        if actual!=duration:raise ValueError('Minimum press duration mismatch')
