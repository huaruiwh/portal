"""Read page-218 numeric objects field by field and compare with the original/build evidence.

Read-only: no property is written. Usage: python tools/diagnose218.py
"""
import json,sys,os,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'tools'))
from eb_rebuild_page import call

PAGE=218
TGT_TITLE='组装机_MT8106iP.emtp'
KEYS=['NE_%d'%i for i in range(9)]
REPORT=ROOT/'evidence/page218-numeric-diagnosis.json'

def load(p):return json.loads(p.read_text(encoding='utf-8'))
def windows():
    call('snapshot')
    for _ in range(30):
        try:return [w for w in load(ROOT/'evidence/windows.json') if w.get('title')]
        except Exception:time.sleep(.1)
    raise ValueError('windows.json unreadable')

def rows_of(tabs,scope):
    out={}
    for r in tabs.get(scope,[]):
        if 'value' in r:out.setdefault(r['name'],[]).append(r['value'])
    return out

def main():
    lock=ROOT/'tools/batch.lock'
    with lock.open('x',encoding='utf8') as fh:fh.write(json.dumps({'pid':os.getpid(),'task':'diagnose218'},ensure_ascii=False))
    out=None
    try:
        out={'page':PAGE,'read':{},'diffs':{},'finished':False}
        m=[w for w in windows() if TGT_TITLE in w['title']]
        if len(m)!=1:raise ValueError('Unique target required')
        h=m[0]['handle']
        for i in range(0,len(KEYS),3):
            batch=KEYS[i:i+3]
            call('uia',h,json.dumps({'move_objects':{'page':PAGE,'op':'read','items':[{'key':k,'fields':{}} for k in batch]}}))
            for k in batch:
                f=ROOT/'evidence'/('move-objects-%d-verify-%s.json'%(PAGE,k))
                # read op writes the same evidence path as verify; collect from the module evidence dir
                for cand in sorted((ROOT/'evidence').glob('move-objects-218-*.json'),key=lambda p:p.stat().st_mtime,reverse=True):
                    j=load(cand)
                    if j.get('op')=='read':
                        for it in j.get('items',[]):
                            if it['key']==k:out['read'][k]=it['tabs']
            print(json.dumps({'read':sorted(out['read'].keys())},ensure_ascii=False),flush=True)
        # compare key fields with the original cache and the build report
        for k in out['read']:
            tabs=out['read'][k]
            cur={'一般属性':rows_of(tabs,'一般属性'),'格式':rows_of(tabs,'格式'),'数值输入':rows_of(tabs,'数值输入'),
                 '字体':rows_of(tabs,'字体'),'轮廓':rows_of(tabs,'轮廓'),'标签':rows_of(tabs,'标签'),'图片':rows_of(tabs,'图片')}
            src=load(ROOT/'evidence/source-object-properties'/('%d_%s.json'%(PAGE,k)))
            srows={s:rows_of(src['tabs'],s) for s in ('一般属性','格式','数值输入','字体','轮廓')}
            d={}
            for scope in ('一般属性','格式','数值输入','字体','轮廓'):
                for name in set(list(cur[scope])+list(srows.get(scope,{}))):
                    a=cur[scope].get(name); b=srows.get(scope,{}).get(name)
                    if a!=b:d.setdefault(scope,{})[name]={'now':a,'original':b}
            out['diffs'][k]=d
        REPORT.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
        for k in KEYS:
            if k not in out['diffs']:continue
            d=out['diffs'][k]
            summary=[]
            for scope,fields in d.items():
                for name,v in fields.items():
                    summary.append('%s/%s: 现在=%s 原件=%s'%(scope,name,v['now'],v['original']))
            print(json.dumps({'key':k,'diff_count':len(summary),'diffs':summary[:6]},ensure_ascii=False),flush=True)
        out['finished']=True
        REPORT.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
    except Exception as e:
        out=(out or {});out['error']=traceback.format_exc()
        REPORT.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
        print(json.dumps({'error':str(e)[:400]},ensure_ascii=False),flush=True)
        raise
    finally:
        lock.unlink(missing_ok=True)

if __name__=='__main__':main()
