"""One UIA metadata cache per visible tab; native values remain freshly read."""
from eb_uia_inventory import descendants
from eb_native_messages import text,combo_text,msg

def bind(d,wants):
    wants=list(dict.fromkeys(wants));found={}
    for c in descendants(d):
        e=c.element_info;key=(e.control_type,e.name)
        if key in wants and e.visible:found.setdefault(key,[]).append(c)
    for key in wants:
        if key not in found:raise ValueError('Required cached field absent '+str(key))
    return [(key,c)for key in wants for c in found[key]]

def read(refs):
    out=[]
    for (typ,name),c in refs:
        e=c.element_info;h=e.handle;cls=e.class_name
        if h and typ=='Edit'and cls in ('Edit','RichEdit20W','RichEdit20A'):value=text(h).rstrip('\r\n')
        elif h and typ=='ComboBox'and cls=='ComboBox':value=combo_text(h)
        elif h and typ in ('CheckBox','RadioButton')and cls=='Button':value=msg(h,240)
        else:value=c.get_value().rstrip('\r\n')if typ=='Edit'else c.selected_text()if typ=='ComboBox'else c.get_toggle_state()if typ=='CheckBox'else int(c.is_selected())
        out.append({'type':typ,'name':name,'value':value})
    return out

def capture(d,wants):return read(bind(d,wants))
