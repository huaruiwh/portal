"""Finish minimum-height spacing, compile the actual saved target, archive."""
import json,os
from datetime import datetime
from continue_scale_post200 import ROOT,DIR,load,put,archive
from eb_rebuild_page import call
def main():
 lock=ROOT/'tools/batch.lock'
 with lock.open('x',encoding='utf8')as f:f.write(json.dumps({'pid':os.getpid(),'task':'layout-scale-finalize'}))
 wp=DIR/'workflow.json';out=load(wp)
 try:
  pages=[load(DIR/f'page-{p}.json')for p in out['scope']]
  if not all(p['page_size_verified']and len(p['verified'])==len(p['keys'])for p in pages):raise ValueError('Page adaptation incomplete')
  for p in (200,202):
   if not load(DIR/f'table-grid-{p}.json')['verified']:raise ValueError('Table visual grid pending')
   t=load(DIR/f'{p}_TB_0.json')
   if not t.get('table_count_repair_verified')or t['table_before']!=t['table_after']:raise ValueError('Table counts not preserved')
  call('snapshot');ts=[w for w in load(ROOT/'evidence/windows.json')if '组装机_MT8106iP.emtp'in w['title']and w['class']=='EasyBuilderPro']
  if len(ts)!=1:raise ValueError('Unique live target required')
  h=ts[0]['handle'];call('uia',h,json.dumps({'scale_post200':{'page':204,'mode':'lamp_overlap'},'build_bit_general':0}))
  records=[]
  for p in pages:
   for k in p['keys']:
    r=load(DIR/f"{p['page']}_{k}.json");g=r['after']
    if not r['verified']:raise ValueError('Unverified geometry '+k)
    if any(int(g[pos])<0 or int(g[pos])+int(g.get(size,'0'))>limit for pos,size,limit in [('X :',' 宽度 :',890),(' Y :','高度 :',469)]):raise ValueError('Outside page '+k)
    records.append(r)
  call('uia',h,json.dumps({'compile_target':True}));out['compile']=load(ROOT/'evidence/latest-project-compile.json')
  if not out['compile']['ok']or not out['compile']['output_updated']:raise ValueError('Latest real compile did not pass')
  call('uia',h,json.dumps({'open_target_page':200}));call('snapshot')
  out.update({'finished':True,'finished_at':datetime.now().isoformat(timespec='seconds'),'total_pages':len(pages),'total_verified_objects':len(records),'all_page_dimensions_verified':True,'all_directory_counts_verified':True,'all_bounds_verified':True,'table_grid_verified_pages':[200,202],'native_minimum_controls':[str(r['page'])+':'+r['key']for r in records if'native_minimum_bounds'in r],'minimum_height_gap_adjustments':[{'page':r['page'],'key':r['key'],**r['minimum_height_gap_adjustment']}for r in records if'minimum_height_gap_adjustment'in r],'runtime_verified':False,'review_page':200})
  out.pop('error',None);put(wp,out);archive(out)
  print(json.dumps({'pages':out['total_pages'],'objects':out['total_verified_objects'],'compile':out['compile']['messages'],'native_minimum_controls':len(out['native_minimum_controls']),'gap_adjustments':len(out['minimum_height_gap_adjustments'])}),flush=True)
 except Exception as e:out['finished']=False;out['finalized']=False;out['finalize_error']=str(e);put(wp,out);archive(out);raise
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':main()
