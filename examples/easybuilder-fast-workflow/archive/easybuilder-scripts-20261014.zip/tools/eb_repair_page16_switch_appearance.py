"""Repair existing TS0..10 from the original, without creating any object."""
import json,re
from eb_rebuild_page import ROOT,call

def run():
 lock=ROOT/'tools/batch.lock'
 with lock.open('x'):pass
 path=ROOT/'evidence/page16-switch-appearance-workflow.json';r={'page':16,'completed':[],'ok':False,'creates_objects':False}
 def persist():path.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
 try:
  call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
  def handle(t):
   cs=[w['handle'] for w in ws if w['class']=='EasyBuilderPro' and t in w['title']]
   if len(cs)!=1:raise ValueError('One exact project required')
   return cs[0]
  sh=handle('组装机2台15工位取消.cmtp');th=handle('组装机_MT8106iP.emtp')
  def ui(h,q):return call('uia',h,json.dumps(q,ensure_ascii=False))
  ui(th,{'target_page_audit':16})
  inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(v['observed_objects'] for v in inv['pages'] if v['id']==16)
  for n in range(11):
   key=f'TS_{n}';r.update(stage=key,phase='source');persist()
   saved=ROOT/f'evidence/target-016-TS{n}-appearance-repaired.json'
   if saved.exists():
    old=json.loads(saved.read_text(encoding='utf8'))
    if not old.get('saved_requested'):raise ValueError('Unfinished repair report')
    r['completed'].append(key);persist();continue
   name=next(s for s in names if re.search(r'(?:^|\])\s*'+key+r'(?:\s|$)',s));cache=ROOT/f'evidence/source-object-properties/016_{key}.json';s=json.loads(cache.read_text(encoding='utf8'))
   if any(v['name']=='使用文字标签' and v.get('value')==1 for v in s['tabs']['标签']):
    if set(s.get('state_colors',{}).get('标签',{}))!={'0','1'}:ui(sh,{'extract':{'page':16,'object':name,'only_color':True,'state_color_probe':{'tab':'标签','state':'0','labels':['颜色 :']}}})
   r['phase']='repair-existing';persist();ui(th,{'page':16,'bit_kind':'TS','build_bit_general':n,'repair_source_appearance':True})
   r['completed'].append(key);persist()
  ui(th,{'target_page_audit':16});r.update(ok=True,phase='saved-and-directory-audited');persist();print(json.dumps(r,ensure_ascii=False))
 except Exception as e:r['error']=str(e);persist();raise
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':run()
