"""Observe editor-only PLC-control configuration. Never execute PLC actions."""
import json,time,ctypes,subprocess
from pathlib import Path
from pywinauto import Desktop,mouse
from PIL import ImageGrab
ROOT=Path(__file__).resolve().parent.parent

def run(handle,q):
 action=q['plc_control_config']['action']
 if action in ('accept_target_definition','import_target_batch','audit_target_manager','verify_saved_definition'):
  from collections import Counter
  from eb_color_picker import native_window_handles
  from eb_extract import rows
  from eb_live_inventory import clear
  from eb_page26_shapes import cancel
  manager_handle=int(q['plc_control_config'].get('manager',handle))
  manager=Desktop(backend='win32').window(handle=manager_handle).wrapper_object()
  roots=[w for w in Desktop(backend='win32').windows()if w.process_id()==manager.process_id()and '组装机_MT8106iP.emtp'in w.window_text()]
  if len(roots)!=1 or manager.window_text()!='PLC 控制':raise ValueError('Known target manager required')
  lists=manager.descendants(class_name='ListBox')
  if len(lists)!=1:raise ValueError('Unique target manager list required')
  control=lists[0]
  source_labels=[r['name']for r in json.loads((ROOT/'evidence/plc-control-source-manager.json').read_text(encoding='utf8'))if r['type']=='ListItem'][1:]
  source_labels=[str(i+1)+' :\t'+label.split('\t',1)[1]for i,label in enumerate(source_labels)]
  if len(source_labels)!=69:raise ValueError('Complete source manager inventory required')
  workflow_file=ROOT/'evidence/plc-control-transfer-workflow.json'
  workflow=json.loads(workflow_file.read_text(encoding='utf8'))if workflow_file.exists()else {'expected':69,'excluded_source_indices':[0],'accepted':[],'finished':False}
  def persist():workflow_file.write_text(json.dumps(workflow,ensure_ascii=False,indent=2),encoding='utf8')
  def check_definition(dialog,index,actual=None):
   if actual is None:actual=rows(dialog)
   expected=json.loads((ROOT/f'evidence/plc-control-source-{index+1:03d}.json').read_text(encoding='utf8'))['rows']
   fields=lambda rs:Counter((r['type'],r['name'],str(r['value']))for r in rs if 'value'in r)
   missing=fields(expected)-fields(actual)
   if missing:raise ValueError('PLC definition mismatch '+str(index)+': '+repr(missing))
   return actual
  def accept(dialog,index,actual=None):
   actual=check_definition(dialog,index,actual)
   record={'index':index,'rows':actual,'property_session_verified':True,'saved':False,'saved_reopened_verified':False}
   path=ROOT/f'evidence/plc-control-target-{index+1:03d}.json'
   path.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf8')
   workflow.update({'current_index':index,'phase':'confirm_requested'});persist()
   native=Desktop(backend='win32').window(handle=dialog.handle).wrapper_object()
   ok=[c for c in native.descendants(class_name='Button')if c.window_text()=='确定'and c.is_visible()]
   if len(ok)!=1:raise ValueError('Exact target definition OK required')
   ok[0].click_input();time.sleep(.15)
   if ctypes.windll.user32.IsWindow(dialog.handle)and ctypes.windll.user32.IsWindowVisible(dialog.handle):raise ValueError('Definition did not close; inspect validation')
   labels=control.item_texts()
   if labels!=source_labels[:index]:raise ValueError('Saved target manager labels differ from source order: '+repr(labels[-2:]))
   record['manager_confirmed']=True;path.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf8')
   if index not in workflow['accepted']:workflow['accepted'].append(index)
   workflow.update({'phase':'manager_confirmed','current_index':index});persist()
  if action=='accept_target_definition':
   accept(Desktop(backend='uia').window(handle=handle).wrapper_object(),int(q['plc_control_config']['index']));return
  if action=='verify_saved_definition':
   index=int(q['plc_control_config']['index'])
   labels=control.item_texts()
   if labels!=source_labels[:len(labels)]or index>len(labels):raise ValueError('Actual saved row order must match')
   props=[h for h in native_window_handles(manager.process_id(),title_match='PLC 控制')if h!=manager_handle]
   if not props:
    manager.set_focus()
    if not control.is_single_selection():control.send_message_timeout(0x0185,0,-1,timeout=2)
    control.select(index-1);control.set_item_focus(index-1)
    if list(control.selected_indices())!=[index-1]:raise ValueError('Saved definition list selection did not move to requested index')
    buttons=[b for b in manager.descendants(class_name='Button')if b.window_text()=='设置...']
    if len(buttons)!=1:raise ValueError('Unique settings required')
    buttons[0].click_input()
   for _ in range(25):
    props=[h for h in native_window_handles(manager.process_id(),title_match='PLC 控制')if h!=manager_handle]
    if len(props)==1:break
    time.sleep(.1)
   if len(props)!=1:raise ValueError('Unique saved definition required')
   dialog=Desktop(backend='uia').window(handle=props[0]).wrapper_object()
   try:actual=check_definition(dialog,index)
   finally:cancel(dialog)
   record={'index':index,'rows':actual,'property_session_verified':True,'manager_confirmed':True,'saved':bool(workflow.get('project_saved')),'saved_reopened_verified':True}
   (ROOT/f'evidence/plc-control-target-{index+1:03d}.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf8')
   if index not in workflow['accepted']:workflow['accepted'].append(index)
   workflow.update({'phase':'manager_confirmed','current_index':index});persist();return
  if action=='audit_target_manager':
   labels=control.item_texts()
   if labels!=source_labels:raise ValueError('Complete PLC list mismatch')
   (ROOT/'evidence/plc-control-target-manager-audit.json').write_text(json.dumps({'count':len(labels),'labels':labels,'matches_source_without_sound':True},ensure_ascii=False,indent=2),encoding='utf8');return
  for index in q['plc_control_config']['indices']:
   labels=control.item_texts()
   if labels!=source_labels[:len(labels)]:raise ValueError('Existing target rows differ; do not append')
   if index<=len(labels):
    if index not in workflow['accepted']:run(manager_handle,{'plc_control_config':{'action':'verify_saved_definition','index':index}})
    continue
   if index!=len(labels)+1:raise ValueError('Serial source order required')
   existing=[h for h in native_window_handles(manager.process_id(),title_match='PLC 控制')if h!=manager_handle]
   if existing:
    if len(existing)!=1 or workflow.get('current_index')!=index or workflow.get('phase')!='editing':raise ValueError('Unknown existing dialog; inspect before editing')
   else:
    workflow.update({'current_index':index,'phase':'add_requested'});persist()
    manager.set_focus();buttons=[b for b in manager.descendants(class_name='Button')if b.window_text()=='新增...']
    if len(buttons)!=1:raise ValueError('Unique add configuration required')
    buttons[0].click_input()
   props=[]
   for _ in range(20):
    props=[h for h in native_window_handles(manager.process_id(),title_match='PLC 控制')if h!=manager_handle]
    if len(props)==1:break
    time.sleep(.1)
   if len(props)!=1:raise ValueError('Unique new configuration dialog required')
   dialog=Desktop(backend='uia').window(handle=props[0]).wrapper_object()
   workflow.update({'phase':'editing','dialog':props[0]});persist()
   actual=run(props[0],{'plc_control_config':{'action':'configure_target_definition','index':index}})
   accept(dialog,index,actual)
  return
 if action=='save_target_project':
  manager=Desktop(backend='win32').window(handle=handle).wrapper_object()
  roots=[w for w in Desktop(backend='win32').windows()if w.process_id()==manager.process_id()and '组装机_MT8106iP.emtp'in w.window_text()]
  if len(roots)!=1 or manager.window_text()!='PLC 控制':raise ValueError('Known target PLC manager required')
  run(handle,{'plc_control_config':{'action':'audit_target_manager'}})
  close=[c for c in manager.descendants(class_name='Button')if c.window_text()=='关闭'and c.is_visible()]
  if len(close)!=1:raise ValueError('Exact manager Close required')
  project=ROOT/'output/组装机_MT8106iP.emtp';before=project.stat().st_mtime_ns
  close[0].click_input()
  for _ in range(25):
   if roots[0].is_enabled():break
   time.sleep(.1)
  from eb_object_ui import save
  save(roots[0])
  for _ in range(80):
   if project.stat().st_mtime_ns!=before:break
   time.sleep(.1)
  else:raise ValueError('Project save timestamp did not change; inspect before claiming persistence')
  data={'saved':True,'bytes':project.stat().st_size,'mtime_ns':project.stat().st_mtime_ns,'manager_count':69,'sound_excluded':True}
  (ROOT/'evidence/plc-control-project-save.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
  for index in range(1,70):
   file=ROOT/f'evidence/plc-control-target-{index+1:03d}.json';record=json.loads(file.read_text(encoding='utf8'));record['saved']=True;file.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf8')
  return
 if action=='observe_target_macros':
  dialog=Desktop(backend='uia').window(handle=handle).wrapper_object()
  from eb_native_form import typed_children
  from pywinauto.controls.win32_controls import ComboBoxWrapper
  combos=[c for c in typed_children(dialog,'ComboBox')if c.window_text()=='宏指令 :'and c.is_visible()]
  if len(combos)!=1:raise ValueError('Unique macro binding selector required')
  choices=ComboBoxWrapper(combos[0].handle).item_texts()
  (ROOT/'evidence/plc-control-target-macro-choices.json').write_text(json.dumps(choices,ensure_ascii=False,indent=2),encoding='utf8');return
 if action in ('configure_target_definition','capture_target_definition'):
  dialog=Desktop(backend='uia').window(handle=handle).wrapper_object()
  roots=[w for w in Desktop(backend='win32').windows() if w.process_id()==dialog.process_id()and '组装机_MT8106iP.emtp'in w.window_text()]
  if len(roots)!=1 or dialog.window_text()!='PLC 控制':raise ValueError('Target PLC definition required')
  from eb_extract import rows
  index=int(q['plc_control_config']['index'])
  source=json.loads((ROOT/f'evidence/plc-control-source-{index+1:03d}.json').read_text(encoding='utf8'))['rows']
  if action=='configure_target_definition':
   from eb_native_form import fields
   from eb_live_inventory import clear
   prop=[r for r in source if r['type']=='ComboBox'and r['name']=='属性']
   report=fields(dialog,prop);clear(handle);time.sleep(.15)
   # Type choice precedes address: switching LB/LW can reset the address editor.
   keys=[('Edit','描述 :'),('ComboBox','设备 :'),('CheckBox','只在指定的窗口打开时才执行'),('ComboBox','触发模式 :'),('ComboBox','宏指令 :'),('ComboBox',' Down'),('Edit','Static')]
   for typ,name in keys:
    selected=[r for r in source if r['type']==typ and r['name']==name]
    if selected and name=='宏指令 :':
     from eb_native_form import typed_children
     from eb_macro_picker import choose
     combos=[c for c in typed_children(dialog,'ComboBox')if c.window_text()==name and c.is_visible()]
     if len(combos)!=1:raise ValueError('Unique target macro selector required')
     choose(combos[0],selected[0]['value'],dialog.process_id())
     from eb_native_messages import combo_text
     report.append({'type':'ComboBox','name':name,'value':combo_text(combos[0].handle)})
     clear(handle)
    elif selected and name==' Down':
     from eb_native_form import typed_children
     from eb_address_type import choose
     editors=[c for c in typed_children(dialog,'Edit')if c.window_text()=='Static'and c.is_visible()]
     scoped=[]
     if len(editors)==1:
      ebox=editors[0].rectangle();cy=(ebox.top+ebox.bottom)//2
      native=Desktop(backend='win32').window(handle=handle).wrapper_object()
      qt=[c for c in native.descendants(class_name='Qt5QWindowIcon')if c.is_visible()]
      candidates=[c for c in qt if c.rectangle().top<=cy<=c.rectangle().bottom and c.rectangle().right<=ebox.left and c.rectangle().width()>80]
      if len(candidates)==1:
       parent=Desktop(backend='uia').window(handle=candidates[0].handle).wrapper_object()
       scoped=[c for c in parent.descendants(control_type='ComboBox')if c.window_text()==' Down'and c.is_visible()]
     if len(scoped)==1:
      choose(scoped[0],selected[0]['value'],dialog.process_id())
      actual=scoped[0].selected_text()
      if actual!=selected[0]['value']:raise ValueError('PLC address type readback mismatch')
      report.append({'type':'ComboBox','name':name,'value':actual,'basis':'actual address editor aligned Qt child, exact accessible Down selector'})
     else:report.extend(fields(dialog,selected))
     clear(handle)
    elif selected:report.extend(fields(dialog,selected));clear(handle)
   remaining=[r for r in source if 'value'in r and (r['type'],r['name'])not in keys and r['name']!='属性']
   if remaining:report.extend(fields(dialog,remaining))
  captured=report if action=='configure_target_definition'else rows(dialog)
  (ROOT/f'evidence/plc-control-target-{index+1:03d}.json').write_text(json.dumps({'index':index,'rows':captured,'saved':False},ensure_ascii=False,indent=2),encoding='utf8')
  return captured
 if action=='capture_source_batch':
  manager=Desktop(backend='win32').window(handle=handle).wrapper_object()
  if manager.window_text()!='PLC 控制':raise ValueError('PLC manager required')
  roots=[w for w in Desktop(backend='win32').windows() if w.process_id()==manager.process_id()and '.cmtp'in w.window_text()]
  if len(roots)!=1:raise ValueError('Original project capture only')
  from eb_color_picker import native_window_handles
  from eb_extract import rows
  from eb_page26_shapes import cancel
  lists=manager.descendants(class_name='ListBox');buttons=[b for b in manager.descendants(class_name='Button')if b.window_text()=='设置...']
  if len(lists)!=1 or len(buttons)!=1:raise ValueError('Unique source list/settings required')
  for index in q['plc_control_config']['indices']:
   file=ROOT/f'evidence/plc-control-source-{index+1:03d}.json'
   if file.exists() and 'rows'in json.loads(file.read_text(encoding='utf8')):continue
   manager.set_focus();lists[0].select(index);buttons[0].click_input()
   props=[]
   for _ in range(15):
    props=[h for h in native_window_handles(manager.process_id(),title_match='PLC 控制')if h!=handle]
    if len(props)==1:break
    time.sleep(.1)
   if len(props)!=1:raise ValueError('Unique source definition required')
   dialog=Desktop(backend='uia').window(handle=props[0]).wrapper_object()
   try:
    read=rows(dialog)
    if any('read_error'in row for row in read):raise ValueError('Source definition field read failed')
    data={'index':index,'rows':read,'source_modified':False,'label':lists[0].item_texts()[index]}
    file.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
   finally:cancel(dialog)
  return
 if action=='capture_source_definition':
  dialog=Desktop(backend='uia').window(handle=handle).wrapper_object()
  roots=[w for w in Desktop(backend='win32').windows() if w.process_id()==dialog.process_id()and '.cmtp'in w.window_text()]
  if len(roots)!=1 or dialog.window_text()!='PLC 控制':raise ValueError('Read source PLC properties only')
  from eb_extract import rows
  data={'index':q['plc_control_config']['index'],'rows':rows(dialog),'source_modified':False}
  (ROOT/f"evidence/plc-control-source-{data['index']+1:03d}.json").write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8');return
 if action=='open_source_definition':
  dialog=Desktop(backend='win32').window(handle=handle).wrapper_object()
  if dialog.window_text()!='PLC 控制':raise ValueError('PLC manager required')
  roots=[w for w in Desktop(backend='win32').windows() if w.process_id()==dialog.process_id()and '.cmtp'in w.window_text()]
  if len(roots)!=1:raise ValueError('Read source definitions only')
  lists=dialog.descendants(class_name='ListBox');buttons=[b for b in dialog.descendants(class_name='Button') if b.window_text()=='设置...' and b.is_visible()]
  if len(lists)!=1 or len(buttons)!=1:raise ValueError('Exact manager list/editor action required')
  index=int(q['plc_control_config']['index'])
  if not 0<=index<lists[0].item_count():raise ValueError('Observed row index required')
  dialog.set_focus();lists[0].select(index);buttons[0].click_input();time.sleep(.15);return
 if action=='copy_source_rows':
  dialog=Desktop(backend='win32').window(handle=handle).wrapper_object()
  if dialog.window_text()!='PLC 控制':raise ValueError('Exact PLC-control editor manager required')
  roots=[w for w in Desktop(backend='win32').windows()if w.process_id()==dialog.process_id()and '.cmtp'in w.window_text()]
  if len(roots)!=1:raise ValueError('Original project only for capture')
  lists=dialog.descendants(class_name='ListBox')
  if len(lists)!=1:raise ValueError('Unique source PLC list required')
  control=lists[0];dialog.set_focus();control.set_focus();control.select(0)
  from pywinauto.keyboard import send_keys
  sequence_before=ctypes.windll.user32.GetClipboardSequenceNumber()
  send_keys('^a^c',pause=.04);time.sleep(.2)
  sequence_after=ctypes.windll.user32.GetClipboardSequenceNumber()
  import win32clipboard as clip
  opened=False;formats=[]
  try:
   clip.OpenClipboard(handle);opened=True;fmt=0
   while True:
    fmt=clip.EnumClipboardFormats(fmt)
    if not fmt:break
    try:name=clip.GetClipboardFormatName(fmt)
    except Exception:name=str(fmt)
    formats.append({'id':fmt,'name':name})
  finally:
   if opened:clip.CloseClipboard()
  (ROOT/'evidence/plc-control-clipboard-formats.json').write_text(json.dumps({'count':control.item_count(),'formats':formats,'sequence_before':sequence_before,'sequence_after':sequence_after},ensure_ascii=False,indent=2),encoding='utf8')
  return
 ctypes.windll.user32.SetProcessDPIAware()
 root=Desktop(backend='win32').window(handle=handle).wrapper_object()
 if not any(name in root.window_text()for name in ('组装机2台15工位取消.cmtp','组装机_MT8106iP.emtp')):raise ValueError('Known local editor only')
 if not root.is_enabled():raise ValueError('Editor blocked by modal; inspect actual dialog')
 root.set_focus();r=root.rectangle()
 if ctypes.windll.user32.GetForegroundWindow()!=handle:raise ValueError('Editor foreground required')
 action=q['plc_control_config']['action']
 if action=='observe_ribbon':
  image=ROOT/'evidence/plc-ribbon-local.png';out=ROOT/'evidence/plc-ribbon-ocr.json'
  ImageGrab.grab(bbox=(r.left,r.top,r.right,r.top+190)).save(image)
  code=(ROOT/'tools/Read-LocalImageText.ps1').read_text(encoding='utf8')
  code=code.replace('param([string]$ImagePath,[string]$OutputPath)',"$ImagePath='"+str(image).replace("'","''")+"';$OutputPath='"+str(out).replace("'","''")+"'")
  p=subprocess.run(['C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoProfile','-Command',code],capture_output=True,text=True,timeout=30)
  if p.returncode:raise RuntimeError('Local OCR failed')
  return
 if action=='click_observed':
  box=q['plc_control_config']['box']
  if len(box)!=4 or not(0<=box[0]<box[2]<=r.width() and 0<=box[1]<box[3]<=190):raise ValueError('Observed ribbon rectangle required')
  mouse.click(coords=(r.left+int((box[0]+box[2])/2),r.top+int((box[1]+box[3])/2)));time.sleep(.2);return
 raise ValueError('Unknown PLC-config editor action')
