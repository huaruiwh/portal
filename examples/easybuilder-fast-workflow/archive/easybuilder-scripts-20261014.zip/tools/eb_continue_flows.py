"""Serial, resumable flow-page reconstruction; no device connection or simulation."""
import json,sys,time,re
from eb_rebuild_page import ROOT,call
from eb_flow_model import counts
from eb_collect_complex import run as collect
from eb_rebuild_flow import run as build
from eb_roundtrip_flow import run as verify

def windows():
    call('snapshot')
    return json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
def project(ws,title):
    found=[w for w in ws if w['class']=='EasyBuilderPro' and title in w['title']]
    if len(found)!=1:raise ValueError('One exact project required')
    return found[0]
def ui(w,q):return call('uia',w['handle'],json.dumps(q,ensure_ascii=False))
def run(pages):
    report={'pages':pages,'completed':[],'ok':False}
    path=ROOT/'evidence/flow-continuation.json'
    def save(stage,page):
        report.update(stage=stage,page=page)
        path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
        print(json.dumps({'page':page,'stage':stage}),flush=True)
    try:
        for page in pages:
            counts(page);save('cache source',page);collect(page)
            ws=windows();source=project(ws,'组装机2台15工位取消.cmtp');target=project(ws,'组装机_MT8106iP.emtp')
            settings=ROOT/f'evidence/source-pages-settings/{page:03d}.json'
            if not settings.exists():ui(source,{'page_settings':page,'color_probe':True})
            ui(target,{'restore_target_window':True,'reviewed_size':True})
            if not (ROOT/f'evidence/target-page-{page:03d}-created.json').exists():ui(target,{'create_target_page':page})
            ui(target,{'open_target_page':page});save('rebuild original selector',page)
            if not (ROOT/f'evidence/target-{page:03d}-MS0-built.json').exists():ui(target,{'page':page,'build_ms':0,'auto_create':True})
            save('rebuild bit and text',page);build(page)
            inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
            names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==page)
            lowest=[re.search(r'(?:^|\])\s*([A-Z]+)_(\d+)',v) for v in names if '(最下层)' in v]
            if len(lowest)!=1 or lowest[0] is None:raise ValueError('Unique observed source lowest layer required')
            ui(target,{'page':page,'order_sp':int(lowest[0][2]),'kind':lowest[0][1]});ui(target,{'target_page_audit':page})
            save('compile',page);ui(target,{'compile_target':True,'start_only':True});time.sleep(2)
            target=project(windows(),'组装机_MT8106iP.emtp')
            ui(target,{'compile_target':True,'capture_result':True,'expected_pid':target['pid']})
            target=project(windows(),'组装机_MT8106iP.emtp')
            old=target['pid'];call('keys',target['handle'],'%{F4}');call('launch',value=str(ROOT/'output/组装机_MT8106iP.emtp'))
            save('reopen verification',page)
            for _ in range(20):
                ws=windows();ready=[w for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title'] and w['pid']!=old]
                if len(ready)==1:break
                time.sleep(.5)
            else:raise ValueError('Reopened project not ready')
            saved_args=sys.argv;sys.argv=['eb_roundtrip_flow.py',str(old),'--page',str(page)]
            try:verify(old)
            finally:sys.argv=saved_args
            from eb_record_flow_progress import record
            record(page)
            report['completed'].append(page);save('saved compiled verified',page)
        report['ok']=True;save('complete',pages[-1])
    except Exception as e:
        report['error']=str(e);path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');raise
if __name__=='__main__':run([int(v) for v in sys.argv[1:]])
