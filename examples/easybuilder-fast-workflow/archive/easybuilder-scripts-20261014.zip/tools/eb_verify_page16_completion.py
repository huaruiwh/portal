"""Compare native saved readback against all 101 original objects, no GUI."""
import json,re
from eb_rebuild_page import ROOT
from eb_layout import geometry

def run():
 inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(v['observed_objects'] for v in inv['pages'] if v['id']==16)
 a=json.loads((ROOT/'evidence/target-page16-audit.json').read_text(encoding='utf8'))
 if not a['tree_verified'] or a['target_count']!=104 or a['source_count']!=101:raise ValueError('Complete 101+3 directory required')
 checks=[]
 def shape(rs):return rs if isinstance(rs,dict) else {v['name']:v['value'] for v in rs if v['type']=='Edit' and v['name'] in {'X :',' Y :',' 宽度 :','高度 :'}}
 def vals(rs,names):return [(v['type'],v['name'],v['value']) for v in rs if v['name'] in names and 'value' in v]
 for name in names:
  key=re.search(r'(?:^|\])\s*([A-Z]+)_(\d+)',name);kind,n=key.groups();key=f'{kind}_{n}'
  s=json.loads((ROOT/f'evidence/source-object-properties/016_{key}.json').read_text(encoding='utf8'));d=json.loads((ROOT/f'evidence/target-016-{kind}{n}-built.json').read_text(encoding='utf8'))
  expected=geometry(s);actual=shape(d['geometry'])
  if kind=='AL':
   expected=dict(expected);expected[' Y :']=str(int(expected[' Y :'])+24);expected['高度 :']=str(int(expected['高度 :'])-24)
  c={'object':key,'saved_readback_exists':d.get('saved_requested') is True,'geometry_verified':expected==actual}
  x=int(actual['X :']);y=int(actual[' Y :']);w=int(actual.get(' 宽度 :','1'));h=int(actual.get('高度 :','1'))
  c['inside_1024x600']=0<=x<1024 and 0<=y<600 and w>0 and h>0 and x+w<=1024 and y+h<=600
  if kind in {'TS','BL','NE','ND'}:
   c['addresses_verified']=vals(s['tabs']['一般属性'],{'设备 :','Static',' Down'})==vals(d['general'],{'设备 :','Static',' Down'})
  if kind=='BL':
   flags=lambda rs:{v['name']:v['value'] for v in rs if v['type']=='CheckBox'}
   c['source_picture_flags_verified']=flags(s['tabs']['图片'])==flags(d['picture'])
  if kind=='TS':
   c['safety_verified']=vals(s['tabs']['安全'],{'最短按压时间',' Down','操作前先确认','使用寄存器状态/数值','声音','用户限制 Down'})==vals(d['safety'],{'最短按压时间',' Down','操作前先确认','使用寄存器状态/数值','声音','用户限制 Down'})
   family=next(v['name'] for v in s['tabs']['图片'] if v['type']=='Text' and v['name'] in ('Button - Standard','Selector_3_Position_Metal_Silver-Red'))
   c['original_family_verified']=any(v['type']=='Text' and v['name']==family for v in d['picture'])
   enabled=any(v['name']=='使用文字标签' and v.get('value')==1 for v in s['tabs']['标签'])
   c['captions_verified']=not enabled or all(vals(s['label_states'][state],{''})==vals(d['labels'][state],{''}) for state in ('0','1'))
  if kind=='TX':c['caption_verified']=vals(s['tabs']['文字/批注'],{'内容'})==vals(d['text'],{'内容'})
  checks.append(c)
 r={'date':'2026-10-09','page':16,'source_count':101,'physical_target_count':104,'model_adaptation_objects':['DW_5','TX_31','TX_32'],'checks':checks,'ok':len(checks)==101 and all(v for c in checks for k,v in c.items() if k!='object'),'evidence_only':True,'offline_simulation_verified':False,'pending':['矢量形状身份/矩形线宽样式最终外观对照','离线和实机交互验收']}
 (ROOT/'evidence/page16-completion-checks.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
 if not r['ok']:raise ValueError('Page16 saved native parameter evidence mismatch: '+str([c for c in checks if any(v is False for v in c.values())]))
 print(json.dumps({'page':16,'source_count':101,'target_count':104,'ok':True},ensure_ascii=False))
if __name__=='__main__':run()
