import json
from eb_extract import ROOT,rows
from eb_object_ui import target,properties
from eb_native_form import tab
from eb_native_messages import msg
from eb_color_picker import probe

def run(handle,q):
 page=q['header_color_check']['page'];key=q['header_color_check']['key']
 if (page,key) not in [(10,'TX_0'),(11,'TX_0'),(10,'SP_0'),(11,'SP_0')]:raise ValueError('Reviewed header only')
 source=json.loads((ROOT/f'evidence/source-object-properties/{page:03d}_{key}.json').read_text(encoding='utf8'))
 root,w=target(handle,page);d,name=properties(root,w,key,source['dialog_title'])
 try:
  tab(d,next(iter(source['tabs'])))
  names=list(source['colors']);selected=[names[q['header_color_check']['color_index']]] if 'color_index' in q['header_color_check'] else names
  colors={name:probe(d,name) for name in selected}
  r={'page':page,'key':key,'source_rgb':{k:source['colors'][k] for k in selected},'target_rgb':colors,'colors_verified':all(colors[k]==source['colors'][k] for k in selected),'project_modified':False}
  (ROOT/f'evidence/header-{page}-{key}-color-{q["header_color_check"].get("color_index",0)}-check.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
 finally:
  cs=[c for c in d.descendants(control_type='Button') if c.window_text()==chr(21462)+chr(28040) and c.is_visible()]
  if len(cs)!=1:raise ValueError('One cancel required')
  msg(cs[0].handle,245)
