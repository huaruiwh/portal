import json,time,ctypes
from ctypes import wintypes
from pywinauto import mouse
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties
from eb_native_form import typed_children
from eb_native_messages import msg

def run(handle,q):
 mouse.release()
 root,w=target(handle,200);a=json.loads((ROOT/'evidence/page200-table-grid-target.json').read_text(encoding='utf8'))
 d,_=properties(root,w,'TB_0','表格的属性')
 cancel=[b for b in typed_children(d,'Button') if b.window_text()=='取消'];msg(cancel[0].handle,245);time.sleep(.15)
 u=ctypes.windll.user32
 class CursorInfo(ctypes.Structure):_fields_=[('cbSize',wintypes.DWORD),('flags',wintypes.DWORD),('hCursor',wintypes.HANDLE),('ptScreenPos',wintypes.POINT)]
 u.LoadCursorW.restype=ctypes.c_void_p
 standard={str(u.LoadCursorW(None,i)):label for i,label in [(32512,'arrow'),(32644,'size-we'),(32645,'size-ns'),(32646,'size-all'),(32642,'size-nwse'),(32643,'size-nesw')]}
 out=[];ox,oy=a['origin'];sx,sy=a['scale']
 if q.get('adjust_table_grid'):
  from PIL import ImageGrab
  from eb_object_ui import save
  from eb_table_grid_probe import run as grid_probe
  original=json.loads((ROOT/'evidence/page200-table-grid-source.json').read_text(encoding='utf8'))
  def current():
   box=a['crop'];im=ImageGrab.grab(bbox=tuple(box)).convert('RGB');ww,hh=im.size;xs=[0]*ww;ys=[0]*hh
   for yy in range(hh):
    for xx in range(ww):
     rr,gg,bb=im.getpixel((xx,yy))
     if bb>220 and rr<30 and gg<30:xs[xx]+=1;ys[yy]+=1
   def centers(cs,threshold,offset,origin,scale):
    groups=[]
    for i,c in enumerate(cs):
     if c>=threshold:
      if groups and i==groups[-1][-1]+1:groups[-1].append(i)
      else:groups.append([i])
    return [(offset+sum(g)/len(g)-origin)/scale for g in groups]
   return {'vertical_lines':centers(xs,hh*.65,box[0],ox,sx),'horizontal_lines':centers(ys,ww*.65,box[1],oy,sy)}
  changes=[]
  for axis,expected_count,label in [('vertical_lines',4,'size-we'),('horizontal_lines',15,'size-ns')]:
   desired=original[axis]
   if len(desired)!=expected_count:raise ValueError('Original grid projection incomplete')
   for i in range(1,expected_count-1):
    observed=current()[axis]
    if len(observed)!=expected_count:raise ValueError('Current grid projection incomplete')
    old,new=observed[i],desired[i]
    if abs(old-new)<=1.8:continue
    start=(round(ox+old*sx),round(oy+82*sy)) if axis=='vertical_lines' else (round(ox+514*sx),round(oy+old*sy))
    end=(round(ox+new*sx),start[1]) if axis=='vertical_lines' else (start[0],round(oy+new*sy))
    mouse.move(coords=start);time.sleep(.1);info=CursorInfo();info.cbSize=ctypes.sizeof(info);u.GetCursorInfo(ctypes.byref(info))
    if standard.get(str(info.hCursor))!=label:raise ValueError('Observed grid divider resize cursor required')
    mouse.press(coords=start)
    try:mouse.move(coords=end)
    finally:mouse.release(coords=end)
    time.sleep(.1)
    changed=current()[axis]
    if len(changed)!=expected_count or abs(changed[i]-new)>1.8:raise ValueError('Grid divider saved position differs from source')
    changes.append({'axis':axis,'index':i,'before':old,'requested':new,'actual':changed[i]})
  save(root);grid_probe(handle,{'table_grid_probe':'target'})
  final=json.loads((ROOT/'evidence/page200-table-grid-target.json').read_text(encoding='utf8'))
  matched=all(len(final[k])==len(original[k]) and all(abs(x-y)<=1.8 for x,y in zip(final[k],original[k])) for k in ['vertical_lines','horizontal_lines'])
  if not matched:raise ValueError('Final grid projection differs from original')
  (ROOT/'evidence/page200-table-custom-grid-adjustment.json').write_text(json.dumps({'changes':changes,'source':original,'target':final,'matched':matched,'image_transmitted':False},ensure_ascii=False,indent=2),encoding='utf8')
  from eb_native_form import tab
  from eb_extract import rows
  from eb_color_picker import probe
  from eb_layout import geometry
  s=json.loads((ROOT/'evidence/source-object-properties/200_TB_0.json').read_text(encoding='utf8'))
  d,_=properties(root,w,'TB_0','表格的属性');tab(d,'一般属性');general=rows(d)
  for key in ('垂直 :','水平 :','宽度 :'):
   if [r['value'] for r in general if r['type']=='Edit' and r['name']==key]!=[r['value'] for r in s['tabs']['一般属性'] if r['type']=='Edit' and r['name']==key]:raise ValueError('Final table count/width mismatch')
  if [probe(d,'颜色 :',i) for i in (0,2)]!=s['table_line_colors']:raise ValueError('Final line colors mismatch')
  tab(d,'轮廓');bounds=rows(d);shape=geometry(s)
  if {r['name']:r['value'] for r in bounds if r['type']=='Edit' and r['name'] in shape}!=shape:raise ValueError('Final table bounds mismatch')
  cancel=[b for b in typed_children(d,'Button') if b.window_text()=='取消'];msg(cancel[0].handle,245)
  p=ROOT/'evidence/target-200-TB0-built.json';report=json.loads(p.read_text(encoding='utf8'));report.update(custom_cell_sizes_review_pending=False,custom_grid_verified=True,final_geometry=bounds);p.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
  return
 for axis,v in [('vertical',a['vertical_lines'][1]),('horizontal',a['horizontal_lines'][1])]:
  points=[(v,y) for y in [79,82,200,508]] if axis=='vertical' else [(x,v) for x in [511,514,550,815]]
  for x,y in points:
   mouse.move(coords=(round(ox+x*sx),round(oy+y*sy)));time.sleep(.15)
   info=CursorInfo();info.cbSize=ctypes.sizeof(info);u.GetCursorInfo(ctypes.byref(info))
   out.append({'axis':axis,'canvas':[x,y],'cursor':standard.get(str(info.hCursor),str(info.hCursor))})
 (ROOT/'evidence/page200-table-resize-probe.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')



