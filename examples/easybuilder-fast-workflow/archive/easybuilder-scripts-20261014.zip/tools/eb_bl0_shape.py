"""Inspect original BL0 vector using native gallery, without source saves."""
import json,time
from pywinauto import Desktop
from eb_extract import ROOT,rows
from eb_object_ui import dialog
from eb_native_form import tab
from eb_native_messages import msg

def run(handle,q):
 root=Desktop(backend='win32').window(handle=handle).wrapper_object()
 pid=root.process_id()
 mode=q['bl0_shape']
 if mode=='bitmap-gallery':
  d=dialog(pid,'位状态指示灯/位状态切换开关的属性');tab(d,'图片')
  bs=sorted([c for c in d.descendants(control_type='Button') if c.element_info.name=='图库...' and c.is_visible() and c.is_enabled()],key=lambda c:c.rectangle().top)
  if len(bs)!=2:raise ValueError('Two gallery buttons required')
  bs[0].click_input();g=dialog(pid,'图片管理');Desktop(backend='win32').window(handle=g.handle).set_focus();time.sleep(.5)
  suffix='source' if '组装机2台15工位取消.cmtp' in root.window_text() else 'target'
  g.capture_as_image().save(str(ROOT/f'evidence/bl0-bitmap-gallery-{suffix}.png'))
  entries=[{'type':c.element_info.control_type,'name':c.element_info.name} for c in g.descendants(cache_enable=True) if c.is_visible() and c.element_info.control_type in ('Group','MenuItem','Text')]
  (ROOT/'evidence/bl0-bitmap-gallery-live.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2),encoding='utf8')
  return
 if mode=='cancel-bitmap-source':
  for title in ('图片管理','位状态指示灯/位状态切换开关的属性'):
   x=dialog(pid,title)
   bs=[c for c in x.descendants(control_type='Button') if c.element_info.name=='取消' and c.is_visible()]
   if len(bs)!=1:raise ValueError('Unique cancel required')
   msg(bs[0].handle,245)
  return
 if mode=='select-square':
  if '组装机_MT8106iP.emtp' not in root.window_text():raise ValueError('Target only')
  g=dialog(pid,'图片管理');Desktop(backend='win32').window(handle=g.handle).set_focus()
  groups=[c for c in g.descendants(control_type='Group') if c.is_visible() and c.element_info.name=='1']
  if len(groups)!=1:raise ValueError('One observed Standard square group1 required')
  groups[0].click_input(coords=(60,70))
  bs=[c for c in g.descendants(control_type='Button') if c.is_visible() and c.element_info.name=='确定']
  if len(bs)!=1:raise ValueError('Unique gallery confirm required')
  bs[0].click_input();d=dialog(pid,'位状态指示灯/位状态切换开关的属性');tab(d,'图片')
  picture=rows(d)
  if not all(any(r['type']=='Text' and r['name']==name for r in picture) for name in ('Button - Standard','96x96')):raise ValueError('Square bitmap metadata mismatch')
  from eb_native_form import confirm
  from eb_object_ui import save,properties,target
  confirm(d);save(root)
  root,w=target(handle,16);d,_=properties(root,w,'BL_0','位状态指示灯/位状态切换开关的属性');tab(d,'图片')
  Desktop(backend='win32').window(handle=d.handle).set_focus();time.sleep(.5)
  d.capture_as_image().save(str(ROOT/'evidence/bl0-square-saved-local.png'))
  report={'page':16,'object':'BL_0','bitmap_family':'Button - Standard','bitmap_group':'1','bitmap_size':'96x96','saved':True,'reopened_property':True,'picture':rows(d),'runtime_verified':False}
  (ROOT/'evidence/page16-BL0-shape-correction.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
  bs=[c for c in d.descendants(control_type='Button') if c.element_info.name=='取消' and c.is_visible()]
  if len(bs)!=1:raise ValueError('One readback cancel required')
  msg(bs[0].handle,245)
  return
 if mode=='cancel-source':
  for title in ('向量图管理','位状态指示灯/位状态切换开关的属性'):
   x=dialog(pid,title)
   bs=[c for c in x.descendants(control_type='Button') if c.element_info.name=='取消' and c.is_visible()]
   if len(bs)!=1:raise ValueError('Unique cancel required')
   msg(bs[0].handle,245)
  return
 if mode=='target-preview':
  from eb_object_ui import target,properties
  root,w=target(handle,16);d,_=properties(root,w,'BL_0','位状态指示灯/位状态切换开关的属性');tab(d,'图片')
  Desktop(backend='win32').window(handle=d.handle).set_focus();time.sleep(.5)
  d.capture_as_image().save(str(ROOT/'evidence/bl0-target-picture-local.png'))
  return
 if mode in ('inspect','resume'):
  d=dialog(pid,'位状态指示灯/位状态切换开关的属性');tab(d,'图片')
  (ROOT/'evidence/bl0-source-picture-live.json').write_text(json.dumps(rows(d),ensure_ascii=False,indent=2),encoding='utf8')
  d.capture_as_image().save(str(ROOT/'evidence/bl0-source-picture-local.png'))
  bs=[c for c in d.descendants(control_type='Button') if c.element_info.name=='图库...' and c.is_visible() and c.is_enabled()]
  if len(bs)!=2:raise ValueError('Two observed picture/vector gallery buttons required')
  bs.sort(key=lambda c:c.rectangle().top)
  bs[1].click_input()
  g=dialog(pid,'向量图管理')
  g.capture_as_image().save(str(ROOT/'evidence/bl0-source-vector-local.png'))
  entries=[{'type':c.element_info.control_type,'name':c.element_info.name} for c in g.descendants(cache_enable=True) if c.is_visible() and c.element_info.control_type in ('Group','MenuItem','TabItem','Text')]
  (ROOT/'evidence/bl0-source-vector-live.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2),encoding='utf8')
  for x in (g,d):
   bs=[c for c in x.descendants(control_type='Button') if c.element_info.name=='取消' and c.is_visible()]
   if len(bs)!=1:raise ValueError('Unique cancel required')
   msg(bs[0].handle,245)
