"""Move named objects (outline fields only) in the target project, in worker-sized batches.

Requests:
  {'move_objects':{'page':P,'op':'move','items':[{'key':'NE_0','fields':{'X :':'580'}},...]}}
      write + in-dialog readback + confirm, then one project save.
  {'move_objects':{'page':P,'op':'verify','items':[{'key':'NE_0','fields':{'X :':'580'}},...]}}
      reopen each object and read the fields back.

Batches stay small so every worker call finishes well inside the 55 s subprocess limit.
No other property, binding or object is touched.
"""
import json
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save
from eb_open_page import run as open_page
from eb_native_form import tab,fields,confirm
from eb_page26_shapes import cancel
from eb_live_fields import capture
from eb_page203_rewrite import TITLES

NAMES=('X :',' Y :',' 宽度 :','高度 :')

def scope_filter(handle,page):
    """Force the reviewed directory filter to exactly '<page> :' so keys resolve uniquely."""
    from pywinauto import Desktop
    from eb_directory import scope
    from eb_native_messages import put,text
    w=Desktop(backend='uia').window(handle=handle).wrapper_object()
    native=Desktop(backend='win32').window(handle=handle).wrapper_object();wr=w.rectangle()
    filters=[c for c in scope(w).descendants(control_type='Edit') if c.is_visible()]
    if len(filters)!=1:raise ValueError('Unique directory filter required')
    want=str(page)+' :'
    if filters[0].handle and filters[0].class_name()=='Edit':
        put(filters[0].handle,want)
    else:
        from pywinauto.keyboard import send_keys
        native.set_focus();filters[0].click_input();filters[0].set_focus()
        import win32clipboard
        win32clipboard.OpenClipboard()
        try:
            win32clipboard.EmptyClipboard();win32clipboard.SetClipboardText(want,win32clipboard.CF_UNICODETEXT)
        finally:win32clipboard.CloseClipboard()
        send_keys('^a^v',pause=.03)
        import time as _t;_t.sleep(.15)
    got=text(filters[0].handle) if filters[0].handle and filters[0].class_name()=='Edit' else filters[0].get_value()
    if got!=want:raise ValueError('Page filter readback mismatch: %r'%got)

def open_props(handle,page,key,kind):
    """Locate the object row, scrolling the directory viewport when the row is out of view."""
    from pywinauto import mouse
    from eb_directory import scope
    last=None
    for attempt in range(14):
        root,w=target(handle,page)
        try:
            return properties(root,w,key,TITLES[kind])
        except ValueError as e:
            last=e
            if 'Unique target object required' not in str(e):raise
            trees=[t for t in scope(w).descendants(control_type='Tree') if t.is_visible()]
            if len(trees)!=1:raise
            r=trees[0].rectangle()
            mouse.scroll(coords=((r.left+r.right)//2,(r.top+r.bottom)//2),wheel_dist=-6 if attempt<7 else 6)
            import time as _t;_t.sleep(.12)
    raise ValueError('Object not located after scrolling: %s (%s)'%(key,last))

def run(handle,q):
    req=q['move_objects'];page=int(req['page']);op=req.get('op','move');items=req['items']
    if not items or len(items)>6:raise ValueError('Reviewed batch of 1..6 items required')
    for it in items:
        if it['key'].split('_')[0] not in TITLES:raise ValueError('Unreviewed object kind: '+it['key'])
        if any(n not in NAMES for n in it['fields']):raise ValueError('Outline fields only: '+it['key'])
    open_page(handle,{'open_target_page':page})
    scope_filter(handle,page)
    out={'page':page,'op':op,'items':[],'mismatches':[],'verified':False}
    if op=='read':
        from eb_extract import rows
        from pywinauto import Desktop
        for it in items:
            d,_=open_props(handle,page,it['key'],it['key'].split('_')[0])
            try:
                tabs={}
                names=[c.window_text() for c in d.descendants(control_type='TabItem') if c.is_visible()]
                for t in dict.fromkeys(names):
                    try:
                        tab(d,t);tabs[t]=rows(d)
                    except Exception as e:tabs[t]=[{'error':str(e)[:120]}]
                out['items'].append({'key':it['key'],'tabs':tabs})
            finally:cancel(d)
        out['verified']=True
    elif op=='move':
        for it in items:
            root,w=target(handle,page)
            d,_=open_props(handle,page,it['key'],it['key'].split('_')[0])
            try:
                tab(d,'轮廓')
                before={r['name']:r['value'] for r in capture(d,[('Edit',n) for n in NAMES])}
                fields(d,[{'type':'Edit','name':n,'value':str(v)} for n,v in it['fields'].items()],commit_edits=True)
                got={r['name']:r['value'] for r in capture(d,[('Edit',n) for n in it['fields']])}
                for n,v in it['fields'].items():
                    if got.get(n)!=str(v):
                        fields(d,[{'type':'Edit','name':n,'value':str(v)}],commit_edits=True)
                        got={r['name']:r['value'] for r in capture(d,[('Edit',n) for n in it['fields']])}
                        if got.get(n)!=str(v):raise ValueError('Write readback mismatch %s %s: %r'%(it['key'],n,got.get(n)))
                confirm(d);d=None
            finally:
                if d is not None:cancel(d)
            out['items'].append({'key':it['key'],'before':before,'set':it['fields']})
        root,w=target(handle,page);save(root)
        out['verified']=True
    else:
        for it in items:
            root,w=target(handle,page)
            d,_=open_props(handle,page,it['key'],it['key'].split('_')[0])
            try:
                tab(d,'轮廓')
                got={r['name']:r['value'] for r in capture(d,[('Edit',n) for n in it['fields']])}
                out['items'].append({'key':it['key'],'expected':it['fields'],'reopened':got})
                for n,v in it['fields'].items():
                    if got.get(n)!=str(v):out['mismatches'].append('%s %s: %r!=%s'%(it['key'],n,got.get(n),v))
            finally:cancel(d)
        out['verified']=not out['mismatches']
    tag='move' if op=='move' else 'verify'
    p=ROOT/f'evidence/move-objects-{page}-{tag}-{items[0]["key"]}.json'
    p.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
    if not out['verified']:raise ValueError('Move verification failed: %s'%out['mismatches'])
