"""Archive only completed repairs; never infer success from an open gallery."""
import json
from datetime import datetime
from eb_rebuild_page import ROOT
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8-sig'))
def write(p,r):(ROOT/p).write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
reports=[read(f'evidence/page26-TS{n}-shape-correction.json') for n in range(7)]
if not all(r['saved'] and r['general_unchanged'] and r['geometry_unchanged'] for r in reports):raise ValueError('Seven saved readbacks required')
compile=read('evidence/latest-project-compile.json')
if not compile['ok'] or compile['project_bytes']!=(ROOT/'output/组装机_MT8106iP.emtp').stat().st_size:raise ValueError('Current compile required')
now=datetime.now().isoformat(timespec='seconds')
for n,r in enumerate(reports):
 p=f'evidence/target-026-TS{n}-built.json';b=read(p);b['picture']=r['picture'];b['shape_correction']=r;write(p,b)
cp=read('evidence/resume-checkpoint.json');cp.update(date=now,bytes=compile['project_bytes'],exob_bytes=compile['exob_bytes'],page26_shapes=reports,current_compile=compile,batch_running=False,next='26页7按钮图形修正保存，继续17/18及后续外观核对；17报警只读提取超时未完成，先检查弹窗后恢复，不重复新增。');write('evidence/resume-checkpoint.json',cp)
entry=f'''\n\n### {now} 26页按钮图形修正

- 源TS_0—TS_4：Button - Standard / 3，143x64金属矩形；TS_5、TS_6：Switch - Flat / 5，70x29滑动开关。旧目标全部Button - Flat / 3，107x51，图库类型错误。原件0和5已打开原生图库核实具体选中项，以此作为两类修复基准。
- 已修正7/7既有按钮并保存、重开属性核对名称尺寸。地址及一般参数、位置尺寸逐项与修正前一致；没有写颜色、标签、安全字段，没有新增按钮。颜色两状态及其它外观细节未新验收。
- 实际编译{compile['messages']}，警告{compile['warning_details']}；工程{compile['project_bytes']}字节，EXOB {compile['exob_bytes']}字节；运行交互仍未验收。
- 脚本 tools/eb_page26_shapes.py；串行worker请求 {{"page26_shapes":"repair","n":0,"index":"5","build_bit_general":0}}，n取0到6，build_bit_general仅保留300秒单控件超时路由，实际dispatch为修复已有对象。Switch - Flat / 5入口已补入 eb_picture_family.py。图库枚举开启元数据缓存。
- 17页目录32/32完整、SP_0轮廓通过；报警条只读提取遇 subprocess.TimeoutExpired，55秒操作未完成。用户转向26页后控制器停止、取消残留报警属性，不将17/18记为验收完成。
- 26首次TS_0额外颜色检查遇 subprocess.TimeoutExpired: timed out after 300 seconds，未生成保存报告；退出残留颜色/属性后改为只替换图片。Colors取消按钮改用原生枚举与短超时消息，避免UIA模态关闭等待。本轮未重启worker或增加超时，保留单控件300/普通55秒限制。
- 验证与复现：evidence/page26-TS0-shape-correction.json至TS6均saved=true、general_unchanged=true、geometry_unchanged=true；继续操作前核对request/response一致、无控制器及弹窗。最终仿真仍待。
'''
for p in ('README.md','docs/MT8106iP重建-实现记录.md'):
 with (ROOT/p).open('a',encoding='utf8') as f:f.write(entry)
print('Archived seven page26 bitmap repairs.')
