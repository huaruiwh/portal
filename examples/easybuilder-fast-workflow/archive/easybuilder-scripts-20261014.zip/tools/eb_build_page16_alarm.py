"""Rebuild native MT alarm body; retain cMT header as separate static objects."""
import json,re,time
from eb_extract import ROOT,rows
from eb_object_ui import target,dialog,placed_properties,save
from eb_native_form import tab,fields,confirm
from eb_layout import geometry
from eb_color_picker import set_rgb,probe

def run(handle,q):
 a=json.loads((ROOT/'evidence/target-page16-audit.json').read_text(encoding='utf8'))
 if a['source_count']!=101 or 'AL_0' not in a['missing']:raise ValueError('Fresh missing native alarm required')
 if (ROOT/'evidence/target-016-AL0-built.json').exists():raise ValueError('Saved alarm exists; never duplicate')
 source=json.loads((ROOT/'evidence/source-object-properties/016_AL_0.json').read_text(encoding='utf8'))
 defaults=json.loads((ROOT/'evidence/new-16-AL-defaults.json').read_text(encoding='utf8'))
 if source['dialog_title']!='报警显示的属性' or defaults['title']!='新增 报警显示':raise ValueError('Source and MT alarm identities required')
 if [r.get('value') for r in source['tabs']['标题'] if r['name']=='使用标题']!=[1]:raise ValueError('Explicit source header required')
 if any(r.get('value')!=0 for r in source['tabs']['排序'] if r['type']=='CheckBox' and re.match(r'Row (?:1|[4-9]), Column 1$',r['name'])):raise ValueError('Only time and message columns reviewed')
 root,w=target(handle,16)
 if not q.get('resume'):
  root.set_focus();root.click_input(coords=(437,52));root.click_input(coords=tuple(defaults['entry']))
 d=dialog(root.process_id(),'新增 报警显示');captured={};checks=[]
 def colour(label,rgb):
  r=set_rgb(d,rgb,label);actual=r['after'] if r.get('already_equal') else probe(d,label)
  if actual!=rgb:raise ValueError('Alarm colour mismatch '+label)
  checks.append({'label':label,'native_readback':actual})
 tab(d,'一般属性');fields(d,source['tabs']['一般属性']);captured['一般属性']=rows(d)
 tab(d,'报警')
 # All source alarm enable flags are off, including grid; MT has one grid flag.
 if any(r.get('value')!=0 for r in source['tabs']['报警'] if r['type']=='CheckBox' and r['name']=='启用'):raise ValueError('Source dynamic alarm feature requires review')
 fields(d,[r for r in source['tabs']['报警'] if r['type']=='Edit' or r['name']=='透明'])
 fields(d,[{'type':'CheckBox','name':'启用','value':0}])
 for label in ('外框颜色 :','背景颜色 :'):colour(label,source['colors'][label])
 captured['报警']=rows(d)
 tab(d,'排序')
 common=[]
 for r in source['tabs']['排序']:
  if r['name']=='日期 :' or re.match(r'Row [6-9],',r['name']):continue
  if r['type']=='Edit' and r['name']=='Row 3, Column 3':r=dict(r,value='37')
  common.append(r)
 fields(d,common,commit_edits=True);captured['排序']=rows(d)
 tab(d,'安全');fields(d,source['tabs']['安全']);captured['安全']=rows(d)
 tab(d,'图片');fields(d,source['tabs']['图片'])
 from eb_frame_vector import choose
 choose(d,root.process_id());tab(d,'图片');colour('图案颜色 :',source['colors']['图案颜色 :']);captured['图片']=rows(d)
 tab(d,'字体');fields(d,[r for r in source['tabs']['字体'] if r['name'] in ('尺寸 :','斜体')]);captured['字体']=rows(d)
 confirm(d);d,name=placed_properties(root,w,'AL_0','报警显示的属性')
 for t in ('报警','排序','安全','字体'):
  tab(d,t);actual=rows(d)
  expected=[(r['type'],r['name'],r.get('value')) for r in captured[t] if 'value' in r]
  if [(r['type'],r['name'],r.get('value')) for r in actual if 'value' in r]!=expected:raise ValueError('Alarm persisted field mismatch '+t)
 tab(d,'轮廓');shape=geometry(source);total=dict(shape);shape[' Y :']=str(int(shape[' Y :'])+24);shape['高度 :']=str(int(shape['高度 :'])-24)
 fields(d,[{'type':'Edit','name':k,'value':v} for k,v in shape.items()]);shape_readback=rows(d);confirm(d);save(root)
 report={'page':16,'source':'AL_0','target':name,'tabs':captured,'colours':checks,'geometry':shape_readback,'saved_requested':True,'whole_source_geometry':total,'header_height':24,'header_pending':True,'model_differences':['MT无标题页，源蓝字/浅蓝底标题由静态文字与矩形补齐','源日期与扩展列6至9关闭，目标日期格式MM/DD/YY且日期关闭','源自动调整栏宽，目标消息显示字符37适配417px；原源值20保留于source cache','MT报警字体仅提供字号与斜体，源语言字体对应的实际字形待运行核对'],'offline_simulation_verified':False}
 (ROOT/'evidence/target-016-AL0-built.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
