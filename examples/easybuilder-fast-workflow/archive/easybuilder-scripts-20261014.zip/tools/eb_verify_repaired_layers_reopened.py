import json,time
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
with lock.open('x'):pass
report={'ok':False,'checks':[],'runtime_verified':False}
path=ROOT/'evidence/repaired-layers-project-reopened.json'
def persist():path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
def window():
 call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'));return next(w for w in ws if w['class']=='EasyBuilderPro' and '_MT8106iP_' in w['title'])
try:
 w=window();old=w['pid'];call('keys',w['handle'],'^s');call('keys',w['handle'],'%{F4}');call('launch',value=str(next((ROOT/'output').glob('*.emtp'))))
 for _ in range(20):
  try:
   w=window()
   if w['pid']!=old:break
  except StopIteration:pass
  time.sleep(.5)
 else:raise ValueError('Fresh project process required')
 report.update(old_pid=old,new_pid=w['pid'],new_handle=w['handle']);persist()
 call('uia',w['handle'],json.dumps({'restore_target_window':True}))
 for page in (16,100,101,102):
  report['stage']=page;persist()
  call('uia',w['handle'],json.dumps({'page_settings':page,'target_readonly':True}))
  src=json.loads((ROOT/f'evidence/source-pages-settings/{page:03d}.json').read_text(encoding='utf8'));dst=json.loads((ROOT/f'evidence/target-pages-settings/{page:03d}.json').read_text(encoding='utf8'))
  names=[chr(24213)+chr(23618)+' :',chr(20013)+chr(23618)+' :',chr(39030)+chr(23618)+' :']
  get=lambda d:{x['name']:x.get('value') for x in d['controls'] if x['type']=='ComboBox' and x['name'] in names}
  good=get(src)==get(dst);report['checks'].append({'page':page,'layers':get(dst),'ok':good});persist()
  if not good:raise ValueError('Reopened layer mismatch')
  print(page,'disk verified',flush=True)
 report['ok']=True;report['stage']='completed';persist()
except Exception as e:report['error']=str(e);persist();raise
finally:lock.unlink(missing_ok=True)
