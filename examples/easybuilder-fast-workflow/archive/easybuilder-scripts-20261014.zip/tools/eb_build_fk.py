"""103-page function keys: bind existing destinations/macros, never execute."""
import json
from eb_extract import ROOT,rows
from eb_object_ui import target,dialog,placed_properties,save
from eb_native_form import tab,fields,confirm,commit_text
from eb_layout import geometry
def run(handle,q):
    page,n=int(q['page']),int(q['build_fk'])
    if not (page==103 and n in range(7) or page in (11,200,202) and n==0):raise ValueError('Cached background keys only')
    if page==11:
        audit=json.loads((ROOT/'evidence/target-page11-audit.json').read_text(encoding='utf8'))
        if 'FK_0' not in audit['missing']:raise ValueError('Missing source key required')
    path=ROOT/f'evidence/target-{page:03d}-FK{n}-built.json'
    if page in (200,202) and not q.get('resume'):
        audit=json.loads((ROOT/f'evidence/target-page{page}-audit.json').read_text(encoding='utf8'))
        if 'FK_0' not in audit['missing']:raise ValueError('Missing FK0 proof required')
    if path.exists():raise ValueError('Saved key exists; no duplicate')
    s=json.loads((ROOT/f'evidence/source-object-properties/{page:03d}_FK_{n}.json').read_text(encoding='utf8'))
    root,w=target(handle,page)
    if not q.get('resume'):
        from eb_ribbon import create
        create(root,'FK','新增 功能键')
    d=dialog(root.process_id(),'新增 功能键');tab(d,'一般属性')
    g=s['tabs']['一般属性']
    mode=next(r['value'] for r in g if r['name']=='属性 Down')
    if mode=='窗口':
        fields(d,[{'type':'RadioButton','name':'','value':1}])
        fields(d,[dict(r,name='') if r['name']=='窗口 Down' else r for r in g if r['name'] in ('窗口 Down','当按钮松开后发出指令','启用')])
        value=next(r['value'] for r in g if r['type']=='ComboBox' and r['name']==' Down')
        cs=[c for c in d.descendants(control_type='ComboBox') if c.window_text()==' Down' and c.is_visible()]
        if len(cs)!=1:raise ValueError('One destination combo required')
        combo=cs[0]
        if combo.selected_text().strip()!=value.strip():
            edits=[c for c in combo.descendants(control_type='Edit') if c.is_visible()]
            if len(edits)!=1:raise ValueError('One observed destination editor required')
            editors=[c for c in d.descendants(control_type='Edit') if c.window_text()==edits[0].window_text() and c.is_visible()]
            idx=next(i for i,c in enumerate(editors) if c.element_info.runtime_id==edits[0].element_info.runtime_id)
            commit_text(d,edits[0].window_text(),value,idx)
        if combo.selected_text().strip()!=value.strip():raise ValueError('Destination readback mismatch')
    elif mode=='执行宏指令':
        fields(d,[{'type':'RadioButton','name':'触发宏指令','value':1}]);fields(d,[r for r in g if r['name'] in ('当按钮松开后发出指令','启用')])
    else:raise ValueError('Unreviewed function-key action')
    macros=[r for r in g if r['name']=='执行宏指令 Down']
    if macros:
        from eb_macro_picker import choose
        from pywinauto.controls.win32_controls import ComboBoxWrapper
        value=macros[0]['value'];cached=json.loads((ROOT/'evidence/formal-macros-reopened-uia.json').read_text(encoding='utf8'))
        identity=value.replace('[ID:','[ID : ').replace('] ',']\t')
        if not any(r.get('name')==identity for r in cached):raise ValueError('Imported macro identity not verified: '+identity)
        cs=[c for c in d.descendants(control_type='ComboBox') if c.is_visible() and c.element_info.class_name=='ComboBox' and (ComboBoxWrapper(c.handle).selected_text().startswith('[ID:') or ComboBoxWrapper(c.handle).selected_text()=='停用')]
        if len(cs)!=1:raise ValueError('One macro combo required')
        choose(cs[0],value,root.process_id())
    if page in (200,202):
        fields(d,[r for r in g if r['name'] in ('当父窗口被关闭时结束弹出窗口',)])
    general=rows(d);tab(d,'安全');fields(d,s['tabs']['安全']);safety=rows(d)
    tab(d,'图片');fields(d,s['tabs']['图片'],skip=(('CheckBox','调整对象尺寸为图片原尺寸'),) if page in (200,202) else ())
    if page in (200,202) and s.get('picture_identity',{})!={'family':'System Button - Flat','index':'3','method':'local selected-thumbnail yellow header; no image transmitted'}:raise ValueError('Original FK0 picture identity required')
    from eb_flat_picture import choose as flat
    flat(d,root.process_id());picture=rows(d)
    tab(d,'标签');labels={}
    for state,rs in s.get('label_states',{'0':s['tabs']['标签']}).items():
        if page in (200,202):rs=[dict(r,value='微软正黑体 Light') if r['name']=='字体 :' else dict(r,value='13') if r['name']=='尺寸 :' else r for r in rs]
        fields(d,rs,skip=(('Edit',''),));caption=next(r['value'] for r in rs if r['type']=='Edit' and r['name']=='');commit_text(d,'',caption);labels[state]=rows(d)
    if page in (200,202):
        from eb_color_picker import set_rgb,probe
        set_rgb(d,s['colors']['颜色 :'])
        if probe(d)!=s['colors']['颜色 :']:raise ValueError('FK0 label color mismatch')
    confirm(d);d,name=placed_properties(root,w,f'FK_{n}','功能键的属性');tab(d,'一般属性');general_reopened=rows(d)
    tab(d,'轮廓');fields(d,[{'type':'Edit','name':k,'value':v} for k,v in geometry(s).items()]);shape=rows(d);confirm(d);save(root)
    path.write_text(json.dumps({'page':page,'source':s['object'],'target':name,'general':general_reopened,'safety':safety,'picture':picture,'labels':labels,'geometry':shape,'saved_requested':True,'macro_executed':False,'label_color_review_pending':True,'offline_simulation_verified':False},ensure_ascii=False,indent=2),encoding='utf8')


