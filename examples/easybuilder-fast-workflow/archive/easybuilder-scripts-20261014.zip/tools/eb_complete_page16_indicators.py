"""Serial page16 missing indicator reconstruction with exact two-state RGB."""
import json,re,sys
from eb_rebuild_page import ROOT,call

def run(numbers):
 lock=ROOT/'tools/batch.lock'
 with lock.open('x'):pass
 p=ROOT/'evidence/page16-missing-indicator-workflow.json';report={'page':16,'completed':[],'ok':False}
 def persist():p.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 try:
  call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
  def handle(title):
   a=[w['handle'] for w in ws if w['class']=='EasyBuilderPro' and title in w['title']]
   if len(a)!=1:raise ValueError('Unique exact project required')
   return a[0]
  sh=handle('组装机2台15工位取消.cmtp');th=handle('组装机_MT8106iP.emtp')
  def ui(h,q):return call('uia',h,json.dumps(q,ensure_ascii=False))
  def audit():
   try:ui(th,{'target_page_audit':16})
   except RuntimeError as e:
    if 'Target object audit incomplete' not in str(e):raise
   a=json.loads((ROOT/'evidence/target-page16-audit.json').read_text(encoding='utf8'))
   if a['source_count']!=101 or a['unexpected']:raise ValueError('Unexpected indicator audit')
   return a
  inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(p['observed_objects'] for p in inv['pages'] if p['id']==16)
  for n in numbers:
   if n not in range(5,33):raise ValueError('Unreviewed new indicator')
   key=f'BL_{n}';report['stage']=key;persist();a=audit()
   if key not in a['missing']:
    if not (ROOT/f'evidence/target-016-BL{n}-built.json').exists():raise ValueError('Existing indicator without saved report; read back before any input')
    report['completed'].append(key);persist();continue
   cache=ROOT/f'evidence/source-object-properties/016_{key}.json';name=next(s for s in names if re.search(r'(?:^|\])\s*'+key+r'(?:\s|$)',s))
   source=json.loads(cache.read_text(encoding='utf8'))
   tabs=[('图片',['图案颜色 :','颜色 :'])]
   if any(r['name']=='使用文字标签' and r.get('value')==1 for r in source['tabs']['标签']):tabs.append(('标签',['颜色 :']))
   for tab,labels in tabs:
    for state in ('0','1'):
     source=json.loads(cache.read_text(encoding='utf8'))
     if set(source.get('state_colors',{}).get(tab,{}).get(state,{}))!=set(labels):
      report['phase']=f'source:{tab}:{state}';persist()
      ui(sh,{'extract':{'page':16,'object':name,'only_color':True,'state_color_probe':{'tab':tab,'state':state,'labels':labels}}})
   report['phase']='build';persist();ui(th,{'page':16,'bit_kind':'BL','build_bit_general':n})
   a=audit()
   if key in a['missing']:raise ValueError('Saved indicator missing')
   report['completed'].append(key);report['target_count']=a['target_count'];persist()
  report['ok']=True;persist();print(json.dumps(report,ensure_ascii=False))
 except Exception as e:report['error']=str(e);persist();raise
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':run([int(n) for n in sys.argv[1:]] or list(range(5,33)))
