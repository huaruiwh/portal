"""Serial local-worker workflow for validated page12/13 control templates."""
import json,re,time,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
def call(action,handle=0,value=''):
    rid=str(uuid.uuid4());req={'id':rid,'action':action,'handle':handle,'text':value,'keys':value,'file':value,'wait':.3 if action=='uia' else 0}
    tmp=ROOT/'tools'/'request.tmp';tmp.write_text(json.dumps(req,ensure_ascii=False),encoding='utf8');tmp.replace(ROOT/'tools'/'request.json')
    end=time.monotonic()+310
    while time.monotonic()<end:
        try:response=json.loads((ROOT/'evidence'/'response.json').read_text(encoding='utf8'))
        except (FileNotFoundError,json.JSONDecodeError):time.sleep(.1);continue
        if response.get('id')==rid:
            if not response.get('ok'):raise RuntimeError(response.get('error'))
            return response
        time.sleep(.1)
    raise TimeoutError('Worker timeout; inspect UI state before retry')
def run(page):
    from eb_template_guard import ALLOWED
    if page not in ALLOWED:raise ValueError('Only reviewed SW/BL inventory pages supported')
    lock=ROOT/'tools'/'batch.lock'
    with lock.open('x',encoding='utf8'):pass
    progress={'page':page,'completed':[],'ok':False}
    report_path=ROOT/'evidence'/f'page-{page}-workflow.json'
    def persist():report_path.write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf8')
    try:
        call('snapshot');windows=json.loads((ROOT/'evidence'/'windows.json').read_text(encoding='utf8'))
        def resolve(title):
            matches=[w['handle'] for w in windows if title in w['title'] and w['class']=='EasyBuilderPro']
            if len(matches)!=1:raise ValueError('Exactly one project required: '+title)
            return matches[0]
        source=resolve('组装机2台15工位取消.cmtp');target=resolve('组装机_MT8106iP.emtp')
        def ui(handle,request):return call('uia',handle,json.dumps(request,ensure_ascii=False))
        settings_path=ROOT/'evidence'/'source-pages-settings'/f'{page:03d}.json'
        if not settings_path.exists() or 'background_rgb' not in json.loads(settings_path.read_text(encoding='utf8')):ui(source,{'page_settings':page,'color_probe':True})
        inventory=json.loads((ROOT/'evidence'/'source-pages-inventory.json').read_text(encoding='utf8'))
        names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==page)
        for name in names:
            key=re.match(r'^((?:SW|BL)_\d+)\s',name)
            if not key:raise ValueError('Workflow has an unsupported object')
            progress['stage']='extract '+key[1];persist()
            if not (ROOT/'evidence'/'source-object-properties'/f'{page:03d}_{key[1]}.json').exists():ui(source,{'extract':{'page':page,'object':name}})
        progress['stage']='validate source template';persist()
        from eb_template_guard import validate_page
        validate_page(page,names)
        if not (ROOT/'evidence'/f'target-page-{page:03d}-size.json').exists():
            progress['stage']='prepare target page';persist()
            ui(target,{'create_target_page':page} if page>=19 else {'target_page_size':page})
        settings=json.loads((ROOT/'evidence'/'source-pages-settings'/f'{page:03d}.json').read_text(encoding='utf8'))
        name=next(c['value'] for c in settings['controls'] if c['type']=='Edit' and c['name']=='窗口名称 :')
        call('snapshot')
        current=json.loads((ROOT/'evidence'/'windows.json').read_text(encoding='utf8'))
        active=next(w['title'] for w in current if w['handle']==target)
        progress['stage']='open exact page';persist()
        ui(target,{'open_target_page':page})
        for kind in ('SW','BL'):
            ids=sorted(int(re.match(r'^'+kind+r'_(\d+)\s',name)[1]) for name in names if name.startswith(kind+'_'))
            for n in ids:
                progress['stage']='build '+kind+'_'+str(n);persist()
                if not (ROOT/'evidence'/f'target-{page:03d}-{kind}{n}-built.json').exists():ui(target,{'page':page,'build_'+kind.lower():n})
                progress['completed'].append(f'{kind}_{n}');persist()
        progress['stage']='audit';persist()
        ui(target,{'target_page_audit':page})
        from eb_verify_page import run as verify
        verify(page)
        progress['ok']=True;progress['stage']='saved and audited';persist()
        print(json.dumps({'ok':True,'page':page,'objects':len(progress['completed'])},ensure_ascii=False))
    except Exception as error:
        progress['error']=str(error);persist();raise
    finally:lock.unlink(missing_ok=True)
