"""Recreate reviewed static-address page16 numeric fields, with explicit model gaps."""
import json,time
from pywinauto import Desktop
from eb_extract import ROOT,rows
from eb_native_form import tab,fields,confirm,commit_text
from eb_object_ui import target,dialog,placed_properties,save
from eb_layout import geometry


def run(handle,q):
    page=int(q['page']);kind=q['numeric_kind'];n=int(q['build_numeric'])
    if not (page==16 and kind in ('NE','ND') and n in range(4 if kind=='NE' else 8) or page in (200,202) and kind=='NE' and n in range(25)):raise ValueError('Unreviewed numeric object')
    source=json.loads((ROOT/'evidence'/'source-object-properties'/f'{page:03d}_{kind}_{n}.json').read_text(encoding='utf8'))
    if page in (200,202) and source.get('vector_identity',{}).get('family')!='System Frame':raise ValueError('Page200 original numeric vector family requires review')
    if page in (200,202) and source['vector_identity']['index']!='0':raise ValueError('Page200 original numeric vector index requires review')
    general=source['tabs']['一般属性']
    for row in general:
        if row['type']=='CheckBox' and row['name'] in ('读取/写入使用不同的地址','启用') and row.get('value')!=0:raise ValueError('Numeric dynamic/different addressing needs review')
    for row in source['tabs']['安全']:
        if row['type']=='CheckBox' and row.get('value')!=0 and not (page in (200,202) and row['name']=='当用户无权限操作此类别时弹出提示窗口' and row['value']==1):raise ValueError('Numeric security condition needs review')
    root,w=target(handle,page)
    if not q.get('resume'):
        from eb_prepare_complex import run as prepare
        prepare(handle,{'page':page,'prepare_complex':'NUM'})
    d=dialog(root.process_id(),'新增 数值');captured={}
    tab(d,'一般属性')
    if page in (200,202):fields(d,[r for r in general if r['name']=='启用输入功能'])
    normal=[row for row in general if row['name'] not in ('设备 :',' Down','Static')]
    fields(d,normal)
    fields(d,[row for row in general if row['type']=='ComboBox' and row['name']=='设备 :'])
    fields(d,[row for row in general if row['type']=='ComboBox' and row['name']==' Down'])
    fields(d,[row for row in general if row['type']=='Edit' and row['name']=='Static'])
    # The target exposes two independent index enable flags; both remain off.
    enable_count=sum(row['type']=='CheckBox' and row['name']=='启用' for row in rows(d))
    fields(d,[{'type':'CheckBox','name':'启用','value':0} for _ in range(enable_count)])
    captured['一般属性']=rows(d)
    if kind=='NE':
        original=source['tabs']['数值输入']
        flags={row['name']:row['value'] for row in original if row['type'] in ('CheckBox','RadioButton') and 'value' in row}
        if (flags.get('系统键盘'),flags.get('自定义键盘')) not in ((1,0),(0,1)):raise ValueError('Invalid source keypad flags')
        source_keypads=[row['value'] for row in original if row['type']=='ComboBox' and row['name']==' Down']
        expected_keypad='50. Keypad 1 - Integer' if flags['系统键盘'] else '51. Keypad 2 - Integer'
        if not flags['系统键盘'] and source_keypads!=[expected_keypad]:raise ValueError('Unreviewed custom keypad window')
        tab(d,'数值输入')
        fields(d,original,skip=(('CheckBox','显示上下限值'),('CheckBox','显示当前数值'),('RadioButton','系统键盘'),('RadioButton','自定义键盘'),('Edit',''),('ComboBox',' Down')))
        if not flags['系统键盘']:
            if page in (200,202):
                selectors=[c for c in d.descendants(control_type='ComboBox') if c.window_text()==' Down' and c.is_visible()]
                if len(selectors)!=1:raise ValueError('Unique numeric keypad selector required')
                from eb_address_type import choose
                choose(selectors[0],expected_keypad,d.process_id())
            else:commit_text(d,'',expected_keypad)
        captured['数值输入']=rows(d)
        choices=[row['value'] for row in captured['数值输入'] if row['type']=='ComboBox' and row['name']==' Down']
        if choices!=[expected_keypad]:raise ValueError('Unreviewed target keypad mapping')
    for name in ('格式','安全','字体'):
        tab(d,name)
        if page in (200,202) and name=='安全':fields(d,[r for r in source['tabs'][name] if r['name']=='用户限制 Down'])
        skip=(('CheckBox','使用控制权'),) if name=='安全' else (('Edit','内容'),) if name=='字体' else ()
        fields(d,source['tabs'][name],skip=skip,commit_edits=name=='格式');captured[name]=rows(d)
    tab(d,'图片')
    picture_flags=[r for r in source['tabs']['图片'] if r['type']=='CheckBox'] if page in (200,202) else [{'type':'CheckBox','name':'使用向量图','value':1},{'type':'CheckBox','name':'内部','value':1},{'type':'CheckBox','name':'外框','value':1}]
    if page in (200,202):
        unsupported={'使用图片','调整对象尺寸为图片原尺寸'}
        if any(r['value'] for r in picture_flags if r['name'] in unsupported):raise ValueError('Numeric raster image behavior requires review')
        picture_flags=[r for r in picture_flags if r['name'] not in unsupported]
    fields(d,picture_flags)
    if page in (200,202):
        from eb_frame_vector import choose
        choose(d,root.process_id())
        from eb_color_picker import set_rgb,probe
        for label,rgb in source['colors'].items():
            set_rgb(d,rgb,label)
            if probe(d,label)!=rgb:raise ValueError('Numeric source color mismatch')
    captured['图片']=rows(d);confirm(d)
    # Source and target name this unified numeric control differently.
    root.set_focus();root.click_input(coords=(963,367))
    from pywinauto.keyboard import send_keys
    send_keys('{ESC}',pause=.01);time.sleep(.1)
    from eb_object_ui import object_item
    item=object_item(w,f'{kind}_{n}');item.double_click_input(coords=(40,item.rectangle().height()//2))
    props=[]
    for _ in range(40):
        props=[win for win in Desktop(backend='win32').windows() if win.process_id()==root.process_id() and win.is_visible() and win.window_text() in ('数值的属性','数值元件的属性')]
        if len(props)==1:break
        time.sleep(.1)
    if len(props)!=1:raise ValueError('Observed numeric property title required')
    d=Desktop(backend='uia').window(handle=props[0].handle).wrapper_object()
    tab(d,'一般属性');created=rows(d)
    expected_address=next(row['value'] for row in general if row['type']=='Edit' and row['name']=='Static')
    if [row['value'] for row in created if row['type']=='Edit' and row['name']=='Static']!=[expected_address]:raise ValueError('Numeric created address mismatch')
    tab(d,'轮廓');shape=geometry(source)
    fields(d,[{'type':'Edit','name':key,'value':value} for key,value in shape.items()]);shape_readback=rows(d)
    confirm(d);save(root)
    report={'page':page,'source':source['object'],'target':f'{kind}_{n}','tabs':captured,'general':created,'geometry':shape_readback,'saved_requested':True,
            'custom_picture_review_pending':True,'font_color_review_pending':True,'trigger_actions_review_pending':True,
            'keyboard_window_50_review_pending':kind=='NE','offline_simulation_verified':False}
    (ROOT/'evidence'/f'target-{page:03d}-{kind}{n}-built.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
