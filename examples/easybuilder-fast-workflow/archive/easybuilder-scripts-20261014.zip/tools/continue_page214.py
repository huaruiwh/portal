import json,os,re,traceback
from pathlib import Path
from eb_rebuild_page import ROOT,call
r=ROOT;p=r/'evidence/page214-build-workflow.json';lock=r/'tools/batch.lock'
if lock.exists():raise RuntimeError('Controller already running')
lock.write_text(json.dumps({'pid':os.getpid(),'task':'build214'}),encoding='utf8')
d={'page':214,'built':[],'finished':False,'reference':213,'target_height':469}
def record():
 p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
 marker='\n### 2026-10-12：214页参考201重建进度'
 text=marker+'\n'+json.dumps(d,ensure_ascii=False)+'\n脚本 tools/continue_page214.py，目标890×469，源参数缓存复用，单件复制300秒。仅通过保存读回的控件计入built；颜色图库仍需原件复核，不执行源关闭宏15、不下载。\n'
 for f in ['README.md','docs/MT8106iP重建-实现记录.md']:
  path=r/f;t=path.read_text(encoding='utf8');idx=t.find(marker)
  if idx>=0:
   end=t.find('\n### ',idx+len(marker));t=t[:idx]+(t[end:]if end>=0 else '')
  path.write_text(t+text,encoding='utf8')
try:
 height=json.loads((r/'evidence/scale-890x469/page-214-initial-height.json').read_text(encoding='utf8'))
 if not height['saved_reopened_verified']:raise ValueError('Height not verified')
 call('snapshot');ws=json.loads((r/'evidence/windows.json').read_text(encoding='utf8'));h=next(w['handle']for w in ws if '组装机_MT8106iP.emtp'in w['title'])
 inv=json.loads((r/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(x['observed_objects']for x in inv['pages']if x['id']==214)
 keys=sorted([re.search(r'(?:^|\])\s*([A-Z]+_\d+)',n)[1]for n in names],key=lambda k:(k.split('_')[0],int(k.split('_')[1])))
 d['total']=len(keys);record()
 for offset in range(0,len(keys),3):
  batch=keys[offset:offset+3];pending=[]
  for key in batch:
   report=r/f'evidence/target-214-{key}-built.json'
   if not report.exists()or not json.loads(report.read_text(encoding='utf8')).get('saved_reopened_verified'):pending.append(key)
  if pending:
   d['current_batch']=pending;record();call('uia',h,json.dumps({'page214_controls':pending,'build_bit_general':0}))
  for key in batch:
   proof=json.loads((r/f'evidence/target-214-{key}-built.json').read_text(encoding='utf8'))
   if not proof['saved_reopened_verified']:raise ValueError('Unverified control '+key)
   d['built'].append(key)
  record()
 call('uia',h,json.dumps({'target_page_audit':214}));call('uia',h,json.dumps({'compile_target':True}))
 d['finished']=True;record()
except Exception as e:
 d['error']=str(e);record();raise
finally:lock.unlink(missing_ok=True)
