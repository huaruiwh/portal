import json,statistics
from eb_rebuild_page import ROOT
p=ROOT/'evidence/compact-capture-trial.json';d=json.loads(p.read_text(encoding='utf8'))
assert not d['changed'] and not d['saved'] and all(r['equal']for r in d['results'])
rows=[{'tab':r['tab'],'old_median_seconds':statistics.median(s['old_seconds']for s in r['samples']),'compact_median_seconds':statistics.median(s['compact_seconds']for s in r['samples'])}for r in d['results']]
size=(ROOT/'output/组装机_MT8106iP.emtp').stat().st_size
record=f'''

### 2026-10-11：继续寻找更快方法——整组UIA读取负向试验

用户要求进一步加速。分析TS_8阶段：一般属性差异写入0.3733164秒，保存后重开核对12.9180988秒，继续微调地址输入收益很小。新建tools/eb_compact_capture_trial.py：在201/TS_8已保存属性上，以类型一次枚举UIA字段、对原生字段用短超时消息读取值，与原eb_live_fields.capture交替对照各3次。每次字段结果完全一致；原件未触碰，目标只读打开后取消，无编辑和保存。

实测中位秒数：{json.dumps(rows,ensure_ascii=False)}。新路线明显更慢：一般属性17.0403437至19.6997114秒、标签11.0110033至12.0193208秒、轮廓7.3694746至9.0128389秒；旧路线对应约6.1、1.0、1.0秒。结论：本机Qt/Win32混合窗口下，整组UIA枚举成本大；不能凭减少代码查询次数推断真实加速。此路线仅保留试验入口，未接入生产，也未替换当前learned native identity路线。生产计数维持25/52，剩27，工程实际{size}字节；无新编译或运行验收。测试等待期间response仍是旧请求结果，不作为本次完成证据；最后控制器finished且新报告生成才确认试验完成。

复现请求原文：{{"fast_fields_benchmark":true,"compact_capture":true,"build_bit_general":0}}，调用tools/eb_rebuild_page.call('uia',10488686,json.dumps(request))，需管理员worker可用且无其它控制器；只读试验约3分钟，不需要反复运行。证据evidence/compact-capture-trial.json。已验证最快生产方案仍是同模板连续复制、差异写入、批次目录审计，平均28.11213345秒/件。下一步候选：一般参数只核对修改字段与地址设备类型，其余采用已验证模板及批次不变项审计；精确对象属性直接入口减少目录定位；真正原生字段映射取代Qt查询。尚未实现或计时，不能称几秒或已达最优。安全条件、原图库、文字、地址和几何不能省略；不通过未验证二进制修改或控制宏求速度。
'''
for f in (ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md'):
    with f.open('a',encoding='utf8')as stream:stream.write(record)
cp=ROOT/'evidence/resume-checkpoint.json';v=json.loads(cp.read_text(encoding='utf-8-sig'));v.update(batch_running=False,compact_capture_trial_adopted=False,compact_capture_trial_report='evidence/compact-capture-trial.json',next_action='Keep verified batch route. Consider changed-field readback plus batch invariant verification; not yet validated. TS_9 not created; no duplicate TS_0..8.')
cp.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'adopted':False,'docs_updated':2,'medians':rows},ensure_ascii=False))
