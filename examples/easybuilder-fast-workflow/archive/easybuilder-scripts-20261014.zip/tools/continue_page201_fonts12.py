import json,os
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
with lock.open('x',encoding='utf8')as f:f.write(json.dumps({'pid':os.getpid(),'task':'201 font12'}))
try:
    call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'));h=next(w['handle']for w in ws if w['class']=='EasyBuilderPro'and'组装机_MT8106iP.emtp'in w['title'])
    keys=[f'TX_{n}'for n in range(13)]+[f'TS_{n}'for n in range(15)]
    for start in range(0,len(keys),5):
        batch=keys[start:start+5];call('uia',h,json.dumps({'page201_font_batch':batch,'build_bit_general':0},ensure_ascii=False));print(json.dumps({'font12_verified':batch,'total':min(start+5,len(keys))}),flush=True)
finally:lock.unlink()
