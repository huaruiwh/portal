"""Observed native form schemas; no persistent HWND or value cache."""
import ctypes,json,hashlib,time
from pathlib import Path
from types import SimpleNamespace
from pywinauto import Desktop
from eb_native_messages import visible_handles,text,combo_text,msg
U=ctypes.windll.user32
ROOT=Path(__file__).resolve().parent.parent
DIR=ROOT/'evidence/native-form-profiles-v2'
_cache={}
_virtual_cache={}
def clear(handle):
 h=int(handle);_cache.pop(h,None)
 for key in list(_virtual_cache):
  if key[0]==h:_virtual_cache.pop(key,None)

def virtual_fields(d,typ):
 # Qt virtual fields have no HWND. Reuse only inside the same live dialog/tab
 # and unchanged native child handles; values are read from the provider live.
 signature=tuple(visible_handles(int(d.handle),('Edit','RichEdit20W','RichEdit20A','ComboBox','Button')))
 key=(int(d.handle),typ,signature)
 if key not in _virtual_cache:
  _virtual_cache[key]=[c for c in d.descendants(control_type=typ,cache_enable=True) if c.is_visible()]
 return _virtual_cache[key]
def native_caption(h):
 b=ctypes.create_unicode_buffer(1024);U.GetWindowTextW(h,b,1024);return b.value
def native_class(h):
 b=ctypes.create_unicode_buffer(128);U.GetClassNameW(h,b,128);return b.value
class NativeField:
 def __init__(self,h,typ,name,cls):
  self.handle=h;self.element_info=SimpleNamespace(handle=h,control_type=typ,name=name,class_name=cls);self._uia=None
 def is_visible(self):return bool(U.IsWindow(self.handle) and U.IsWindowVisible(self.handle))
 def is_enabled(self):return bool(U.IsWindowEnabled(self.handle))
 def window_text(self):return self.element_info.name
 def class_name(self):return self.element_info.class_name
 def get_value(self):return text(self.handle)
 def selected_text(self):return combo_text(self.handle)
 def __getattr__(self,name):
  if self._uia is None:self._uia=Desktop(backend='uia').window(handle=self.handle).wrapper_object()
  return getattr(self._uia,name)
def current(d):
 for attempt in range(3):
  try:return _current_once(d)
  except ValueError as error:
   if str(error)!='Field changed while observing schema' or attempt==2 or not U.IsWindow(d.handle):raise
   clear(d.handle);time.sleep(.1)

def _current_once(d):
 h=int(d.handle)
 if not U.IsWindow(h):raise ValueError('Property dialog disappeared')
 handles=visible_handles(h,('Edit','RichEdit20W','RichEdit20A','ComboBox','Button'))
 signature=tuple(handles)
 old=_cache.get(h)
 if old and old[0]==signature:return old[1]
 from ctypes.wintypes import RECT
 base=RECT();U.GetWindowRect(h,ctypes.byref(base))
 def descriptor(v):
  box=RECT();U.GetWindowRect(v,ctypes.byref(box));parents=[];parent=U.GetParent(v)
  for _ in range(12):
   if not parent or parent==h:break
   parents.append((native_class(parent),U.GetDlgCtrlID(parent)));parent=U.GetParent(parent)
  return (native_class(v),U.GetDlgCtrlID(v),U.GetWindowLongW(v,-16),parents,(box.left-base.left,box.top-base.top,box.right-base.left,box.bottom-base.top))
 desc=[descriptor(v)for v in handles]
 labels=[(native_class(v),native_caption(v))for v in visible_handles(h,('Static','Button')) if native_caption(v)]
 tabs=visible_handles(h,('SysTabControl32',))
 tab=msg(tabs[0],0x130B)if len(tabs)==1 else None
 identity={'version':2,'title':native_caption(h),'tab':tab,'controls':desc,'labels':labels}
 key=hashlib.sha256(json.dumps(identity,ensure_ascii=False,sort_keys=True).encode('utf8')).hexdigest()
 DIR.mkdir(exist_ok=True);path=DIR/(key+'.json')
 controls=[];profile=None
 if path.exists():
  data=json.loads(path.read_text(encoding='utf8'))
  if data.get('identity')==json.loads(json.dumps(identity)) and len(data['fields'])==len(handles):profile=data['fields']
 if profile:
  for handle,cls,row in zip(handles,desc,profile):
   typ,name=row['type'],row['name'];c=NativeField(handle,typ,name,cls[0]);controls.append((handle,typ,name,c))
 else:
  fields=[]
  for handle in handles:
   if not U.IsWindow(handle):raise ValueError('Field changed while observing schema')
   c=Desktop(backend='uia').window(handle=handle).wrapper_object()
   typ,name=c.element_info.control_type,c.element_info.name
   fields.append({'type':typ,'name':name});controls.append((handle,typ,name,c))
  path.write_text(json.dumps({'identity':identity,'fields':fields,'method':'observed UIA identities; validated native structure'},ensure_ascii=False,indent=2),encoding='utf8')
 with (ROOT/'evidence/native-profile-use.jsonl').open('a',encoding='utf8')as f:f.write(json.dumps({'key':key,'title':identity['title'],'tab':tab,'profile_hit':bool(profile),'field_count':len(handles)},ensure_ascii=False)+'\n')
 _cache[h]=(signature,controls)
 return controls
