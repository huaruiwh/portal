"""Choose the original installed three-state selector family by metadata."""
from pywinauto import Desktop
from eb_native_form import confirm

def choose_gallery(pid):
    windows=[w for w in Desktop(backend='win32').windows() if w.process_id()==pid and w.window_text()=='图片管理' and w.is_visible()]
    if len(windows)!=1:raise ValueError('Observed selector gallery required')
    gallery=Desktop(backend='uia').window(handle=windows[0].handle).wrapper_object()
    entries=[(c.element_info.name,c.rectangle()) for c in gallery.descendants(control_type='Text',cache_enable=True) if c.is_visible()]
    def group_texts(group):
        box=group.rectangle()
        return [name for name,rect in entries if box.left<=rect.left<box.right and box.top<=rect.top<box.bottom]
    groups=[g for g in gallery.descendants(control_type='Group',cache_enable=True) if g.is_visible() and g.element_info.name.isdigit() and 'Selector_3_Position_Green' in group_texts(g)]
    if len(groups)!=1:raise ValueError('Exact installed green selector required')
    texts=group_texts(groups[0])
    if '状态数 : 3' not in texts:raise ValueError('Three selector images required')
    groups[0].click_input(coords=(60,70));confirm(gallery)


def choose_existing(d,pid):
    import time
    controls=[c for c in d.descendants(control_type='Button',cache_enable=True) if c.element_info.name=='图库...' and c.is_visible()]
    if len(controls)!=2:raise ValueError('Two picture galleries required')
    existing=[w for w in Desktop(backend='win32').windows() if w.process_id()==pid and w.window_text()=='图片管理' and w.is_visible()]
    if not existing:controls[0].click_input()
    for _ in range(15):
        existing=[w for w in Desktop(backend='win32').windows() if w.process_id()==pid and w.window_text()=='图片管理' and w.is_visible()]
        if len(existing)==1:break
        time.sleep(.1)
    ws=[w for w in Desktop(backend='win32').windows() if w.process_id()==pid and w.window_text()=='图片管理' and w.is_visible()]
    if len(ws)!=1:raise ValueError('Picture gallery required')
    g=Desktop(backend='uia').window(handle=ws[0].handle).wrapper_object()
    menu=[c for c in g.descendants(control_type='MenuItem',cache_enable=True) if c.is_visible() and c.element_info.name and c.rectangle().top<g.rectangle().top+150]
    if len(menu)!=1:raise ValueError('Single picture library menu required')
    if menu[0].element_info.name!='选择开关':
        menu[0].click_input();time.sleep(.1)
        choices=[]
        for w in Desktop(backend='win32').windows():
            if w.process_id()==pid and w.class_name().startswith('Qt5QWindowPopup') and w.is_visible():
                u=Desktop(backend='uia').window(handle=w.handle).wrapper_object()
                choices.extend(c for c in u.descendants(control_type='MenuItem',cache_enable=True) if c.element_info.name=='选择开关' and c.is_visible())
        if len(choices)!=1:raise ValueError('Existing imported selector library required')
        choices[0].click_input();time.sleep(.1)
    choose_gallery(pid)
