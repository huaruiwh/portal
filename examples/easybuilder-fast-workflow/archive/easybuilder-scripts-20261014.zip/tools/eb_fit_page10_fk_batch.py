import json
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
with lock.open('x'):pass
try:
 call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'));w=next(w for w in ws if w['class']=='EasyBuilderPro' and '_MT8106iP_' in w['title'])
 call('uia',w['handle'],json.dumps({'open_target_page':10}))
 for i in range(6):
  call('uia',w['handle'],json.dumps({'fit_page10_fk':'FK_'+str(i)}));print(i,'saved',flush=True)
finally:lock.unlink(missing_ok=True)
