"""Preserve original page200 bit interlocks across cMT/MT safety form differences."""
import json,time,subprocess,re
from pywinauto.keyboard import send_keys
from pywinauto import Desktop
from eb_extract import ROOT,rows
from eb_native_form import fields

def apply(d,source):
 rs=source['tabs']['安全'];fields(d,[r for r in rs if r['type']=='CheckBox'])
 prefix=[];seen_down=0
 for r in rs:
  if r['type']=='ComboBox' and r['name']==' Down':
   seen_down+=1
   if seen_down==3:break
  prefix.append(r)
 fields(d,prefix)
 selectors=[c for c in d.descendants(control_type='ComboBox') if c.window_text()==' Down' and c.is_visible()]
 vals=[r['value'] for r in rs if r['type']=='ComboBox' and r['name']==' Down']
 if len(vals)!=5 or vals[2]!='关闭时不执行任何操作' or vals[4]!='位' or len(selectors)!=4:raise ValueError('Unreviewed page200 source/target bit safety form')
 behavior=selectors[2];wanted=vals[2]
 if behavior.selected_text()!=wanted:
  from PIL import ImageGrab
  Desktop(backend='win32').window(handle=d.handle).set_focus()
  behavior.click_input(coords=(behavior.rectangle().width()-12,behavior.rectangle().height()//2));time.sleep(.25)
  menus=[w for w in Desktop(backend='win32').windows(process=d.process_id()) if w.is_visible() and w.class_name().startswith('Qt5QWindowPopup')]
  if len(menus)!=1:raise ValueError('Unique observed safety behavior popup required')
  popup=menus[0];rect=popup.rectangle()
  image=ROOT/'evidence/page200-safety-popup-local.png';out=ROOT/'evidence/page200-safety-popup-ocr.json'
  ImageGrab.grab(bbox=(rect.left,rect.top,rect.right,rect.bottom)).save(image)
  code=(ROOT/'tools/Read-LocalImageText.ps1').read_text(encoding='utf8')
  code=code.replace('param([string]$ImagePath,[string]$OutputPath)',"$ImagePath='"+str(image).replace("'","''")+"';$OutputPath='"+str(out).replace("'","''")+"'")
  result=subprocess.run([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe','-NoProfile','-Command',code],capture_output=True,text=True,timeout=30)
  if result.returncode:raise RuntimeError(result.stderr)
  ocr=json.loads(out.read_text(encoding='utf-8-sig'));lines={}
  for word in ocr['words']:
   center=word['y']+word['height']/2
   bucket=next((k for k in lines if abs(k-center)<7),center)
   lines.setdefault(bucket,[]).append(word)
  matches=[]
  for y,words in lines.items():
   caption=''.join(w['text'] for w in sorted(words,key=lambda w:w['x']))
   normalized=re.sub(r'\s','',caption)
   # Local OCR may omit 操 in 操作; require the unique identifying phrase,
   # then require the full exact UIA selected value before any confirmation.
   if normalized==wanted or (wanted=='关闭时不执行任何操作' and normalized=='关闭时不执行任何作'):matches.append((y,words))
  if len(matches)!=1:raise ValueError('Exact original safety behavior not recognized in local popup: '+ocr['text'])
  y,words=matches[0];x=sum(w['x']+w['width']/2 for w in words)/len(words)
  popup.click_input(coords=(int(x),int(y)));time.sleep(.2)
  if behavior.selected_text()!=wanted:raise ValueError('Original safety behavior mouse readback mismatch')
  (ROOT/'evidence/page200-safety-mode-options.json').write_text(json.dumps({'source':vals,'local_popup_text':ocr['text'],'selected':behavior.selected_text(),'method':'local OCR exact phrase then native readback; no screenshot transmitted'},ensure_ascii=False,indent=2),encoding='utf8')
 # MT bit controls have no cMT bit/word selector: the I bit address fixes bit mode.
 adapted=[];down_index=0
 for r in rs:
  if r['type']=='ComboBox' and r['name']==' Down':
   down_index+=1
   if down_index==5:continue
  adapted.append(r)
 fields(d,adapted)
 after=rows(d)
 expected=[(r['type'],r['name'],r['value']) for r in adapted if 'value' in r]
 actual=[(r['type'],r['name'],r['value']) for r in after if 'value' in r]
 if expected!=actual:raise ValueError('Page200 target safety fields differ after model adaptation')
 (ROOT/'evidence/page200-safety-model-adaptation.json').write_text(json.dumps({'source_bit_word_selector':'位','target_has_selector':False,'target_behavior':wanted,'adapted_expected':expected,'native_readback':actual,'matched':True},ensure_ascii=False,indent=2),encoding='utf8')
