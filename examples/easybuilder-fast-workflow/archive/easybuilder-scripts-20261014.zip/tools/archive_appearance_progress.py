from eb_rebuild_page import ROOT
import json
from datetime import datetime
stamp=datetime.now().isoformat(timespec='seconds')
def good(p,key):
 try:return bool(json.loads(p.read_text(encoding='utf-8-sig')).get(key))
 except (FileNotFoundError,ValueError):return False
shape=sum(good(ROOT/f'evidence/page26-TS{n}-shape-correction.json','saved') for n in range(7))
color=sum(good(ROOT/f'evidence/page26-TS{n}-color-correction.json','native_reopened_rgb_verified') for n in range(7))
bl=good(ROOT/'evidence/page26-BL0-shape-correction.json','saved')
text=f'''
### {stamp} 26页修正后推广规律

- 已完成26页TS图形{shape}/7、保存后原色读回{color}/7；BL0图形保存和重开地址/尺寸核对={bl}。BL原色以各自color-correction报告为准，未写报告不得算完成。
- 原件图库实查：Button - Standard / 3 / 143x64；Switch - Flat / 5 / 70x29；Lamp - Flat / 3 / 143x64。源BL0图库证据page26-BL0-source-gallery-local.png；只读取原件，图库取消退出，不保存源工程。
- 原因：旧目标统一使用Button - Flat，不能依据相同尺寸推断图库。BL3—6启用向量，尚须查实际向量及内外框颜色，不能套用灯图片规则。
- 自动队列在27页前主动边界退出，原报错为`Queue boundary: original lamp gallery review required before extending repair scope`，用于先核实灯图库，并非新增失败。恢复入口：Python tools/eb_fix_flow_appearances.py；脚本逐个检查saved和native_reopened_rgb_verified后跳过，串行请求，不重复新增。先确保没有控制器、请求响应同ID以及属性弹窗退出。
- 新增pilot_lamp_once.py只读源图库；pilot_lamp_repair.py修既有BL0并核对颜色；eb_picture_family.py加入已观察的System Lamp / Flat路径，page26-lamp-gallery-approved.json记录编号3。旧编译不代表本轮新编译，运行交互仍未验收。
- 后续范围26—45及47，共21页142个TS按钮；灯与向量分别核实后处理。保留103用户TS0模板。省流量策略：缓存已验证源数据，复用规则，只回传文字结果；颜色按原件状态0/1实际RGB，不能统一替换。
'''
for rel in ('README.md','docs/MT8106iP重建-实现记录.md'):
 p=ROOT/rel;p.write_text(p.read_text(encoding='utf8')+'\n'+text,encoding='utf8')
print(f'documented: TS shapes {shape}/7; colors {color}/7; BL0 shape {bl}')
