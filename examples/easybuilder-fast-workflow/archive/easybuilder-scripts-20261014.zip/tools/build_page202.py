"""Only page202, cached source identity; serial saved checkpoints, no downloads."""
import os,json,re,traceback
from datetime import datetime
from eb_rebuild_page import ROOT,call

def ui(h,q):return call('uia',h,json.dumps(q,ensure_ascii=False))
def main():
 if (ROOT/'evidence/page202-whole-page-copy.json').exists():raise ValueError('202 already copied; use rewrite_page202_copy.py, never rebuild duplicates')
 lock=ROOT/'tools/batch.lock'
 with lock.open('x',encoding='utf8') as f:json.dump({'pid':os.getpid(),'task':'build202'},f)
 p=ROOT/'evidence/page-202-build-workflow.json';d={'date':datetime.now().isoformat(),'completed':[],'status':'building','pid':os.getpid()}
 try:
  from eb_flow_model import counts
  counts(202)
  if not (ROOT/'evidence/target-page-202-created.json').exists():ui(10488686,{'create_target_page':202})
  ui(10488686,{'open_target_page':202})
  inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(x['observed_objects'] for x in inv['pages'] if x['id']==202)
  for name in names:
   key=re.search(r'(?:^|\])\s*([A-Z]{2}_\d+)',name)[1];kind,num=key.split('_');n=int(num);d['stage']=key;p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8');rp=ROOT/f'evidence/target-202-{kind}{n}-built.json'
   if not rp.exists():
    if kind=='NE' and n>0:q={'copy_page202_numeric':n}
    elif kind=='BL' and n>=4:q={'copy_page202_lamp':n}
    elif kind=='TX':q={'build_tx':n}
    elif kind=='SP':q={'build_sp':n}
    elif kind in ('TS','BL','SW'):q={'build_bit_general':n,'bit_kind':kind}
    elif kind=='NE':q={'build_numeric':n,'numeric_kind':'NE'}
    elif kind=='DW':q={'build_rectangle':n}
    elif kind=='FK':q={'build_fk':n}
    elif kind=='TB':q={'build_page202_table':True}
    else:raise ValueError('Unreviewed kind')
    q['page']=202
    if 'build_bit_general' not in q:q['build_bit_general']=0
    ui(10488686,q)
   source=json.loads((ROOT/f'evidence/source-object-properties/202_{key}.json').read_text(encoding='utf8'));built=json.loads(rp.read_text(encoding='utf8'))
   if kind in ('TS','BL','SW') and not built.get('picture_colors_verified'):ui(10488686,{'page202_button_colors':True,'kind':kind,'number':n,'build_bit_general':0})
   fp=ROOT/f'evidence/font-adjustments/202_{key}.json'
   if kind in ('TX','TS','SW','NE','FK') and not (kind=='NE' and n>0):
    old=json.loads(fp.read_text(encoding='utf8')) if fp.exists() else {}
    if not old.get('verified'):
     q={'adjust_fonts':True,'page':202,'key':key,'build_bit_general':0}
     if kind in ('TS','SW'):q['uniform_button_size']=13
     elif kind=='TX':q['size_override']=11 if n==12 else 12
     elif kind in ('NE','FK'):q['size_override']=13
     if not old.get('save_requested'):ui(10488686,dict(q,phase='edit'))
     ui(10488686,dict(q,phase='verify'))
   d['completed'].append(key);p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps({'saved':key,'count':len(d['completed'])}),flush=True)
  d['status']='saved-74-controls-review-pending'
 except Exception:d['status']='needs-review';d['error']=traceback.format_exc();print(d['error'],flush=True)
 finally:
  p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8');lock.unlink(missing_ok=True)
if __name__=='__main__':main()

