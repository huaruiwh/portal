"""Small command line for offline checks and no-screenshot UIA batches."""
import argparse, json, subprocess, sys, time, uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('check')
    rebuild=sub.add_parser('rebuild-page')
    rebuild.add_argument('--page',type=int,required=True)
    sequence=sub.add_parser('rebuild-pages')
    sequence.add_argument('--pages',type=int,nargs='+',required=True)
    batch = sub.add_parser('batch')
    batch.add_argument('--handle', type=int, required=True)
    batch.add_argument('--job', type=Path, required=True)
    args = parser.parse_args()
    if args.command in ('rebuild-page','rebuild-pages'):
        from eb_rebuild_page import run
        for page in args.pages if args.command=='rebuild-pages' else [args.page]:
            try:
                run(page)
            except Exception as error:
                print(json.dumps({'ok':False,'page':page,'error':type(error).__name__,
                                  'details':str(ROOT/'evidence'/f'page-{page}-workflow.json')},ensure_ascii=False))
                raise SystemExit(1)
        return
    if args.command == 'check':
        subprocess.run([sys.executable, str(ROOT/'tools'/'audit_original_macros.py')], check=True, capture_output=True)
        macros = json.loads((ROOT/'evidence'/'original-macros-dependency-audit.json').read_text(encoding='utf8'))
        buttons = json.loads((ROOT/'evidence'/'window10-buttons-manifest.json').read_text(encoding='utf-8-sig'))
        verified=[]
        for path in sorted((ROOT/'evidence').glob('target-page*-audit.json')):
            tree=json.loads(path.read_text(encoding='utf-8-sig'))
            parameters=ROOT/'evidence'/f"page-{tree['page']}-parameter-audit.json"
            if tree.get('tree_verified') and parameters.exists() and json.loads(parameters.read_text(encoding='utf-8-sig')).get('ok'):
                verified.append({'page':tree['page'],'objects':tree['target_count']})
        print(json.dumps({'macro_count': macros['macro_count'], 'io_calls': macros['io_call_count'],
                          'automatic_execution_ids': macros['automatic_execution_ids'],
                          'pending_window10_buttons': sum(b['status'] not in ('saved_verified','created_saved') for b in buttons),
                          'parameter_verified_pages':verified,'parameter_verified_objects':sum(p['objects'] for p in verified),
                          'whole_project_complete':False,'offline_simulation_verified':False,'project_bytes':
                          (ROOT/'output'/'组装机_MT8106iP.emtp').stat().st_size}, ensure_ascii=False))
        return
    job = json.loads(args.job.read_text(encoding='utf-8-sig'))
    if not 1 <= len(job['batch']) <= 12:
        raise ValueError('Use 1..12 steps per batch; split at dialog boundaries')
    lock = ROOT/'tools'/'batch.lock'
    with lock.open('x', encoding='utf8'):
        pass
    try:
        rid = str(uuid.uuid4())
        request = {'id': rid, 'action': 'uia', 'handle': args.handle,
                   'text': json.dumps(job, ensure_ascii=False), 'wait': 0}
        temp = ROOT/'tools'/'request.tmp'
        temp.write_text(json.dumps(request, ensure_ascii=False), encoding='utf8')
        temp.replace(ROOT/'tools'/'request.json')
        end = time.monotonic() + 30
        while time.monotonic() < end:
            try:
                response = json.loads((ROOT/'evidence'/'response.json').read_text(encoding='utf8'))
            except (FileNotFoundError, json.JSONDecodeError):
                time.sleep(.1)
                continue
            if response.get('id') == rid:
                if not response.get('ok'):
                    raise RuntimeError(response.get('error'))
                report = json.loads((ROOT/'evidence'/'batch-result.json').read_text(encoding='utf8'))
                print(json.dumps({key: report[key] for key in ('ok', 'steps_completed', 'elapsed_seconds')}))
                return
            time.sleep(.1)
        raise TimeoutError('Worker response timeout; inspect state before retrying')
    finally:
        lock.unlink(missing_ok=True)

if __name__ == '__main__':
    main()
