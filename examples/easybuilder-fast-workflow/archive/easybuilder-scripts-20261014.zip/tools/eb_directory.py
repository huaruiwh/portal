"""Restrict directory queries to the uniquely observed left dock panel."""
def scope(window):
    r=window.rectangle()
    panels=[]
    for c in window.children(cache_enable=True):
        box=c.rectangle()
        if r.left<=box.left<r.left+30 and box.right<r.left+500 and box.height()>500 and c.is_visible():panels.append(c)
    return panels[0] if len(panels)==1 else window
