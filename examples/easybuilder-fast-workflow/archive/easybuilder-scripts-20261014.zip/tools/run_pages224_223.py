import subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent.parent
for name in ('cache_page224.py','start_page224.py','cache_page223.py','start_page223.py'):
 p=subprocess.run([sys.executable,str(r/'tools'/name)],cwd=r)
 if p.returncode:sys.exit(p.returncode)
