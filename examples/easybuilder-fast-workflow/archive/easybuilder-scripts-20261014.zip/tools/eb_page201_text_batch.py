import json,time
from eb_rebuild_page import ROOT
from eb_build_tx import run as build
from eb_copy_200_style_object import read_audit
from eb_object_ui import target,properties
from eb_native_form import tab
from eb_page26_shapes import cancel
from eb_live_fields import capture
from eb_original_style_existing import verify_fields
from eb_layout import geometry
from eb_adjust_fonts import fitted
from eb_page208 import write

def run(handle,q):
    ids=q['page201_text_batch']
    if ids not in ([0,1,2],[3,4,5],[6,7,8],[9,10,11,12]):raise ValueError('Reviewed text batches only')
    t=time.perf_counter();a=read_audit(handle,201);done=[]
    recoverable={f'TX_{n}'for n in ids if (ROOT/f'evidence/target-201-TX{n}-built.json').exists()}
    if a['unexpected']or any(k not in recoverable for k in a['address_name_mismatch']):raise ValueError('Initial directory mismatch')
    for n in ids:
        key=f'TX_{n}';rp=ROOT/f'evidence/target-201-TX{n}-built.json';phase=ROOT/f'evidence/target-201-TX{n}-text-phase.json'
        if rp.exists()and json.loads(rp.read_text(encoding='utf8')).get('saved_reopened_verified'):continue
        if not rp.exists():
            if phase.exists()or key not in a['missing']:raise ValueError('Unknown creation phase; inspect '+key)
            write(phase,{'stage':'creation-requested','key':key})
            build(handle,{'page':201,'build_tx':n})
        root,w=target(handle,201);d,_=properties(root,w,key,'文字/批注的属性')
        s=json.loads((ROOT/f'evidence/source-object-properties/201_{key}.json').read_text(encoding='utf8'));g=geometry(s);size,_=fitted(s['tabs']['文字/批注'],[{'type':'Edit','name':k,'value':v}for k,v in g.items()],201,13)
        try:
            tab(d,'文字/批注');want=[{'type':'Edit','name':'内容','value':next(r['value']for r in s['tabs']['文字/批注']if r['type']=='Edit'and r['name']=='内容')},{'type':'ComboBox','name':'字体 :','value':'微软正黑体 Light'},{'type':'ComboBox','name':'尺寸 :','value':str(size)}]
            verify_fields(capture(d,[(r['type'],r['name'])for r in want]),want)
            tab(d,'轮廓');verify_fields(capture(d,[('Edit',k)for k in g]),[{'type':'Edit','name':k,'value':v}for k,v in g.items()])
        finally:cancel(d)
        r=json.loads(rp.read_text(encoding='utf8'));r.update(saved_reopened_verified=True,font='微软正黑体 Light',font_size=size,original_text_preserved=True);write(rp,r);write(phase,{'stage':'verified','key':key});done.append(key)
    after=read_audit(handle,201)
    if any(f'TX_{n}'in after['missing']for n in ids)or after['unexpected']or after['address_name_mismatch']:raise ValueError('Text final directory mismatch')
    write(ROOT/('evidence/page201-text-batch-'+ '-'.join(map(str,ids))+'.json'),{'finished':True,'done':done,'seconds':time.perf_counter()-t,'count':after['target_count'],'remaining':len(after['missing'])})
