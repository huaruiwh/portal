"""Sync actual page16 evidence into the same documentation; never operates GUI."""
import json,time,sys,re
from datetime import datetime
from eb_rebuild_page import ROOT
BEGIN='<!-- PAGE16-LIVE-BEGIN -->';END='<!-- PAGE16-LIVE-END -->'
def sync():
 a=json.loads((ROOT/'evidence/target-page16-audit.json').read_text(encoding='utf8'))
 running=(ROOT/'tools/batch.lock').exists()
 r=json.loads((ROOT/'evidence/page16-missing-indicator-workflow.json').read_text(encoding='utf8'))
 switches=ROOT/'evidence/page16-missing-switch-workflow.json'
 sr=json.loads(switches.read_text(encoding='utf8')) if switches.exists() else {}
 appearance=ROOT/'evidence/page16-switch-appearance-workflow.json'
 ar=json.loads(appearance.read_text(encoding='utf8')) if appearance.exists() else {}
 final_path=ROOT/'evidence/page16-final-reopened.json'
 fr=json.loads(final_path.read_text(encoding='utf8')) if final_path.exists() else {}
 lamp_path=ROOT/'evidence/page16-existing-indicator-workflow.json'
 lamps=json.loads(lamp_path.read_text(encoding='utf8')) if lamp_path.exists() else {}
 size=(ROOT/'output/组装机_MT8106iP.emtp').stat().st_size
 p=ROOT/'evidence/resume-checkpoint.json';d=json.loads(p.read_text(encoding='utf8'));d.update(page16_source_objects=101,page16_objects=a['target_count'],page16_missing_objects=len(a['missing']),page16_texts_completed=11,bytes=size,batch_running=running,page16_indicator_stage=r['stage'],page16_indicator_phase=r.get('phase'),page16_indicator_saved=len(r['completed']),page16_indicator_workflow_ok=r['ok'],next='先核对batch.lock、page16-missing-indicator-workflow.json及worker/request/response；11个TX已保存不重复新增。指标源状态颜色已逐件采集，当前BL流程未结束前不并发GUI。继续7TS、AL0、DW4；向量形状最终对照、编译与重开仍待。');p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
 d.update(page16_model_adaptation_objects=a.get('model_adaptation_objects',[]),page16_switch_workflow=sr,next='先核对batch.lock及worker/request/response，缺失TS用python tools/eb_complete_page16_switches.py；101原控件外有DW5/TX31/TX32三个报警标题型号适配组件。源图库选择开关第一屏为Green，银红Selector_3_Position_Metal_Silver-Red在下一屏，图库须先激活后翻页。不重复新增，之后复核旧TS0..10图片/最短按压、矩形样式、保存编译重开。')
 d.update(date=datetime.now().date().isoformat(),page16_switch_appearance=ar,page16_final_reopened=fr)
 if ar.get('ok'):d['next']='旧TS0..10修复已保存，禁止重复创建；继续python tools/eb_finish_page16.py，若已有final-reopened阶段必须根据实际UI恢复，不重复重开。'
 if fr.get('ok'):d['next']='16页补件、原按钮样式修正、编译及11件重开抽查完成；后续外观细节和离线/实机交互验收另有未完成项，禁止下载PLC/HMI或运行PLC宏。'
 d['page16_existing_indicator_repair']=lamps
 if fr.get('reopened_pid'):d.update(target_pid=fr['reopened_pid'],target_handle=fr['reopened_handle'])
 if lamps and (not lamps.get('ok') or fr.get('project_bytes')!=size):d['next']='BL0..4原有指示灯正在按源修复，读取page16-existing-indicator-workflow.json及实际弹窗；无batch.lock后用同一修复脚本续作，不新增。该阶段改动后必须重新编译并运行eb_finish_page16.py，旧重开证据不能代替。'
 p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
 block=f"{BEGIN}\n2026-10-09 16页实时归档：源101件，目标最新目录{a['target_count']}件，仍缺{len(a['missing'])}件；EMTP {size}字节。TX_20..30共11件、BL_5..32共28件已保存。AL0原生报警和DW4已保存；MT没有cMT标题页，用DW5/TX31/TX32三件补源蓝字RGB0/0/255、背景RGB192/208/224。AL消息显示字符37，日期隐藏、网格关闭，body与24像素标题合计高185。目标最终应104物理件，对应101源件+3型号适配，源目录保持101。TS流程stage={sr.get('stage')}，phase={sr.get('phase')}，保存{len(sr.get('completed',[]))}件，ok={sr.get('ok')}；batch.lock存在={running}。本轮最终编译/重开/形状对照未完成。\n关键修正：eb_color_picker允许标签矩形包含颜色按钮，修复Color selector not unique；Qt排序表格字段需commit_edits=True，修复Native property readback mismatch；属性palette延迟须复用而非重复创建。源金属银红旋钮位于选择开关图库翻页后的Selector_3_Position_Metal_Silver-Red，95x109；图库必须set_focus后导航，绿色group0不是原件。标准按钮System Button→Standard。eb_press_safety从源安全Down读取0.5/0.1，不再固定0.1。\n恢复命令：python tools/eb_complete_page16_switches.py；已有控制器时不要执行第二次，出错先检查实际弹窗与saved report。python tools/eb_sync_page16_checkpoint.py仅归档，不操作GUI。旧页TS0..10样式和安全仍须复核；不把基础保存当运行验收。\n{END}"
 for p in (ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md'):
  block=block.replace('2026-10-09 16页实时归档',datetime.now().isoformat(timespec='seconds')+' 16页实时归档')
  if not block.endswith(END):raise ValueError('Live documentation block marker required')
  s=p.read_text(encoding='utf8');pattern=re.escape(BEGIN)+r'.*?'+re.escape(END)
  if BEGIN in s:s=re.sub(pattern,lambda _:block,s,flags=re.S)
  else:s+='\n\n'+block+'\n'
  p.write_text(s,encoding='utf8')
 return r['ok'] or ('error' in r and not running)
if __name__=='__main__':
 if '--watch' in sys.argv:
  last=None
  while True:
   try:
    p=ROOT/'evidence/page16-missing-indicator-workflow.json';stamp=p.stat().st_mtime_ns
    if stamp!=last:
     last=stamp
     if sync():break
   except (FileNotFoundError,json.JSONDecodeError):pass
   time.sleep(2)
 else:sync()
