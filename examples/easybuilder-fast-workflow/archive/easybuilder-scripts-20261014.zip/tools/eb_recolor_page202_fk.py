import json
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save
from eb_native_form import tab,confirm
from eb_color_picker import set_rgb,probe
from eb_page26_shapes import cancel
from eb_extract import rows

def run(handle,q):
 root,w=target(handle,202);s=json.loads((ROOT/'evidence/source-object-properties/202_FK_0.json').read_text(encoding='utf8'));colors=s['state_colors']
 d,_=properties(root,w,'FK_0','功能键的属性');tab(d,'轮廓');before=rows(d)
 def visit(write):
  result={}
  for scope,states in colors.items():
   tab(d,scope);cs=[c for c in d.descendants(control_type='ComboBox') if c.is_visible() and c.window_text()=='状态 :' and c.element_info.class_name=='ComboBox']
   if len(cs)!=1:raise ValueError('Unique FK0 state selector required')
   result[scope]={}
   for state,labels in states.items():
    ComboBoxWrapper(cs[0].handle).select(state);result[scope][state]={}
    for label,color in labels.items():
     if write:set_rgb(d,color,label)
     actual=probe(d,label)
     if actual!=color:raise ValueError('FK0 exact color mismatch')
     result[scope][state][label]=actual
  return result
 visit(True);confirm(d);save(root);d,_=properties(root,w,'FK_0','功能键的属性');actual=visit(False)
 tab(d,'轮廓');after=rows(d)
 sig=lambda rs:[(x['type'],x['name'],x['value']) for x in rs if 'value' in x]
 if sig(before)!=sig(after):raise ValueError('Recolor changed geometry')
 cancel(d);p=ROOT/'evidence/target-202-FK0-built.json';report=json.loads(p.read_text(encoding='utf8'));report.update(state_colors=actual,colors_saved_reopened_verified=True);p.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 (ROOT/'evidence/page202-FK0-color-verification.json').write_text(json.dumps({'state_colors':actual,'geometry_unchanged':True,'saved_reopened_verified':True},ensure_ascii=False,indent=2),encoding='utf8')
