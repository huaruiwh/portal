import json,os,time
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
with lock.open('x',encoding='utf8')as f:f.write(json.dumps({'pid':os.getpid(),'task':'201 remaining button batches'}))
try:
    call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
    hs=[w['handle']for w in ws if w['class']=='EasyBuilderPro'and'组装机_MT8106iP.emtp'in w['title']]
    if len(hs)!=1:raise ValueError('Unique target required')
    for ids in ([9,10],[11,12],[13,14]):
        if all((ROOT/f'evidence/target-201-TS{n}-built.json').exists()and json.loads((ROOT/f'evidence/target-201-TS{n}-built.json').read_text(encoding='utf8')).get('saved_reopened_verified')for n in ids):continue
        t=time.perf_counter();call('uia',hs[0],json.dumps({'page201_batch':ids,'build_bit_general':0},ensure_ascii=False))
        p=ROOT/('evidence/page201-batch-'+ '-'.join(map(str,ids))+'.json');d=json.loads(p.read_text(encoding='utf8'));d['controller_wall_seconds']=time.perf_counter()-t;p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
        print(json.dumps({'ids':ids,'seconds':d['controller_wall_seconds'],'count':d['after_count'],'remaining':d['remaining']}),flush=True)
finally:lock.unlink()
