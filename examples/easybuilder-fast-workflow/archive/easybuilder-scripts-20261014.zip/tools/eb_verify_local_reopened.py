"""Read every local-test control and verify a bijection after EB renumbering."""
import json,re
from eb_rebuild_page import ROOT,call
from eb_roundtrip_audit import run as audit
from eb_layout import geometry

def run():
    call('snapshot')
    ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
    found=[w for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
    if len(found)!=1:raise ValueError('Unique reopened target required')
    w=found[0]
    if w['pid']==22544:raise ValueError('Original target process still running')
    def ui(q):return call('uia',w['handle'],json.dumps(q,ensure_ascii=False))
    inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
    from eb_roundtrip_main import selected
    for page in (48,49):
        ui({'open_target_page':page});ui({'page_settings':page,'target_readonly':True,'color_probe':True})
        src=json.loads((ROOT/f'evidence/source-pages-settings/{page:03d}.json').read_text(encoding='utf8'))
        dst=json.loads((ROOT/f'evidence/target-pages-settings/{page:03d}.json').read_text(encoding='utf8'))
        keep={'窗口名称 :','窗口编号 :','宽度 :','高度 :','底层 :','中层 :','顶层 :','打开窗口时执行 :','循环执行 :','关闭窗口时执行 :','垄断'}
        ref=json.loads((ROOT/'evidence/source-pages-settings/031.json').read_text(encoding='utf8'))
        if sorted(selected(src['controls'],keep))!=sorted(selected(dst['controls'],keep)) or dst['background_rgb']!=ref['background_rgb']:raise ValueError('Reopened settings mismatch')
        names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==page)
        keys=[re.match(r'^([A-Z]+_\d+)',n)[1] for n in names]
        for name in names:
            ui({'extract':{'page':page,'object':name,'target_readonly':True}})
        sources={k:json.loads((ROOT/f'evidence/source-object-properties/{page:03d}_{k}.json').read_text(encoding='utf8')) for k in keys}
        targets={k:json.loads((ROOT/f'evidence/target-object-properties/{page:03d}_{k}.json').read_text(encoding='utf8')) for k in keys}
        mapping={}
        for key,s in sources.items():
            candidates=[k for k,t in targets.items() if k.split('_')[0]==key.split('_')[0] and geometry(s)==geometry(t)]
            if len(candidates)!=1:raise ValueError('Unique geometry identity required')
            mapping[key]=candidates[0]
        if len(set(mapping.values()))!=len(keys):raise ValueError('One-to-one identity required')
        audit(page,keys,mapping)
        try:ui({'target_page_audit':page})
        except RuntimeError as error:
            if 'Target object audit incomplete' not in str(error):raise
        directory=json.loads((ROOT/f'evidence/target-page{page}-audit.json').read_text(encoding='utf8'))
        if directory['missing'] or directory['unexpected'] or directory['target_count']!=len(keys):raise ValueError('Directory count mismatch')
        def normalized(name):return re.sub(r'\s*\(最下层\)$','',name)
        expected={re.match(r'^([A-Z]+_\d+)',n)[1]:normalized(n) for n in names}
        actual={re.match(r'^([A-Z]+_\d+)',n)[1]:normalized(n) for n in directory['objects']}
        for key,dest in mapping.items():
            if actual[dest]!=expected[key].replace(key,dest,1):raise ValueError('Mapped address directory mismatch')
        if not any(n.startswith(mapping['SW_0']+' ') and '(最下层)' in n for n in directory['objects']):raise ValueError('Lowest layer mismatch')
        report={'page':page,'objects':len(keys),'target_pid':w['pid'],'mapping':mapping,'all_properties_verified':True,'settings_verified':True,'background_rgb':dst['background_rgb'],'directory_verified':True,'lowest_layer_verified':True,'offline_simulation_verified':False}
        (ROOT/f'evidence/page-{page}-local-reopened.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
        print(json.dumps(report,ensure_ascii=False),flush=True)

if __name__=='__main__':run()
