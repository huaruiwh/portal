"""Verify saved page26 logic, layout and window-close macro after reopening."""
import json,re,sys
from eb_rebuild_page import ROOT,call
from eb_layout import geometry
from eb_roundtrip_main import selected

def run(previous_pid):
    page=int(sys.argv[sys.argv.index('--page')+1]) if '--page' in sys.argv else 26
    from eb_flow_model import counts
    counts(page)
    call('snapshot')
    windows=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
    targets=[w for w in windows if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
    if len(targets)!=1 or targets[0]['pid']==previous_pid:raise ValueError('A newly reopened target process required')
    target=targets[0]
    def ui(q):call('uia',target['handle'],json.dumps(q,ensure_ascii=False))
    ui({'restore_target_window':True,'reviewed_size':True});ui({'open_target_page':page})
    ui({'page_settings':page,'target_readonly':True,'color_probe':True})
    source_settings=json.loads((ROOT/f'evidence/source-pages-settings/{page:03d}.json').read_text(encoding='utf8'))
    saved_settings=json.loads((ROOT/f'evidence/target-pages-settings/{page:03d}.json').read_text(encoding='utf8'))
    keep={'窗口名称 :','窗口编号 :','宽度 :','高度 :','底层 :','中层 :','顶层 :','打开窗口时执行 :','循环执行 :','关闭窗口时执行 :','垄断'}
    report={'page':page,'previous_pid':previous_pid,'reopened_pid':target['pid'],'page_settings_verified':sorted(selected(source_settings['controls'],keep))==sorted(selected(saved_settings['controls'],keep)),'background_verified':source_settings['background_rgb']==saved_settings['background_rgb'],'checks':[],'sample_only':True,'ok':False,'offline_simulation_verified':False}
    path=ROOT/f'evidence/page-{page}-roundtrip-audit.json'
    settings_only='--settings-only' in sys.argv
    if settings_only:
        old=json.loads(path.read_text(encoding='utf8'))
        if len(old['checks'])!=7 or not all(v for c in old['checks'] for k,v in c.items() if k.endswith('_verified')):raise ValueError('Previously verified unchanged object checks required')
        report['checks']=old['checks'];report['object_checks_reopened_pid']=old.get('object_checks_reopened_pid',old['reopened_pid'])
    inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
    names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==page)
    sample={'TS_0','TS_2','TS_3','MS_0','SW_0','BL_0','TX_0'}
    for name in ([] if settings_only else names):
        key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)[1]
        if key not in sample:continue
        q={'page':page,'object':name,'target_readonly':True}
        if key=='TX_0':q.update(colors=['颜色 :'],color_tab='文字/批注')
        ui({'extract':q})
        source=json.loads((ROOT/f'evidence/source-object-properties/{page:03d}_{key}.json').read_text(encoding='utf8'))
        saved=json.loads((ROOT/f'evidence/target-object-properties/{page:03d}_{key}.json').read_text(encoding='utf8'))
        actual={r['name']:r['value'] for r in saved['tabs']['轮廓'] if r['type']=='Edit' and r['name'] in geometry(source)}
        check={'object':key,'geometry_verified':geometry(source)==actual}
        if key!='TX_0':
            keep={'读取/写入使用不同的地址','设备 :','Static',' Down','模式 :','操作模式 :','偏移量 :','状态数 :','循环 :','设置常数 :','触发宏指令','当按钮松开后发出指令','输出反向'}
            check['address_behavior_verified']=selected(source['tabs']['一般属性'],keep)==selected(saved['tabs']['一般属性'],keep)
        if key=='MS_0':
            check['selector_family_verified']=any(r['name']=='Selector_3_Position_Green' for r in saved['tabs']['图片'])
        if key=='TX_0':check['color_verified']=source['colors']==saved['colors']
        report['checks'].append(check);path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
        print(json.dumps(check,ensure_ascii=False),flush=True)
    ui({'target_page_audit':page})
    report['ok']=len(report['checks'])==len(sample) and report['page_settings_verified'] and report['background_verified'] and all(v for c in report['checks'] for k,v in c.items() if k.endswith('_verified'))
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    if not report['ok']:raise ValueError('Saved flow parameters differ; inspect local evidence')

if __name__=='__main__':run(int(sys.argv[1]))
