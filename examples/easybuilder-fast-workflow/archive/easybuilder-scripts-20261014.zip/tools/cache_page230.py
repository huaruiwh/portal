"""Read missing original parameters in bounded 2-control batches."""
import json,re
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
with lock.open('x',encoding='utf8')as f:f.write('230 original cache batch2')
p=ROOT/'evidence/page230-cache-workflow.json';out={'page':230,'cached':[],'finished':False,'source_readonly':True,'batch_size':2}
def record():p.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
def valid(key):
 f=ROOT/f'evidence/source-object-properties/230_{key}.json'
 if not f.exists():return False
 d=json.loads(f.read_text(encoding='utf8'))
 rows=[r for rs in d.get('tabs',{}).values()for r in rs]+[r for rs in d.get('label_states',{}).values()for r in rs]
 return bool(d.get('tabs',{}).get('轮廓'))and not any('read_error'in r for r in rows)
try:
 call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'));src=[w for w in ws if '组装机2台15工位取消.cmtp'in w['title']and w['class']=='EasyBuilderPro']
 if len(src)!=1:raise ValueError('Unique original required')
 inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(x['observed_objects']for x in inv['pages']if x['id']==230)
 keyed=[(re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)[1],name)for name in names]
 out['cached']=[key for key,name in keyed if valid(key)];pending=[(key,name)for key,name in keyed if key not in out['cached']];record()
 for offset in range(0,len(pending),2):
  batch=pending[offset:offset+2]
  # Complex menu tables run singly to avoid sharing a55s limit.
  groups=[[item]for item in batch]if any(key.startswith('OL_')for key,name in batch)else [batch]
  for group in groups:
   out['current_batch']=[key for key,name in group];record()
   try:
    call('uia',src[0]['handle'],json.dumps({'extract_batch':[{'page':230,'object':name,'basic_only':True}for key,name in group]},ensure_ascii=False))
   except RuntimeError as error:
    if 'InvalidWindowHandle' not in str(error) and 'ElementNotFoundError' not in str(error):raise
    out.setdefault('read_recoveries',[]).append({'keys':[key for key,name in group],'action':'retry missing cache singly after stale dialog'});record()
    for key,name in group:
     if not valid(key):call('uia',src[0]['handle'],json.dumps({'extract':{'page':230,'object':name,'basic_only':True}},ensure_ascii=False))
   for key,name in group:
    if not valid(key):raise ValueError('Original parameter cache incomplete/read_error: '+key)
    out['cached'].append(key);record()
 out['finished']=True;record()
except Exception as e:out['error']=str(e);record();raise
finally:lock.unlink(missing_ok=True)
