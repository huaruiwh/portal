"""Restore a rebuilt page's original dimensions; no source project writes."""
import json,re,time
from pathlib import Path
from pywinauto import Desktop
from pywinauto.keyboard import send_keys
from pywinauto.controls.win32_controls import EditWrapper
ROOT=Path(__file__).resolve().parent.parent

def run(handle,request):
    native_root=Desktop(backend='win32').window(handle=handle).wrapper_object()
    w=Desktop(backend='uia').window(handle=handle).wrapper_object()
    if '组装机_MT8106iP.emtp' not in w.window_text():
        raise ValueError('Rebuilt target project only')
    page_id=int(request['target_page_size'])
    src=json.loads((ROOT/'evidence'/'source-pages-settings'/f'{page_id:03d}.json').read_text(encoding='utf8'))
    values={c['name']:c['value'] for c in src['controls'] if c['type']=='Edit' and c['name'] in ('宽度 :','高度 :')}
    if page_id in (16,17,100,101,102,103) and values=={'宽度 :':'1024','高度 :':'768'}:
        values={'宽度 :':'1024','高度 :':'600'}
    if set(values)!= {'宽度 :','高度 :'}:raise ValueError('Source dimensions missing')
    if not 1<=int(values['宽度 :'])<=1024 or not 1<=int(values['高度 :'])<=600:
        raise ValueError('Source page requires an explicit layout adaptation')
    wr=w.rectangle()
    fields=[c for c in w.descendants(control_type='Edit') if c.rectangle().left>=wr.left and c.rectangle().right<wr.left+500 and wr.top+190<c.rectangle().top<wr.top+270]
    if len(fields)!=1:raise ValueError('Target tree filter must be unique')
    native_root.set_focus();fields[0].click_input();send_keys('^a'+str(page_id),pause=.01)
    time.sleep(.15)
    pages=[c for c in w.descendants(control_type='TreeItem') if re.match(r'^'+str(page_id)+r'\s*:',c.window_text())]
    if len(pages)!=1:raise ValueError('Target page must exist exactly once')
    p=pages[0];p.click_input(button='right',coords=(40,p.rectangle().height()//2))
    time.sleep(.15)
    actions=[]
    for pop in Desktop(backend='win32').windows():
        if pop.process_id()==w.process_id() and (pop.class_name().startswith('Qt5QWindowPopup') or pop.class_name()=='#32768') and pop.is_visible():
            ui=Desktop(backend='uia').window(handle=pop.handle).wrapper_object()
            actions.extend(c for c in ui.descendants(control_type='MenuItem') if c.window_text()=='设置...' and c.is_visible())
    if len(actions)!=1:raise ValueError('Unique target settings action required')
    actions[0].click_input()
    dialogs=[]
    for _ in range(15):
        dialogs=[d for d in Desktop(backend='win32').windows() if d.process_id()==w.process_id() and d.window_text()=='窗口设置' and d.is_visible()]
        if len(dialogs)==1:break
        time.sleep(.1)
    if len(dialogs)!=1:raise ValueError('Target settings dialog not ready')
    d=Desktop(backend='uia').window(handle=dialogs[0].handle).wrapper_object()
    before={}
    for name,value in values.items():
        cs=[c for c in d.descendants(control_type='Edit') if c.window_text()==name and c.is_visible()]
        if len(cs)!=1:raise ValueError('Unique dimension field required: '+name)
        native=EditWrapper(cs[0].handle);before[name]=native.window_text()
        native.set_text(value)
        if native.window_text()!=value:raise ValueError('Dimension readback mismatch')
    buttons=[c for c in d.descendants(control_type='Button') if c.window_text()=='确定' and c.is_visible()]
    if len(buttons)!=1:raise ValueError('Unique target OK required')
    buttons[0].click_input();time.sleep(.2)
    native_root.set_focus();send_keys('^s',pause=.01)
    (ROOT/'evidence'/f'target-page-{page_id:03d}-size.json').write_text(json.dumps({'page':page_id,'before':before,'after':values,'saved_requested':True},ensure_ascii=False,indent=2),encoding='utf8')
