"""Restore existing page16 BL0..4 flags, source bitmap size and native state RGB."""
import json
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_extract import ROOT,rows
from eb_object_ui import target,properties,save
from eb_native_form import tab,fields,confirm
from eb_color_picker import set_rgb,probe

def run(handle,q):
 n=int(q['build_bit_general'])
 if int(q['page'])!=16 or q['bit_kind']!='BL' or n not in range(5):raise ValueError('Existing page16 BL0..4 only')
 src=json.loads((ROOT/f'evidence/source-object-properties/016_BL_{n}.json').read_text(encoding='utf8'))
 if set(src.get('state_colors',{}).get('图片',{}))!={'0','1'}:raise ValueError('Both original image-state RGBs required')
 root,w=target(handle,16);d,name=properties(root,w,f'BL_{n}','位状态指示灯/位状态切换开关的属性')
 tab(d,'一般属性');general=rows(d)
 get=lambda rs:[r['value'] for r in rs if r['type']=='Edit' and r['name']=='Static']
 if get(general)!=get(src['tabs']['一般属性']):raise ValueError('Existing lamp address mismatch')
 if q.get('geometry_only'):
  from eb_layout import geometry
  tab(d,'轮廓');fields(d,[{'type':'Edit','name':key,'value':value} for key,value in geometry(src).items()]);confirm(d);save(root)
  d,_=properties(root,w,f'BL_{n}','位状态指示灯/位状态切换开关的属性');tab(d,'轮廓');actual=rows(d)
  from pywinauto.controls.win32_controls import ButtonWrapper
  cs=[c for c in d.descendants(control_type='Button') if c.is_visible() and c.element_info.name=='取消']
  if len(cs)!=1:raise ValueError('One geometry readback cancel required')
  ButtonWrapper(cs[0].handle).send_message_timeout(0x00F5,timeout=2)
  for p in (ROOT/f'evidence/target-016-BL{n}-built.json',ROOT/f'evidence/target-016-BL{n}-appearance-repaired.json'):
   r=json.loads(p.read_text(encoding='utf8'));r['geometry']=actual;r['geometry_reopened_verified']=True;p.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
  return
 tab(d,'图片');flags=[r for r in src['tabs']['图片'] if r['type']=='CheckBox'];fields(d,flags)
 fields(d,[{'type':'CheckBox','name':'使用图片','value':0}])
 from eb_frame_vector import choose as vector
 vector(d,root.process_id());tab(d,'图片');fields(d,flags)
 if any(r['name']=='使用图片' and r.get('value')==1 for r in flags):
  fields(d,[{'type':'CheckBox','name':'使用向量图','value':0}])
  from eb_picture_family import choose
  expected=next(r['name'] for r in src['tabs']['图片'] if r['type']=='Text' and r['name']=='96x96')
  # Source BL0 has the square metal frame (group1); group0 has the same
  # family and 96x96 size but is round. Metadata alone cannot identify it.
  if n!=0:raise ValueError('Bitmap variant requires original gallery identity')
  choose(d,root.process_id(),'Button - Standard',standard_index='1')
  if not any(r['type']=='Text' and r['name']==expected for r in rows(d)):raise ValueError('Original square bitmap size mismatch')
  fields(d,flags)
 checks=[]
 def colours(scope):
  cs=[c for c in d.descendants(control_type='ComboBox') if c.is_visible() and c.element_info.name=='状态 :']
  if len(cs)!=1:raise ValueError('One existing indicator state required')
  for state in ('0','1'):
   ComboBoxWrapper(cs[0].handle).select(state)
   for key,rgb in src['state_colors'][scope][state].items():
    label,sep,occ=key.partition('#');occurrence=int(occ) if sep else 0
    change=set_rgb(d,rgb,label,occurrence);actual=change['after'] if change.get('already_equal') else probe(d,label,occurrence)
    if actual!=rgb:raise ValueError('Original lamp RGB mismatch')
    checks.append({'scope':scope,'state':state,'label':key,'native_readback':actual})
 colours('图片');picture=rows(d);tab(d,'标签')
 use=next(r['value'] for r in src['tabs']['标签'] if r['name']=='使用文字标签');fields(d,[{'type':'CheckBox','name':'使用文字标签','value':use}]);labels={}
 if use:
  cs=[c for c in d.descendants(control_type='ComboBox') if c.is_visible() and c.element_info.name=='状态 :']
  if len(cs)!=1:raise ValueError('One original lamp caption state required')
  for state in ('0','1'):
   ComboBoxWrapper(cs[0].handle).select(state);actual=rows(d)
   original=src['label_states'][state];get_text=lambda rs:[r['value'] for r in rs if r['type']=='Edit' and r['name']=='']
   if get_text(actual)!=get_text(original):raise ValueError('Original lamp caption mismatch')
   fields(d,original,skip=(('ComboBox','状态 :'),('Edit','')))
  colours('标签')
  for state in ('0','1'):ComboBoxWrapper(cs[0].handle).select(state);labels[state]=rows(d)
 else:labels['disabled']=rows(d)
 tab(d,'安全');fields(d,src['tabs']['安全']);safety=rows(d);tab(d,'轮廓')
 from eb_layout import geometry
 fields(d,[{'type':'Edit','name':key,'value':value} for key,value in geometry(src).items()]);shape=rows(d);confirm(d);save(root)
 report={'page':16,'source':src['object'],'target':name,'general':general,'picture':picture,'labels':labels,'safety':safety,'geometry':shape,'saved_requested':True,'native_rgb_checks':checks,'source_state_colors':src['state_colors'],'picture_flags_restored':True,'vector_shape_identity_review_pending':True,'offline_simulation_verified':False}
 (ROOT/f'evidence/target-016-BL{n}-built.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 (ROOT/f'evidence/target-016-BL{n}-appearance-repaired.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
