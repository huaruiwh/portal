"""Commit target lamp label text, preserving different source state captions."""
import time
from pywinauto.controls.win32_controls import ComboBoxWrapper,EditWrapper,ButtonWrapper
from pywinauto.keyboard import send_keys

def commit(d,texts):
    import ctypes
    from eb_native_messages import put,text
    cache={}
    def unique(typ,name):
        key=(typ,name)
        if key in cache and ctypes.windll.user32.IsWindow(cache[key].handle):return cache[key]
        from eb_native_form import typed_children
        matches=[c for c in typed_children(d,typ) if c.element_info.name==name and c.is_visible()]
        if len(matches)!=1:
            matches=[c for c in d.descendants(control_type=typ,cache_enable=True) if c.element_info.name==name and c.is_visible()]
        if len(matches)!=1:raise ValueError('Unique label editor required: '+name)
        cache[key]=matches[0]
        return matches[0]
    state=ComboBoxWrapper(unique('ComboBox','状态 :').handle)
    def write(text):
        editor=unique('Edit','');native=EditWrapper(editor.handle)
        normalized=text.replace('\r\n','\n').replace('\r','\n')
        if '\n' in normalized and not(native.style() & 4):raise ValueError('Multiline caption requires multiline editor')
        put(editor.handle,text)
        editor.set_focus()
        send_keys('{TAB}',pause=.01);time.sleep(.1)
    if texts[0]==texts[1]:
        state.select('0');time.sleep(.1)
        if EditWrapper(unique('Edit','').handle).window_text().rstrip('\r\n')!=texts[0]:write(texts[0])
        ButtonWrapper(unique('Button','将当前内容复制到所有的状态').handle).send_message_timeout(0x00F5,timeout=2)
    else:
        for n,text in enumerate(texts):
            state.select(str(n));time.sleep(.1)
            write(text)
    for n,text in enumerate(texts):
        state.select(str(n));time.sleep(.1)
        actual=EditWrapper(unique('Edit','').handle).window_text().rstrip('\r\n')
        for _ in range(20):
            if actual==text:break
            time.sleep(.03)
            actual=EditWrapper(unique('Edit','').handle).window_text().rstrip('\r\n')
        if actual!=text:raise ValueError('Committed label state mismatch: '+repr((n,text,actual)))
