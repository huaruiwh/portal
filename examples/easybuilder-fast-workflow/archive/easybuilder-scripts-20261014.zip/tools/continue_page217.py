import json,os,re,traceback
from pathlib import Path
from eb_rebuild_page import ROOT,call
r=ROOT;p=r/'evidence/page217-build-workflow.json';lock=r/'tools/batch.lock'
if lock.exists():raise RuntimeError('Controller already running')
lock.write_text(json.dumps({'pid':os.getpid(),'task':'build217'}),encoding='utf8')
d={'page':217,'built':[],'finished':False,'reference':218,'target_height':469}
def record():
 p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
 marker='\n### 2026-10-12：217页参考218重建进度'
 text=marker+'\n'+json.dumps(d,ensure_ascii=False)+'\n脚本 tools/continue_page217.py，目标890×469，源参数缓存复用，单件完整控件60秒。仅通过保存读回的控件计入built；颜色图库仍需原件复核，不执行任何源关闭宏、不下载。\n'
 for f in ['README.md','docs/MT8106iP重建-实现记录.md']:
  path=r/f;t=path.read_text(encoding='utf8');idx=t.find(marker)
  if idx>=0:
   end=t.find('\n### ',idx+len(marker));t=t[:idx]+(t[end:]if end>=0 else '')
  path.write_text(t+text,encoding='utf8')
try:
 height=json.loads((r/'evidence/scale-890x469/page-217-initial-height.json').read_text(encoding='utf8'))
 if not height['saved_reopened_verified']:raise ValueError('Height not verified')
 call('snapshot');ws=json.loads((r/'evidence/windows.json').read_text(encoding='utf8'));h=next(w['handle']for w in ws if '组装机_MT8106iP.emtp'in w['title'])
 inv=json.loads((r/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(x['observed_objects']for x in inv['pages']if x['id']==217)
 keys=sorted([re.search(r'(?:^|\])\s*([A-Z]+_\d+)',n)[1]for n in names],key=lambda k:(k.split('_')[0],int(k.split('_')[1])))
 d['total']=len(keys);record()
 for offset in range(0,len(keys),1):
  batch=keys[offset:offset+1];pending=[]
  for key in batch:
   report=r/f'evidence/target-217-{key}-built.json'
   if not report.exists()or not json.loads(report.read_text(encoding='utf8')).get('saved_reopened_verified'):pending.append(key)
  if pending:
   d['current_batch']=pending;record()
   try:call('uia',h,json.dumps({'page217_controls':pending,'build_bit_general':0}))
   except RuntimeError as error:
    if len(pending)!=1 or not ('timed out after 60 seconds'in str(error)or('Original appearance readback differs'in str(error)and '内容'in str(error))):raise
    journal=r/f'evidence/target-217-{pending[0]}-copy-phase.json'
    if not journal.exists()or json.loads(journal.read_text(encoding='utf8')).get('stage')!='saved-unverified':raise
    d.setdefault('timeout_recoveries',[]).append({'key':pending[0],'action':'verify saved existing control; no rewrite/paste'});record()
    call('uia',h,json.dumps({'page217_controls':pending,'build_bit_general':0}))
  for key in batch:
   proof=json.loads((r/f'evidence/target-217-{key}-built.json').read_text(encoding='utf8'))
   if not proof['saved_reopened_verified']:raise ValueError('Unverified control '+key)
   d['built'].append(key)
  record()
 call('uia',h,json.dumps({'target_page_audit':217}));call('uia',h,json.dumps({'compile_target':True,'entry_via_local_ocr':True}))
 d['finished']=True;record()
except Exception as e:
 d['error']=str(e);record();raise
finally:lock.unlink(missing_ok=True)
