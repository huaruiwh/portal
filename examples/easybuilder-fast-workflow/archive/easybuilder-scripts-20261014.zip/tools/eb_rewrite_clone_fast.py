"""Target-only native input updates after one cached UIA lookup per property tab."""
import ctypes,json,time,re
from pywinauto import Desktop
from pywinauto.keyboard import send_keys
from eb_extract import ROOT
from eb_object_ui import target,properties,dialog,save
from eb_layout import geometry
U=ctypes.windll.user32
U.SendMessageTimeoutW.argtypes=[ctypes.c_void_p,ctypes.c_uint,ctypes.c_size_t,ctypes.c_ssize_t,ctypes.c_uint,ctypes.c_uint,ctypes.POINTER(ctypes.c_size_t)]
U.SendMessageTimeoutW.restype=ctypes.c_size_t
def msg(h,m,w=0,l=0):
    out=ctypes.c_size_t()
    if not U.SendMessageTimeoutW(h,m,w,l,2,1500,ctypes.byref(out)):raise TimeoutError('Native editor control did not respond')
    return out.value
def text(h):
    buf=ctypes.create_unicode_buffer(4096);msg(h,13,len(buf),ctypes.cast(buf,ctypes.c_void_p).value);return buf.value
def put(h,value):
    value=str(value);buf=ctypes.create_unicode_buffer(value);msg(h,12,0,ctypes.cast(buf,ctypes.c_void_p).value)
    if text(h).rstrip('\r\n')!=value.rstrip('\r\n'):raise ValueError('Native copied input mismatch')
def controls(d,typ,name):
    if getattr(d,'_field_cache',None) is None:d._field_cache=d.descendants(cache_enable=True)
    return [c for c in d._field_cache if c.element_info.control_type==typ and c.element_info.name==name and c.element_info.handle and U.IsWindowVisible(c.element_info.handle)]
def tab(d,name):
    matches=[c for c in d.descendants(control_type='TabItem',cache_enable=True) if c.element_info.name==name]
    if len(matches)!=1:raise ValueError('Unique copied-property tab required')
    Desktop(backend='win32').window(handle=d.handle).set_focus();matches[0].click_input();time.sleep(.1);d._field_cache=None
def source_values(items):return [(r['type'],r['name'],r.get('value')) for r in items if 'value' in r]
def run(handle,q):
    started=time.monotonic();timings={}
    key=q['object'];page=int(q['rewrite_clone_fast'])
    if page!=31 or not re.fullmatch(r'(TS|BL|MS|SW|TX)_\d+',key):raise ValueError('First copy trial only')
    source=json.loads((ROOT/f'evidence/source-object-properties/031_{key}.json').read_text(encoding='utf8'));base=json.loads((ROOT/f'evidence/source-object-properties/026_{key}.json').read_text(encoding='utf8'))
    kind=key.split('_')[0];titles={'TS':'位状态切换开关/位状态指示灯的属性','BL':'位状态指示灯/位状态切换开关的属性','MS':'多状态切换开关/多状态指示灯的属性','SW':'多状态设置的属性','TX':'文字/批注的属性'}
    root,w=target(handle,page)
    if q.get('resume'):d=dialog(root.process_id(),titles[kind])
    else:d,_=properties(root,w,key,titles[kind])
    timings['open_properties']=round(time.monotonic()-started,3)
    report={'page':page,'object':key,'template':26,'changes':[],'appearance_inherited':True,'offline_simulation_verified':False}
    if kind!='TX':
        tab(d,'一般属性')
        general=source['tabs']['一般属性'];old=base['tabs']['一般属性']
        ordinary=[r for r in general if 'value' in r and r['name']!='Static'];prior=[r for r in old if 'value' in r and r['name']!='Static']
        for a,b in zip(ordinary,prior):
            if (a['type'],a['name'])!=(b['type'],b['name']):raise ValueError('Copied control schema differs')
            if a['value']!=b['value']:
                if a['type']!='CheckBox':raise ValueError('Copied mode/device requires separate review')
                c=controls(d,'CheckBox',a['name'])
                if len(c)!=1:raise ValueError('Unique copied check box required')
                state=msg(c[0].handle,240)
                if state!=a['value']:msg(c[0].handle,245)
                if msg(c[0].handle,240)!=a['value']:raise ValueError('Copied check box mismatch')
                report['changes'].append(a['name'])
        addresses=[r['value'] for r in general if r['type']=='Edit' and r['name']=='Static']
        edits=controls(d,'Edit','Static')
        if len(edits)!=len(addresses):raise ValueError('Copied address field count mismatch')
        for c,value in zip(edits,addresses):put(c.handle,value)
        report['addresses']=[text(c.handle) for c in edits]
        if report['addresses']!=addresses:raise ValueError('Copied address readback mismatch')
        def captions(s):return {k:next(r['value'] for r in v if r['type']=='Edit' and r['name']=='') for k,v in s.get('label_states',{}).items()}
        labels=captions(source);previous=captions(base)
        if labels!=previous:
            if set(labels)!={'0','1'}:raise ValueError('Two copied caption states required')
            tab(d,'标签');state=controls(d,'ComboBox','状态 :')
            if len(state)!=1:raise ValueError('Unique copied label state selector required')
            h=state[0].handle;cid=U.GetDlgCtrlID(h);parent=U.GetParent(h)
            if msg(h,326)!=2:raise ValueError('Two native caption states required')
            for n in (0,1):
                msg(h,334,n);msg(parent,273,(1<<16)|cid,h);time.sleep(.08)
                edits=controls(d,'Edit','')
                if len(edits)!=1:raise ValueError('Unique copied caption editor required')
                put(edits[0].handle,labels[str(n)])
                Desktop(backend='win32').window(handle=edits[0].handle).set_focus();send_keys('{TAB}',pause=.01)
            checked={}
            for n in (0,1):
                msg(h,334,n);msg(parent,273,(1<<16)|cid,h);time.sleep(.08)
                edits=controls(d,'Edit','')
                if len(edits)!=1:raise ValueError('Unique label readback editor required')
                checked[str(n)]=text(edits[0].handle).rstrip('\r\n')
            if checked!={k:v.rstrip('\r\n') for k,v in labels.items()}:raise ValueError('Copied caption-state persistence mismatch')
            report['labels']=checked;report['changes'].append('captions')
    else:
        tab(d,'文字/批注');edits=controls(d,'Edit','内容')
        if len(edits)!=1:raise ValueError('Unique copied text content required')
        value=next(r['value'] for r in source['tabs']['文字/批注'] if r['type']=='Edit' and r['name']=='内容')
        put(edits[0].handle,value);Desktop(backend='win32').window(handle=edits[0].handle).set_focus();send_keys('{TAB}',pause=.01);report['text']=value
    timings['address_and_text']=round(time.monotonic()-started,3)
    if source_values(source['tabs']['安全'])!=source_values(base['tabs']['安全']):raise ValueError('Copied safety differences require review')
    expected=geometry(source)
    if expected==geometry(base):
        report['geometry']=expected;report['geometry_inherited_from_copied_template']=True
    else:
        tab(d,'轮廓');actual={}
        for name,value in expected.items():
            edits=controls(d,'Edit',name)
            if len(edits)!=1:raise ValueError('Unique copied geometry field required')
            put(edits[0].handle,value);actual[name]=text(edits[0].handle)
        if actual!=expected:raise ValueError('Copied geometry native readback mismatch')
        report['geometry']=actual;report['geometry_inherited_from_copied_template']=False
    buttons=controls(d,'Button','确定')
    if len(buttons)!=1:raise ValueError('Unique copied properties OK required')
    msg(buttons[0].handle,245);time.sleep(.1);save(root);report['saved_requested']=True;timings['total']=round(time.monotonic()-started,3);report['timings_seconds']=timings
    (ROOT/f'evidence/target-031-{key}-clone-rewritten.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
