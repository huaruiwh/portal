"""Read the last four additions from a freshly reopened saved project."""
import json
from eb_rebuild_page import ROOT,call
from eb_layout import geometry

def run():
 lock=ROOT/'tools/batch.lock'
 with lock.open('x'):pass
 path=ROOT/'evidence/last-four-reopened.json';r={'ok':False,'checks':[],'offline_simulation_verified':False}
 def persist():path.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
 try:
  call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'));w=next(w for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title'])
  if w['pid']==8624:raise ValueError('Fresh reopened process required')
  r.update(target_pid=w['pid'],target_handle=w['handle']);persist();call('uia',w['handle'],json.dumps({'restore_target_window':True}))
  inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
  for page,keys in ((10,('TS_0',)),(11,('TS_0','WP_0','WP_1'))):
   call('uia',w['handle'],json.dumps({'open_target_page':page}))
   for key in keys:
    r['stage']={'page':page,'key':key};persist()
    name=next(n for p in inv['pages'] if p['id']==page for n in p['observed_objects'] if n.startswith(key+' '))
    call('uia',w['handle'],json.dumps({'extract':{'page':page,'object':name,'target_readonly':True}}))
    s=json.loads((ROOT/f'evidence/source-object-properties/{page:03d}_{key}.json').read_text(encoding='utf8'));t=json.loads((ROOT/f'evidence/target-object-properties/{page:03d}_{key}.json').read_text(encoding='utf8'))
    names={'设备 :','Static',' Down','操作模式 :','读取/写入使用不同的地址','输出反向','触发宏指令','使用窗口编号偏移量'}
    select=lambda rs,nm: [(v['type'],v['name'],v['value']) for v in rs if v['name'] in nm and 'value'in v]
    expected=geometry(s);actual={v['name']:v['value'] for v in t['tabs']['轮廓'] if v['type']=='Edit' and v['name'] in expected}
    general=select(s['tabs']['一般属性'],names)==select(t['tabs']['一般属性'],names)
    position=True;safety=True
    if key.startswith('WP'):
     position=select(s['tabs']['位置'],{'自动调整窗口尺寸'})==select(t['tabs']['位置'],{'自动调整窗口尺寸'})
     safety=all(v.get('value')==0 for v in s['tabs']['安全'] if v['type']=='CheckBox')
    else:
     nm={v['name'] for v in s['tabs']['安全'] if 'value'in v};safety=select(s['tabs']['安全'],nm)==select(t['tabs']['安全'],nm)
    check={'page':page,'key':key,'general_verified':general,'geometry_verified':actual==expected,'position_verified':position,'safety_verified':safety,'model_popup_behavior_verified':False if key=='WP_1' else None}
    r['checks'].append(check);persist()
    if not all(check[k] for k in ('general_verified','geometry_verified','position_verified','safety_verified')):raise ValueError('Reopened last-object fields mismatch: '+key)
    print(page,key,'verified',flush=True)
   call('uia',w['handle'],json.dumps({'target_page_audit':page}))
  r['ok']=True;persist()
 except Exception as e:r['error']=str(e);persist();raise
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':run()
