"""Inspect and use the target editor's actual page-copy action."""
import json,re,time
from pywinauto import Desktop
from eb_extract import ROOT

def run(handle,q):
    source=int(q['clone_page']);dest=int(q['destination'])
    if (source,dest)!=(26,31):raise ValueError('First reviewed copy trial only')
    root=Desktop(backend='win32').window(handle=handle).wrapper_object()
    if '组装机_MT8106iP.emtp' not in root.window_text():raise ValueError('Target-only page copy')
    if not json.loads((ROOT/'evidence/page-26-roundtrip-audit.json').read_text(encoding='utf8'))['ok']:raise ValueError('Verified template required')
    if q.get('paste_only'):
        from eb_open_page import run as open_page
        from pywinauto.keyboard import send_keys
        open_page(handle,{'open_target_page':dest})
        root.set_focus();root.click_input(coords=(963,367));send_keys('^v',pause=.15);time.sleep(.5)
        (ROOT/'evidence/page-31-clone-step.json').write_text(json.dumps({'template':source,'page':dest,'copy_paste_sent':True,'directory_verified':False,'address_text_rewritten':False},ensure_ascii=False,indent=2),encoding='utf8')
        return
    if q.get('copy_controls'):
        from eb_open_page import run as open_page
        from pywinauto.keyboard import send_keys
        import shutil
        backup=ROOT/'backup/复制样页前_20261008.emtp'
        backup.parent.mkdir(exist_ok=True)
        if not backup.exists():shutil.copy2(ROOT/'output/组装机_MT8106iP.emtp',backup)
        open_page(handle,{'open_target_page':source})
        root.set_focus();root.click_input(coords=(963,367));send_keys('^a^c',pause=.15)
        from eb_create_page import run as create
        create(handle,{'create_target_page':dest})
        open_page(handle,{'open_target_page':dest})
        root.set_focus();root.click_input(coords=(963,367));send_keys('^v',pause=.15)
        time.sleep(.5)
        (ROOT/'evidence/page-31-clone-step.json').write_text(json.dumps({'template':source,'page':dest,'copy_paste_sent':True,'directory_verified':False,'address_text_rewritten':False},ensure_ascii=False,indent=2),encoding='utf8')
        return
    from eb_open_page import run as open_page
    open_page(handle,{'open_target_page':source})
    w=Desktop(backend='uia').window(handle=handle).wrapper_object()
    nodes=[c for c in w.descendants(control_type='TreeItem') if re.match(r'^26\s*:',c.window_text()) and c.is_visible()]
    if len(nodes)!=1:raise ValueError('Unique template page header required')
    nodes[0].click_input(button='right',coords=(40,nodes[0].rectangle().height()//2));time.sleep(.2)
    items=[]
    for win in Desktop(backend='win32').windows():
        if win.process_id()==root.process_id() and win.class_name().startswith('Qt5QWindowPopup') and win.is_visible():
            popup=Desktop(backend='uia').window(handle=win.handle).wrapper_object()
            items.extend({'name':c.window_text(),'enabled':c.is_enabled()} for c in popup.descendants(control_type='MenuItem') if c.is_visible())
    (ROOT/'evidence/page-copy-menu.json').write_text(json.dumps(items,ensure_ascii=False,indent=2),encoding='utf8')
    if not items:raise ValueError('Observed page context menu required')
