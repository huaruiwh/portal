"""Move only the interior VERTICAL table lines back to the original column boundaries.

Rows are left exactly as they are (the original divides rows evenly; the reviewed 均等 state
already matches it), so only the custom column widths are restored.

Request:  {'table_columns':{'page':P,'key':'TB_n','bounds':{...},'wanted':[x0,x1,x2,x3]}}
The pixel projection and drag/cursor verification follow the reviewed table_grid procedure.
"""
import json,time,ctypes,re
from ctypes import wintypes
from PIL import ImageGrab
from pywinauto import Desktop,mouse
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save
from eb_native_form import tab,confirm
from eb_page26_shapes import cancel
from eb_live_fields import capture
from eb_page203_rewrite import TITLES
NAMES=('X :',' Y :',' 宽度 :','高度 :')

def run(handle,q):
    req=q['table_columns'];page=int(req['page']);key=req['key']
    wanted=[float(v) for v in req['wanted']]
    root,w=target(handle,page)
    d,_=properties(root,w,key,TITLES['TB'])
    out={'page':page,'key':key,'wanted':wanted,'image_transmitted':False}
    try:
        tab(d,'一般属性')
        out['counts']=capture(d,[('Edit','垂直 :'),('Edit','水平 :')])
        cs=[c for c in d.descendants(control_type='ComboBox') if c.is_visible() and c.element_info.name=='间距 :']
        out['spacing_before']=cs[0].selected_text() if len(cs)==1 else None
        tab(d,'轮廓')
        g={r['name']:r['value'] for r in capture(d,[('Edit',n) for n in NAMES])}
        out['bounds_before']=g
        actual={r['name']:r['value'] for r in capture(d,[('Edit',n) for n in NAMES])}
        for n,v in req['bounds'].items():
            if actual.get(n)!=str(v):
                from eb_native_form import fields
                fields(d,[{'type':'Edit','name':k,'value':v} for k,v in req['bounds'].items()],commit_edits=True)
                break
        confirm(d);d=None;save(root)
    finally:
        if d is not None:cancel(d)
    root,w=target(handle,page)
    bars=[c for c in w.children() if c.element_info.class_name.startswith('EBRibbonStatusBar')]
    if len(bars)!=1:raise ValueError('Unique canvas statusbar required')
    sample=[]
    for px,py in [(900,400),(1300,800)]:
        mouse.move(coords=(px,py));time.sleep(.15)
        texts=[c.window_text() for c in bars[0].descendants(control_type='Text') if c.is_visible()]
        sample.append({k:int(next(re.search(r'^'+k+r'\s*=\s*(-?\d+)',s)[1] for s in texts if re.search(r'^'+k+r'\s*=\s*(-?\d+)',s))) for k in ['X','Y']})
    sx=400/(sample[1]['X']-sample[0]['X']);sy=400/(sample[1]['Y']-sample[0]['Y'])
    ox=900-sample[0]['X']*sx;oy=400-sample[0]['Y']*sy
    x,y,width,height=[int(g[n]) for n in NAMES]
    box=[round(ox+x*sx)-4,round(oy+y*sy)-4,round(ox+(x+width)*sx)+5,round(oy+(y+height)*sy)+5]
    def current():
        im=ImageGrab.grab(bbox=tuple(box)).convert('RGB');ww,hh=im.size;xs=[0]*ww
        for yy in range(hh):
            for xx in range(ww):
                rr,gg,bb=im.getpixel((xx,yy))
                if bb>220 and rr<30 and gg<30:xs[xx]+=1
        gs=[]
        for i,v in enumerate(xs):
            if v>=hh*.65:
                if gs and i==gs[-1][-1]+1:gs[-1].append(i)
                else:gs.append([i])
        return [(box[0]+sum(a)/len(a)-ox)/sx for a in gs]
    u=ctypes.windll.user32;u.LoadCursorW.restype=ctypes.c_void_p
    class CI(ctypes.Structure):_fields_=[('cbSize',wintypes.DWORD),('flags',wintypes.DWORD),('hCursor',wintypes.HANDLE),('ptScreenPos',wintypes.POINT)]
    live=current()
    out['live_before']=live
    # Record what the detector actually sees before any drag, so a mismatch is diagnosable.
    im=ImageGrab.grab(bbox=tuple(box)).convert('RGB');ww,hh=im.size;xs=[0]*ww
    for yy in range(hh):
        for xx in range(ww):
            rr,gg,bb=im.getpixel((xx,yy))
            if bb>220 and rr<30 and gg<30:xs[xx]+=1
    out['diagnostics']={'crop_box':box,'crop_size':[ww,hh],'max_count':max(xs) if xs else 0,
                        'columns_above':{str(t):len([v for v in xs if v>=hh*t]) for t in (0.3,0.5,0.65,0.8)},
                        'histogram_peaks':[{'x':box[0]+i,'count':xs[i]} for i in range(ww) if xs[i]>=hh*0.3]}
    if len(live)!=len(wanted):
        (ROOT/f'evidence/table-columns-{page}-{key}.json').write_text(json.dumps(dict(out,error='live line count differs'),ensure_ascii=False,indent=2),encoding='utf8')
        raise ValueError('Observed vertical line count differs: %d vs %d'%(len(live),len(wanted)))
    if req.get('op')=='probe':
        (ROOT/f'evidence/table-columns-{page}-{key}.json').write_text(json.dumps(dict(out,probe=True),ensure_ascii=False,indent=2),encoding='utf8')
        return
    changes=[]
    for i in range(1,len(wanted)-1):
        live=current()
        if len(live)!=len(wanted):raise ValueError('Vertical line count changed while dragging')
        oldpos,newpos=live[i],wanted[i]
        if abs(oldpos-newpos)<=1.8:continue
        start=(round(ox+oldpos*sx),round(oy+(y+3)*sy))
        end=(round(ox+newpos*sx),start[1])
        found=False
        for delta in (0,-1,1,-2,2,-3,3):
            trial=(start[0]+delta,start[1])
            mouse.move(coords=trial);time.sleep(.08)
            ci=CI();ci.cbSize=ctypes.sizeof(ci);u.GetCursorInfo(ctypes.byref(ci))
            if ci.hCursor==u.LoadCursorW(None,32644):start=trial;found=True;break
        if not found:raise ValueError('Divider resize cursor not observed at %s'%(start,))
        mouse.press(coords=start)
        try:mouse.move(coords=end)
        finally:mouse.release(coords=end)
        time.sleep(.12);changes.append({'index':i,'before':oldpos,'after':newpos})
    root.set_focus();time.sleep(.3)
    after=current()
    out['live_after']=after;out['changes']=changes
    ok=len(after)==len(wanted) and all(abs(v-e)<=2.5 if i in (0,len(wanted)-1) else abs(v-e)<=1.8 for i,(v,e) in enumerate(zip(after,wanted)))
    out['verified']=bool(ok)
    d,_=properties(root,w,key,TITLES['TB'])
    try:
        tab(d,'一般属性')
        out['counts_after']=capture(d,[('Edit','垂直 :'),('Edit','水平 :')])
        cs=[c for c in d.descendants(control_type='ComboBox') if c.is_visible() and c.element_info.name=='间距 :']
        out['spacing_after']=cs[0].selected_text() if len(cs)==1 else None
    finally:cancel(d)
    if out['counts_after']!=out['counts']:raise ValueError('Row/column counts changed while fixing columns')
    save(root)
    (ROOT/f'evidence/table-columns-{page}-{key}.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
    if not ok:raise ValueError('Fixed column lines not verified: %s %s'%(page,key))
