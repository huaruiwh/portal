"""Rebuild source main-page rectangle primitives with exact border color."""
import json,time
from pywinauto import Desktop
from pywinauto.keyboard import send_keys
from eb_extract import ROOT,rows
from eb_object_ui import target,properties,save
from eb_native_form import tab,fields,confirm
from eb_color_picker import set_rgb,probe
from eb_layout import geometry

def run(handle,q):
    n=int(q['build_rectangle'])
    page=int(q['page'])
    if not (page==16 and n in range(5) or page==201 and n in (0,1) or page in (10,103,200,202) and n==0):raise ValueError('Unreviewed rectangle')
    if page==16 and n==4:
        if (ROOT/'evidence/target-016-DW4-built.json').exists():raise ValueError('Saved rectangle exists; no duplicate')
        audit=json.loads((ROOT/'evidence/target-page16-audit.json').read_text(encoding='utf8'))
        if audit['source_count']!=101 or 'DW_4' not in audit['missing']:raise ValueError('Fresh complete-source missing rectangle proof required')
    if page in (200,202) and (ROOT/f'evidence/target-{page:03d}-DW0-built.json').exists():raise ValueError('Saved rectangle exists; no duplicate')
    if page==10:
        if (ROOT/'evidence/target-010-DW0-built.json').exists():raise ValueError('Saved rectangle exists; no duplicate')
        audit=json.loads((ROOT/'evidence/target-page10-audit.json').read_text(encoding='utf8'))
        if 'DW_0' not in audit['missing']:raise ValueError('Missing rectangle required')
    source=json.loads((ROOT/'evidence'/'source-object-properties'/f'{page:03d}_DW_{n}.json').read_text(encoding='utf8'))
    if page in (10,200,201,202) and 'border' in source.get('rectangle_colors',{}):source['colors']={'颜色 :':source['rectangle_colors']['border']}
    if source['dialog_title']!='矩形元件属性' or source.get('colors',{}).keys()!={'颜色 :'}:raise ValueError('Source rectangle identity and exact border RGB required')
    root=Desktop(backend='win32').window(handle=handle).wrapper_object()
    if '组装机_MT8106iP.emtp' not in root.window_text() or f'[{page} - ' not in root.window_text():raise ValueError('Exact target page required')
    w=Desktop(backend='uia').window(handle=handle).wrapper_object()
    if q.get('move_palette_only'):
        palettes=[win for win in Desktop(backend='win32').windows() if win.process_id()==root.process_id() and win.is_visible() and win.window_text()=='属性']
        if len(palettes)!=1:raise ValueError('Unique observed drawing palette required')
        palettes[0].move_window(x=1900,y=40)
        return
    if q.get('draw_after_palette'):
        palettes=[win for win in Desktop(backend='win32').windows() if win.process_id()==root.process_id() and win.is_visible() and win.window_text()=='属性']
        if len(palettes)!=1:raise ValueError('Unique observed drawing palette required')
        palettes[0].move_window(x=1900,y=40)
        root.set_focus();root.drag_mouse_input(dst=(750,700),src=(600,600),button='left',absolute=False)
        time.sleep(.3)
        windows=[win for win in Desktop(backend='win32').windows() if win.process_id()==root.process_id() and win.is_visible() and win.class_name()=='#32770']
        result=[{'handle':win.handle,'title':win.window_text()} for win in windows]
        (ROOT/'evidence'/'rectangle-entry-after-close.json').write_text(json.dumps(result,ensure_ascii=False),encoding='utf8')
        return
    if not q.get('resume'):
        root.set_focus();root.click_input(coords=(373,52) if page in (10,16,103,200,201,202) else (350,52));root.click_input(coords=(54,118) if page in (10,16,103,200,201,202) else (62,116))
        time.sleep(.5)
        palettes=[win for win in Desktop(backend='win32').windows() if win.process_id()==root.process_id() and win.is_visible() and win.window_text()=='属性']
        if len(palettes)!=1:raise ValueError('Unique observed drawing palette required')
        palettes[0].move_window(x=1900,y=40)
        root.click_input(coords=(600,500));root.click_input(coords=(700,550))
        time.sleep(.3)
        if q.get('probe'):
            windows=[win for win in Desktop(backend='win32').windows() if win.process_id()==root.process_id() and win.is_visible() and win.class_name()=='#32770']
            result=[{'handle':win.handle,'title':win.window_text(),'controls':rows(Desktop(backend='uia').window(handle=win.handle).wrapper_object())} for win in windows]
            (ROOT/'evidence'/'rectangle-entry.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
            return
        send_keys('{ESC}',pause=.01)
    if q.get('resume'):root.set_focus();send_keys('{ESC}',pause=.01);time.sleep(.2)
    d,name=properties(root,w,f'DW_{n}','矩形元件属性')
    tabs=[c.window_text() for c in d.descendants(control_type='TabItem') if c.is_visible() and c.window_text().strip()=='形状']
    if len(tabs)!=1:raise ValueError('Observed shape tab required')
    tab(d,tabs[0]);fields(d,source['tabs'][' 形状'])
    set_rgb(d,source['colors']['颜色 :'])
    if probe(d)!=source['colors']['颜色 :']:raise ValueError('Rectangle border RGB mismatch')
    if page in (10,200,201,202):
        colors=source['rectangle_colors']
        for i,key in enumerate(('fill','border') if 'fill' in colors else ('border',)):
            set_rgb(d,colors[key],'颜色 :',i)
            if probe(d,'颜色 :',i)!=colors[key]:raise ValueError('Rectangle exact color mismatch')
    shape_settings=rows(d);tab(d,'安全');fields(d,source['tabs']['安全']);safety=rows(d)
    tab(d,'轮廓');shape=geometry(source)
    fields(d,[{'type':'Edit','name':key,'value':value} for key,value in shape.items()]);shape_readback=rows(d)
    confirm(d);save(root)
    report={'page':page,'source':source['object'],'target':f'DW_{n}','shape':shape_settings,'safety':safety,'colors':source['colors'],'geometry':shape_readback,
            'saved_requested':True,'line_width_and_style_review_pending':True,'offline_simulation_verified':False}
    (ROOT/'evidence'/f'target-{page:03d}-DW{n}-built.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')

