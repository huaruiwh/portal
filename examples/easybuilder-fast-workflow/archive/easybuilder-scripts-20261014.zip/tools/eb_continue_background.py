"""Serial, saved-report-aware background rebuilding; no concurrent GUI."""
import json
from eb_rebuild_page import ROOT,call
def run():
    lock=ROOT/'tools/batch.lock'
    with lock.open('x'):pass
    progress={'page':103,'completed':[],'ok':False}
    report=ROOT/'evidence/page-103-workflow.json'
    def persist():report.write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf8')
    try:
        call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
        matches=[w for w in ws if '组装机_MT8106iP.emtp' in w['title'] and w['class']=='EasyBuilderPro']
        if len(matches)!=1:raise ValueError('One target required')
        h=matches[0]['handle'];call('uia',h,json.dumps({'open_target_page':103}))
        for kind,n,q in [('FK',i,{'page':103,'build_fk':i}) for i in range(7)]+[('TS',0,{'page':103,'build_bit_general':0,'bit_kind':'TS'}),('DW',0,{'page':103,'build_rectangle':0})]:
            progress['stage']=f'{kind}_{n}';persist()
            if not (ROOT/f'evidence/target-103-{kind}{n}-built.json').exists():call('uia',h,json.dumps(q))
            progress['completed'].append(f'{kind}_{n}');persist();print('saved '+f'{kind}_{n}',flush=True)
        progress['ok']=True;progress['stage']='buttons and rectangle saved';persist()
    except Exception as e:progress['error']=str(e);persist();raise
    finally:lock.unlink(missing_ok=True)
if __name__=='__main__':run()
