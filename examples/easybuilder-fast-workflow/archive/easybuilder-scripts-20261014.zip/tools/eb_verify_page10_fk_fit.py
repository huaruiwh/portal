import json
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
with lock.open('x'):pass
try:
 call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'));w=next(w for w in ws if w['class']=='EasyBuilderPro' and '_MT8106iP_' in w['title'])
 # Compile is captured separately before parameter verification.
 print('parameter readback started',flush=True)
 inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(v['observed_objects'] for v in inv['pages'] if v['id']==10)
 for i in range(6):
  import re
  key='FK_'+str(i);name=next(n for n in names if re.search(r'(?:^|\])\s*'+re.escape(key)+r'(?:\s|$)',n))
  call('uia',w['handle'],json.dumps({'extract':{'page':10,'object':name,'target_readonly':True}}))
  t=json.loads((ROOT/f'evidence/target-object-properties/010_{key}.json').read_text(encoding='utf8'));p=ROOT/f'evidence/page10-{key}-fit.json';d=json.loads(p.read_text(encoding='utf8'))
  actual={v['name']:v.get('value') for rs in t['tabs'].values() for v in rs if v['type']=='Edit' and v['name'] in d['expected']}
  d['property_reopened_verified']=actual==d['expected'];p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
  if not d['property_reopened_verified']:raise ValueError('Persisted geometry mismatch '+key)
  print(key,'verified',flush=True)
finally:lock.unlink(missing_ok=True)
