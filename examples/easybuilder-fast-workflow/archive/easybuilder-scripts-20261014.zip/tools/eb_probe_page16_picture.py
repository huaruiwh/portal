"""Open a cancellable bit-picture gallery and record native library menu names."""
import json,time
from pywinauto import Desktop
from eb_object_ui import target,dialog
from eb_native_form import tab,fields
from eb_extract import ROOT

def run(handle,q):
 root,w=target(handle,16)
 if not q.get('resume_gallery'):
  from eb_ribbon import create
  create(root,'BIT','新增 位状态指示灯/位状态切换开关')
  d=dialog(root.process_id(),'新增 位状态指示灯/位状态切换开关');tab(d,'图片')
  fields(d,[{'type':'CheckBox','name':'使用图片','value':1},{'type':'CheckBox','name':'使用向量图','value':0}])
  bs=[c for c in d.descendants(control_type='Button') if c.element_info.name=='图库...' and c.is_visible() and c.is_enabled()]
  if len(bs)!=1:raise ValueError('One enabled bitmap gallery button required')
  bs[0].click_input()
 g=dialog(root.process_id(),'图片管理')
 if q.get('open_menu',True):
  ms=[c for c in g.descendants(control_type='MenuItem') if c.is_visible() and c.element_info.name and c.rectangle().top<g.rectangle().top+150]
  if len(ms)!=1:raise ValueError('One gallery category control required')
  ms[0].click_input();time.sleep(.2)
 entries=[]
 for win in Desktop(backend='win32').windows():
  if win.process_id()==root.process_id() and win.is_visible() and win.class_name().startswith('Qt5QWindowPopup'):
   u=Desktop(backend='uia').window(handle=win.handle).wrapper_object()
   entries.extend({'name':c.element_info.name,'type':c.element_info.control_type,'rect':[c.rectangle().left,c.rectangle().top,c.rectangle().right,c.rectangle().bottom]} for c in u.descendants() if c.is_visible() and c.element_info.name)
 (ROOT/'evidence/page16-picture-library-menu.json').write_text(json.dumps({'entries':entries,'gallery_handle':g.handle},ensure_ascii=False,indent=2),encoding='utf8')
