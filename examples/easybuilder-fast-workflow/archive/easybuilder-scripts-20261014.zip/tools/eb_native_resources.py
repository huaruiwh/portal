"""Read built-in menu/accelerator resources as data; never execute the binary."""
import ctypes,json,struct
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
K=ctypes.WinDLL('kernel32',use_last_error=True)
K.LoadLibraryExW.argtypes=[ctypes.c_wchar_p,ctypes.c_void_p,ctypes.c_uint];K.LoadLibraryExW.restype=ctypes.c_void_p
K.FindResourceW.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p];K.FindResourceW.restype=ctypes.c_void_p
K.LoadResource.argtypes=[ctypes.c_void_p,ctypes.c_void_p];K.LoadResource.restype=ctypes.c_void_p
K.LockResource.argtypes=[ctypes.c_void_p];K.LockResource.restype=ctypes.c_void_p
K.SizeofResource.argtypes=[ctypes.c_void_p,ctypes.c_void_p];K.SizeofResource.restype=ctypes.c_uint
CALLBACK=ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_ssize_t)
K.EnumResourceNamesW.argtypes=[ctypes.c_void_p,ctypes.c_void_p,CALLBACK,ctypes.c_ssize_t]
K.FreeLibrary.argtypes=[ctypes.c_void_p]
TYPE_CALLBACK=ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_ssize_t)
K.EnumResourceTypesW.argtypes=[ctypes.c_void_p,TYPE_CALLBACK,ctypes.c_ssize_t]

def read(binary):
    handle=K.LoadLibraryExW(str(binary),None,2)
    if not handle:raise OSError(ctypes.get_last_error(),str(binary))
    result={'binary':str(binary),'menus':[],'accelerators':[],'strings':{},'toolbars':[],'unsupported_menus':[]}
    try:
        result['resource_types']=[]
        @TYPE_CALLBACK
        def visit_type(module,kind,param):
            result['resource_types'].append(kind if kind<=65535 else ctypes.wstring_at(kind))
            return True
        K.EnumResourceTypesW(handle,visit_type,0)
        for resource_type in (4,6,9,241):
            @CALLBACK
            def visit(module,kind,name,param):
                label=name if name<=65535 else ctypes.wstring_at(name)
                found=K.FindResourceW(module,name,kind);size=K.SizeofResource(module,found)
                data=ctypes.string_at(K.LockResource(K.LoadResource(module,found)),size)
                if resource_type==241:
                    version,width,height,count=struct.unpack_from('<HHHH',data)
                    if version!=1 or size!=8+2*count:raise ValueError('Unexpected toolbar resource layout')
                    result['toolbars'].append({'resource':label,'width':width,'height':height,'commands':list(struct.unpack_from('<'+'H'*count,data,8))})
                elif resource_type==6:
                    at=0
                    for index in range(16):
                        length=struct.unpack_from('<H',data,at)[0];at+=2
                        value=data[at:at+2*length].decode('utf-16le');at+=2*length
                        if value:result['strings'][str((int(label)-1)*16+index)]=value
                elif resource_type==9:
                    if size%8:raise ValueError('Unexpected accelerator resource size')
                    result['accelerators'].extend({'resource':label,'flags':f,'key':k,'command':c} for f,k,c,p in struct.iter_unpack('<HHHH',data))
                elif data[:2]==b'\0\0':
                    offset=4+struct.unpack_from('<H',data,2)[0]
                    def string(at):
                        end=at
                        while end+2<=size and data[end:end+2]!=b'\0\0':end+=2
                        return data[at:end].decode('utf-16le'),end+2
                    def items(at,parents):
                        while at<size:
                            flags=struct.unpack_from('<H',data,at)[0];at+=2
                            command=None
                            if not flags&16:command=struct.unpack_from('<H',data,at)[0];at+=2
                            text,at=string(at)
                            result['menus'].append({'resource':label,'path':parents+[text],'command':command,'flags':flags})
                            if flags&16:at=items(at,parents+[text])
                            if flags&128:break
                        return at
                    items(offset,[])
                else:result['unsupported_menus'].append({'resource':label,'version':data[:2].hex(),'size':size})
                return True
            K.EnumResourceNamesW(handle,resource_type,visit,0)
    finally:K.FreeLibrary(handle)
    return result

if __name__=='__main__':
    result=read(Path(r'C:\Program Files\EBpro\EasyBuilder Pro.exe'))
    (ROOT/'evidence/native-command-resources.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({'menus':len(result['menus']),'accelerators':len(result['accelerators']),'extended_menus':len(result['unsupported_menus']),'resource_types':result['resource_types']}))
