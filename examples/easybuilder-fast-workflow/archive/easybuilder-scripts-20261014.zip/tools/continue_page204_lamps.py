"""Serial existing-template lamp copies, original204 appearance must match."""
import json,os,traceback
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock';wf=ROOT/'evidence/page204-lamps-workflow.json'
with lock.open('x',encoding='utf8') as f:json.dump({'pid':os.getpid(),'task':'204 lamps'},f)
d={'pid':os.getpid(),'page':204,'status':'running','verified':[]}
def checkpoint():
 wf.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
 p=ROOT/'evidence/resume-checkpoint.json';c=json.loads(p.read_text(encoding='utf8'));c.update(status='page204-lamps-'+d['status'],batch_running=d['status']=='running',active_page=204,current_stage=d.get('current'));p.write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding='utf8')
try:
 proof=json.loads((ROOT/'evidence/original-style-204-BL_0.json').read_text(encoding='utf8'))
 if not proof.get('original_style_fields_verified'):raise ValueError('BL0 original fields readback required')
 for n in range(10):
  key=f'BL_{n}';d['current']=key;checkpoint();p=ROOT/f'evidence/target-204-BL{n}-built.json'
  if not p.exists():call('uia',10488686,json.dumps({'page':204,'copy_200_style_object':key,'local_original_template':'BL_0','build_bit_general':0},ensure_ascii=False))
  if not json.loads(p.read_text(encoding='utf8')).get('saved_reopened_verified'):raise ValueError('Saved lamp requires review; do not duplicate '+key)
  d['verified'].append(key);checkpoint();print(json.dumps({'lamp_saved_reopened_verified':key}),flush=True)
 d['status']='lamps-saved-final-page-review-pending'
except Exception:
 d['status']='needs-review';d['error']=traceback.format_exc();print(d['error'],flush=True)
finally:checkpoint();lock.unlink(missing_ok=True)
