"""Transactional target-only layout adaptation to890x469, current bounds as baseline."""
import json,re,time,ctypes
from pathlib import Path
from pywinauto import Desktop
from pywinauto.keyboard import send_keys
from eb_rebuild_page import ROOT
from eb_native_form import tab,fields,confirm,typed_children
from eb_page26_shapes import cancel
from eb_extract import rows
from eb_object_ui import target,properties,save
from eb_open_page import run as open_page
from eb_page203_rewrite import TITLES
from eb_live_fields import capture
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_timing import timed
DIR=ROOT/'evidence/scale-890x469'
NAMES=('X :',' Y :',' 宽度 :','高度 :')
def put(path,data):
 path.parent.mkdir(parents=True,exist_ok=True)
 tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8');tmp.replace(path)
def load(p):return json.loads(p.read_text(encoding='utf8'))
def directory(w):
 from eb_directory import scope
 ds=[c for c in w.descendants(control_type='TabItem')if c.element_info.name=='目录树'and c.is_visible()]
 if len(ds)==1:ds[0].click_input()
 return scope(w)
def settings(h,page):
 root,w=target(h,page)
 existing=[v for v in Desktop(backend='win32').windows()if v.process_id()==root.process_id()and v.is_visible()and v.window_text()=='窗口设置']
 if existing:
  if len(existing)!=1:raise ValueError('Ambiguous scale settings recovery')
  d=Desktop(backend='uia').window(handle=existing[0].handle).wrapper_object()
  number=capture(d,[('Edit','窗口编号 :')])
  if len(number)!=1 or str(number[0]['value'])!=str(page):raise ValueError('Scale settings recovery page differs')
  return root,w,d
 dr=directory(w)
 popups=[p for p in Desktop(backend='win32').windows()if p.process_id()==root.process_id()and p.is_visible()and p.class_name().startswith('Qt5QWindowPopup')]
 if popups:root.set_focus();send_keys('{ESC}',pause=.01)
 ps=[c for c in dr.descendants(control_type='TreeItem',cache_enable=True)if re.match(r'^'+str(page)+r'\s*:',c.element_info.name)]
 if len(ps)!=1 or ps[0].rectangle().height()<=0 or ps[0].rectangle().top<root.rectangle().top+240 or ps[0].rectangle().bottom>root.rectangle().bottom-50:
  from pywinauto import mouse
  ts=[t for t in dr.descendants(control_type='Tree')if t.is_visible()]
  if len(ts)!=1:raise ValueError('Unique page tree viewport required')
  r=ts[0].rectangle();mouse.scroll(coords=((r.left+r.right)//2,(r.top+r.bottom)//2),wheel_dist=80);time.sleep(.1)
  ps=[c for c in dr.descendants(control_type='TreeItem',cache_enable=True)if re.match(r'^'+str(page)+r'\s*:',c.element_info.name)]
 if len(ps)!=1:raise ValueError('Unique scale page header required')
 if not(root.rectangle().top+240<=ps[0].rectangle().top<ps[0].rectangle().bottom<=root.rectangle().bottom-50):raise ValueError('Settings page header outside viewport')
 acts=[];observed=[]
 for attempt in range(2):
  root.set_focus()
  if attempt:send_keys('{ESC}',pause=.01)
  ps[0].click_input(button='right',coords=(40,ps[0].rectangle().height()//2));time.sleep(.4)
  acts=[];observed=[]
  for pop in Desktop(backend='win32').windows():
   if pop.process_id()==root.process_id()and pop.is_visible()and(pop.class_name().startswith('Qt5QWindowPopup')or pop.class_name()=='#32768'):
    u=Desktop(backend='uia').window(handle=pop.handle).wrapper_object()
    entries=[c for c in u.descendants(control_type='MenuItem')if c.is_visible()]
    observed.extend(c.window_text()for c in entries)
    acts.extend(c for c in entries if c.window_text()=='设置...')
  if len(acts)==1:break
 if len(acts)!=1:
  put(DIR/f'page-{page}-settings-menu-failure.json',{'observed':observed,'page':page,'node':ps[0].element_info.name})
  raise ValueError('Unique scale settings action required: '+repr(observed))
 acts[0].click_input()
 from eb_object_ui import dialog
 return root,w,dialog(root.process_id(),'窗口设置')
@timed
def geo(d):
 tab(d,'轮廓')
 try:rs=capture(d,[('Edit',n)for n in NAMES])
 except ValueError:rs=rows(d)
 g={r['name']:r['value']for r in rs if r['type']=='Edit'and r['name']in NAMES and'value'in r}
 if not {'X :',' Y :'}.issubset(g):raise ValueError('Missing actual coordinates')
 return g
def scaled(g,bounds):
 sx=890/int(bounds['宽度 :']);sy=469/int(bounds['高度 :'])
 out={}
 for pos,size,ratio in [('X :',' 宽度 :',sx),(' Y :','高度 :',sy)]:
  start=int(g[pos]);out[pos]=str(round(start*ratio))
  if size in g:out[size]=str(max(1,round((start+int(g[size]))*ratio)-round(start*ratio)))
 return out
def font_scopes(page,key):
 # Cached source indicates available tabs only; current target values are baseline.
 p=ROOT/f'evidence/source-object-properties/{page:03d}_{key}.json'
 if page==202:
  m=load(ROOT/'evidence/page202-copy-mapping.json').get('mapping',{})
  keys=[k for k,v in m.items()if v==key]
  if len(keys)==1:p=ROOT/f'evidence/source-object-properties/{page:03d}_{keys[0]}.json'
 if page==208 and not p.exists():
  c=load(ROOT/'evidence/page208-whole-page-copy.json')
  if c.get('template')==204 and c.get('stage')=='saved-compiled'and c.get('count')==36:p=ROOT/f'evidence/source-object-properties/204_{key}.json'
 if not p.exists():raise ValueError('Missing property tab inventory '+str(p))
 s=load(p)
 return [t for t,rs in s['tabs'].items()if t!='轮廓'and any(r['type']=='ComboBox'and r['name']=='尺寸 :'for r in rs)]
@timed
def fonts(d,scopes,before=None,ratio=1):
 result={}
 for scope in scopes:
  tab(d,scope);cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']
  states=ComboBoxWrapper(cs[0].handle).item_texts()if len(cs)==1 else [None]
  result[scope]={}
  for state in states:
   if state is not None:
    ComboBoxWrapper(cs[0].handle).select(state)
    time.sleep(.1) # Allow the state-specific font fields to finish loading.
   sid=str(state)
   if before is not None:
    size=max(6,round(int(before[scope][sid]['size'])*ratio))
    size_controls=[c for c in typed_children(d,'ComboBox') if c.element_info.name=='尺寸 :']
    if len(size_controls)!=1:raise ValueError('Unique font size combo required for commit')
    ComboBoxWrapper(size_controls[0].handle).set_focus()
    # Emit the native selection notifications even when the visible value matches.
    font_combo=ComboBoxWrapper(size_controls[0].handle)
    choices=font_combo.item_texts()
    if str(size) not in choices:raise ValueError('Requested font size unavailable')
    # Keyboard selection follows the application commit path, including editable text objects.
    send_keys('{HOME}'+('{DOWN}'*choices.index(str(size)))+'{TAB}',pause=.02)
   else:
    rs=capture(d,[('ComboBox','尺寸 :')]);size=int(rs[0]['value'])
   result[scope][sid]={'size':str(size)}
 return result
def table_grid(h,page):
 # Reuse the previously validated local-only pixel projection and resize-cursor guard.
 from PIL import ImageGrab
 from pywinauto import mouse
 from ctypes import wintypes
 root,w=target(h,page);rp=DIR/f'{page}_TB_0.json';r=load(rp);g=r['after'];old=r['before']
 d,_=properties(root,w,'TB_0',TITLES['TB']);tab(d,'一般属性');general=rows(d);put(DIR/f'table-general-{page}.json',general)
 fields(d,[{'type':'ComboBox','name':'间距 :','value':'自定义'}]);live_bounds=geo(d)
 put(DIR/f'table-bounds-{page}.json',{'before_probe':live_bounds,'expected':g})
 fields(d,[{'type':'Edit','name':n,'value':v}for n,v in g.items()],commit_edits=True);confirm(d);save(root)
 d,_=properties(root,w,'TB_0',TITLES['TB']);cancel(d)
 bars=[c for c in w.children()if c.element_info.class_name.startswith('EBRibbonStatusBar')]
 if len(bars)!=1:raise ValueError('Unique canvas statusbar required')
 sample=[]
 for px,py in [(900,400),(1300,800)]:
  mouse.move(coords=(px,py));time.sleep(.15);texts=[c.window_text()for c in bars[0].descendants(control_type='Text')if c.is_visible()]
  sample.append({k:int(next(re.search(r'^'+k+r'\s*=\s*(-?\d+)',s)[1]for s in texts if re.search(r'^'+k+r'\s*=\s*(-?\d+)',s)))for k in ['X','Y']})
 sx=400/(sample[1]['X']-sample[0]['X']);sy=400/(sample[1]['Y']-sample[0]['Y']);ox=900-sample[0]['X']*sx;oy=400-sample[0]['Y']*sy
 x,y,width,height=[int(g[n])for n in NAMES];box=[round(ox+x*sx)-2,round(oy+y*sy)-2,round(ox+(x+width)*sx)+3,round(oy+(y+height)*sy)+3]
 bp=ROOT/f'evidence/page{page}-table-grid-target.json'
 if not bp.exists()and page==202 and old==load(DIR/'200_TB_0.json')['before']and load(ROOT/'evidence/page202-copy-mapping.json').get('bindings_verified'):
  bp=ROOT/'evidence/page200-table-grid-target.json'
 base=load(bp)
 wanted={axis:[(x if axis=='vertical_lines'else y)+(v-int(old['X :'if axis=='vertical_lines'else' Y :']))*(width/int(old[' 宽度 :'])if axis=='vertical_lines'else height/int(old['高度 :']))for v in base[axis]]for axis in ('vertical_lines','horizontal_lines')}
 def current():
  im=ImageGrab.grab(bbox=tuple(box)).convert('RGB');ww,hh=im.size;xs=[0]*ww;ys=[0]*hh
  for yy in range(hh):
   for xx in range(ww):
    rr,gg,bb=im.getpixel((xx,yy))
    if bb>220 and rr<30 and gg<30:xs[xx]+=1;ys[yy]+=1
  def centers(cs,threshold,offset,origin,scale):
   gs=[]
   for i,v in enumerate(cs):
    if v>=threshold:
     if gs and i==gs[-1][-1]+1:gs[-1].append(i)
     else:gs.append([i])
   return [(offset+sum(a)/len(a)-origin)/scale for a in gs]
  return {'vertical_lines':centers(xs,hh*.65,box[0],ox,sx),'horizontal_lines':centers(ys,ww*.65,box[1],oy,sy)}
 u=ctypes.windll.user32;u.LoadCursorW.restype=ctypes.c_void_p
 class CI(ctypes.Structure):_fields_=[('cbSize',wintypes.DWORD),('flags',wintypes.DWORD),('hCursor',wintypes.HANDLE),('ptScreenPos',wintypes.POINT)]
 changes=[]
 for axis,cursor_id in [('vertical_lines',32644),('horizontal_lines',32645)]:
  for i in range(1,len(wanted[axis])-1):
   live=current()[axis]
   if len(live)!=len(wanted[axis]):put(DIR/f'table-grid-{page}.json',{'actual':current(),'expected':wanted,'verified':False,'image_transmitted':False});raise ValueError('Scaled table grid line count differs')
   oldpos,newpos=live[i],wanted[axis][i]
   if abs(oldpos-newpos)<=1.8:continue
   start=(round(ox+oldpos*sx),round(oy+(y+3)*sy))if axis=='vertical_lines'else(round(ox+(x+3)*sx),round(oy+oldpos*sy))
   end=(round(ox+newpos*sx),start[1])if axis=='vertical_lines'else(start[0],round(oy+newpos*sy))
   cursor_found=False
   for delta in [0,-1,1,-2,2,-3,3]:
    trial=(start[0]+delta,start[1])if axis=='vertical_lines'else(start[0],start[1]+delta)
    mouse.move(coords=trial);time.sleep(.08);ci=CI();ci.cbSize=ctypes.sizeof(ci);u.GetCursorInfo(ctypes.byref(ci))
    if ci.hCursor==u.LoadCursorW(None,cursor_id):start=trial;cursor_found=True;break
   if not cursor_found:
    put(DIR/f'table-grid-{page}.json',{'actual':current(),'expected':wanted,'cursor_failure':{'axis':axis,'index':i,'point':start,'actual_cursor':ci.hCursor,'required_cursor':u.LoadCursorW(None,cursor_id)},'verified':False,'image_transmitted':False});raise ValueError('Observed scaled divider resize cursor required')
   mouse.press(coords=start)
   try:mouse.move(coords=end)
   finally:mouse.release(coords=end)
   time.sleep(.1);changes.append({'axis':axis,'index':i,'before':oldpos,'after':newpos})
 d,_=properties(root,w,'TB_0',TITLES['TB']);after_drag=geo(d)
 if after_drag!=g:fields(d,[{'type':'Edit','name':n,'value':v}for n,v in g.items()],commit_edits=True);confirm(d);save(root)
 else:cancel(d)
 for _ in range(20):
  if root.is_enabled():break
  time.sleep(.05)
 root.set_focus();time.sleep(.3)
 actual=current();verified=all(len(actual[a])==len(wanted[a])and all(abs(v-e)<=(2.5 if i in (0,len(wanted[a])-1)else 1.8)for i,(v,e)in enumerate(zip(actual[a],wanted[a])))for a in wanted)
 put(DIR/f'table-grid-{page}.json',{'actual':actual,'expected':wanted,'changes':changes,'bounds_after_drag':after_drag,'verified':verified,'tolerance_interior':1.8,'tolerance_outer_edge_calibration':2.5,'image_transmitted':False})
 if not verified:raise ValueError('Scaled custom table lines mismatch')
 save(root)
def lamp_overlap(h,page,p):
 groups={}
 for key in p['keys']:
  if not key.startswith('BL_'):continue
  r=load(DIR/f'{page}_{key}.json');g=r['after']
  groups.setdefault((g['X :'],g[' 宽度 :']),[]).append(r)
 for rs in groups.values():
  rs.sort(key=lambda r:int(r['after'][' Y :']))
  for i in range(len(rs)-2,-1,-1):
   a,b=rs[i],rs[i+1];g=a['after'];end=int(g[' Y :'])+int(g['高度 :']);next_y=int(b['after'][' Y :'])
   if end<next_y or not('native_minimum_bounds'in a or'native_minimum_bounds'in b):continue
   original_gap=int(b['before'][' Y :'])-int(a['before'][' Y :'])-int(a['before']['高度 :'])
   if original_gap<0:continue # Intentional original overlapping objects are unchanged.
   new_y=next_y-1-int(g['高度 :'])
   if new_y<0:raise ValueError('Minimum-height lamps cannot fit their group')
   root,w=target(h,page);d,_=properties(root,w,a['key'],TITLES['BL'])
   try:tab(d,'轮廓');fields(d,[{'type':'Edit','name':' Y :','value':str(new_y)}]);confirm(d);d=None;save(root)
   finally:
    if d is not None:cancel(d)
   expected=dict(g,**{' Y :':str(new_y)});d,_=properties(root,w,a['key'],TITLES['BL'])
   try:
    if geo(d)!=expected:raise ValueError('Lamp gap adjustment saved bounds differ')
   finally:cancel(d)
   a['minimum_height_gap_adjustment']={'before_y':g[' Y :'],'after_y':str(new_y),'next_lamp':b['key'],'gap':1};a['after']=expected;put(DIR/f"{page}_{a['key']}.json",a)
 p['minimum_lamp_gaps_verified']=True;put(DIR/f'page-{page}.json',p)
def run(h,q):
 page=int(q['scale_post200']['page']);mode=q['scale_post200'].get('mode','objects')
 if page<200:raise ValueError('Only existing pages200+')
 root=Desktop(backend='win32').window(handle=h).wrapper_object()
 if '组装机_MT8106iP.emtp'not in root.window_text():raise ValueError('Target only')
 if mode=='redock':
  from ctypes import wintypes
  from pywinauto import mouse
  fs=[v for v in Desktop(backend='win32').windows()if v.process_id()==root.process_id()and v.is_visible()and v.window_text()=='目录树'and v.class_name().startswith('BCGPMiniFrame')]
  if len(fs)!=1:raise ValueError('Unique observed floating directory required')
  f=fs[0]
  class TBI(ctypes.Structure):_fields_=[('cbSize',wintypes.DWORD),('rcTitleBar',wintypes.RECT),('rgstate',wintypes.DWORD*6)]
  t=TBI();t.cbSize=ctypes.sizeof(t)
  if not ctypes.windll.user32.GetTitleBarInfo(f.handle,ctypes.byref(t)):raise ValueError('Observed native caption required')
  b=t.rcTitleBar;r=f.rectangle()
  if not(r.left<=b.left<b.right<=r.right and r.top<=b.top<b.bottom<=r.top+50):
   ui=Desktop(backend='uia').window(handle=f.handle).wrapper_object();cs=[c for c in ui.children()if c.is_visible()and c.rectangle().top>r.top]
   if len(cs)!=1:raise ValueError('Unique observed floating client area required')
   point=((r.left+r.right)//2,(r.top+cs[0].rectangle().top)//2)
   from eb_native_messages import msg
   hit=msg(f.handle,0x84,0,(point[0]&65535)|((point[1]&65535)<<16));put(DIR/'floating-caption-hit-test.json',{'hit':hit,'point':point,'frame':[r.left,r.top,r.right,r.bottom],'client_top':cs[0].rectangle().top})
   if hit not in (1,2):raise ValueError('Observed custom caption hit required: '+str(hit))
   b.left=r.left;b.right=r.right;b.top=r.top;b.bottom=cs[0].rectangle().top
  put(DIR/'floating-directory-repair.json',{'window':f.handle,'title':f.window_text(),'caption':[b.left,b.top,b.right,b.bottom],'stage':'caption-observed'})
  f.set_focus();mouse.double_click(coords=((b.left+b.right)//2,(b.top+b.bottom)//2));time.sleep(.4)
  fs=[v for v in Desktop(backend='win32').windows()if v.process_id()==root.process_id()and v.is_visible()and v.window_text()=='目录树'and v.class_name().startswith('BCGPMiniFrame')]
  if fs:raise ValueError('Directory did not redock')
  put(DIR/'floating-directory-repair.json',{'stage':'redocked','verified':True});return
 directory(Desktop(backend='uia').window(handle=h).wrapper_object());open_page(h,{'open_target_page':page})
 pp=DIR/f'page-{page}.json'
 if mode=='prepare':
  from eb_page_audit import run as audit_page
  try:audit_page(h,{'target_page_audit':page})
  except ValueError as e:
   if 'Target object audit incomplete'not in str(e):raise
  root,w,d=settings(h,page)
  try:
   rs=rows(d);g={r['name']:r['value']for r in rs if r['type']=='Edit'and r['name']in('宽度 :','高度 :')}
   put(DIR/f'settings-{page}-probe.json',rs)
  finally:cancel(d)
  audit=load(ROOT/f'evidence/target-page{page}-audit.json')
  keys=[re.search(r'(?:^|\])\s*([A-Z]+_\d+)',n)[1]for n in audit['objects']]
  if len(keys)!=len(set(keys)):raise ValueError('Duplicate target keys')
  if not pp.exists():put(pp,{'page':page,'before':g,'after':{'宽度 :':'890','高度 :':'469'},'keys':keys,'verified':[],'page_size_verified':False})
  return
 if mode=='blank_height':
  root,w,d=settings(h,page)
  try:
   fields(d,[{'type':'Edit','name':'高度 :','value':'469'}],commit_edits=True);confirm(d);d=None;save(root)
  finally:
   if d is not None:cancel(d)
  root,w,d=settings(h,page)
  try:
   actual=capture(d,[('Edit','宽度 :'),('Edit','高度 :')])
   if next(r['value']for r in actual if r['name']=='高度 :')!='469':raise ValueError('Page height save differs')
   put(DIR/f'page-{page}-initial-height.json',{'values':actual,'saved_reopened_verified':True})
  finally:cancel(d)
  return
 p=load(pp)
 if mode=='inspect':
  key=q['scale_post200']['key'];r=load(DIR/f'{page}_{key}.json')
  root,w=target(h,page);d,_=properties(root,w,key,TITLES[key.split('_')[0]])
  try:
   observation={'geometry':geo(d),'fonts':fonts(d,r['scopes']),'expected_geometry':r['after'],'expected_fonts':r['fonts_after']}
   if key.startswith('TB_'):
    tab(d,'一般属性');observation['table_general']=rows(d)
   put(DIR/f'{page}_{key}-observed.json',observation)
  finally:cancel(d)
  return
 if mode=='lamp_overlap':lamp_overlap(h,page,p);return
 if mode=='table_grid':table_grid(h,page);return
 if mode=='repair_tables':
  for key in p['keys']:
   if not key.startswith('TB_'):continue
   rp=DIR/f'{page}_{key}.json';r=load(rp);wanted=r['table_before']
   root,w=target(h,page);d,_=properties(root,w,key,TITLES['TB'])
   try:tab(d,'一般属性');fields(d,wanted,commit_edits=True);confirm(d);d=None;save(root)
   finally:
    if d is not None:cancel(d)
   d,_=properties(root,w,key,TITLES['TB'])
   try:
    tab(d,'一般属性')
    if capture(d,[('Edit','垂直 :'),('Edit','水平 :')])!=wanted:raise ValueError('Restored table row/column count differs')
    if geo(d)!=r['after']:raise ValueError('Table bounds changed after row repair')
   finally:cancel(d)
   r['table_after']=wanted;r['table_count_preserved']=True;r['table_count_repair_verified']=True;put(rp,r)
  return
 if mode=='size':
  if len(p['verified'])!=len(p['keys']):raise ValueError('All controls must be verified before page resize')
  root,w,d=settings(h,page)
  try:fields(d,[{'type':'Edit','name':n,'value':v}for n,v in p['after'].items()],commit_edits=True);confirm(d);d=None;save(root)
  finally:
   if d is not None:cancel(d)
  root,w,d=settings(h,page)
  try:
   actual={r['name']:r['value']for r in capture(d,[('Edit',n)for n in p['after']])}
   if actual!=p['after']:raise ValueError('Saved page dimensions differ')
  finally:cancel(d)
  lamp_overlap(h,page,p)
  from eb_page_audit import run as audit_page
  try:audit_page(h,{'target_page_audit':page})
  except ValueError as e:
   if 'Target object audit incomplete'not in str(e):raise
  audit=load(ROOT/f'evidence/target-page{page}-audit.json')
  actual_keys=[re.search(r'(?:^|\])\s*([A-Z]+_\d+)',n)[1]for n in audit['objects']]
  if len(actual_keys)!=len(p['keys'])or set(actual_keys)!=set(p['keys']):raise ValueError('Final target directory changed')
  violations=[]
  for key in p['keys']:
   r=load(DIR/f'{page}_{key}.json');g=r['after']
   for pos,size,limit in [('X :',' 宽度 :',890),(' Y :','高度 :',469)]:
    if int(g[pos])<0 or int(g[pos])+int(g.get(size,'0'))>limit:violations.append({'key':key,'bounds':g})
  if violations:put(DIR/f'page-{page}-out-of-bounds.json',violations);raise ValueError('Scaled controls beyond page bounds')
  p['directory_count_verified']=True;p['bounds_verified']=True;p['page_size_verified']=True;put(pp,p);return
 keys=q['scale_post200']['keys'];ratio=469/int(p['before']['高度 :'])
 if not keys or len(keys)>4 or any(k not in p['keys']for k in keys):raise ValueError('Reviewed object batch required')
 for key in keys:
  rp=DIR/f'{page}_{key}.json';record=load(rp)if rp.exists()else None
  if record and record.get('verified'):continue
  root,w=target(h,page);d,_=properties(root,w,key,TITLES[key.split('_')[0]])
  try:
   scopes=font_scopes(page,key)
   if record is None:
    old=geo(d);beforefonts=fonts(d,scopes);record={'page':page,'key':key,'before':old,'after':scaled(old,p['before']),'fonts_before':beforefonts,'scopes':scopes,'verified':False,'stage':'baseline','runtime_verified':False};put(rp,record)
   if key.startswith('TB_')and'table_before'not in record:
    tab(d,'一般属性');table=capture(d,[('Edit','垂直 :'),('Edit','水平 :')]);record['table_before']=table
    record['table_after']=table;record['table_count_preserved']=True;put(rp,record)
   record['stage']='write-requested';put(rp,record)
   if 'table_after'in record:tab(d,'一般属性');fields(d,record['table_after'],commit_edits=True)
   record['fonts_after']=fonts(d,scopes,record.get('font_fit_override',record['fonts_before']),1 if 'font_fit_override'in record else ratio)
   if q['scale_post200'].get('verify')=='pre-save-readback' and fonts(d,scopes)!=record['fonts_after']:raise ValueError('Scaled font size differs before save: '+key)
   tab(d,'轮廓');fields(d,[{'type':'Edit','name':n,'value':v}for n,v in record['after'].items()])
   record['geometry_native_fast_write']=True
   actual=geo(d)
   if actual!=record['after']:raise ValueError('Scaled fields differ before save: '+str((key,record['after'],actual)))
   confirm(d);d=None;save(root);record['stage']='saved-unverified';put(rp,record)
  finally:
   if d is not None and ctypes.windll.user32.IsWindowVisible(d.handle):cancel(d)
  if q['scale_post200'].get('verify')=='pre-save-readback':
   record['verified']=True;record['stage']='verified';record['verification']='pre-save readback in the open property dialog; post-save reopen deferred to sampled verification';put(rp,record)
   if key not in p['verified']:p['verified'].append(key)
   put(pp,p);continue
  for attempt in range(4):
   d,_=properties(root,w,key,TITLES[key.split('_')[0]])
   try:
    actual=geo(d)
    if actual!=record['after']:
     if record.get('geometry_native_fast_write')and not record.get('committed_geometry_fallback'):
      record['committed_geometry_fallback']=True;record['native_write_saved_difference']=actual;put(rp,record)
      fields(d,[{'type':'Edit','name':n,'value':v}for n,v in record['after'].items()],commit_edits=True);confirm(d);d=None;save(root);continue
     if attempt>=3 or not scopes or any(actual[n]!=record['after'][n]for n in ('X :',' Y :')):raise ValueError('Scaled saved geometry differs: '+str((key,record['after'],actual)))
     reduced={t:{s:{'size':str(max(6,int(v['size'])-1))}for s,v in ss.items()}for t,ss in record['fonts_after'].items()}
     if reduced==record['fonts_after']:
      fits=all(int(actual.get(size,'0'))<=int(record['before'].get(size,'0'))for size in (' 宽度 :','高度 :'))and int(actual['X :'])+int(actual.get(' 宽度 :','0'))<=890 and int(actual[' Y :'])+int(actual.get('高度 :','0'))<=469
      if not fits:raise ValueError('Minimum6pt still expands beyond original/page bounds: '+str((key,record['after'],actual)))
      record['proportional_bounds_before_native_minimum']=record['after'];record['native_minimum_bounds']=actual;record['after']=actual;put(rp,record)
      if fonts(d,scopes)!=record['fonts_after']:raise ValueError('Native minimum font size differs')
      break
     record.setdefault('native_auto_fit',[]).append({'saved_bounds':actual,'font_sizes_reduced':reduced})
     record['font_fit_override']=reduced;record['fonts_after']=reduced;put(rp,record)
     fonts(d,scopes,reduced,1);tab(d,'轮廓');fields(d,[{'type':'Edit','name':n,'value':v}for n,v in record['after'].items()],commit_edits=True);confirm(d);d=None;save(root);continue
    actual_fonts=fonts(d,scopes)
    if actual_fonts!=record['fonts_after']:
     record.setdefault('font_commit_recovery',[]).append({'observed':actual_fonts,'expected':record['fonts_after'],'attempt':attempt});put(rp,record)
     if attempt>=1:raise ValueError('Saved font size differs after bounded commit recovery')
     fonts(d,scopes,record['fonts_after'],1)
     tab(d,'轮廓');fields(d,[{'type':'Edit','name':n,'value':v}for n,v in record['after'].items()],commit_edits=True)
     confirm(d);d=None;save(root);continue
    if 'table_after'in record:
     tab(d,'一般属性')
     if capture(d,[('Edit','垂直 :'),('Edit','水平 :')])!=record['table_after']:raise ValueError('Saved table spacing differs')
    break
   finally:
    if d is not None:cancel(d)
  record['verified']=True;record['stage']='verified';record['verification']='post-save full reopen geometry and fonts';put(rp,record)
  if key not in p['verified']:p['verified'].append(key)
  put(pp,p)
