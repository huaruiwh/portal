"""Fresh compile, real restart and native read-only sampling of saved page16."""
import json,re,time,sys
from datetime import datetime
from eb_rebuild_page import ROOT,call
from eb_layout import geometry
from eb_verify_page16_completion import run as verify

def run():
 lock=ROOT/'tools/batch.lock'
 with lock.open('x'):pass
 path=ROOT/'evidence/page16-final-reopened.json';r={'page':16,'date':datetime.now().isoformat(timespec='seconds'),'ok':False,'sample_only':True,'offline_simulation_verified':False,'checks':[]}
 def persist():path.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
 def window():
  call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'));ts=[w for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
  if len(ts)!=1:raise ValueError('One exact target project required')
  return ts[0]
 try:
  rp=json.loads((ROOT/'evidence/page16-switch-appearance-workflow.json').read_text(encoding='utf8'))
  if not rp.get('ok'):raise ValueError('Existing switch repair not complete')
  w=window()
  def ui(q):return call('uia',w['handle'],json.dumps(q,ensure_ascii=False))
  ui({'target_page_audit':16});verify();r['stage']='compile';persist()
  if '--resume-compiled' in sys.argv:
   pending=json.loads((ROOT/'evidence/compile-pending.json').read_text(encoding='utf8'))
   if pending.get('phase')!='completed' or pending.get('output_mtime_ns')!=(ROOT/'output/组装机_MT8106iP.exob').stat().st_mtime_ns or pending.get('project_bytes')!=(ROOT/'output/组装机_MT8106iP.emtp').stat().st_size:raise ValueError('Exact already-completed compile evidence required')
  else:ui({'compile_target':True})
  compile_report=json.loads((ROOT/'evidence/latest-project-compile.json').read_text(encoding='utf8'));r['compile']=compile_report
  if not compile_report['ok']:raise ValueError('Fresh compile not successful')
  old=w['pid'];r.update(stage='reopen',previous_pid=old);persist()
  call('keys',w['handle'],'^s');call('keys',w['handle'],'%{F4}');call('launch',value=str(ROOT/'output/组装机_MT8106iP.emtp'))
  for _ in range(30):
   try:
    w=window()
    if w['pid']!=old:break
   except ValueError:pass
   time.sleep(.5)
  else:raise ValueError('Different reopened target process required')
  r.update(reopened_pid=w['pid'],reopened_handle=w['handle']);persist();ui({'restore_target_window':True,'reviewed_size':True})
  ui({'page_settings':16,'target_readonly':True,'color_probe':True})
  settings=json.loads((ROOT/'evidence/target-pages-settings/016.json').read_text(encoding='utf8'))
  rs={x['name']:x.get('value') for x in settings['controls'] if 'value' in x}
  edits={x['name']:x.get('value') for x in settings['controls'] if x['type']=='Edit' and 'value' in x}
  r['page_settings']={'background_rgb':settings['background_rgb'],'bottom_layer':rs.get('底层 :'),'width':edits.get('宽度 :'),'height':edits.get('高度 :')}
  if settings['background_rgb']!=[155,155,150] or not re.match(r'^10(?:\.|\s|$)',rs.get('底层 :','')) or (edits.get('宽度 :'),edits.get('高度 :'))!=('1024','600'):raise ValueError('Page16 original background/bottom layer/dimensions mismatch')
  ui({'open_target_page':16});ui({'target_page_audit':16});a=json.loads((ROOT/'evidence/target-page16-audit.json').read_text(encoding='utf8'))
  r.update(directory_source_count=a['source_count'],directory_target_count=a['target_count'],directory_verified=a['tree_verified']);persist()
  inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(v['observed_objects'] for v in inv['pages'] if v['id']==16)
  sample=['TS_4','TS_10','TS_15','TS_17','BL_0','BL_4','BL_32','TX_30','DW_4','AL_0','DW_5','TX_31','TX_32']
  header=json.loads((ROOT/'evidence/page16-alarm-header-adaptation.json').read_text(encoding='utf8'))
  def vals(rows,names):return [(v['type'],v['name'],v['value']) for v in rows if v['name'] in names and 'value' in v]
  def shaped(rows):return {v['name']:v['value'] for v in rows if v['type']=='Edit' and v['name'] in {'X :',' Y :',' 宽度 :','高度 :'}}
  for key in sample:
   r['stage']=key;persist()
   observed=a['objects'] if key in {'DW_5','TX_31','TX_32'} else names
   name=next(s for s in observed if re.search(r'(?:^|\])\s*'+key+r'(?:\s|$)',s))
   q={'page':16,'object':name,'target_readonly':True}
   if key.startswith('TS_'):
    src=json.loads((ROOT/f'evidence/source-object-properties/016_{key}.json').read_text(encoding='utf8'))
    if any(v['name']=='使用文字标签' and v.get('value')==1 for v in src['tabs']['标签']):q['state_color_probe']={'tab':'标签','state':'0','labels':['颜色 :']}
   if key.startswith('BL_'):q['state_color_probe']={'tab':'图片','state':'0','labels':['图案颜色 :','颜色 :'],'all_occurrences':True,'collect_labels':True}
   if key.startswith('TX_'):q.update(colors=['颜色 :'],color_tab='文字/批注')
   if key=='DW_4':q.update(colors=['颜色 :'],color_tab=' 形状')
   ui({'extract':q});d=json.loads((ROOT/f'evidence/target-object-properties/016_{key}.json').read_text(encoding='utf8'));c={'object':key}
   if key not in {'DW_5','TX_31','TX_32'}:
    src=json.loads((ROOT/f'evidence/source-object-properties/016_{key}.json').read_text(encoding='utf8'));expected=geometry(src)
    if key=='AL_0':expected[' Y :']=str(int(expected[' Y :'])+24);expected['高度 :']=str(int(expected['高度 :'])-24)
    c['geometry_verified']=expected==shaped(d['tabs']['轮廓'])
    if key.startswith(('TS_','BL_')):
     c['addresses_verified']=vals(src['tabs']['一般属性'],{'设备 :','Static',' Down'})==vals(d['tabs']['一般属性'],{'设备 :','Static',' Down'})
    if key.startswith('TS_'):
     c['safety_verified']=vals(src['tabs']['安全'],{'最短按压时间',' Down','使用寄存器状态/数值','用户限制 Down'})==vals(d['tabs']['安全'],{'最短按压时间',' Down','使用寄存器状态/数值','用户限制 Down'})
     fam=next(v['name'] for v in src['tabs']['图片'] if v['type']=='Text' and v['name'] in ('Button - Standard','Selector_3_Position_Metal_Silver-Red'));c['picture_verified']=any(v['name']==fam for v in d['tabs']['图片'])
     if 'state_color_probe' in q:
      c['label_rgb_verified']=src['state_colors']['标签']==d['state_colors']['标签'];c['captions_verified']=all(vals(src['label_states'][s],{''})==vals(d['label_states'][s],{''}) for s in ('0','1'))
    if key.startswith('BL_'):
     c['two_state_rgb_verified']=src['state_colors']['图片']==d['state_colors']['图片']
     if '标签' in src['state_colors']:
      c['label_rgb_verified']=src['state_colors']['标签']==d['state_colors']['标签'];c['captions_verified']=all(vals(src['label_states'][s],{''})==vals(d['label_states'][s],{''}) for s in ('0','1'))
    if key=='TX_30':c['text_verified']=vals(src['tabs']['文字/批注'],{'内容'})==vals(d['tabs']['文字/批注'],{'内容'});c['colour_verified']=src['colors']==d['colors']
    if key=='DW_4':c['border_colour_verified']=src['colors']==d['colors']
    if key=='AL_0':
     built=json.loads((ROOT/'evidence/target-016-AL0-built.json').read_text(encoding='utf8'));c['native_alarm_verified']=d['dialog_title']=='报警显示的属性'
     for t in ('报警','排序'):
      if t in built['tabs'] and t in d['tabs']:c[t+'_verified']=vals(built['tabs'][t],{v['name'] for v in built['tabs'][t] if 'value' in v})==vals(d['tabs'][t],{v['name'] for v in built['tabs'][t] if 'value' in v})
   else:
    plan=header['background'] if key=='DW_5' else header[key]
    expected=plan['geometry'];actual=shaped(d['tabs']['轮廓']);c['geometry_verified']=all(actual.get(k)==v for k,v in expected.items())
    if key.startswith('TX_'):
     c['caption_verified']=vals(d['tabs']['文字/批注'],{'内容'})==[('Edit','内容',plan['caption'])];c['blue_colour_verified']=d['colors']=={'颜色 :':[0,0,255]}
   r['checks'].append(c);persist()
   if any(v is False for v in c.values()):raise ValueError('Fresh reopened parameter mismatch '+key+' '+str(c))
  ui({'open_target_page':16})
  r.update(stage='completed',ok=len(r['checks'])==len(sample) and r['directory_verified'],project_bytes=(ROOT/'output/组装机_MT8106iP.emtp').stat().st_size);persist();print(json.dumps({'page':16,'checks':len(sample),'ok':r['ok'],'bytes':r['project_bytes']},ensure_ascii=False))
 except Exception as e:r['error']=str(e);persist();raise
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':run()
