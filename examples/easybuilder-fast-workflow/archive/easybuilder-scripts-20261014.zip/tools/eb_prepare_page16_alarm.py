"""Discover alarm-display entry by tooltip and capture real MT defaults, then cancel."""
import json,time
from pywinauto import Desktop,mouse
from eb_object_ui import target,dialog
from eb_native_form import tab
from eb_native_messages import msg
from eb_extract import ROOT,rows

def run(handle,q):
 root,w=target(handle,16)
 a=json.loads((ROOT/'evidence/target-page16-audit.json').read_text(encoding='utf8'))
 if a['source_count']!=101 or 'AL_0' not in a['missing']:raise ValueError('Fresh complete-source missing alarm proof required')
 root.set_focus();root.click_input(coords=(437,52));time.sleep(.2)
 candidates=[];observations=[]
 r=root.rectangle()
 for y in (87,116,145):
  mouse.move(coords=(r.left+346,r.top+y));time.sleep(1.4)
  texts=[]
  for win in Desktop(backend='uia').windows():
   if win.process_id()==root.process_id() and win.element_info.handle!=root.handle and win.is_visible():
    texts.extend([win.window_text()]+[c.window_text() for c in win.descendants()])
  observations.append({'point':[346,y],'texts':list(dict.fromkeys(t for t in texts if t))})
  if any('报警显示' in t for t in texts):candidates.append(y)
 (ROOT/'evidence/page16-alarm-entry-probe.json').write_text(json.dumps(observations,ensure_ascii=False,indent=2),encoding='utf8')
 if not candidates and q.get('probe_known_adjacent_entry'):
  candidates=[116] # Between the previously verified alarm-bar and event-display entries.
 if len(candidates)!=1:raise ValueError('Unique observed Alarm Display tooltip required before click')
 root.click_input(coords=(346,candidates[0]));d=dialog(root.process_id(),'新增 报警显示')
 captured={}
 try:
  for name in [c.window_text() for c in d.descendants(control_type='TabItem') if c.is_visible()]:
   tab(d,name);captured[name]=rows(d)
  tab(d,'报警')
  groups=[{'name':c.element_info.name,'rect':[c.rectangle().left,c.rectangle().top,c.rectangle().right,c.rectangle().bottom]} for c in d.descendants(control_type='Group') if c.is_visible()]
  controls=[{'type':c.element_info.control_type,'name':c.element_info.name,'rect':[c.rectangle().left,c.rectangle().top,c.rectangle().right,c.rectangle().bottom]} for c in d.descendants() if c.is_visible() and c.element_info.control_type in ('Text','CheckBox')]
  from eb_color_picker import probe
  palette={label:probe(d,label) for label in ('外框颜色 :','背景颜色 :','颜色 :')}
  (ROOT/'evidence/new-16-AL-defaults.json').write_text(json.dumps({'title':d.window_text(),'tabs':captured,'groups':groups,'alarm_controls':controls,'alarm_palette':palette,'entry':[346,candidates[0]],'project_modified':False},ensure_ascii=False,indent=2),encoding='utf8')
 finally:
  cs=[c for c in d.descendants(control_type='Button') if c.window_text()=='取消' and c.is_visible()]
  if len(cs)!=1:raise ValueError('Unique uncreated alarm cancel required')
  msg(cs[0].handle,245)
