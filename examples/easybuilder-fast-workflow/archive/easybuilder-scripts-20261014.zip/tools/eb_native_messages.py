"""Bounded native text and checkbox calls; no persistent control cache."""
import ctypes
U=ctypes.windll.user32
U.SendMessageTimeoutW.argtypes=[ctypes.c_void_p,ctypes.c_uint,ctypes.c_size_t,ctypes.c_ssize_t,ctypes.c_uint,ctypes.c_uint,ctypes.POINTER(ctypes.c_size_t)]
U.SendMessageTimeoutW.restype=ctypes.c_size_t
def msg(h,m,w=0,l=0):
    out=ctypes.c_size_t()
    if not U.SendMessageTimeoutW(h,m,w,l,2,1500,ctypes.byref(out)):raise TimeoutError('Native control response exceeded 1500ms')
    return out.value
def text(h):
    b=ctypes.create_unicode_buffer(8192);msg(h,13,len(b),ctypes.cast(b,ctypes.c_void_p).value);return b.value
def put(h,value):
    b=ctypes.create_unicode_buffer(str(value));msg(h,12,0,ctypes.cast(b,ctypes.c_void_p).value)
    if text(h).rstrip('\r\n')!=str(value).rstrip('\r\n'):raise ValueError('Native text readback mismatch')
def combo_text(h):
    index=msg(h,327)
    if index>=0x7fffffff:raise ValueError('Native combo has no selection')
    b=ctypes.create_unicode_buffer(8192)
    msg(h,328,index,ctypes.cast(b,ctypes.c_void_p).value)
    return b.value
def combo_select(h,index):
    msg(h,334,index)
    parent=U.GetParent(h);cid=U.GetDlgCtrlID(h)
    for code in (9,1,8):msg(parent,273,(code<<16)|cid,h)


def visible_handles(parent,classes):
    """Enumerate current HWNDs without constructing a Win32 wrapper per child."""
    found=[];wanted=set(classes)
    callback=ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_ssize_t)
    @callback
    def visit(h,_):
        if U.IsWindow(h) and U.IsWindowVisible(h):
            cls=ctypes.create_unicode_buffer(128);U.GetClassNameW(h,cls,128)
            if cls.value in wanted:found.append(int(h))
        return True
    U.EnumChildWindows(parent,visit,0)
    return found
