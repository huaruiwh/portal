import sys, os, json, ctypes, traceback
import time, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
LIB=ROOT/'tools'/'python-libs'
sys.path[:0]=[str(LIB),str(LIB/'win32'),str(LIB/'win32'/'lib'),str(LIB/'Pythonwin')]
os.add_dll_directory(str(LIB/'pywin32_system32'))
from pywinauto import Desktop
from PIL import ImageGrab
ctypes.windll.user32.SetProcessDPIAware()
U=ctypes.windll.user32
def native_text(hwnd):
 cls=ctypes.create_unicode_buffer(256);U.GetClassNameW(hwnd,cls,256)
 if cls.value not in ('Edit','ComboBox','Button','Static','SysTabControl32'):
  return ''
 buf=ctypes.create_unicode_buffer(8192);out=ctypes.c_size_t()
 ok=U.SendMessageTimeoutW(hwnd,13,len(buf),ctypes.cast(buf,ctypes.c_void_p),2,100,ctypes.byref(out))
 return buf.value if ok else '<text timeout>'
def controls(hwnd):
 found=[]
 callback=ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p)
 @callback
 def visit(h,l):
  cls=ctypes.create_unicode_buffer(256);U.GetClassNameW(h,cls,256)
  import ctypes.wintypes as wt
  r=wt.RECT();U.GetWindowRect(h,ctypes.byref(r))
  found.append({'handle':int(h),'parent':U.GetParent(h),'class':cls.value,'id':U.GetDlgCtrlID(h),'visible':bool(U.IsWindowVisible(h)),'enabled':bool(U.IsWindowEnabled(h)),'rect':[r.left,r.top,r.right,r.bottom],'text':native_text(h)})
  return True
 U.EnumChildWindows(hwnd,visit,0)
 return found
def task_windows():
 handles=[]
 callback=ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p)
 @callback
 def visit(h,_):
  cls=ctypes.create_unicode_buffer(256);U.GetClassNameW(h,cls,256)
  pid=ctypes.c_ulong();U.GetWindowThreadProcessId(h,ctypes.byref(pid))
  handles.append((int(h),pid.value,cls.value));return True
 U.EnumWindows(visit,0)
 pids={pid for h,pid,cls in handles if cls=='EasyBuilderPro'}
 result=[]
 from pywinauto.controls.hwndwrapper import InvalidWindowHandle
 for h,pid,cls in handles:
  if pid not in pids or not U.IsWindow(h):continue
  try:result.append(Desktop(backend='win32').window(handle=h).wrapper_object())
  except InvalidWindowHandle:continue
 return result

def snapshot():
 report=[]
 roots=task_windows()
 pids={p.process_id() for p in roots if p.class_name()=='EasyBuilderPro'}
 for w in roots:
  title=w.window_text()
  if w.process_id() in pids and (w.is_visible() or w.class_name()=='EasyBuilderPro'):
   r=w.rectangle()
   row={'handle':w.handle,'title':title,'pid':w.process_id(),'class':w.class_name(),'rect':[r.left,r.top,r.right,r.bottom],'children':[]}
   for c in (w.descendants() if w.class_name()=='#32770' else []):
    cr=c.rectangle()
    row['children'].append({'handle':c.handle,'text':ctypes.windll.user32.GetWindowTextLengthW(c.handle),'class':c.class_name(),'id':c.control_id(),'rect':[cr.left,cr.top,cr.right,cr.bottom]})
   report.append(row)
 (ROOT/'evidence'/'windows.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 # Screenshots are now explicit, not produced after every operation.
 return [{'handle':r['handle'],'title':r['title'],'rect':r['rect'],'children':len(r['children'])} for r in report]
if len(sys.argv)>1 and sys.argv[1]=='worker':
 ready=ROOT/'evidence'/'worker-ready.json'
 if ready.exists():
  oldpid=json.loads(ready.read_text())['pid']
  if oldpid!=os.getpid():
   old=ctypes.windll.kernel32.OpenProcess(1,False,oldpid)
   if old:ctypes.windll.kernel32.TerminateProcess(old,0);ctypes.windll.kernel32.CloseHandle(old)
 last=json.loads((ROOT/'tools/request.json').read_text(encoding='utf-8-sig')).get('id','') if (ROOT/'tools/request.json').exists() else ''
 (ROOT/'evidence'/'worker-ready.json').write_text(json.dumps({'pid':os.getpid(),'admin':bool(ctypes.windll.shell32.IsUserAnAdmin())}),encoding='utf8')
 while True:
  try:
   reqpath=ROOT/'tools'/'request.json'
   if reqpath.exists():
    req=json.loads(reqpath.read_text(encoding='utf-8-sig'))
    if req['id']!=last:
     last=req['id'];result={'id':last}
     try:
      action=req['action']
      if action=='quit':break
      if action=='launch':
       f=Path(req['file']).resolve()
       if ROOT not in f.parents:raise ValueError('Project must be inside task directory')
       subprocess.Popen(['C:\\Program Files\\EBpro\\EasyBuilder Pro.exe',str(f)],cwd='C:\\Program Files\\EBpro')
      elif action=='screenshot':
       ImageGrab.grab().save(ROOT/'evidence'/'desktop.png')
      elif action!='snapshot':
       w=Desktop(backend='win32').window(handle=req['handle'])
       if w.process_id() not in [p.process_id() for p in task_windows() if p.class_name()=='EasyBuilderPro']:raise ValueError('Not an EasyBuilder window')
       if action=='inspect':
        result['controls']=controls(w.handle)
        (ROOT/'evidence'/'controls.json').write_text(json.dumps(result['controls'],ensure_ascii=False,indent=2),encoding='utf8')
       elif action=='uia':
        options=json.loads(req.get('text') or '{}')
        # A single original builder must finish before its readback/save report.
        limit=60 if any(k in options for k in ('build_bit_general','build_ms','build_tx','copy_200_style_object')) and not options.get('page215_clone') else 300 if any(k in options for k in ('create_target_page','scale_post200','page_settings','table_fix','move_objects','table_columns','page215_clone')) else 55
        p=subprocess.run([sys.executable,str(ROOT/'tools'/'eb_uia.py'),str(w.handle),req.get('text','')],capture_output=True,text=True,timeout=limit)
        if p.returncode:raise RuntimeError(f'UIA subprocess exit_code={p.returncode}; stderr={p.stderr!r}; stdout={p.stdout!r}')
        result['uia_file']=str(ROOT/'evidence'/'uia.json')
       elif action=='setedit':
        if w.class_name()!='Edit':raise ValueError('setedit requires native Edit')
        w.set_edit_text(req['text'])
        result['value']=native_text(w.handle)
        if result['value']!=req['text']:raise ValueError('Edit readback mismatch')
       elif action=='select':
        if w.class_name()!='ComboBox':raise ValueError('select requires native ComboBox')
        w.select(req['text']);result['value']=w.selected_text()
       elif action=='items':
        if w.class_name()!='ComboBox':raise ValueError('items requires native ComboBox')
        result['items']=w.item_texts();result['value']=w.selected_text()
       elif action=='invoke':
        if w.class_name()!='Button':raise ValueError('invoke requires native Button')
        w.click()
       else:
        perform_input=True
       if action in ('inspect','uia','setedit','select','items','invoke'):
        time.sleep(req.get('wait',0.5));result['windows']=snapshot();result['ok']=True
        (ROOT/'evidence'/'response.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
        continue
       if ctypes.windll.user32.GetForegroundWindow()!=w.handle:
        ctypes.windll.user32.ShowWindow(w.handle,9)
        w.set_focus()
       time.sleep(0.3)
       foreground=ctypes.windll.user32.GetForegroundWindow()
       if foreground!=w.handle:raise RuntimeError(f'Focus mismatch: expected {w.handle}, got {foreground}')
       if action=='click':w.click_input(coords=tuple(req['coords']),double=req.get('double',False))
       elif action=='rightclick':w.click_input(button='right',coords=tuple(req['coords']))
       elif action=='keys':w.type_keys(req['keys'],with_spaces=True,pause=0.05)
       elif action=='text':
        import pywinauto.clipboard as clip
        # Unicode text is sent through keyboard's Unicode packet implementation.
        from pywinauto.keyboard import send_keys
        send_keys(req['text'],with_spaces=True,with_tabs=False,with_newlines=False,vk_packet=True)
       elif action=='restore':w.restore()
       else:raise ValueError('Unsupported action')
      time.sleep(req.get('wait',0.5));result['windows']=snapshot();result['ok']=True
     except Exception:result['ok']=False;result['error']=traceback.format_exc()
     (ROOT/'evidence'/'response.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
  except Exception:
   (ROOT/'evidence'/'worker-error.txt').write_text(traceback.format_exc(),encoding='utf8')
  time.sleep(0.2)
 sys.exit(0)
try:
 if len(sys.argv)>1:
  target=Desktop(backend='win32').window(handle=int(sys.argv[2]))
  target.set_focus()
  if sys.argv[1]=='click':target.click_input(coords=(int(sys.argv[3]),int(sys.argv[4])))
  elif sys.argv[1]=='keys':target.type_keys(sys.argv[3],with_spaces=True,pause=0.05)
  elif sys.argv[1]=='restore':target.restore()
 windows=Desktop(backend='win32').windows()
 report=[]
 for w in windows:
  title=w.window_text()
  if 'EasyBuilder Pro' in title or w.class_name()=='#32770':
   r=w.rectangle()
   row={'handle':w.handle,'title':title,'pid':w.process_id(),'class':w.class_name(),'rect':[r.left,r.top,r.right,r.bottom],'children':[]}
   for c in w.descendants():
    cr=c.rectangle()
    row['children'].append({'handle':c.handle,'text':c.window_text(),'class':c.class_name(),'id':c.control_id(),'rect':[cr.left,cr.top,cr.right,cr.bottom]})
   report.append(row)
 (ROOT/'evidence'/'windows.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 ImageGrab.grab().save(ROOT/'evidence'/'desktop.png')
 print(json.dumps([{'handle':r['handle'],'title':r['title'],'rect':r['rect'],'children':len(r['children'])} for r in report],ensure_ascii=True))
except Exception:
 (ROOT/'evidence'/'probe-error.txt').write_text(traceback.format_exc(),encoding='utf8')
 raise
