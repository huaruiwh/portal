"""Serial original vector/clock rebuild for missing base-page controls."""
import json
from eb_rebuild_page import ROOT,call

def run():
 lock=ROOT/'tools/batch.lock'
 with lock.open('x'):pass
 r={'ok':False,'completed':[]};path=ROOT/'evidence/base-header-workflow.json'
 def persist():path.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
 try:
  call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'));h=next(w['handle'] for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title'])
  for page in (10,11):
   call('uia',h,json.dumps({'open_target_page':page}))
   for kind in ('SP','DC','AB'):
    r['stage']={'page':page,'kind':kind};persist()
    if not (ROOT/f'evidence/target-{page:03d}-{kind}0-built.json').exists():call('uia',h,json.dumps({'page':page,'build_'+kind.lower():0}))
    r['completed'].append({'page':page,'kind':kind});persist()
   try:call('uia',h,json.dumps({'target_page_audit':page}))
   except RuntimeError as e:
    if 'Target object audit incomplete' not in str(e):raise
  r['ok']=True;persist()
 except Exception as e:r['error']=str(e);persist();raise
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':run()
