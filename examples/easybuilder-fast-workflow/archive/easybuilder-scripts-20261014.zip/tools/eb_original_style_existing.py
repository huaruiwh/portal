"""Apply cached original appearance to an existing switch; never paste."""
import json,re
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save,dialog
from eb_open_page import run as open_page
from eb_native_form import tab,fields,confirm,typed_children
from eb_page26_shapes import cancel,native_rows
from eb_color_picker import set_rgb,probe
from eb_layout import geometry

PAGES=(204,206,210,212,218,221,224,235)
TITLES={'TS':'位状态切换开关/位状态指示灯的属性','BL':'位状态指示灯/位状态切换开关的属性'}

def sig(rs):
 return [(r['type'],r['name'],r['value']) for r in rs if 'value' in r]

def label_fields(rs):
 out=[]
 for r in rs:
  if 'value' not in r or r['type'] not in ('ComboBox','Edit','CheckBox','RadioButton'):continue
  if r['name']=='状态 :' or (r['type']=='Edit' and r['name']=='字体 :'):continue
  row=dict(r)
  if row['name']=='字体 :':row['value']=re.sub(r'\s*\[.*$','',str(row['value']))
  out.append(row)
 return out

def form_rows(d):
 from pywinauto import Desktop
 from eb_native_messages import text
 actual=native_rows(d)
 for c in Desktop(backend='win32').window(handle=d.handle).wrapper_object().descendants(class_name='RichEdit20W'):
  if c.is_visible():
   ui=Desktop(backend='uia').window(handle=c.handle).wrapper_object()
   actual.append({'type':'Edit','name':ui.element_info.name,'class':'RichEdit20W','value':text(c.handle).rstrip('\r\n')})
 return actual

def verify_fields(actual,expected):
 counters={}
 for r in expected:
  key=(r['type'],r['name']);i=counters.get(key,0);counters[key]=i+1
  found=[v for v in actual if (v['type'],v['name'])==key and 'value' in v]
  if i>=len(found) or (str(found[i]['value']).replace('\r\n','\n').replace('\r','\n') if r['type']=='Edit' else found[i]['value'])!=(str(r['value']).replace('\r\n','\n').replace('\r','\n') if r['type']=='Edit' else r['value']):raise ValueError('Original appearance readback differs: '+str(key))

def state(d,value):
 cs=[c for c in typed_children(d,'ComboBox') if c.element_info.name=='状态 :']
 if len(cs)!=1:raise ValueError('Unique original style state selector required')
 ComboBoxWrapper(cs[0].handle).select(value)

def run(handle,q):
 page=int(q['page']);key=q['apply_existing_original_style'];kind=key.split('_')[0]
 if page not in PAGES or kind not in TITLES:raise ValueError('Original appearance pilot scope TS/BL only')
 if q.get('inspect_open'):
  from pywinauto import Desktop
  root=Desktop(backend='win32').window(handle=handle).wrapper_object();d=dialog(root.process_id(),TITLES[kind])
  (ROOT/'evidence/original-style-open-label-readback.json').write_text(json.dumps(form_rows(d),ensure_ascii=False,indent=2),encoding='utf8');cancel(d);return
 built=ROOT/f'evidence/target-{page:03d}-{key.replace("_","")}-built.json'
 if not built.exists():raise ValueError('Existing saved control report required; no new object created')
 source=json.loads((ROOT/f'evidence/source-object-properties/{page:03d}_{key}.json').read_text(encoding='utf8'))
 if not source.get('state_colors'):raise ValueError('Original two-state RGB cache required')
 open_page(handle,{'open_target_page':page});root,w=target(handle,page)
 d,_=properties(root,w,key,TITLES[kind]);before={}
 for t in ('一般属性','安全'):
  tab(d,t);before[t]=sig(native_rows(d))
 tab(d,'图片')
 # An already matching gallery is acceptable; a different gallery needs a reviewed adapter.
 metadata=[r['name'] for r in source['tabs']['图片'] if r['type']=='Text' and (r['name']=='SYSTEM' or re.fullmatch(r'\d+x\d+',r['name']) or ' - ' in r['name'])]
 actual=[r['name'] for r in native_rows(d) if r['type']=='Text']
 vector_match=False
 if source.get('vector_identity'):
  base=json.loads((ROOT/f'evidence/source-object-properties/200_{kind}_0.json').read_text(encoding='utf8'))
  vector_match=source['vector_identity']==base.get('vector_identity') and any(r['name']=='使用向量图' and r.get('value')==1 for r in native_rows(d))
 if not vector_match and (not metadata or any(v not in actual for v in metadata)):
  cancel(d);raise ValueError('Original bitmap family/size differs; gallery replacement needs exact identity')
 if not q.get('verify_only'):fields(d,[r for r in source['tabs']['图片'] if r['type']=='CheckBox' and 'value' in r])
 expected_labels={}
 for value,rs in source['label_states'].items():
  tab(d,'标签');state(d,value);expected_labels[value]=label_fields(rs)
  if not q.get('verify_only'):fields(d,expected_labels[value])
 for scope,states in source['state_colors'].items():
  tab(d,scope)
  for value,colors in states.items():
   state(d,value)
   for name,rgb in colors.items():
    if not q.get('verify_only'):set_rgb(d,rgb,name)
 shape=geometry(source)
 if page==204 and kind=='BL' and shape[' 宽度 :']=='15':shape[' 宽度 :']='16'
 if page==204 and key in ('BL_6','BL_7','BL_8','BL_9') and shape['高度 :']=='46':shape['高度 :']='52'
 tab(d,'轮廓')
 if not q.get('verify_only'):
  fields(d,[{'type':'Edit','name':k,'value':v} for k,v in shape.items()]);confirm(d);save(root)
 else:cancel(d)
 d,_=properties(root,w,key,TITLES[kind]);observed={}
 for t,expected in before.items():
  tab(d,t)
  if sig(native_rows(d))!=expected:raise ValueError('Original style changed behavior/safety: '+t)
 for value,rs in expected_labels.items():
  tab(d,'标签');state(d,value);verify_fields(form_rows(d),rs)
 for scope,states in source['state_colors'].items():
  tab(d,scope);observed[scope]={}
  for value,colors in states.items():
   state(d,value);observed[scope][value]={}
   for name,rgb in colors.items():
    actual=probe(d,name);observed[scope][value][name]=actual
    if actual!=rgb:raise ValueError('Saved original RGB mismatch')
 tab(d,'轮廓');verify_fields(native_rows(d),[{'type':'Edit','name':k,'value':v} for k,v in shape.items()]);cancel(d)
 result={'page':page,'key':key,'original_style_verified':False,'original_style_fields_verified':True,'gallery_identity_review_pending':True,'original_colors':observed,'shape':shape,'label_fields':expected_labels,'gallery_metadata':metadata,'font_fallback_adapter':'cMT font fallback list removed; main installed font preserved','behavior_and_safety_unchanged':True,'saved_reopened_verified':True,'runtime_verified':False}
 (ROOT/f'evidence/original-style-{page}-{key}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
 report=json.loads(built.read_text(encoding='utf8'));report['original_style_verified']=False;report['original_style_fields_verified']=True;report['gallery_identity_review_pending']=True;report['appearance_inherited_from_user_approved_200']=False;report['original_style_evidence']=f'original-style-{page}-{key}.json';built.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
