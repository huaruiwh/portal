"""Serial main-page bit reconstruction; resume only saved object reports."""
import json
from eb_rebuild_page import ROOT,call

def run():
    lock=ROOT/'tools'/'batch.lock'
    with lock.open('x'):pass
    report={'page':16,'completed':[],'ok':False};path=ROOT/'evidence'/'page-16-bit-workflow.json'
    def persist():path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    try:
        call('snapshot');wins=json.loads((ROOT/'evidence'/'windows.json').read_text(encoding='utf8'))
        targets=[w for w in wins if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
        if len(targets)!=1:raise ValueError('Unique target required')
        target=targets[0]['handle'];call('uia',target,json.dumps({'open_target_page':16}))
        for kind,count in (('TS',11),('BL',5)):
            for n in range(count):
                report['stage']=kind+'_'+str(n);persist()
                if not (ROOT/'evidence'/f'target-016-{kind}{n}-built.json').exists():
                    call('uia',target,json.dumps({'page':16,'bit_kind':kind,'build_bit_general':n}))
                report['completed'].append(kind+'_'+str(n));persist()
        report['ok']=True;persist();print(json.dumps({'ok':True,'bit_objects':len(report['completed']),'whole_page_complete':False}))
    except Exception as exc:report['error']=str(exc);persist();raise
    finally:lock.unlink(missing_ok=True)

if __name__=='__main__':run()
