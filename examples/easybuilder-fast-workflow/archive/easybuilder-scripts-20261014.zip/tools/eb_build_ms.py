"""Recreate the reviewed three-position DB word selector on page26."""
import json
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_extract import ROOT,rows
from eb_object_ui import target,dialog,placed_properties,save
from eb_native_form import tab,fields,confirm

def run(handle,q):
    page=int(q.get('page',26))
    from eb_flow_model import counts
    counts(page)
    source=json.loads((ROOT/f'evidence/source-object-properties/{page:03d}_MS_0.json').read_text(encoding='utf8'))
    if not any(r['name']=='状态数 :' and r.get('value')=='3' for r in source['tabs']['一般属性']):raise ValueError('Three source states required')
    if not any(r['name']=='Selector_3_Position_Green' for r in source['tabs']['图片']):raise ValueError('New selector image requires review')
    if any(r['type']=='CheckBox' and r['name']=='使用寄存器状态/数值' and r.get('value') for r in source['tabs']['安全']):raise ValueError('Dynamic selector visibility requires review')
    root,w=target(handle,page)
    if q.get('choose_gallery'):
        from eb_selector_picture import choose_gallery
        choose_gallery(root.process_id());return
    if q.get('auto_create') and not q.get('resume'):
        from eb_ribbon import create
        create(root,'MS','新增 多状态指示灯/多状态切换开关')
    d=dialog(root.process_id(),'新增 多状态指示灯/多状态切换开关')
    if q.get('finish_gallery'):
        from eb_selector_picture import choose_existing
        choose_existing(d,root.process_id())
    if q.get('auto_create'):
        tab(d,'图片')
        fields(d,[r for r in source['tabs']['图片'] if r['type']=='CheckBox'])
        from eb_selector_picture import choose_existing
        choose_existing(d,root.process_id())
    tab(d,'一般属性');general=source['tabs']['一般属性']
    fields(d,[r for r in general if r['name'] not in ('设备 :',' Down','Static','偏移量 :')])
    for typ,name in (('ComboBox','设备 :'),('ComboBox',' Down'),('Edit','Static')):
        fields(d,[r for r in general if r['type']==typ and r['name']==name],commit_edits=True)
    fields(d,[r for r in general if r['name']=='偏移量 :'])
    general_readback=rows(d)
    tab(d,'图片')
    if not any(r['name']=='Selector_3_Position_Green' for r in rows(d)):raise ValueError('Original selector family must be selected first')
    fields(d,[r for r in source['tabs']['图片'] if r['type']=='CheckBox']);pictures=rows(d)
    tab(d,'标签');fields(d,[r for r in source['tabs']['标签'] if r['type']=='CheckBox'])
    state=[c for c in d.descendants(control_type='ComboBox') if c.window_text()=='状态 :' and c.is_visible()]
    labels={}
    from eb_native_form import commit_text
    label_enabled=next(r['value'] for r in source['tabs']['标签'] if r['name']=='使用文字标签' and r['type']=='CheckBox')
    if label_enabled and (len(state)!=1 or set(source.get('label_states',{}))!={'0','1','2'}):raise ValueError('Three explicit source label states required')
    for value in (('0','1','2') if label_enabled else ()):
        ComboBoxWrapper(state[0].handle).select(value)
        fields(d,source['label_states'][value],skip=(('ComboBox','状态 :'),('Edit','')))
        text=next(r['value'] for r in source['label_states'][value] if r['type']=='Edit' and r['name']=='')
        commit_text(d,'',text);labels[value]=rows(d)
    tab(d,'安全');fields(d,source['tabs']['安全']);safety=rows(d);confirm(d)
    d,name=placed_properties(root,w,'MS_0','多状态切换开关/多状态指示灯的属性')
    tab(d,'轮廓');shape={r['name']:r['value'] for r in source['tabs']['轮廓'] if r['type']=='Edit' and r['name'] in ('X :',' Y :',' 宽度 :','高度 :')}
    fields(d,[{'type':'Edit','name':key,'value':value} for key,value in shape.items()],commit_edits=True);geometry=rows(d)
    confirm(d);save(root)
    report={'page':page,'source':source['object'],'target':name,'general':general_readback,'labels':labels,'safety':safety,'picture':pictures,'geometry':geometry,'saved_requested':True,'label_color_review_pending':True,'offline_simulation_verified':False}
    (ROOT/f'evidence/target-{page:03d}-MS0-built.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
