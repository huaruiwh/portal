"""Serial 204-page native local-copy continuation, never duplicate saved controls."""
import json,os,traceback
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock';wf=ROOT/'evidence/page204-local-copy-workflow.json'
with lock.open('x',encoding='utf8') as f:json.dump({'pid':os.getpid(),'task':'204 local TS copies'},f)
d={'pid':os.getpid(),'page':204,'status':'running','verified':[],'pending':[]}
def checkpoint():
 wf.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
 cp=ROOT/'evidence/resume-checkpoint.json';c=json.loads(cp.read_text(encoding='utf8'));c.update(status='page204-local-copy-'+d['status'],batch_running=d['status']=='running',active_page=204,current_stage=d.get('current'),page204_local_copy_workflow=wf.name);cp.write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding='utf8')
try:
 for n in range(1,22):
  key=f'TS_{n}';d['current']=key;checkpoint();report=ROOT/f'evidence/target-204-TS{n}-built.json'
  if report.exists():
   if not json.loads(report.read_text(encoding='utf8')).get('saved_reopened_verified'):raise ValueError('Saved but unverified control; no repeat paste '+key)
  else:
   r=call('uia',10488686,json.dumps({'page':204,'copy_200_style_object':key,'local_original_template':'TS_0','build_bit_general':0},ensure_ascii=False))
  d['verified'].append(key);checkpoint();print(json.dumps({'saved_reopened_verified':key}),flush=True)
 d['status']='TS-copies-saved-other-kinds-pending';d['current']='Review original gallery identity, then build missing BL/SW/DW with same-kind local copies'
except Exception:
 d['status']='needs-review';d['error']=traceback.format_exc();print(d['error'],flush=True)
finally:
 checkpoint();lock.unlink(missing_ok=True);print(json.dumps({'status':d['status'],'verified_count':len(d['verified'])}),flush=True)
