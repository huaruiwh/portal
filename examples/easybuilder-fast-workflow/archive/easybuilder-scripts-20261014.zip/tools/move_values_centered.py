"""Move page 210/212/218 numeric objects to the centre of their table cell.

The tables are in the reviewed 均等 state (3 equal columns, evenly divided rows), so each numeric
box is moved horizontally so that its centre equals its own cell centre. Nothing else is touched:
no table line, no text, no binding, no other object.

Usage:  python tools/move_values_centered.py
"""
import json,os,re,sys,time,traceback,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'tools'))
from eb_rebuild_page import call

TABLES=[(210,'TB_0'),(210,'TB_1'),(212,'TB_0'),(218,'TB_0')]
if len(sys.argv)>1:TABLES=[t for t in TABLES if str(t[0])==sys.argv[1]]
TGT_TITLE='组装机_MT8106iP.emtp'
REVIEWED=(1848,1281)
BACKUP=ROOT/'backup/tools-old-name-20261011_220309'
DIR=ROOT/'evidence/scale-890x469'
WF=ROOT/'evidence/move-values-workflow.json'
COLS=3
CHUNK=int(sys.argv[2]) if len(sys.argv)>2 else 4

def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
def load(p):return json.loads(p.read_text(encoding='utf-8'))

def patch_dispatch():
    f=ROOT/'tools/eb_uia.py'
    old=" if 'extract' in batch_request:"
    new=(" if batch_request.get('move_objects'):\n"
         "  from eb_move_objects import run\n"
         "  run(int(sys.argv[1]),batch_request)\n"
         "  sys.exit(0)\n"
         +old)
    b=f.read_bytes();bom=b[:3]==b'\xef\xbb\xbf'
    t=b.decode('utf-8-sig') if bom else b.decode('utf-8')
    if 'move_objects' in t:return 'already'
    n=t.count(old)
    if n!=1:raise ValueError('dispatch anchor count=%d; no edit'%n)
    BACKUP.mkdir(parents=True,exist_ok=True)
    dst=BACKUP/'eb_uia.py.before-move-objects-dispatch.bak'
    if not dst.exists():shutil.copy2(f,dst)
    o=t.replace(old,new)
    data=(b'\xef\xbb\xbf'+o.encode('utf-8')) if bom else o.encode('utf-8')
    tmp=f.with_suffix('.py.tmp');tmp.write_bytes(data);tmp.replace(f)
    if f.read_bytes()!=data:raise ValueError('dispatch patch readback mismatch')
    return 'edited'

def ne_geometry(page):
    out={}
    for f in (ROOT/'evidence/scale-890x469').glob('%d_NE_*.json'%page):
        j=load(f);g=j.get('after') or {}
        if 'X :' in g and ' 宽度 :' in g:
            out[f.stem.split('_',1)[1]]={'X':int(g['X :']),'W':int(g[' 宽度 :']),'Y':int(g.get(' Y :',0))}
    return out

def derive(page,key,frame):
    nes=ne_geometry(page)
    fx,fw=int(frame['X :']),int(frame[' 宽度 :'])
    inside={k:v for k,v in nes.items() if fx<=v['X']+v['W']/2<=fx+fw}
    if not inside:return None,{'reason':'no numeric objects inside this table'}
    groups={}
    for k,v in inside.items():groups.setdefault(v['X'],[]).append(k)
    xs=sorted(groups)
    if len(xs)>COLS-1:return None,{'reason':'more numeric columns than value columns','xs':xs}
    plan=[];detail=[]
    for i,x in enumerate(xs):
        col=i+1                                  # column 0 holds the row labels
        centre=fx+(col+0.5)*fw/COLS
        for k in sorted(groups[x]):
            w=inside[k]['W']
            target=int(round(centre-w/2))
            if target!=inside[k]['X']:plan.append({'key':k,'fields':{'X :':str(target)}})
            detail.append({'key':k,'from':inside[k]['X'],'to':target,'cell_centre':round(centre,1)})
    return plan,{'frame':[fx,fw],'numeric_columns':xs,'cell_centres':[round(fx+(c+0.5)*fw/COLS,1) for c in range(1,COLS)],'items':detail}

def windows():
    call('snapshot')
    for _ in range(30):
        try:return [w for w in load(ROOT/'evidence/windows.json') if w.get('title')]
        except Exception:time.sleep(.1)
    raise ValueError('windows.json unreadable')

def target_handle():
    m=[w for w in windows() if TGT_TITLE in w['title'] and w.get('class')=='EasyBuilderPro']
    if len(m)!=1:raise ValueError('Unique target window required')
    t=m[0]
    if (t['rect'][2]-t['rect'][0],t['rect'][3]-t['rect'][1])!=REVIEWED:
        call('uia',t['handle'],json.dumps({'restore_target_window':True,'reviewed_size':True}))
        m=[w for w in windows() if TGT_TITLE in w['title'] and w.get('class')=='EasyBuilderPro']
        t=m[0]
    return t['handle']

def main():
    lock=ROOT/'tools/batch.lock'
    with lock.open('x',encoding='utf8') as fh:fh.write(json.dumps({'pid':os.getpid(),'task':'move-values'},ensure_ascii=False))
    out=None
    try:
        out={'date':time.strftime('%Y-%m-%dT%H:%M:%S'),'dispatch':patch_dispatch(),'tables':{},'finished':False,
             'scope':'numeric objects only; moved horizontally to their cell centre'}
        write(WF,out)
        print(json.dumps({'dispatch':out['dispatch']},ensure_ascii=False),flush=True)
        h=target_handle()
        def clear_leftovers(tag):
            for w in windows():
                if w.get('title') and 'EasyBuilder Pro V' not in w['title']:
                    print(json.dumps({'clearing_leftover':{tag:w.get('title')}},ensure_ascii=False),flush=True)
                    try:call('keys',w['handle'],'{ESC}')
                    except Exception as e:print(json.dumps({'clear_error':str(e)[-140:]},ensure_ascii=False),flush=True)
                    time.sleep(1)
        for page,key in TABLES:
            name='%d_%s'%(page,key);rec={'page':page,'key':key}
            try:
                rp=DIR/('%d_%s.json'%(page,key))
                if not rp.exists():raise ValueError('No scale record for '+name)
                plan,info=derive(page,key,load(rp)['after'])
                rec['derivation']=info
                if not plan:
                    rec['result']='nothing to move' if plan is not None else 'skipped: '+info.get('reason','')
                    out['tables'][name]=rec;write(WF,out)
                    print(json.dumps({'skip':{name:rec['result']}},ensure_ascii=False),flush=True)
                    continue
                rec['planned']=len(plan)
                print(json.dumps({'plan':{name:{'items':len(plan),'detail':info['items'][:4]}}},ensure_ascii=False),flush=True)
                clear_leftovers(name)
                moved=0;mismatches=[]
                for i in range(0,len(plan),CHUNK):
                    batch=plan[i:i+CHUNK]
                    call('uia',h,json.dumps({'move_objects':{'page':page,'op':'move','items':batch}}))
                    moved+=len(batch)
                    print(json.dumps({'moved':{name:moved}},ensure_ascii=False),flush=True)
                print(json.dumps({'stage':'verify','table':name},ensure_ascii=False),flush=True)
                for i in range(0,len(plan),6):
                    batch=plan[i:i+6]
                    call('uia',h,json.dumps({'move_objects':{'page':page,'op':'verify','items':batch}}))
                    vf=ROOT/'evidence'/('move-objects-%d-verify-%s.json'%(page,batch[0]['key']))
                    if vf.exists():mismatches+=(load(vf).get('mismatches') or [])
                rec.update({'moved':moved,'verified':not mismatches,'mismatches':mismatches,
                            'result':'moved and verified after save+reopen' if not mismatches else 'not verified'})
                out['tables'][name]=rec;write(WF,out)
                print(json.dumps({'applied':{name:{'verified':rec['verified'],'moved':moved}}},ensure_ascii=False),flush=True)
            except Exception as e:
                rec['error']=str(e)[-400:]
                out['tables'][name]=rec;write(WF,out)
                print(json.dumps({'table_error':{name:rec['error']}},ensure_ascii=False),flush=True)
        for w in windows():
            if w.get('title') and 'EasyBuilder Pro V' not in w['title']:
                try:call('keys',w['handle'],'{ESC}')
                except Exception:pass
                time.sleep(1)
        print(json.dumps({'stage':'compile'},ensure_ascii=False),flush=True)
        call('uia',h,json.dumps({'compile_target':True}))
        out['compile']=load(ROOT/'evidence/latest-project-compile.json')
        out['finished']=bool(out['compile'].get('ok'))
        write(WF,out)
        print(json.dumps({'finished':out['finished'],'messages':out['compile']['messages'],
                          'project_bytes':out['compile']['project_bytes'],'exob_bytes':out['compile']['exob_bytes']},ensure_ascii=False),flush=True)
    except Exception as e:
        out=(out or {});out['error']=traceback.format_exc();write(WF,out)
        print(json.dumps({'error':str(e)[:600]},ensure_ascii=False),flush=True)
        raise
    finally:
        lock.unlink(missing_ok=True)

if __name__=='__main__':main()
