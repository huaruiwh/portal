"""Reject unsupported source behavior before creating any target objects."""
import json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
ALLOWED={11:(12,12),12:(4,8),13:(8,10),14:(5,8),15:(3,8),17:(13,12),18:(1,8),19:(6,8),20:(2,8),21:(2,8),22:(1,8),23:(3,8),24:(1,8),25:(1,8),48:(2,8),49:(1,8)}

def validate_object(page,kind,n):
    if page not in ALLOWED or n not in range(ALLOWED[page][kind=='BL']):
        raise ValueError('Unreviewed page/object range')
    source=json.loads((ROOT/'evidence'/'source-object-properties'/f'{page:03d}_{kind}_{n}.json').read_text(encoding='utf8'))
    general=source['tabs']['一般属性']
    def field(typ,name):
        values=[c['value'] for c in general if c['type']==typ and c['name']==name]
        if len(values)!=1:raise ValueError('Ambiguous source field: '+name)
        return values[0]
    devices=[c['value'] for c in general if c['type']=='ComboBox' and c['name']=='设备 :']
    types=[c['value'] for c in general if c['type']=='ComboBox' and c['name']==' Down']
    if devices!=(['Local HMI']* (2 if kind=='SW' else 1)):raise ValueError('Unsupported source devices')
    if types!=(['LW','LB'] if kind=='SW' else ['LB']):raise ValueError('Unsupported source address types')
    for c in source['tabs']['安全']:
        allowed_press=page in (11,17) and c['name']=='最短按压时间' and c.get('value')==1
        allowed_duration=page in (11,17) and c['name']==' Down' and c.get('value')=='0.1'
        if c['type']=='CheckBox' and c.get('value')!=0 and not allowed_press:raise ValueError('Source safety option requires separate implementation: '+c['name'])
        if c['type']=='ComboBox' and c.get('value')!='无' and not allowed_duration:raise ValueError('Source user restriction requires separate implementation')
    if kind=='SW':
        for typ,name,expected in [('ComboBox','模式 :','写入常数'),('CheckBox','启用',1),('CheckBox','当按钮松开后发出指令',0),('RadioButton','设 ON',1),('RadioButton','写入后',1)]:
            if field(typ,name)!=expected:raise ValueError('Unsupported SW behavior: '+name)
        if any(c.get('value','').strip() for state in source.get('label_states',{}).values() for c in state if c['type']=='Edit' and c['name']==''):
            if page!=17 or n!=12 or set(source.get('label_states',{}))!={'0','1'}:
                raise ValueError('SW text label requires separate implementation')
            if not any(c['name']=='Button - Flat' for c in source['tabs']['图片']):raise ValueError('Unsupported labelled SW picture family')
    else:
        for typ,name,expected in [('RadioButton','位状态指示灯',1),('CheckBox','输出反向',0),('ComboBox','模式 :','无')]:
            if field(typ,name)!=expected:raise ValueError('Unsupported BL behavior: '+name)
        if not any(c['name']=='Button - Flat' for c in source['tabs']['图片']):raise ValueError('Unsupported picture family')
    return source

def validate_page(page,names):
    settings=json.loads((ROOT/'evidence'/'source-pages-settings'/f'{page:03d}.json').read_text(encoding='utf8'))['controls']
    for c in settings:
        if c['type']=='ComboBox' and c['name'] in ('底层 :','中层 :','顶层 :') and c.get('value')!='无':
            raise ValueError('Page layer requires separate implementation')
        if c['type']=='ComboBox' and c['name'] in ('打开窗口时执行 :','循环执行 :','关闭窗口时执行 :') and c.get('value')!='停用':
            raise ValueError('Page macro hook requires separate implementation')
    expected=ALLOWED[page]
    counts=tuple(sum(name.startswith(kind+'_') for name in names) for kind in ('SW','BL'))
    if counts!=expected:raise ValueError('Source inventory count changed')
    for name in names:
        key=re.match(r'^(SW|BL)_(\d+)\s',name)
        if not key:raise ValueError('Unsupported object type')
        validate_object(page,key[1],int(key[2]))
