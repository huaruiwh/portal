import json,time
from pywinauto import Desktop
from eb_extract import ROOT
from eb_object_ui import target,object_item
from pywinauto.keyboard import send_keys
def run(handle,q):
 root,w=target(handle,103);item=object_item(w,'TS_0');root.set_focus();item.click_input(button='right',coords=(30,item.rectangle().height()//2));time.sleep(.2)
 items=[]
 for win in Desktop(backend='win32').windows():
  if win.process_id()==root.process_id() and win.is_visible() and (win.class_name().startswith('Qt') or win.class_name()=='#32768'):
   u=Desktop(backend='uia').window(handle=win.handle).wrapper_object()
   items.extend({'name':c.window_text(),'rect':list(c.rectangle())} for c in u.descendants(control_type='MenuItem') if c.is_visible())
 (ROOT/'evidence/reset-context-menu.json').write_text(json.dumps(items,ensure_ascii=False,indent=2),encoding='utf8')
 send_keys('{ESC}',pause=.01)
