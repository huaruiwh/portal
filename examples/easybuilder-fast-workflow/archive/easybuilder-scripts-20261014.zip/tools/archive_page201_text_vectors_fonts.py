import json,py_compile
from eb_rebuild_page import ROOT,call
call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'));h=next(w['handle']for w in ws if w['class']=='EasyBuilderPro'and'组装机_MT8106iP.emtp'in w['title'])
call('uia',h,json.dumps({'fast_fields_benchmark':True,'final_audit':True}))
def load(n):return json.loads((ROOT/'evidence'/n).read_text(encoding='utf-8-sig'))
a=load('target-page201-audit.json');assert a['target_count']==46 and len(a['missing'])==6 and not a['unexpected']and not a['address_name_mismatch']
keys=[f'TX_{n}'for n in range(13)]+[f'TS_{n}'for n in range(15)]
assert all(load(f'page201-font12-{key}.json')['verified']for key in keys)
assert load('page201-vectors-batch.json')['finished']
size=(ROOT/'output/组装机_MT8106iP.emtp').stat().st_size
times=[load('page201-text-batch-'+ '-'.join(map(str,ids))+'.json')['seconds']for ids in ([0,1,2],[3,4,5],[6,7,8],[9,10,11,12])]
for name in ('eb_page201_text_batch.py','eb_page201_vectors.py','eb_page201_font_batch.py','continue_page201_text_batches.py','continue_page201_fonts12.py'):
    py_compile.compile(str(ROOT/'tools'/name),doraise=True)
text=f'''

### 2026-10-11：按26页原生流程完成201文字、背景，全部文字标签降至12号

用户要求省流量继续，并明确“按照26页的方法”。本轮采用原生新增、逐控件Python/UIA串行写参数保存、小批次最后查目录；不回传截图，不反复切换复制方案。新增TX_0..TX_12共13独立文字、SP_0/SP_1两个背景向量图。原件缓存逐件读文字/字体/颜色/安全/轮廓；创建文字先设置微软正黑体 Light适配字号，再恢复源适配坐标尺寸，保存后核对文字、字体、字号、几何。4个文字批次worker耗时{json.dumps(times)}秒；首批包含已保存TX_0恢复验证，未计入之前失败、源读取，不当作完整首次端到端速度。向量图原图库System Frame/index0，两件填充RGB240/240/240、边框RGB225/225/225，创建后读回颜色与几何；把SP_1先置底，再SP_0置底，最后目录前两项SP_0、SP_1，SP_0最下层。没有用默认图库替代原形状。

用户随后要求处理字号，选择第一项“201页全部文字和按钮标签”。本轮明确统一当前13号降到12号：TX_0..TX_12共13独立文字，TS_0..TS_14共15按钮，两态标签均12号，共28控件。模块eb_page201_font_batch仅修改字体/字号，随后恢复原源geometry；重开逐件读文字、字体、字号、位置/尺寸，对照原文字和几何全部通过，地址、权限、安全、颜色、图形未写入。逐件证据evidence/page201-font12-TX_0.json等，verified=true；原built报告font_size已更新为12，旧“13号”描述是历史阶段，不能作为当前模板字号。200页及其它旧页未在本轮调整。

最终真实目录46/52件，剩6：{json.dumps(a['missing'],ensure_ascii=False)}，额外0、地址/名称差异0。目录空格呈现适配记录：{json.dumps(a.get('model_adaptation_objects'),ensure_ascii=False)}。工程{size}字节，停201页，目标当前handle={h}。原件只读取消；无PLC/HMI下载、宏执行、发布、新编译或整页运行验收。

问题→解决：
- 首个文字保存后，核对代码取同名Text“内容”标签而非Edit，报KeyError: 'value'；按实际type=Edit定位修正，既有built仅重开验证，没有重复创建。
- 源目录如“[实际位置 ] TX_0”含尾随空格，目标目录“[实际位置] TX_0”省略空格，导致Initial directory mismatch。仅在独立文本已保存重开、literal原文相等且仅括号前空白不同的情况下记录目录呈现适配；不消除真正文字或地址差异。
- 原窗口全部关闭，尝试向旧handle10488686操作报InvalidWindowHandle: Handle 10488686 is not a vaild window handle。本次在未创建SP前失败，保存成果仍在磁盘；snapshot证实无EasyBuilder窗口，使用管理员worker action=launch重新打开output工程。启动临时Qt窗口UIA树只有Pane、没有按钮，不盲点；待启动完成，重新snapshot找到真实目标handle={h}，restore_target_window+reviewed_size恢复1848×1281、X262/Y0，open_target_page201后接续。源参数8件已全部缓存，继续不依赖原件打开。旧失败脚本留下仅本次持有的batch.lock，确认控制器已退出且内容为“201 native vectors”后移除；后续脚本使用finally释放。
- DW_0源rectangle_probe白名单遗漏201，已加入201；DW_1无rectangle_colors、OL_0/1为“项目选单/源数据/状态设置”复杂控件，不能按指示灯盲造。剩6件未新建；DW_1需单独真实颜色读取，OL菜单/状态项需映射真实入口与完整条目，SW/FK需核对原图颜色和目标功能。不能把缓存完成称为这些控件制作完成。

脚本与恢复命令（项目目录，管理员worker已运行，无其它controller）：
`& "C:\\Users\\wei'ke\\.cache\\codex-runtimes\\codex-primary-runtime\\dependencies\\python\\python.exe" tools/continue_page201_text_batches.py`
`& "C:\\Users\\wei'ke\\.cache\\codex-runtimes\\codex-primary-runtime\\dependencies\\python\\python.exe" tools/continue_page201_fonts12.py`
以上都按verified报告跳过；已完成文字禁止新建、禁止复测重跑当速度结果。向量请求{{"page201_vectors":true,"build_bit_general":0}}，字号请求page201_font_batch每批最多5件、单完整请求300秒。控制器首先snapshot按真实标题取handle，不复用旧值。文本creation-requested无built时禁止再次新建，先查看实际弹窗/目录；有built时只验证。实现模块eb_build_tx(201创建时适配字体)、eb_page201_text_batch、eb_page201_vectors、eb_page201_font_batch、eb_page_audit(严格literal证据后的目录空格适配)。语法检查通过，28字号报告、13文字报告、2背景报告与最终目录通过；未新增仅镜像实现的测试。下一步按26页原生流程继续最后6件，保留12号字体规律、小批次串行、原件参数缓存、保存断点及批次目录核对。
'''
for p in (ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md'):
    with p.open('a',encoding='utf8')as f:f.write(text)
cp=ROOT/'evidence/resume-checkpoint.json';d=json.loads(cp.read_text(encoding='utf-8-sig'));d.update(status='page201-text-vectors-font12-saved',page201_objects=46,page201_remaining_objects=6,project_bytes=size,target_project_bytes=size,batch_running=False,target_handle=h,current_stage='13 texts, 15 buttons font12 verified; SP0/SP1 saved and ordered; 46/52 directory clean',next_action='Native sequential26 workflow. Remaining DW0/DW1/OL0/OL1/SW0/FK0 source cached; DW1 exact RGB and OL complete menu/state mapping required before creation. No duplicate NE/ND/TS/TX/SP. Font12 current201 templates, not historical13.',page201_font12_verified=keys)
cp.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'count':46,'remaining':6,'font12_verified':28,'bytes':size,'docs_updated':2},ensure_ascii=False))
