"""Fix the custom-spacing table grids on pages 210/212/218 so no row is clipped by the scaled frame.

Usage:  python tools/fix_table_rows.py

Phase 1 probes each table's real spacing options (read-only, popup read, no guess).
Phase 2 applies the unique non-custom option, saves and verifies after reopen.
Phase 3 compiles. Every other page and every other object is untouched.
"""
import json,os,sys,time,traceback,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'tools'))
from eb_rebuild_page import call

TABLES=[(210,'TB_0'),(210,'TB_1'),(212,'TB_0'),(218,'TB_0')]
TGT_TITLE='组装机_MT8106iP.emtp'
REVIEWED=(1848,1281)
BACKUP=ROOT/'backup/tools-old-name-20261011_220309'
WF=ROOT/'evidence/table-row-fix-workflow.json'
PREFER=('等分','平均','均分','自动','等距')

def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
def load(p):return json.loads(p.read_text(encoding='utf8'))

def patch_dispatch():
    f=ROOT/'tools/eb_uia.py'
    old=" if 'extract' in batch_request:"
    new=(" if batch_request.get('table_fix'):\n"
         "  from eb_table_fix import run\n"
         "  run(int(sys.argv[1]),batch_request)\n"
         "  sys.exit(0)\n"
         +old)
    b=f.read_bytes();bom=b[:3]==b'\xef\xbb\xbf'
    t=b.decode('utf-8-sig') if bom else b.decode('utf-8')
    if 'table_fix' in t:return 'already'
    n=t.count(old)
    if n!=1:raise ValueError('dispatch anchor count=%d; no edit'%n)
    BACKUP.mkdir(parents=True,exist_ok=True)
    dst=BACKUP/'eb_uia.py.before-table-fix-dispatch.bak'
    if not dst.exists():shutil.copy2(f,dst)
    o=t.replace(old,new)
    data=(b'\xef\xbb\xbf'+o.encode('utf-8')) if bom else o.encode('utf-8')
    tmp=f.with_suffix('.py.tmp');tmp.write_bytes(data);tmp.replace(f)
    if f.read_bytes()!=data:raise ValueError('dispatch patch readback mismatch')
    return 'edited'

def windows():
    call('snapshot')
    for _ in range(30):
        try:return [w for w in load(ROOT/'evidence/windows.json') if w.get('title')]
        except Exception:time.sleep(.1)
    raise ValueError('windows.json unreadable')

def target_handle():
    ws=windows()
    m=[w for w in ws if TGT_TITLE in w['title'] and w.get('class')=='EasyBuilderPro']
    if len(m)!=1:raise ValueError('Unique target window required')
    t=m[0]
    if (t['rect'][2]-t['rect'][0],t['rect'][3]-t['rect'][1])!=REVIEWED:
        call('uia',t['handle'],json.dumps({'restore_target_window':True,'reviewed_size':True}))
        ws=windows();m=[w for w in ws if TGT_TITLE in w['title'] and w.get('class')=='EasyBuilderPro']
        t=m[0]
    return t['handle']

def main():
    lock=ROOT/'tools/batch.lock'
    with lock.open('x',encoding='utf8') as fh:fh.write(json.dumps({'pid':os.getpid(),'task':'table-row-fix'},ensure_ascii=False))
    out=None
    try:
        out={'date':time.strftime('%Y-%m-%dT%H:%M:%S'),'dispatch':patch_dispatch(),'tables':{},'finished':False,
             'scope':'only the custom-spacing tables on 210/212/218; no other object touched'}
        write(WF,out)
        print(json.dumps({'dispatch':out['dispatch']},ensure_ascii=False),flush=True)
        h=target_handle()
        def clear_leftovers(tag):
            for w in windows():
                if w.get('title') and 'EasyBuilder Pro V' not in w['title']:
                    print(json.dumps({'clearing_leftover':{tag:w.get('title')}},ensure_ascii=False),flush=True)
                    try:
                        call('keys',w['handle'],'{ESC}')
                    except Exception as e:
                        print(json.dumps({'clear_error':str(e)[-160:]},ensure_ascii=False),flush=True)
                    time.sleep(1)
        for page,key in TABLES:
            rec={'page':page,'key':key}
            try:
                clear_leftovers('%d_%s'%(page,key))
                call('uia',h,json.dumps({'open_target_page':page}))
                probe=call('uia',h,json.dumps({'table_fix':{'page':page,'key':key,'op':'probe'}}))
                pf=ROOT/'evidence'/('table-fix-probe-%d-%s.json'%(page,key))
                p=load(pf) if pf.exists() else {}
                rec.update({'spacing_before':p.get('spacing_before'),'options':p.get('options'),
                            'counts_before':p.get('counts_before'),'hints_before':p.get('hints_before')})
                print(json.dumps({'probe':rec},ensure_ascii=False),flush=True)
                alts=[o for o in (p.get('options') or []) if o and o!='自定义']
                if len(alts)==1:
                    want=alts[0]
                else:
                    pref=[o for o in alts if any(x in o for x in PREFER)]
                    want=pref[0] if len(pref)==1 else None
                if want is None:
                    rec['result']='ambiguous options; probe recorded, nothing changed'
                    out['tables']['%d_%s'%(page,key)]=rec;write(WF,out)
                    print(json.dumps({'skip':rec['result'],'options':alts},ensure_ascii=False),flush=True)
                    continue
                rec['set_to']=want
                call('uia',h,json.dumps({'table_fix':{'page':page,'key':key,'op':'apply','set':want}}))
                ff=ROOT/'evidence'/('table-fix-%d-%s.json'%(page,key))
                r=load(ff) if ff.exists() else {}
                rec.update({'spacing_reopened':r.get('spacing_reopened'),'counts_reopened':r.get('counts_reopened'),
                            'saved_reopened_verified':r.get('saved_reopened_verified'),'result':'applied and verified'})
                out['tables']['%d_%s'%(page,key)]=rec;write(WF,out)
                print(json.dumps({'applied':{'%d_%s'%(page,key):rec['result'],'set_to':want,'verified':rec['saved_reopened_verified']}},ensure_ascii=False),flush=True)
            except Exception as e:
                rec['error']=str(e)[-400:]
                out['tables']['%d_%s'%(page,key)]=rec;write(WF,out)
                print(json.dumps({'table_error':{'%d_%s'%(page,key):rec['error']}},ensure_ascii=False),flush=True)
        left=[w for w in windows() if w.get('title') and 'EasyBuilder Pro V' not in w['title']]
        for w in left:
            print(json.dumps({'clearing_leftover':w.get('title')},ensure_ascii=False),flush=True)
            call('keys',w['handle'],'{ESC}');time.sleep(1)
        print(json.dumps({'stage':'compile'},ensure_ascii=False),flush=True)
        call('uia',h,json.dumps({'compile_target':True}))
        out['compile']=load(ROOT/'evidence/latest-project-compile.json')
        out['finished']=bool(out['compile'].get('ok'))
        write(WF,out)
        print(json.dumps({'finished':out['finished'],'messages':out['compile']['messages'],
                          'project_bytes':out['compile']['project_bytes'],'exob_bytes':out['compile']['exob_bytes']},ensure_ascii=False),flush=True)
    except Exception as e:
        out=(out or {});out['error']=traceback.format_exc();write(WF,out)
        print(json.dumps({'error':str(e)[:600]},ensure_ascii=False),flush=True)
        raise
    finally:
        lock.unlink(missing_ok=True)

if __name__=='__main__':main()
