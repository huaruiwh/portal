import json
from eb_rebuild_page import ROOT
from eb_build_rectangle import run as build
from eb_object_ui import target,properties
from eb_native_form import tab
from eb_page26_shapes import cancel
from eb_live_fields import capture
from eb_original_style_existing import verify_fields
from eb_layout import geometry
from eb_color_picker import probe
from eb_page208 import write
from eb_copy_200_style_object import read_audit
def run(handle,q):
    a=read_audit(handle,201)
    for n in (0,1):
        p=ROOT/f'evidence/target-201-DW{n}-built.json';phase=ROOT/f'evidence/target-201-DW{n}-phase.json'
        if p.exists()and json.loads(p.read_text(encoding='utf8')).get('saved_reopened_verified'):continue
        if not p.exists():
            if phase.exists()or f'DW_{n}'not in a['missing']:raise ValueError('Unknown rectangle creation phase')
            write(phase,{'stage':'creation-requested'});build(handle,{'page':201,'build_rectangle':n})
        s=json.loads((ROOT/f'evidence/source-object-properties/201_DW_{n}.json').read_text(encoding='utf8'));root,w=target(handle,201);d,_=properties(root,w,f'DW_{n}','矩形元件属性')
        try:
            tab(d,' 形状');want=[r for r in s['tabs'][' 形状']if'value'in r];verify_fields(capture(d,[(r['type'],r['name'])for r in want]),want)
            for i,key in enumerate(('fill','border')if'fill'in s['rectangle_colors']else ('border',)):
                if probe(d,'颜色 :',i)!=s['rectangle_colors'][key]:raise ValueError('Saved rectangle RGB mismatch')
            tab(d,'轮廓');g=geometry(s);verify_fields(capture(d,[('Edit',k)for k in g]),[{'type':'Edit','name':k,'value':v}for k,v in g.items()])
        finally:cancel(d)
        r=json.loads(p.read_text(encoding='utf8'));r.update(saved_reopened_verified=True,line_width_and_style_review_pending=False);write(p,r);write(phase,{'stage':'verified'})
    a=read_audit(handle,201);write(ROOT/'evidence/page201-rectangles-batch.json',{'count':a['target_count'],'remaining':len(a['missing']),'finished':True})
