import subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent.parent
for name in ('cache_page230.py','start_page230.py'):
 p=subprocess.run([sys.executable,str(r/'tools'/name)],cwd=r)
 if p.returncode:sys.exit(p.returncode)
