"""Recreate one source multistate-setting object in target page 12."""
import json,time
from pathlib import Path
from pywinauto import Desktop
from pywinauto.controls.win32_controls import EditWrapper,ComboBoxWrapper,ButtonWrapper
from pywinauto.keyboard import send_keys
from eb_extract import rows
ROOT=Path(__file__).resolve().parent.parent

def run(handle,request):
    begin=time.monotonic();n=int(request['build_sw']);page=int(request.get('page',12))
    from eb_template_guard import validate_object
    validate_object(page,'SW',n)
    source=json.loads((ROOT/'evidence'/'source-object-properties'/f'{page:03d}_SW_{n}.json').read_text(encoding='utf8'))
    general=source['tabs']['一般属性']
    value=next(c['value'] for c in general if c['name']=='设置常数 :' and c['type']=='Edit')
    if any(c['value']!='Local HMI' for c in general if c['type']=='ComboBox' and c['name']=='设备 :'):raise ValueError('Only validated local HMI template supported')
    addresses=[c['value'] for c in general if c['name']=='Static' and c['type']=='Edit']
    from eb_layout import geometry as adapt_geometry
    geometry=adapt_geometry(source)
    native_root=Desktop(backend='win32').window(handle=handle).wrapper_object()
    pid=native_root.process_id()
    w=Desktop(backend='uia').window(handle=handle).wrapper_object()
    if '组装机_MT8106iP.emtp' not in native_root.window_text() or f'[{page} - ' not in native_root.window_text():raise ValueError('Expected target page')
    r=native_root.rectangle()
    if (r.width(),r.height()) not in ((2218,1537),(1848,1281)):raise ValueError('Ribbon/layout dimensions changed')
    profile={(447,63):(427,63),(736,111):(532,138),(373,111):(378,103),(1156,440):(963,367)}
    def point(x,y):return profile[(x,y)] if r.width()==1848 else (x,y)
    existing=[] if request.get('resume') else [c.window_text() for c in w.descendants(control_type='TreeItem') if c.window_text().startswith(f'SW_{n} ')]
    if existing:raise ValueError('Target object already exists; verify instead of duplicating')
    def mark(stage):
        (ROOT/'evidence'/'builder-stage.json').write_text(json.dumps({'page':page,'object':'SW_'+str(n),'stage':stage,'elapsed':round(time.monotonic()-begin,3)},ensure_ascii=False),encoding='utf8')
    def dialog(title):
        for _ in range(20):
            ds=[d for d in Desktop(backend='win32').windows() if d.process_id()==pid and d.window_text()==title and d.is_visible()]
            if len(ds)==1:return Desktop(backend='uia').window(handle=ds[0].handle).wrapper_object()
            time.sleep(.1)
        raise ValueError('Dialog not ready: '+title)
    controls_cache={}
    native_cache={}
    def control(d,typ,name,index=None):
        ids={'描述 :':1174,'设置常数 :':1156,'Static':2510,'设备 :':1646,'启用':1856,'设 ON':1887,'设 OFF':1888,'写入前':1865,'写入后':1864,'确定':1,'取消':2}
        if name in ids and typ!='TabItem':
            h=d.handle
            if h not in native_cache:native_cache[h]=Desktop(backend='win32').window(handle=h).descendants()
            matches=[v for v in native_cache[h] if v.control_id()==ids[name] and v.is_visible()]
            matches.sort(key=lambda v:v.rectangle().top)
            if index is None:
                if len(matches)!=1:raise ValueError('Unique native field required: '+name)
                return matches[0]
            return matches[index]
        if d.handle not in controls_cache:controls_cache[d.handle]=d.descendants(cache_enable=True)
        cs=[c for c in controls_cache[d.handle] if c.element_info.control_type==typ and c.window_text()==name and c.is_visible()]
        if index is None:
            if len(cs)!=1:raise ValueError('Unique control required: '+name)
            return cs[0]
        return cs[index]
    def edit(d,name,value,index=None):
        mark('edit '+name)
        c=control(d,'Edit',name,index);native=EditWrapper(c.handle);native.set_edit_text(value)
        if native.window_text().rstrip('\r\n')!=value:raise ValueError('Edit verification failed: '+name)
    def radio(d,name):
        mark('radio '+name)
        c=control(d,'RadioButton',name);ButtonWrapper(c.handle).click()
        if ButtonWrapper(c.handle).get_check_state()!=1:raise ValueError('Radio verification failed: '+name)
    if not request.get('resume'):
        if page in (11,48,49):
            from eb_ribbon import create
            create(native_root,'SW','新增 多状态设置')
        else:native_root.set_focus();native_root.click_input(coords=point(447,63));time.sleep(.1);native_root.click_input(coords=point(736,111))
    d=dialog('新增 多状态设置')
    control(d,'TabItem','一般属性').select();controls_cache.clear();native_cache.clear()
    mark('device0')
    dev=control(d,'ComboBox','设备 :',0);ComboBoxWrapper(dev.handle).select('Local HMI')
    edit(d,'Static',addresses[0],0);edit(d,'设置常数 :',value)
    mark('enable notification')
    enabled=control(d,'CheckBox','启用')
    native_enabled=ButtonWrapper(enabled.handle)
    if native_enabled.get_check_state()!=1:
        native_enabled.click();time.sleep(.05);controls_cache.clear()
    if native_enabled.get_check_state()!=1:raise ValueError('Notification not enabled')
    mark('device1')
    dev=control(d,'ComboBox','设备 :',1);ComboBoxWrapper(dev.handle).select('Local HMI')
    edit(d,'Static',addresses[1],1);radio(d,'设 ON');radio(d,'写入后')
    mark('read general')
    addrs=[control(d,'ComboBox',' Down',i).selected_text() for i in (0,1)]
    if addrs!=['LW','LB']:raise ValueError('Address type mismatch: '+str(addrs))

    # Source settings buttons have empty labels; never inherit a previous creation preset.
    control(d,'TabItem','标签').select();controls_cache.clear()
    label=ButtonWrapper(control(d,'CheckBox','使用文字标签').handle)
    texts=[next((v['value'] for v in source.get('label_states',{}).get(state,[]) if v['type']=='Edit' and v['name']==''),'') for state in ('0','1')]
    labels={}
    if any(texts):
        if label.get_check_state()!=1:label.send_message_timeout(0x00F5,timeout=2)
        controls_cache.clear();native_cache.clear()
        from eb_native_form import fields
        for state in ('0','1'):
            ComboBoxWrapper(control(d,'ComboBox','状态 :').handle).select(state)
            fields(d,source['label_states'][state],skip=(('Edit',''),))
        from eb_label_commit import commit
        commit(d,texts)
        for state in ('0','1'):
            ComboBoxWrapper(control(d,'ComboBox','状态 :').handle).select(state);labels[state]=rows(d)
        control(d,'TabItem','图片').select();controls_cache.clear()
        image=ButtonWrapper(control(d,'CheckBox','使用图片').handle)
        if image.get_check_state()!=1:image.send_message_timeout(0x00F5,timeout=2)
        if not any(c.window_text()=='Button - Flat' for c in d.descendants(control_type='Text')):
            from eb_flat_picture import choose
            choose(d,pid)
    else:
        if label.get_check_state()!=0:label.send_message_timeout(0x00F5,timeout=2)
        if label.get_check_state()!=0:raise ValueError('Blank SW label preset verification failed')
    from eb_press_safety import apply as apply_safety
    apply_safety(d,source)

    mark('confirm creation')
    control(d,'Button','确定').click_input();time.sleep(.15)
    native_root.set_focus();native_root.click_input(coords=point(1156,440));send_keys('{ESC}',pause=.01);time.sleep(.2)
    matches=[c for c in w.descendants(control_type='TreeItem') if c.window_text().startswith(f'SW_{n} ')]
    if not matches:
        headers=[c for c in w.descendants(control_type='TreeItem') if c.window_text().startswith(str(page)+' :')]
        if len(headers)!=1:raise ValueError('Page header required to load new objects')
        try:headers[0].expand()
        except Exception:
            from pywinauto import mouse
            box=headers[0].rectangle();native_root.set_focus();mouse.click(coords=(box.left-14,(box.top+box.bottom)//2))
        time.sleep(.1)
        matches=[c for c in w.descendants(control_type='TreeItem') if c.window_text().startswith(f'SW_{n} ')]
    if len(matches)!=1:raise ValueError('New object not uniquely present')
    name=matches[0].window_text();matches[0].double_click_input(coords=(40,matches[0].rectangle().height()//2))
    d=dialog('多状态设置的属性')
    general_readback={'constant':EditWrapper(control(d,'Edit','设置常数 :').handle).window_text(),'addresses':[EditWrapper(control(d,'Edit','Static',i).handle).window_text() for i in (0,1)],'devices':[ComboBoxWrapper(control(d,'ComboBox','设备 :',i).handle).selected_text() for i in (0,1)],'notification':ButtonWrapper(control(d,'CheckBox','启用').handle).get_check_state(),'on':ButtonWrapper(control(d,'RadioButton','设 ON').handle).get_check_state(),'after_write':ButtonWrapper(control(d,'RadioButton','写入后').handle).get_check_state()}
    if general_readback['constant']!=value or general_readback['addresses']!=addresses or general_readback['notification']!=1 or general_readback['on']!=1 or general_readback['after_write']!=1:raise ValueError('Created general fields mismatch')
    control(d,'TabItem','轮廓').select();controls_cache.clear()
    for key,val in geometry.items():edit(d,key,val)
    geometry_readback=rows(d)
    control(d,'Button','确定').click_input();native_root.set_focus();send_keys('^s',pause=.01)
    report={'page':page,'source':source['object'],'target':name,'general':general_readback,'geometry':geometry_readback,'labels':labels,'minimum_press_preserved':page in (11,17),'elapsed_seconds':round(time.monotonic()-begin,3),'saved_requested':True,'appearance_review_pending':True}
    (ROOT/'evidence'/f'target-{page:03d}-SW{n}-built.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
