"""Resumable aspect-preserving layout and font adaptation, pages26..47 only."""
import json,re,time,ctypes
from pathlib import Path
from pywinauto import Desktop
from pywinauto.controls.win32_controls import ComboBoxWrapper
from pywinauto.keyboard import send_keys
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save
from eb_open_page import run as open_page
from eb_native_form import tab,fields,confirm,typed_children
from eb_live_fields import capture
from eb_page26_shapes import cancel
from eb_extract import rows
import eb_scale_post200 as old
DIR=ROOT/'evidence/scale-pages26-47-height391'
TITLES=dict(old.TITLES,MS='多状态切换开关/多状态指示灯的属性')
NAMES=old.NAMES
put=old.put
load=old.load

def scale(g,bounds):
 ratio=391/int(bounds['高度 :']);width=int(bounds['宽度 :']);offset=(width-width*ratio)/2
 out={'X :':str(round(offset+int(g['X :'])*ratio)),' Y :':str(round(int(g[' Y :'])*ratio))}
 for size in (' 宽度 :','高度 :'):
  if size in g:out[size]=str(max(1,round(int(g[size])*ratio)))
 if ' 宽度 :'in g and '高度 :'in g and int(g[' 宽度 :'])==int(g['高度 :']):out['高度 :']=out[' 宽度 :']
 return out

def font_read_write(d,scopes,before=None,ratio=1):
 result={};font=load(ROOT/'tools/font-policy.json')['font']
 for scope in scopes:
  tab(d,scope)
  toggles=[c for c in typed_children(d,'CheckBox')if c.window_text()=='使用文字标签'and c.is_visible()]
  if toggles and not toggles[0].get_toggle_state():continue
  cs=[c for c in typed_children(d,'ComboBox')if c.window_text()=='尺寸 :'and c.is_visible()]
  if not cs:continue
  states=[c for c in typed_children(d,'ComboBox')if c.window_text()=='状态 :'and c.is_visible()]
  choices=ComboBoxWrapper(states[0].handle).item_texts()if len(states)==1 else [None]
  result[scope]={}
  for state in choices:
   if state is not None:
    native=ComboBoxWrapper(states[0].handle)
    if native.selected_text()!=state:native.select(state);time.sleep(.12)
   sid=str(state)
   if before is not None:
    wanted=max(6,round(int(before[scope][sid]['size'])*ratio))
    fields(d,[{'type':'ComboBox','name':'字体 :','value':font}])
    size_control=[c for c in typed_children(d,'ComboBox')if c.window_text()=='尺寸 :'and c.is_visible()]
    if len(size_control)!=1:raise ValueError('Unique font size selector required')
    native_size=ComboBoxWrapper(size_control[0].handle);options=native_size.item_texts()
    if str(wanted)not in options:raise ValueError('Requested font size unavailable')
    if native_size.selected_text()!=str(wanted):
     native_size.set_focus();send_keys('{HOME}'+('{DOWN}'*options.index(str(wanted)))+'{TAB}',pause=.01)
   actual=capture(d,[('ComboBox','字体 :'),('ComboBox','尺寸 :')])
   vals={r['name']:r['value']for r in actual}
   result[scope][sid]={'font':vals['字体 :'],'size':vals['尺寸 :']}
   if before is not None and (str(vals['字体 :']).split(' [')[0]!=font or int(vals['尺寸 :'])!=wanted):raise ValueError('Font adaptation readback mismatch')
 return result

def run(handle,q):
 req=q['scale_26_47'];page=int(req['page']);mode=req.get('mode','object')
 if 'keys'in req:
  for key in req['keys']:run(handle,{'scale_26_47':{'page':page,'key':key,'mode':mode}})
  if mode=='object':
   root,w=target(handle,page);save(root)
   p=load(DIR/f'page-{page}.json')
   for key in p['accepted']:
    path=DIR/f'{page}_{key}.json';record=load(path);record.update(saved=True,accepted_editor_pid=root.process_id());put(path,record)
   p['controls_saved']=list(p['accepted']);put(DIR/f'page-{page}.json',p)
  return
 if not 26<=page<=47:raise ValueError('Only requested pages26 through47')
 old.DIR=DIR
 root=Desktop(backend='win32').window(handle=handle).wrapper_object()
 if '组装机_MT8106iP.emtp'not in root.window_text():raise ValueError('Target only')
 if f'[{page} - 'not in root.window_text()or mode=='prepare':
  old.directory(Desktop(backend='uia').window(handle=handle).wrapper_object());open_page(handle,{'open_target_page':page})
 if mode=='save':save(root);return
 pp=DIR/f'page-{page}.json'
 if mode=='prepare':
  from eb_page_audit import run as audit
  try:audit(handle,{'target_page_audit':page})
  except ValueError as e:
   if 'Target object audit incomplete'not in str(e):raise
  root,w,d=old.settings(handle,page)
  try:rs=rows(d);bounds={r['name']:r['value']for r in rs if r['type']=='Edit'and r['name']in('宽度 :','高度 :')}
  finally:cancel(d)
  keys=[re.search(r'(?:^|\])\s*([A-Z]+_\d+)',v)[1]for v in load(ROOT/f'evidence/target-page{page}-audit.json')['objects']]
  if len(keys)!=len(set(keys)):raise ValueError('Duplicate keys')
  if not pp.exists():put(pp,{'page':page,'before':bounds,'after':dict(bounds,**{'高度 :':'391'}),'keys':keys,'objects_before':load(ROOT/f'evidence/target-page{page}-audit.json')['objects'],'accepted':[],'saved':False,'page_size_verified':False})
  return
 p=load(pp)
 if mode=='size':
  if set(p['accepted'])!=set(p['keys']):raise ValueError('Controls incomplete before page height change')
  root,w,d=old.settings(handle,page)
  try:fields(d,[{'type':'Edit','name':'高度 :','value':'391'}],commit_edits=True);confirm(d);d=None;save(root)
  finally:
   if d is not None:cancel(d)
  root,w,d=old.settings(handle,page)
  try:
   actual={r['name']:r['value']for r in capture(d,[('Edit','宽度 :'),('Edit','高度 :')])}
   if actual!=p['after']:raise ValueError('Page dimensions saved readback mismatch')
  finally:cancel(d)
  p.update(saved=True,page_size_verified=True);put(pp,p)
  for key in p['keys']:
   path=DIR/f'{page}_{key}.json';record=load(path);record['saved']=True;put(path,record)
  return
 key=req['key'];rp=DIR/f'{page}_{key}.json';record=load(rp)if rp.exists()else None
 if key not in p['keys']:raise ValueError('Observed object required')
 if mode=='object'and record and record.get('accepted')and(record.get('saved')or record.get('accepted_editor_pid')==root.process_id()):return
 root,w=target(handle,page)
 if record and record.get('dialog_handle') and ctypes.windll.user32.IsWindow(record['dialog_handle']) and ctypes.windll.user32.IsWindowVisible(record['dialog_handle']):
  d=Desktop(backend='uia').window(handle=record['dialog_handle']).wrapper_object()
  if d.process_id()!=root.process_id()or d.window_text()!=TITLES[key.split('_')[0]]:raise ValueError('Recovery property identity differs')
 elif req.get('resume_dialog'):
  d=Desktop(backend='uia').window(handle=int(req['resume_dialog'])).wrapper_object()
  if d.process_id()!=root.process_id()or d.window_text()!=TITLES[key.split('_')[0]]:raise ValueError('Observed resume dialog differs')
 else:
  try:d,_=properties(root,w,key,TITLES[key.split('_')[0]])
  except ValueError as error:
   if not str(error).startswith('Dialog not ready:'):raise
   from eb_object_ui import dialog
   d=dialog(root.process_id(),TITLES[key.split('_')[0]],attempts=120)
 try:
  if mode=='verify':
   actual=old.geo(d);fonts=font_read_write(d,record['scopes'])
   if actual!=record['after']or fonts!=record['fonts_after']:
    put(DIR/f'{page}_{key}-verify-failure.json',{'actual':actual,'fonts':fonts,'expected':record});raise ValueError('Saved representative geometry/font mismatch: '+key)
   record['saved_reopened_verified']=True;put(rp,record);return
  if record is None:
   scopes=old.font_scopes(page,key)
   before=old.geo(d);fonts=font_read_write(d,scopes)
   record={'page':page,'key':key,'before':before,'after':scale(before,p['before']),'fonts_before':fonts,'scopes':list(fonts),'accepted':False,'saved_reopened_verified':False,'stage':'baseline'};put(rp,record)
  record.update(stage='write_requested',dialog_handle=d.handle);put(rp,record)
  source=load(ROOT/f'evidence/source-object-properties/{page:03d}_{key}.json')
  if '图片'in source['tabs']:
   tab(d,'图片')
   toggles=[c for c in typed_children(d,'CheckBox')if c.window_text()=='调整对象尺寸为图片原尺寸'and c.is_visible()]
   if len(toggles)==1 and toggles[0].get_toggle_state():
    fields(d,[{'type':'CheckBox','name':'调整对象尺寸为图片原尺寸','value':0}]);record['picture_original_size_auto_fit_disabled']=True;put(rp,record)
  record['fonts_after']=font_read_write(d,record['scopes'],record['fonts_before'],391/int(p['before']['高度 :']))
  tab(d,'轮廓');fields(d,[{'type':'Edit','name':n,'value':v}for n,v in record['after'].items()],commit_edits=True)
  if old.geo(d)!=record['after']:raise ValueError('Geometry write readback mismatch')
  confirm(d);d=None
  for _ in range(20):
   if root.is_enabled():break
   time.sleep(.05)
  else:raise ValueError('Property confirmation still blocked')
  record.update(accepted=True,stage='confirmed',property_session_verified=True,accepted_editor_pid=root.process_id());put(rp,record)
  if key not in p['accepted']:p['accepted'].append(key)
  put(pp,p)
 finally:
  if d is not None:cancel(d)
