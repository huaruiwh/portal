"""Serial missing-switch rebuild, source family, native label RGB and safety."""
import json,re,sys
from eb_rebuild_page import ROOT,call

def run():
 lock=ROOT/'tools/batch.lock'
 with lock.open('x'):pass
 p=ROOT/'evidence/page16-missing-switch-workflow.json';r={'page':16,'completed':[],'ok':False}
 def persist():p.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
 try:
  call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
  def handle(title):
   cs=[w['handle'] for w in ws if w['class']=='EasyBuilderPro' and title in w['title']]
   if len(cs)!=1:raise ValueError('One exact project required')
   return cs[0]
  sh=handle('组装机2台15工位取消.cmtp');th=handle('组装机_MT8106iP.emtp')
  def ui(h,q):return call('uia',h,json.dumps(q,ensure_ascii=False))
  def audit():
   try:ui(th,{'target_page_audit':16})
   except RuntimeError as e:
    if 'Target object audit incomplete' not in str(e):raise
   a=json.loads((ROOT/'evidence/target-page16-audit.json').read_text(encoding='utf8'))
   if a['source_count']!=101 or a['unexpected']:raise ValueError('Unreviewed switch inventory')
   return a
  inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(v['observed_objects'] for v in inv['pages'] if v['id']==16)
  for n in range(11,18):
   key=f'TS_{n}';r.update(stage=key,phase='audit');persist();a=audit()
   if key not in a['missing']:
    if not (ROOT/f'evidence/target-016-TS{n}-built.json').exists():raise ValueError('Existing switch needs readback; no duplicate creation')
    r['completed'].append(key);persist();continue
   name=next(s for s in names if re.search(r'(?:^|\])\s*'+key+r'(?:\s|$)',s));cache=ROOT/f'evidence/source-object-properties/016_{key}.json';s=json.loads(cache.read_text(encoding='utf8'))
   if any(v['name']=='使用文字标签' and v.get('value')==1 for v in s['tabs']['标签']):
    if set(s.get('state_colors',{}).get('标签',{}))!={'0','1'}:
     r['phase']='source-label-rgb';persist();ui(sh,{'extract':{'page':16,'object':name,'only_color':True,'state_color_probe':{'tab':'标签','state':'0','labels':['颜色 :']}}})
   r['phase']='build';persist();ui(th,{'page':16,'bit_kind':'TS','build_bit_general':n})
   a=audit()
   if key in a['missing']:raise ValueError('Saved switch absent')
   r['completed'].append(key);r['target_count']=a['target_count'];persist()
  r.update(ok=True,phase='saved-and-directory-audited');persist();print(json.dumps(r,ensure_ascii=False))
 except Exception as e:r['error']=str(e);persist();raise
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':run()
