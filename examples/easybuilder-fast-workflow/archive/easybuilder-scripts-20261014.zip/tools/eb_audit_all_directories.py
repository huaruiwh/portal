"""Serial read-only directory count/address audit on all rebuilt source pages."""
import json,time
from eb_rebuild_page import ROOT,call

def run():
 lock=ROOT/'tools/batch.lock'
 with lock.open('x'):pass
 report={'ok':False,'completed':[],'functional_simulation_verified':False}
 path=ROOT/'evidence/all-pages-directory-audit.json'
 def persist():path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 try:
  call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
  targets=[w for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
  if len(targets)!=1:raise ValueError('One reconstruction target required')
  w=targets[0]
  if path.exists():
   previous=json.loads(path.read_text(encoding='utf8'))
   if previous.get('target_pid')==w['pid']:report['completed']=previous.get('completed',[])
  report['target_pid']=w['pid']
  pages=sorted(int(p.stem) for p in (ROOT/'evidence/source-pages-settings').glob('*.json'))
  report['pages']=pages
  for page in pages:
   if any(x['page']==page for x in report['completed']):continue
   report['stage']=page;persist()
   call('uia',w['handle'],json.dumps({'open_target_page':page}))
   try:call('uia',w['handle'],json.dumps({'target_page_audit':page}))
   except RuntimeError as e:
    if 'Target object audit incomplete' not in str(e):raise
   a=json.loads((ROOT/f'evidence/target-page{page}-audit.json').read_text(encoding='utf8'))
   report['completed'].append({'page':page,'objects':a['target_count'],'tree_verified':a['tree_verified'],'missing':a['missing'],'unexpected':a['unexpected'],'address_name_mismatch':a['address_name_mismatch']});persist()
   print(json.dumps(report['completed'][-1]),flush=True)
  report.update(ok=all(x['tree_verified'] for x in report['completed']),completed_inventory=True,object_count=sum(x['objects'] for x in report['completed']));persist()
 except Exception as e:report['error']=str(e);persist();raise
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':run()
