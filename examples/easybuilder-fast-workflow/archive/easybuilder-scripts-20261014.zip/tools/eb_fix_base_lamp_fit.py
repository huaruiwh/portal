"""Fit the observed two-line BL1 label into the 600px target canvas."""
import json
from eb_extract import ROOT,rows
from eb_object_ui import target,properties,save
from eb_native_form import tab,fields,confirm
from eb_layout import geometry

def run(handle,q):
 n=int(q['fix_base_lamp_fit'])
 if n not in (1,6,8) or q.get('page')!=11:raise ValueError('Reviewed BL1 fit only')
 root,w=target(handle,11);d,_=properties(root,w,f'BL_{n}','位状态指示灯/位状态切换开关的属性')
 tab(d,'标签')
 for state in ('0','1'):
  fields(d,[{'type':'ComboBox','name':'状态 :','value':state},{'type':'ComboBox','name':'尺寸 :','value':'12'}])
 source=json.loads((ROOT/f'evidence/source-object-properties/011_BL_{n}.json').read_text(encoding='utf8'))
 tab(d,'轮廓');expected=geometry(source);fields(d,[{'type':'Edit','name':k,'value':v} for k,v in expected.items()]);confirm(d);save(root)
 (ROOT/f'evidence/target-011-BL{n}-fit.json').write_text(json.dumps({'source_font':14,'target_font':12,'geometry':expected,'saved_requested':True,'reason':'native saved height49 exceeds bottom600; preserve two-line text and source-scaled bounds','reopened_verified':False},ensure_ascii=False,indent=2),encoding='utf8')
