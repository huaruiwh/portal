import json,time
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save
from eb_native_form import tab,fields,confirm,typed_children
from eb_page26_shapes import cancel
from eb_live_fields import capture
from eb_layout import geometry
from eb_page208 import write
from pywinauto.controls.win32_controls import ComboBoxWrapper

def run(handle,q):
    keys=q['page201_font_batch']
    allowed={f'TX_{n}'for n in range(13)}|{f'TS_{n}'for n in range(15)}
    if not keys or len(keys)>5 or not set(keys)<=allowed:raise ValueError('Reviewed201 font batch only')
    for key in keys:
        rp=ROOT/f'evidence/page201-font12-{key}.json'
        if rp.exists()and json.loads(rp.read_text(encoding='utf8')).get('verified'):continue
        s=json.loads((ROOT/f'evidence/source-object-properties/201_{key}.json').read_text(encoding='utf8'));g=geometry(s);is_button=key.startswith('TS_');scope='标签'if is_button else '文字/批注';title='位状态切换开关/位状态指示灯的属性'if is_button else '文字/批注的属性'
        root,w=target(handle,201);d,_=properties(root,w,key,title);before=[]
        try:
            tab(d,scope);states=('0','1')if is_button else (None,)
            boxes=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']if is_button else []
            if is_button and len(boxes)!=1:raise ValueError('Unique label state required')
            for state in states:
                if state is not None:ComboBoxWrapper(boxes[0].handle).select(state);time.sleep(.1)
                before.append(capture(d,[('ComboBox','字体 :'),('ComboBox','尺寸 :')]))
                fields(d,[{'type':'ComboBox','name':'字体 :','value':'微软正黑体 Light'},{'type':'ComboBox','name':'尺寸 :','value':'12'}])
            tab(d,'轮廓');fields(d,[{'type':'Edit','name':k,'value':v}for k,v in g.items()]);confirm(d);d=None;save(root)
        finally:
            if d is not None:cancel(d)
        write(rp,{'key':key,'saved':True,'verified':False,'before':before,'expected_size':12,'geometry':g})
        d,_=properties(root,w,key,title)
        try:
            tab(d,scope);boxes=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']if is_button else []
            for state in states:
                if state is not None:ComboBoxWrapper(boxes[0].handle).select(state);time.sleep(.1)
                textname=''if is_button else '内容';rows=capture(d,[('ComboBox','字体 :'),('ComboBox','尺寸 :'),('Edit',textname)])
                want=next(r['value']for r in (s['label_states'][state]if is_button else s['tabs'][scope])if r['type']=='Edit'and r['name']==textname)
                values={(r['type'],r['name']):str(r['value'])for r in rows}
                if values[('ComboBox','字体 :')]!='微软正黑体 Light'or values[('ComboBox','尺寸 :')]!='12'or values[('Edit',textname)]!=want:raise ValueError('Saved font/text readback mismatch '+key)
            tab(d,'轮廓');actual={r['name']:r['value']for r in capture(d,[('Edit',k)for k in g])}
            if actual!=g:raise ValueError('Font edit changed geometry')
        finally:cancel(d)
        r=json.loads(rp.read_text(encoding='utf8'));r.update(verified=True,original_text_preserved=True);write(rp,r)
        bp=ROOT/f'evidence/target-201-{key.replace("_","")}-built.json';r=json.loads(bp.read_text(encoding='utf8'));r.update(font_size=12,font='微软正黑体 Light',font_adjustment_report=rp.name);write(bp,r)
