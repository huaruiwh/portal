"""Read menu/string resources without executing or modifying the EXE."""
import ctypes, json, struct
from pathlib import Path
K=ctypes.WinDLL('kernel32',use_last_error=True)
K.LoadLibraryExW.argtypes=[ctypes.c_wchar_p,ctypes.c_void_p,ctypes.c_uint]
K.LoadLibraryExW.restype=ctypes.c_void_p
K.FindResourceW.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p]
K.FindResourceW.restype=ctypes.c_void_p
K.LoadResource.argtypes=[ctypes.c_void_p,ctypes.c_void_p]
K.LoadResource.restype=ctypes.c_void_p
K.LockResource.argtypes=[ctypes.c_void_p];K.LockResource.restype=ctypes.c_void_p
K.SizeofResource.argtypes=[ctypes.c_void_p,ctypes.c_void_p]
CB=ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_ssize_t)
K.EnumResourceNamesW.argtypes=[ctypes.c_void_p,ctypes.c_void_p,CB,ctypes.c_ssize_t]
rows=[]
for path in [Path(r'C:\Program Files\EBpro\EasyBuilder Pro.exe'),Path(r'C:\Program Files\EBpro\translation\EBProResource.dll')]:
 h=K.LoadLibraryExW(str(path),None,2)
 types=[]
 TCB=ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_ssize_t)
 @TCB
 def visit_type(module,typ,arg):
  types.append(typ if typ<=65535 else ctypes.wstring_at(typ));return True
 K.EnumResourceTypesW.argtypes=[ctypes.c_void_p,TCB,ctypes.c_ssize_t]
 K.EnumResourceTypesW(h,visit_type,0)
 print(str(path),types)
 for kind in [4,6]:
  @CB
  def visit(module,typ,name,arg):
   rid=name if name<=65535 else ctypes.wstring_at(name)
   res=K.FindResourceW(module,name,typ)
   data=ctypes.string_at(K.LockResource(K.LoadResource(module,res)),K.SizeofResource(module,res))
   if kind==6:
    pos=0
    for i in range(16):
     n=struct.unpack_from('<H',data,pos)[0];pos+=2
     value=data[pos:pos+n*2].decode('utf-16le');pos+=n*2
     if value:rows.append({'kind':'string','id':(int(rid)-1)*16+i,'text':value})
   else:
    rows.append({'kind':'menu','id':rid,'hex':data.hex(),'strings':data.decode('utf-16le',errors='replace')})
   return True
  K.EnumResourceNamesW(h,kind,visit,0)
root=Path(__file__).resolve().parent.parent
(root/'evidence'/'eb-resources.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
for row in rows:
 if row['kind']=='string' and any(s in row['text'] for s in ['宏指令','功能键','Function Key','Macro','新增窗口']):print(json.dumps(row,ensure_ascii=False))
