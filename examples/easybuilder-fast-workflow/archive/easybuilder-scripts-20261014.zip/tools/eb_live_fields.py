"""Read requested fields only; never reuse references after tab/dialog changes."""
from pywinauto import Desktop
import ctypes,time
from eb_native_messages import text,combo_text,msg
from eb_timing import timed

@timed
def capture(d,wants):
 for attempt in range(3):
  try:return _capture_once(d,wants)
  except Exception as e:
   if attempt==2 or not isinstance(e,(ValueError,TimeoutError)) and 'InvalidWindowHandle' not in type(e).__name__:raise
   if not ctypes.windll.user32.IsWindow(d.handle):raise
   from eb_live_inventory import clear
   clear(d.handle)
   time.sleep(.1)

def _capture_once(d,wants):
 wants=list(dict.fromkeys(wants));found={}
 if not ctypes.windll.user32.IsWindow(d.handle):raise ValueError('Live field dialog closed before capture')
 classes={'Edit':('Edit','RichEdit20W','RichEdit20A'),'ComboBox':('ComboBox',),'CheckBox':('Button',),'RadioButton':('Button',)}
 from eb_live_inventory import current
 for h,typ,name,u in current(d):
  key=(typ,name)
  if key in wants:found.setdefault(key,[]).append((h,None))
 missing={key for key in wants if key not in found}
 for typ in set(t for t,name in missing):
  from eb_live_inventory import virtual_fields
  for u in virtual_fields(d,typ):
   key=(typ,u.element_info.name)
   if key in missing and u.is_visible():found.setdefault(key,[]).append((None,u))
 out=[]
 for typ,name in wants:
  refs=found.get((typ,name),[])
  if not refs:raise ValueError('Required live field missing '+str((typ,name)))
  for h,u in refs:
   if h:
    value=text(h).rstrip('\r\n')if typ=='Edit'else combo_text(h)if typ=='ComboBox'else msg(h,240)
   else:value=u.get_value().rstrip('\r\n')if typ=='Edit'else u.selected_text()if typ=='ComboBox'else u.get_toggle_state()if typ=='CheckBox'else int(u.is_selected())
   out.append({'type':typ,'name':name,'value':value})
 return out
