import json
from eb_rebuild_page import ROOT
s=json.loads((ROOT/'evidence/source-object-properties/011_WP_1.json').read_text(encoding='utf8'));t=json.loads((ROOT/'evidence/target-object-properties/011_WP_1.json').read_text(encoding='utf8'))
a=[x.get('value') for rs in s['tabs'].values() for x in rs if x['type']=='RadioButton'];b=[x.get('value') for rs in t['tabs'].values() for x in rs if x['type']=='RadioButton']
report={'source_anchor_states':a,'target_anchor_states':b,'cached_anchor_verified':a==b and len(a)==5,'runtime_verified':False,'basis':'cached property readback; no macros executed','reference':'https://forum.weintekusa.com/t/how-to-use-an-indirect-window/841'}
(ROOT/'evidence/wp1-model-static-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print('anchors',report['cached_anchor_verified'])
