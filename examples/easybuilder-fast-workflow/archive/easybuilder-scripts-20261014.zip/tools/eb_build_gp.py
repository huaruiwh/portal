"""Finalize a separately imported source image as a new target GP object."""
import json
from pywinauto import Desktop
from eb_extract import ROOT,rows
from eb_object_ui import properties,save,dialog
from eb_native_form import tab,fields,confirm
from eb_layout import geometry

def run(handle,q):
    root=Desktop(backend='win32').window(handle=handle).wrapper_object()
    if '组装机_MT8106iP.emtp' not in root.window_text() or '[16 - ' not in root.window_text():raise ValueError('Known target page required')
    source=json.loads((ROOT/'evidence/source-object-properties/016_GP_0.json').read_text(encoding='utf8'))
    if q.get('prepare'):
        d=dialog(root.process_id(),'新增 图片')
        tab(d,'图片')
        texts=[c.window_text() for c in d.descendants(control_type='Text') if c.is_visible()]
        if not all(value in texts for value in ('151','38','235bytes','PNG')):raise ValueError('Imported source image metadata mismatch')
        checks=[c for c in source['tabs']['安全'] if c['type']=='CheckBox']
        if checks!=[{'type':'CheckBox','name':'使用寄存器状态/数值','class':'','value':0}]:raise ValueError('Only unconditional source image visibility reviewed')
        tab(d,'安全');fields(d,[c for c in source['tabs']['安全'] if c['type']!='CheckBox']);confirm(d)
        return
    w=Desktop(backend='uia').window(handle=handle).wrapper_object()
    d,name=properties(root,w,'GP_0','图片的属性')
    tab(d,'图片')
    fields(d,[r for r in source['tabs']['图片'] if r['type']=='CheckBox' and r['name']=='调整元件尺寸为图片原尺寸'])
    tab(d,'轮廓');shape=geometry(source)
    fields(d,[{'type':'Edit','name':key,'value':value} for key,value in shape.items()],commit_edits=True)
    readback=rows(d);confirm(d);save(root)
    report={'page':16,'target':name,'asset':'source/assets/page16-GP0.png','asset_bytes':235,'asset_dimensions':[151,38],'geometry':readback,'saved_requested':True,'rotation_flip_order_review_pending':True,'offline_simulation_verified':False}
    (ROOT/'evidence/target-016-GP0-built.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
