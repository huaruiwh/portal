"""User-authorized 214 -> 223 copy; change captions and bindings only."""
import json,re,time,shutil
from pywinauto import Desktop
from pywinauto.keyboard import send_keys
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save
from eb_native_form import tab,typed_children,commit_text,confirm,fields
from eb_native_messages import text,put
from eb_page26_shapes import cancel
from eb_speed_benchmark import cached_edits,native_edit_read
from eb_copy_200_style_object import TITLES,native_clipboard_data,restore_native_clipboard

def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
def names(page):
 d=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
 return next(x['observed_objects'] for x in d['pages'] if x['id']==page)
def keyname(n):return re.search(r'(?:^|\])\s*([A-Z]+_\d+)',n)[1]
def shape(d):
 tab(d,'轮廓');time.sleep(.2)
 names=('X :',' Y :') if d.window_text()=='文字/批注的属性' else ('X :',' Y :',' 宽度 :','高度 :')
 return native_edit_read(cached_edits(d,names))
def captions(d,kind):
 tab(d,'文字/批注' if kind=='TX' else '标签')
 def read():
  es=[c for c in typed_children(d,'Edit') if c.element_info.class_name in ('RichEdit20W','RichEdit20A')]
  if len(es)!=1:raise ValueError('Unique caption editor required')
  return es[0],text(es[0].handle).rstrip('\r\n')
 if kind=='TX':return {'text':read()[1]}
 cs=[c for c in typed_children(d,'ComboBox') if c.element_info.name=='状态 :']
 if len(cs)!=1:raise ValueError('Unique caption state required')
 combo=ComboBoxWrapper(cs[0].handle);out={}
 for state in combo.item_texts():
  combo.select(state);time.sleep(.2);out[state]=read()[1]
 return out
def addresses(d):
 tab(d,'一般属性')
 es=[c for c in typed_children(d,'Edit') if c.element_info.name=='Static']
 return [text(c.handle).rstrip('\r\n') for c in es],es
def run(handle,q):
 mode=q['page223'];root=Desktop(backend='win32').window(handle=handle).wrapper_object()
 if mode=='cancel_target':
  if '组装机_MT8106iP.emtp' not in root.window_text():raise ValueError('Target only')
  popups=[w for w in Desktop(backend='win32').windows(process=root.process_id()) if w.is_visible() and w.class_name().startswith('Qt5QWindowPopup')]
  if len(popups)==1:popups[0].set_focus();send_keys('{ESC}',pause=.01);time.sleep(.15)
  ds=[w for w in Desktop(backend='win32').windows(process=root.process_id()) if w.is_visible() and w.window_text() in TITLES.values()]
  if len(ds)!=1:raise ValueError('Unique known property dialog required')
  cancel(Desktop(backend='uia').window(handle=ds[0].handle).wrapper_object());return
 if mode=='source':
  if '.cmtp' not in root.window_text() or '[223 - ' not in root.window_text():raise ValueError('Actual source223 required')
  w=Desktop(backend='uia').window(handle=handle).wrapper_object()
  for key in q['keys']:
   p=ROOT/f'evidence/page223-source-{key}.json'
   if p.exists():continue
   root.set_focus();time.sleep(.15)
   kind=key.split('_')[0];d,_=properties(root,w,key,TITLES[kind])
   try:
    out={'key':key,'source_readonly':True,'captions':captions(d,kind)}
    if kind!='TX':out['addresses']=addresses(d)[0]
    write(p,out)
   finally:cancel(d)
  return
 if mode=='clone':
  p=ROOT/'evidence/page223-whole-page-copy.json'
  if p.exists():raise ValueError('Copy journal exists; inspect, never repeat paste')
  from eb_open_page import run as op
  from eb_create_page import run as create
  from eb_page_audit import run as audit
  if set(map(keyname,names(214)))!=set(map(keyname,names(223))):raise ValueError('Source key sets differ')
  op(handle,{'open_target_page':214});root,w=target(handle,214)
  backup=ROOT/'backup/214复制223前_20261013.emtp';backup.parent.mkdir(exist_ok=True)
  if not backup.exists():shutil.copy2(ROOT/'output/组装机_MT8106iP.emtp',backup)
  if not (ROOT/'evidence/target-page-223-created.json').exists():create(handle,{'create_target_page':223})
  op(handle,{'open_target_page':223})
  try:audit(handle,{'target_page_audit':223})
  except ValueError as e:
   if str(e)!='Target object audit incomplete':raise
  a=json.loads((ROOT/'evidence/target-page223-audit.json').read_text(encoding='utf8'))
  if a['target_count']!=0:raise ValueError('Empty destination required')
  op(handle,{'open_target_page':214});root,w=target(handle,214)
  root.click_input(coords=(963,367));send_keys('^a^c',pause=.04);time.sleep(.2)
  data=native_clipboard_data()
  op(handle,{'open_target_page':223});root,w=target(handle,223);restore_native_clipboard(data)
  root.click_input(coords=(963,367));write(p,{'stage':'paste_requested','template':214,'page':223})
  send_keys('^v',pause=.04);time.sleep(.3);send_keys('{ESC}',pause=.02);save(root)
  try:audit(handle,{'target_page_audit':223})
  except ValueError as e:
   if str(e)!='Target object audit incomplete':raise
  a=json.loads((ROOT/'evidence/target-page223-audit.json').read_text(encoding='utf8'))
  if a['target_count']!=48 or a['missing'] or a['unexpected']:raise ValueError('Whole copy keys/count differ')
  write(p,{'stage':'saved-bindings-pending','template':214,'page':223,'count':48})
  return
 if mode!='rewrite':raise ValueError('Unknown page223 action')
 key=q['key'];kind=key.split('_')[0];p=ROOT/f'evidence/target-223-{key}-rewritten.json'
 if p.exists() and json.loads(p.read_text(encoding='utf8')).get('saved_reopened_verified'):return
 source=json.loads((ROOT/f'evidence/page223-source-{key}.json').read_text(encoding='utf8'))
 root,w=target(handle,223);d,_=properties(root,w,key,TITLES[kind]);bounds=shape(d);changed=False
 if kind!='TX':
  actual,es=addresses(d);wanted=source['addresses']
  if len(actual)!=len(wanted):raise ValueError('Copied address schema differs')
  for e,old,new in zip(es,actual,wanted):
   if old!=new:put(e.handle,new);changed=True
 old=captions(d,kind);want=source['captions']
 if set(old)!=set(want):raise ValueError('Copied caption state schema differs')
 if old!=want:
  if kind=='TX':
   es=[c for c in typed_children(d,'Edit') if c.element_info.class_name=='RichEdit20W'];commit_text(d,es[0].element_info.name,want['text'])
  else:
   cs=[c for c in typed_children(d,'ComboBox') if c.element_info.name=='状态 :'];combo=ComboBoxWrapper(cs[0].handle)
   for state,v in want.items():
    if old[state]==v:continue
    combo.select(state);time.sleep(.2);commit_text(d,'',v)
  changed=True
 if shape(d)!=bounds:fields(d,[{'type':'Edit','name':n,'value':v} for n,v in bounds.items()])
 if changed:
  confirm(d);save(root);d,_=properties(root,w,key,TITLES[kind])
 try:
  if kind!='TX' and addresses(d)[0]!=source['addresses']:raise ValueError('Saved copied address mismatch')
  norm=lambda x:{k:v.replace('\r\n','\n').replace('\r','\n') for k,v in x.items()}
  if norm(captions(d,kind))!=norm(want):raise ValueError('Saved copied caption mismatch')
  if shape(d)!=bounds:raise ValueError('Copied dimensions changed')
 finally:cancel(d)
 write(p,{'page':223,'template':214,'key':key,'changed':changed,'addresses':source.get('addresses'),'captions':want,'geometry':bounds,'geometry_unchanged':True,'style_and_safety_inherited':True,'saved_reopened_verified':True,'runtime_verified':False})
