"""Rewrite reviewed203 differences on the existing native201 copy; no new controls."""
import json,time
from collections import defaultdict
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save
from eb_native_form import tab,fields,confirm,commit_text,typed_children
from eb_page26_shapes import cancel
from eb_layout import geometry
from eb_copy_200_style_object import TITLES
from eb_live_fields import capture
from eb_original_style_existing import verify_fields
from pywinauto.controls.win32_controls import ComboBoxWrapper
TITLES=dict(TITLES,ND='数值的属性',OL='项目选单的属性')

def groups(rs):
 d=defaultdict(list)
 for r in rs:
  if r['type']in ('Edit','ComboBox','CheckBox','RadioButton') and 'value'in r:d[(r['type'],r['name'])].append(r)
 return d

def plan(s,b):
 edits=[];unknown=[]
 scopes=[(t,rs,b['tabs'].get(t,[]),None)for t,rs in s['tabs'].items()if t not in ('轮廓','标签')]
 scopes += [('标签',rs,b.get('label_states',{}).get(st,[]),st)for st,rs in s.get('label_states',{}).items()]
 if not s.get('label_states')and '标签'in s['tabs']:scopes.append(('标签',s['tabs']['标签'],b['tabs'].get('标签',[]),None))
 for scope,rs,base,state in scopes:
  g,old=groups(rs),groups(base)
  for ident,want in g.items():
   if [r['value']for r in want]==[r['value']for r in old.get(ident,[])]:continue
   typ,name=ident
   if scope in ('文字/批注','标签','字体')and name in ('字体 :','尺寸 :','状态 :'):continue
   if typ=='Edit' and (name=='Static'and scope in ('一般属性','项目选单','源数据')or name in ('内容','')and scope in ('文字/批注','标签')):
    edits.append({'scope':scope,'state':state,'rows':want})
   else:unknown.append({'scope':scope,'state':state,'identity':ident,'before':[r['value']for r in old.get(ident,[])],'after':[r['value']for r in want]})
 return edits,unknown

def run(handle,q):
 keys=q['page203_rewrite']
 if not keys or len(keys)>5:raise ValueError('203 reviewed batch up to5')
 mapping=json.loads((ROOT/'evidence/page203-copy-mapping.json').read_text(encoding='utf8'))
 if not mapping['stack_order_and_identity_verified']:raise ValueError('Copy identity required')
 for key in keys:
  rp=ROOT/f'evidence/target-203-{key}-rewritten.json'
  if rp.exists()and json.loads(rp.read_text(encoding='utf8')).get('saved_reopened_verified'):continue
  s=json.loads((ROOT/f'evidence/source-object-properties/203_{key}.json').read_text(encoding='utf8'));b=json.loads((ROOT/f'evidence/source-object-properties/201_{key}.json').read_text(encoding='utf8'));edits,unknown=plan(s,b)
  if unknown:
   (ROOT/f'evidence/page203-unreviewed-{key}.json').write_text(json.dumps(unknown,ensure_ascii=False,indent=2),encoding='utf8');raise ValueError('203 semantic differences need adapter: '+key)
  g=geometry(s);mapped=mapping['mapping'][key];kind=key.split('_')[0]
  if not edits and g==geometry(b):
   rp.write_text(json.dumps({'page':203,'key':key,'target':mapped,'saved_reopened_verified':True,'verification_method':'verified201 template plus native whole-copy stack identity and exact203 cached semantics/geometry','changed':False,'runtime_verified':False},ensure_ascii=False,indent=2),encoding='utf8');continue
  root,w=target(handle,203);d,_=properties(root,w,mapped,TITLES[kind])
  try:
   for e in edits:
    tab(d,e['scope'])
    if e['state']is not None:
     cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']
     if len(cs)!=1:raise ValueError('Unique203 state required')
     ComboBoxWrapper(cs[0].handle).select(e['state']);time.sleep(.08)
    rows=e['rows']
    if e['scope']in ('文字/批注','标签'):commit_text(d,rows[0]['name'],rows[0]['value'])
    else:fields(d,rows,commit_edits=True)
   tab(d,'轮廓');fields(d,[{'type':'Edit','name':n,'value':v}for n,v in g.items()],commit_edits=True)
   confirm(d);d=None;save(root)
  finally:
   if d is not None:cancel(d)
  report={'page':203,'key':key,'target':mapped,'saved':True,'saved_reopened_verified':False,'edits':edits,'geometry':g,'font_and_style_inherited_from_verified201':True,'safety_source_equal_to201':True,'runtime_verified':False}
  rp.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
  d,_=properties(root,w,mapped,TITLES[kind])
  try:
   for e in edits:
    tab(d,e['scope'])
    if e['state']is not None:
     cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :'];ComboBoxWrapper(cs[0].handle).select(e['state']);time.sleep(.08)
    actual=capture(d,[(r['type'],r['name'])for r in e['rows']]);verify_fields(actual,e['rows'])
   tab(d,'轮廓');actual={r['name']:r['value']for r in capture(d,[('Edit',n)for n in g])}
   if actual!=g:raise ValueError('203 saved geometry differs')
  finally:cancel(d)
  report['saved_reopened_verified']=True;report['original_text_preserved']=True;rp.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
