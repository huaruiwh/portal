import json,py_compile
from eb_rebuild_page import ROOT
def load(n):return json.loads((ROOT/'evidence'/n).read_text(encoding='utf-8-sig'))
a=load('target-page201-audit.json')
assert a['target_count']==31 and len(a['missing'])==21 and not a['unexpected']and not a['address_name_mismatch']
assert all(load(f'target-201-TS{n}-built.json')['saved_reopened_verified']for n in range(15))
size=(ROOT/'output/组装机_MT8106iP.emtp').stat().st_size
for name in ('eb_page201_batch.py','eb_page201_buttons.py','eb_label_commit.py','continue_page201_button_batches.py'):
    py_compile.compile(str(ROOT/'tools'/name),doraise=True)
b1=load('page201-batch-9-10.json');b3=load('page201-batch-13-14.json')
text=f'''

### 2026-10-11：连续批次完成201页剩余六个按钮

用户授权后续采用连续批次。本轮实际读取并缓存原TS_9至TS_14，原件只读取消；TS_9安全/图库/颜色严格匹配已verified TS_2，TS_10匹配TS_3，TS_11/12/14匹配Flat3蓝色TS_5，TS_13匹配红色停止TS_6。沿用原地址、两态文字、原位置适配尺寸，字体微软正黑体 Light13号；图形、颜色、安全仅在缓存与已verified模板完全相同时继承，其余变化仍读回。每件phase与built独立保存，批次前后目录审计。

实际完成：TS_9..TS_14六按钮saved_reopened_verified=true，201页TS_0..TS_14共15按钮全部保存重开核对；全页31/52件，剩21，额外0、地址/名称差异0。工程{size}字节。剩余原件key原文：{json.dumps(a['missing'],ensure_ascii=False)}。没有新编译或整页运行验收，未PLC/HMI下载或执行宏。

完整成功批次9/10控制器{b1['controller_wall_seconds']:.9f}秒；13/14控制器{b3['controller_wall_seconds']:.9f}秒。11/12曾恢复，不能用恢复耗时当首次整批速度；初批11/12/14的失败报告保留evidence/page201-batch-11-12-14.json，TS_12单件首次epoch及完成时间留在built；本轮含原件读取、故障排查及恢复，不声称六件都固定平均30秒或几秒。

问题、原因、解决：
- 源extract误附build_bit_general:0走旧builder，报KeyError: 'page'，尚未修改工程；源读取请求移除该字段，目标完整批次才保留300秒路由。
- TS_12报ValueError: Committed label state mismatch: 0；未保存弹窗检查取消、按pasted阶段重开而不重贴。eb_label_commit最终读回加入最多20次×0.03秒条件等待，失败返回期望/实值。恢复通过，两态文字保存重开核对正确；此证据不能单独证明所有原始不一致都由等待引起。
- 取消未保存TS_12后仍有模板地址，目录报Batch initial directory mismatch。仅本批已记录pasted/saved-unverified的key允许临时地址差异，完成后目录仍必须全部吻合；已完成的整批跳过，不重写历史计时。
- 为图库复用计划跳过TS_13先做TS_14，实际EasyBuilder使用空缺TS_13，报Unique target object required: TS_14。经实际目录30件、TS_13存在、TS_14缺失及无13/14 built核对，仅删除该未保存试件；保存后目录29件、缺13/14、无差异，记录target-201-TS14-gap-history.json。随后严格按13→14重新连续复制，成功31件。关键规律：同类编号不能跳空缺；批次须按原控件编号顺序，模板身份可分别变化，不能为省一次复制换来错编号。

脚本：tools/cache_page201_remaining_buttons.py（缓存源）；tools/continue_page201_button_batches.py（生产批次）；tools/eb_page201_batch.py（限定9/10、11/12、13/14，严格模板guard与目录）；tools/eb_page201_buttons.py（0..14）；tools/eb_label_commit.py（状态读回条件等待）。恢复命令原文：
`& "C:\\Users\\wei'ke\\.cache\\codex-runtimes\\codex-primary-runtime\\dependencies\\python\\python.exe" tools/continue_page201_button_batches.py`
需管理员worker可用且无其它控制器，batch.lock独占；请求{{"page201_batch":[13,14],"build_bit_general":0}}。已verified跳过，不重贴、不把重复执行时间作新基准。语法检查通过，六个按钮报告与最终真实目录通过；无属性弹窗或运行controller，batch.lock已清除。下一步连续处理TX_0..TX_12及SP/DW/OL/SW/FK：先读取缺失源字段、核对真实入口和模板，再按编号连续批次；其它页面未在本轮修改。已保存按钮禁止重复新增。
'''
for p in (ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md'):
    with p.open('a',encoding='utf8')as f:f.write(text)
cp=ROOT/'evidence/resume-checkpoint.json';d=json.loads(cp.read_text(encoding='utf-8-sig'))
d.update(status='page201-all-fifteen-buttons-saved',page201_objects=31,page201_remaining_objects=21,project_bytes=size,target_project_bytes=size,batch_running=False,current_stage='TS_0..TS_14 saved reopened verified; directory 31/52 clean',next_action='Continue TX_0..TX_12 and SP/DW/OL/SW/FK in sequential numbered batches after source cache and template/entry checks. No duplicate NE/ND/TS. Preserve per-item saved verification and batch directory audit.')
cp.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
(ROOT/'evidence/page201-buttons-preview-workflow.json').write_text(json.dumps({'page':201,'verified':[f'TS_{n}'for n in range(15)],'status':'all-buttons-saved','remaining':21,'total_objects':31},ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'count':31,'remaining':21,'bytes':size,'docs_updated':2},ensure_ascii=False))
