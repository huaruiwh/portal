"""Serial exact source/target background RGB synchronization and reopen verification."""
import json,sys
from eb_rebuild_page import ROOT,call
def run(pages,verify=False):
    lock=ROOT/'tools'/'batch.lock'
    with lock.open('x'):pass
    report={'pages':pages,'completed':[],'ok':False,'phase':'verify after project reopen' if verify else 'source RGB and target save'}
    report_path=ROOT/'evidence'/('background-reopen-progress.json' if verify else 'background-sync-progress.json')
    def save():report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    try:
        call('snapshot');ws=json.loads((ROOT/'evidence'/'windows.json').read_text(encoding='utf8'))
        def resolve(name):
            hs=[w['handle'] for w in ws if w['class']=='EasyBuilderPro' and name in w['title']]
            if len(hs)!=1:raise ValueError('Unique project required')
            return hs[0]
        source=resolve('组装机2台15工位取消.cmtp');target=resolve('组装机_MT8106iP.emtp')
        def ui(h,q):call('uia',h,json.dumps(q,ensure_ascii=False))
        for page in pages:
            report['stage']=page;save()
            path=ROOT/'evidence'/'source-pages-settings'/f'{page:03d}.json'
            src=json.loads(path.read_text(encoding='utf8')) if path.exists() else {}
            legacy_source=sum(c['type']=='Text' and c['name']=='颜色 :' for c in src.get('controls',[]))==2 and 'background_color_occurrence' not in src
            if 'background_rgb' not in src or legacy_source:
                if verify:raise ValueError('Source RGB missing in verification pass')
                ui(source,{'page_settings':page,'color_probe':True});src=json.loads(path.read_text(encoding='utf8'))
            color_path=ROOT/'evidence'/f'target-page-{page:03d}-color.json'
            if verify:
                saved=json.loads(color_path.read_text(encoding='utf8'))
                actual_pid=next(w['pid'] for w in ws if w['handle']==target)
                if saved.get('target_process_id')==actual_pid:raise ValueError('Project must be normally closed and reopened before disk verification')
                ui(target,{'page_settings':page,'target_readonly':True,'color_probe':True})
                dst=json.loads((ROOT/'evidence'/'target-pages-settings'/f'{page:03d}.json').read_text(encoding='utf8'))
                if dst['background_rgb']!=src['background_rgb']:raise ValueError('Reopened background RGB mismatch')
                saved.update(project_reopened_verified=True,reopened_target_process_id=actual_pid)
                color_path.write_text(json.dumps(saved,ensure_ascii=False),encoding='utf8')
            elif not color_path.exists() or json.loads(color_path.read_text(encoding='utf8')).get('label')!='背景颜色 :' or json.loads(color_path.read_text(encoding='utf8')).get('rgb')!=src['background_rgb']:ui(target,{'page_settings':page,'apply_source_background':True})
            report['completed'].append({'page':page,'rgb':src['background_rgb']});save();print(json.dumps({'page':page,'rgb':src['background_rgb'],'verify':verify}),flush=True)
        report['ok']=True;save();print(json.dumps({'ok':True,'pages':len(report['completed']),'phase':report['phase']}))
    except Exception as e:
        report['error']=str(e);save();print(json.dumps({'ok':False,'stage':report.get('stage'),'report':str(report_path)}));raise
    finally:lock.unlink(missing_ok=True)
if __name__=='__main__':run([int(s) for s in sys.argv[1:] if s!='--verify'],verify='--verify' in sys.argv)
