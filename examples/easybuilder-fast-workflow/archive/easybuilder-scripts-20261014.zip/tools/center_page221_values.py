import json,os
from eb_rebuild_page import ROOT,call
r=ROOT;lock=r/'tools/batch.lock'
with lock.open('x')as f:json.dump({'pid':os.getpid(),'task':'center221'},f)
p=r/'evidence/page221-numeric-centering-workflow.json'
d=json.loads(p.read_text(encoding='utf8'))if p.exists()else {'verified':[],'finished':False}
try:
 plan=json.loads((r/'evidence/page221-numeric-centering-plan.json').read_text(encoding='utf8'))
 call('snapshot');ws=json.loads((r/'evidence/windows.json').read_text(encoding='utf8'));h=next(w['handle']for w in ws if '组装机_MT8106iP.emtp'in w['title'])
 for it in plan['items']:
  if it['key']in d['verified']:continue
  d['current']=it['key'];p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
  for op in ('move','verify'):call('uia',h,json.dumps({'move_objects':{'page':221,'op':op,'items':[it]}}))
  d['verified'].append(it['key']);p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
 call('uia',h,json.dumps({'compile_target':True,'entry_via_local_ocr':True}))
 d['finished']=True
except Exception as e:d['error']=str(e);raise
finally:
 p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8');lock.unlink(missing_ok=True)
 for name in ('README.md','docs/MT8106iP重建-实现记录.md'):
  with (r/name).open('a',encoding='utf8')as f:f.write('\n\n### 2026-10-12 221页数值居中实际结果\n'+json.dumps(d,ensure_ascii=False)+'\n恢复：python tools/center_page221_values.py；真实编译见latest-project-compile.json，运行与外观验收仍待。\n')
