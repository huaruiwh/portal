"""Exclusive continuous batches, fixed baselines, per-page saves and final compile."""
import json,time,os,re
from pathlib import Path
from eb_rebuild_page import ROOT,call
DIR=ROOT/'evidence/scale-pages26-47-height391'
def load(p):return json.loads(p.read_text(encoding='utf8'))
def put(p,a):
 tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(a,ensure_ascii=False,indent=2),encoding='utf8');tmp.replace(p)
def main():
 lock=ROOT/'tools/batch.lock'
 with lock.open('x',encoding='utf8')as f:f.write(json.dumps({'pid':os.getpid(),'task':'scale pages26..47 toheight391'}))
 wp=DIR/'workflow.json';workflow=load(wp)
 def persist():put(wp,workflow)
 def ui(h,q,whole=False):return call('uia',h,json.dumps(dict(scale_26_47=q,**({'page_settings':q['page']}if whole else {'build_bit_general':0}))))
 try:
  call('snapshot');windows=load(ROOT/'evidence/windows.json');targets=[w for w in windows if w['class']=='EasyBuilderPro'and '组装机_MT8106iP.emtp'in w['title']]
  if len(targets)!=1:raise ValueError('Unique actual target project required')
  h=targets[0]['handle'];workflow['target_handle']=h;persist()
  for page in workflow['scope']:
   pp=DIR/f'page-{page}.json';workflow['active_page']=page;persist()
   if not pp.exists():
    try:ui(h,{'page':page,'mode':'prepare'},True)
    except Exception as e:
     if page==46 and 'Exact prefix did not identify a defined page'in str(e):
      workflow['pages'][str(page)]={'undefined_empty_page':True,'controls':0,'not_created':True};persist();continue
     raise
   p=load(pp)
   if p.get('page_size_verified')and p.get('bounds_verified')and p.get('directory_count_verified')and p.get('representative_reopened'):continue
   pending=[k for k in p['keys']if k not in p['accepted']]
   for start in range(0,len(pending),3):
    batch=pending[start:start+3];workflow['current_batch']=batch;persist()
    started=time.monotonic()
    for attempt in range(3):
     try:ui(h,{'page':page,'keys':batch});break
     except Exception as e:
      workflow['last_error']={'page':page,'keys':batch,'attempt':attempt+1,'error':str(e)};persist()
      if attempt==2:raise
      time.sleep(.2)
    with (DIR/'timing.jsonl').open('a',encoding='utf8')as f:f.write(json.dumps({'page':page,'keys':batch,'seconds':round(time.monotonic()-started,3)})+'\n')
    p=load(pp);workflow['pages'][str(page)]={'accepted':len(p['accepted']),'total':len(p['keys']),'height_before':p['before']['高度 :'],'saved':False};persist()
   ui(h,{'page':page,'mode':'size'},True)
   p=load(pp);representatives={}
   for key in p['keys']:representatives.setdefault(key.split('_')[0],key)
   for key in representatives.values():ui(h,{'page':page,'key':key,'mode':'verify'})
   from collections import Counter
   circle_like=[];violations=[]
   for key in p['keys']:
    rec=load(DIR/f'{page}_{key}.json');g=rec['after']
    if rec['before'].get(' 宽度 :')==rec['before'].get('高度 :'):
     if g.get(' 宽度 :')!=g.get('高度 :'):raise ValueError('Square/circle aspect not preserved')
     circle_like.append(key)
    if int(g['X :'])<0 or int(g[' Y :'])<0 or int(g['X :'])+int(g.get(' 宽度 :','0'))>int(p['after']['宽度 :'])or int(g[' Y :'])+int(g.get('高度 :','0'))>391:violations.append(key)
   if violations:raise ValueError('Scaled objects outside391 page: '+repr(violations))
   try:call('uia',h,json.dumps({'target_page_audit':page}))
   except Exception as error:
    if 'Target object audit incomplete'not in str(error):raise
   audit=load(ROOT/f'evidence/target-page{page}-audit.json');actual=[re.search(r'(?:^|\])\s*([A-Z]+_\d+)',v)[1]for v in audit['objects']]
   if len(actual)!=len(p['keys'])or set(actual)!=set(p['keys']):raise ValueError('Final page directory differs')
   if sorted(audit['objects'])!=sorted(p['objects_before']):raise ValueError('Object literal/address directory changed during layout adaptation')
   p['unchanged_literal_address_directory']=True
   p['previous_source_mismatch']=audit.get('address_name_mismatch',[])
   p.update(layout_verified=True,representative_reopened=list(representatives.values()),bounds_verified=True,circle_square_bounds_verified=circle_like,directory_count_verified=True);put(pp,p)
   status={'accepted':len(p['accepted']),'total':len(p['keys']),'height':391,'saved':True,'representative_reopened':list(representatives.values())};workflow['pages'][str(page)]=status;persist()
   text='\n2026-10-13 高度391适配：页'+str(page)+'，'+str(len(p['keys']))+'控件，会话字段/轮廓读回、每类代表重开、目录及边界通过；宽度'+p['after']['宽度 :']+'，固定原高'+p['before']['高度 :']+'；当前工程'+str((ROOT/'output/组装机_MT8106iP.emtp').stat().st_size)+'字节。\n'
   for doc in [ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md']:
    with doc.open('a',encoding='utf8')as f:f.write(text)
   print(json.dumps({'page':page,**status}),flush=True)
  call('uia',h,json.dumps({'compile_target':True,'entry_via_local_ocr':True}))
  workflow.update(compile=load(ROOT/'evidence/latest-project-compile.json'),finished=True,runtime_verified=False);workflow.pop('error',None);persist()
  call('uia',h,json.dumps({'open_target_page':26}))
  print('requested existing pages completed and compiled',flush=True)
 except Exception as e:
  workflow.update(error=str(e),finished=False);persist();raise
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':main()
