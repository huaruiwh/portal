"""Read saved page17 properties after a real project restart; no edits."""
import argparse,json,re
from eb_rebuild_page import ROOT,call
from eb_layout import geometry


def values(rows,skip=(),keep=None,rename=None):
    rename=rename or {};result=[]
    for row in rows:
        if 'value' not in row or (row['type'],row['name']) in skip or (keep is not None and row['name'] not in keep):continue
        value=row['value']
        if row['name']=='字体 :' and isinstance(value,str):value=value.split(' [')[0]
        result.append((row['type'],rename.get(row['name'],row['name']),value))
    return result


def run(previous_pid):
    call('snapshot')
    wins=json.loads((ROOT/'evidence'/'windows.json').read_text(encoding='utf8'))
    targets=[w for w in wins if '组装机_MT8106iP.emtp' in w['title'] and w['class']=='EasyBuilderPro']
    if len(targets)!=1 or targets[0]['pid']==previous_pid:raise ValueError('A genuinely reopened target process is required')
    target=targets[0]
    inventory=json.loads((ROOT/'evidence'/'source-pages-inventory.json').read_text(encoding='utf8'))
    names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==17)
    selected={'SP_0','AB_0','DC_0','WP_0','WP_1','TX_0','TS_0','SW_12','BL_0'}
    report={'page':17,'previous_pid':previous_pid,'reopened_pid':target['pid'],'checks':[],
            'ok':False,'offline_simulation_verified':False,'model_differences_pending':True}
    path=ROOT/'evidence'/'page-17-complex-roundtrip-audit.json'
    if path.exists():
        previous=json.loads(path.read_text(encoding='utf8'))
        if previous.get('reopened_pid')==target['pid'] and previous.get('previous_pid')==previous_pid:
            report['checks']=previous['checks']
    for name in names:
        key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)[1]
        if key not in selected:continue
        if any(check['object']==key for check in report['checks']):continue
        request={'extract':{'page':17,'object':name,'target_readonly':True}}
        if key in ('SP_0','AB_0'):
            request['extract'].update(colors=['图案颜色 :','颜色 :'] if key=='SP_0' else ['外框颜色 :','背景颜色 :'],color_tab='图片' if key=='SP_0' else '报警')
        call('uia',target['handle'],json.dumps(request,ensure_ascii=False))
        source=json.loads((ROOT/'evidence'/'source-object-properties'/('017_'+key+'.json')).read_text(encoding='utf8'))
        saved=json.loads((ROOT/'evidence'/'target-object-properties'/('017_'+key+'.json')).read_text(encoding='utf8'))
        expected=geometry(source)
        actual={r['name']:r['value'] for r in saved['tabs']['轮廓'] if r['type']=='Edit' and r['name'] in expected}
        checks={'object':key,'geometry_verified':expected==actual}
        if key.startswith(('SP','AB')):checks['colors_verified']=source['colors']==saved['colors']
        if key=='SP_0':checks['picture_verified']=values(source['tabs']['图片'])==values(saved['tabs']['图片'])
        elif key=='AB_0':
            keep={'显示 Down','显示的类别范围','透明'}
            original=[r for r in source['tabs']['报警'] if r['name'] in keep and r.get('value')!='跑马灯']
            checks['alarm_verified']=values(original)==values(saved['tabs']['报警'],keep=keep)
            checks['sort_verified']=values(source['tabs']['排序'],skip=(('ComboBox','日期 :'),))==values(saved['tabs']['排序'],skip=(('ComboBox','日期 :'),))
            checks['font_size_verified']=values(source['tabs']['字体'],keep={'尺寸 :','斜体'})==values(saved['tabs']['字体'],keep={'尺寸 :','斜体'})
        elif key.startswith('WP'):
            keep={'描述 :','设备 :','Static',' Down','使用窗口编号偏移量'}
            checks['address_verified']=values(source['tabs']['一般属性'],keep=keep)==values(saved['tabs']['一般属性'],keep=keep)
        elif key=='TX_0':
            checks['text_verified']=values(source['tabs']['文字/批注'],skip=(('CheckBox','使用字符串表'),),rename={'多行 :':'水平 :'})==values(saved['tabs']['文字/批注'])
        else:
            checks['general_verified']=values(source['tabs']['一般属性'])==values(saved['tabs']['一般属性'])
            if key in ('TS_0','SW_12'):
                original=source.get('label_states') or {'0':source['tabs']['标签'],'1':source['tabs']['标签']}
                checks['labels_verified']=all(values(original[state],skip=(('ComboBox','状态 :'),))==values(saved['label_states'][state],skip=(('ComboBox','状态 :'),)) for state in ('0','1'))
        report['checks'].append(checks)
        path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    report['ok']=len(report['checks'])==len(selected) and all(all(value for field,value in check.items() if field.endswith('_verified')) for check in report['checks'])
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({'ok':report['ok'],'objects':len(report['checks']),'reopened_pid':target['pid']},ensure_ascii=False))
    if not report['ok']:raise ValueError('Saved mixed-page properties differ; inspect local report')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--previous-pid',type=int,required=True)
    run(parser.parse_args().previous_pid)
