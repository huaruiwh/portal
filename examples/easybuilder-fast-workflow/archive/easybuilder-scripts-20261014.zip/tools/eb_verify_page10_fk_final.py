import json,re
from eb_rebuild_page import ROOT,call
p=ROOT/'evidence/page10-fk-final-check.json'
r={'ok':False,'checks':[]}
lock=ROOT/'tools/batch.lock'
with lock.open('x'):pass
try:
 call('snapshot')
 ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
 w=next(w for w in ws if w['class']=='EasyBuilderPro' and '_MT8106iP_' in w['title'])
 r['target_pid']=w['pid'];r['target_handle']=w['handle']
 call('uia',w['handle'],json.dumps({'open_target_page':10}))
 inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
 names=next(v['observed_objects'] for v in inv['pages'] if v['id']==10)
 for i in range(6):
  key='FK_'+str(i);name=next(n for n in names if re.search(r'(?:^|\])\s*'+re.escape(key)+r'(?:\s|$)',n))
  r['stage']=key;p.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
  call('uia',w['handle'],json.dumps({'extract':{'page':10,'object':name,'target_readonly':True}}))
  s=json.loads((ROOT/f'evidence/source-object-properties/010_{key}.json').read_text(encoding='utf8'))
  t=json.loads((ROOT/f'evidence/target-object-properties/010_{key}.json').read_text(encoding='utf8'))
  tab=next(k for k in s['tabs'] if k==next(iter(s['tabs'])))
  def vals(v):return [(x['type'],x['name'],x['value']) for x in v if 'value'in x]
  a=vals(s['tabs'][tab]);b=vals(t['tabs'].get(tab,[]))
  c={'key':key,'general_equal':a==b,'source_general':a,'target_general':b}
  r['checks'].append(c);p.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
  print(key,a==b,flush=True)
 r['ok']=all(c['general_equal'] for c in r['checks']);r['stage']='readback complete'
 p.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
except Exception as e:
 r['error']=str(e);p.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8');raise
finally:lock.unlink(missing_ok=True)
