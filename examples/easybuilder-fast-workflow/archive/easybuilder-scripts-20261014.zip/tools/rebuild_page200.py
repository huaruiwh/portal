"""Serial page 200 source cache and controlled reconstruction checkpoint."""
import json,re,os,traceback
from datetime import datetime
from eb_rebuild_page import ROOT,call
P=ROOT/'evidence/page-200-workflow.json'
def ui(h,q):return call('uia',h,json.dumps(q,ensure_ascii=False))
def main():
 lock=ROOT/'tools/batch.lock'
 with lock.open('x',encoding='utf8') as f:json.dump({'pid':os.getpid(),'task':'page200'},f)
 d={'date':datetime.now().isoformat(timespec='seconds'),'status':'extracting','completed':[],'pid':os.getpid()}
 try:
  inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(x['observed_objects'] for x in inv['pages'] if x['id']==200);d['total']=len(names)
  for name in names:
   key=re.search(r'(?:^|\])\s*([A-Z]{2}_\d+)',name)[1];d['stage']=key;P.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
   cache=ROOT/f'evidence/source-object-properties/200_{key}.json'
   old=json.loads(cache.read_text(encoding='utf8')) if cache.exists() else {}
   kind=key.split('_')[0]
   missing_colors=(kind in ('SP','TX','NE','SW') and not old.get('colors')) or (kind in ('TS','BL') and not old.get('state_colors')) or (kind=='DW' and not old.get('rectangle_colors'))
   if not cache.exists() or missing_colors or kind in ('SP','BL','NE') and not old.get('vector_identity'):ui(133522,{'extract':{'page':200,'object':name}})
   d['completed'].append(key)
  d['status']='source-cache-complete'
 except Exception:d['status']='needs-review';d['error']=traceback.format_exc();print(d['error'],flush=True)
 finally:
  P.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8');lock.unlink(missing_ok=True);print(json.dumps({'status':d['status'],'completed':len(d['completed']),'stage':d.get('stage')},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
