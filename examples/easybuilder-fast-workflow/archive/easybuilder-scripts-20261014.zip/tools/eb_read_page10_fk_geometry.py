import json
from pywinauto import Desktop
from eb_object_ui import target,properties
from eb_native_form import tab
from eb_native_messages import msg
from eb_extract import ROOT,rows

def run(handle,q):
 key=q['verify_page10_fk_geometry'];p=ROOT/f'evidence/page10-{key}-fit.json';r=json.loads(p.read_text(encoding='utf8'))
 root,w=target(handle,10)
 if q.get('resume_dialog'):
  ds=[d for d in Desktop(backend='win32').windows() if d.process_id()==root.process_id() and d.class_name()=='#32770' and d.is_visible()]
  if len(ds)!=1:raise ValueError('One existing property dialog required')
  d=Desktop(backend='uia').window(handle=ds[0].handle).wrapper_object()
 else:
  source=json.loads((ROOT/'evidence/source-object-properties/010_FK_0.json').read_text(encoding='utf8'))
  d,_=properties(root,w,key,source['dialog_title'])
 old=json.loads((ROOT/f'evidence/target-object-properties/010_{key}.json').read_text(encoding='utf8'))
 shape=next(k for k,v in old['tabs'].items() if any(x['name']=='X :' for x in v))
 tab(d,shape);actual={v['name']:v.get('value') for v in rows(d) if v['type']=='Edit' and v['name'] in r['expected']}
 r['property_reopened_verified']=actual==r['expected'];r['property_reopened_readback']=actual;p.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
 cancel=[c for c in d.descendants(control_type='Button') if c.window_text()==chr(21462)+chr(28040) and c.is_visible()]
 if len(cancel)!=1:raise ValueError('One cancel required')
 msg(cancel[0].handle,245)
 if not r['property_reopened_verified']:raise ValueError('Geometry mismatch '+key)
