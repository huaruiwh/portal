"""Extract visible source object properties. Source is never saved or edited."""
import json,time,re,ctypes
from pathlib import Path
from pywinauto import Desktop,mouse
from pywinauto.keyboard import send_keys
from pywinauto.controls.win32_controls import ComboBoxWrapper,EditWrapper
ROOT=Path(__file__).resolve().parent.parent

from eb_timing import timed

@timed
def rows(dialog):
    from eb_source_rows_profile import fast,remember
    cached=fast(dialog)
    if cached is not None:return cached
    result=[]
    for c in dialog.descendants(cache_enable=True):
        e=c.element_info
        if e.control_type not in ('Edit','ComboBox','CheckBox','RadioButton','Text','Button'):continue
        if not (ctypes.windll.user32.IsWindowVisible(e.handle) if e.handle else c.is_visible()):continue
        r={'type':e.control_type,'name':e.name,'class':e.class_name,'_native_handle':int(e.handle)if e.handle else None}
        try:
            if e.control_type=='Edit':
                if e.handle and e.class_name=='Edit':
                    from eb_native_messages import text
                    r['value']=text(e.handle).rstrip('\r\n')
                else:r['value']=c.get_value().rstrip('\r\n')
            elif e.control_type=='ComboBox':
                if e.class_name=='ComboBox' and e.handle:
                    from eb_native_messages import combo_text
                    r['value']=combo_text(e.handle)
                else:r['value']=c.selected_text()
            elif e.control_type in ('CheckBox','RadioButton'):
                if e.handle:
                    from eb_native_messages import msg
                    r['value']=msg(e.handle,240)
                else:r['value']=c.get_toggle_state() if e.control_type=='CheckBox' else c.is_selected()
        except Exception as error:r['read_error']=type(error).__name__
        result.append(r)
    remember(dialog,result)
    for row in result:row.pop('_native_handle',None)
    return result

def run(handle,request):
    started=time.monotonic()
    w=Desktop(backend='uia').window(handle=handle).wrapper_object()
    q=request['extract'];page_id=q['page'];name=q['object']
    target=bool(q.get('target_readonly')) and '组装机_MT8106iP.emtp' in w.window_text()
    if '组装机2台15工位取消.cmtp' not in w.window_text() and not target:raise ValueError('Original source or explicit read-only target only')
    inv=json.loads((ROOT/'evidence'/'source-pages-inventory.json').read_text(encoding='utf8'))
    record=next(p for p in inv['pages'] if p['id']==page_id)
    if name not in record['observed_objects']:
        key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)
        hp=ROOT/'evidence/page16-alarm-header-adaptation.json'
        if not(target and page_id==16 and key and key[1] in {'DW_5','TX_31','TX_32'} and hp.exists() and json.loads(hp.read_text(encoding='utf8')).get('ok')):raise ValueError('Object must be observed in source inventory or verified model adaptation')
    if not q.get('resume'):
        wr=w.rectangle()
        native_root=Desktop(backend='win32').window(handle=handle).wrapper_object()
        tabs=[c for c in w.descendants(control_type='TabItem') if c.is_visible() and c.window_text()=='目录树']
        if len(tabs)==1:
            native_root.set_focus();tabs[0].click_input();time.sleep(.15)
        from eb_directory import scope
        directory=scope(w)
        fields=[c for c in directory.descendants(control_type='Edit') if c.is_visible()]
        for retry in range(2):
            if len(fields)==1:break
            native_root.set_focus();time.sleep(.2)
            w=Desktop(backend='uia').window(handle=handle).wrapper_object()
            tabs=[c for c in w.descendants(control_type='TabItem')if c.is_visible()and c.window_text()=='目录树']
            if len(tabs)==1:tabs[0].click_input();time.sleep(.2)
            directory=scope(w);fields=[c for c in directory.descendants(control_type='Edit')if c.is_visible()]
        if len(fields)!=1:raise ValueError('Unique source page filter required: '+repr([(c.element_info.name,str(c.rectangle()))for c in fields]))
        field=fields[0];prefix=str(page_id)+' :';attempts=[]
        native_root.set_focus()
        # Qt directory updates after each key can lose the rest of a typed
        # prefix. Prefer its supported atomic ValuePattern, with exact readback.
        if field.get_value()!=prefix:
            try:field.set_edit_text(prefix)
            except Exception as error:
                if type(error).__name__ not in ('COMError','NoPatternInterfaceError'):raise
            time.sleep(.15)
        for attempt in range(3):
            if field.get_value()==prefix:break
            native_root.set_focus()
            if ctypes.windll.user32.GetForegroundWindow()!=native_root.handle:
                attempts.append({'attempt':attempt,'foreground':False});time.sleep(.15);continue
            field.click_input();field.set_focus()
            if not bool(field.element_info.element.CurrentHasKeyboardFocus):
                attempts.append({'attempt':attempt,'focused':False});time.sleep(.15);continue
            current=field.get_value()
            if len(current)>64:raise ValueError('Unexpected long directory filter; do not clear')
            send_keys('{END}',pause=.05)
            send_keys('{BACKSPACE '+str(len(current)+1)+'}',pause=.05)
            # Do not send Delete: an unexpected focus change must not delete canvas objects.
            time.sleep(.1)
            if field.get_value():
                attempts.append({'attempt':attempt,'focused':True,'clear_failed':field.get_value()});continue
            send_keys(prefix,with_spaces=True,pause=.03);time.sleep(.15)
            actual=field.get_value();attempts.append({'attempt':attempt,'focused':True,'actual':actual})
            if actual==prefix:break
        else:
            (ROOT/'evidence/extraction-filter-failure.json').write_text(json.dumps({'page':page_id,'expected':prefix,'attempts':attempts},ensure_ascii=False,indent=2),encoding='utf8')
            raise ValueError('Exact source/target extraction filter readback mismatch')
        native_trees=[c for c in native_root.descendants(class_name='SysTreeView32') if c.is_visible() and c.rectangle().right<wr.left+500]
        trees=[Desktop(backend='uia').window(handle=native_trees[0].handle).wrapper_object()] if len(native_trees)==1 else [c for c in directory.descendants(control_type='Tree') if c.is_visible()]
        if len(trees)!=1:raise ValueError('Source directory tree must be unique')
        tree=trees[0]
        nodes=tree.descendants(control_type='TreeItem')
        headers=[c for c in nodes if re.match(r'^'+str(page_id)+r'\s*:',c.window_text())]
        if not headers:
            mouse.scroll(coords=((tree.rectangle().left+tree.rectangle().right)//2,(tree.rectangle().top+tree.rectangle().bottom)//2),wheel_dist=60);time.sleep(.1)
            headers=[c for c in tree.descendants(control_type='TreeItem') if re.match(r'^'+str(page_id)+r'\s*:',c.window_text())]
        if len(headers)!=1:
            for _ in range(4):
                box=tree.rectangle();mouse.scroll(coords=((box.left+box.right)//2,(box.top+box.bottom)//2),wheel_dist=80);time.sleep(.25)
                headers=[c for c in tree.descendants(control_type='TreeItem') if re.match(r'^'+str(page_id)+r'\s*:',c.window_text())]
                if len(headers)==1:break
        if len(headers)!=1:raise ValueError('Unique page header required after restoring tree viewport')
        page=headers[0]
        if f'[{page_id} - ' not in w.window_text():
            page.double_click_input(coords=(40,page.rectangle().height()//2));time.sleep(.15)
        def find():
            if target:
                key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)
                if not key:raise ValueError('Observed object key required')
                pattern=r'(?:^|\])\s*'+re.escape(key[1])+r'(?:\s|$)'
                matches=[c for c in tree.descendants(control_type='TreeItem') if re.search(pattern,c.window_text())]
            else:matches=[c for c in tree.descendants(control_type='TreeItem') if c.window_text()==name]
            return matches[0] if len(matches)==1 else None
        obj=find()
        if not obj:
            try:
                if page.get_expand_state()==0:page.expand();time.sleep(.1)
            except Exception:
                exposed=any(re.search(r'(?:^|\])\s*[A-Z]+_\d+',c.window_text()) for c in tree.descendants(control_type='TreeItem'))
                if not exposed:
                    r=page.rectangle();mouse.click(coords=(r.left-14,(r.top+r.bottom)//2));time.sleep(.1)
            for _ in range(12):
                obj=find()
                if obj:break
                mouse.scroll(coords=((tree.rectangle().left+tree.rectangle().right)//2,(tree.rectangle().top+tree.rectangle().bottom)//2),wheel_dist=-8);time.sleep(.1)
        if not obj:raise ValueError('Source object not currently exposed')
        for _ in range(8):
            r=obj.rectangle()
            viewport=tree.rectangle()
            if 0<r.height()<60 and max(wr.top+240,viewport.top)<=r.top and r.bottom<=min(wr.bottom-50,viewport.bottom):break
            mouse.scroll(coords=((tree.rectangle().left+tree.rectangle().right)//2,(tree.rectangle().top+tree.rectangle().bottom)//2),wheel_dist=-8);time.sleep(.1);obj=find()
            if not obj:raise ValueError('Object disappeared while scrolling')
        else:raise ValueError('Cannot bring object into source tree viewport')
        # Re-resolve virtual Qt row immediately before absolute pointer input.
        obj=find();r=obj.rectangle();tr=tree.rectangle()
        if not (0<r.height()<60 and tr.left<=r.left<r.right<=tr.right and max(tr.top,wr.top+240)<=r.top<r.bottom<=min(tr.bottom,wr.bottom-50)):
            raise ValueError('Fresh source object row outside safe tree viewport: '+str((r,tr,wr)))
        native_root.set_focus()
        mouse.double_click(coords=(r.left+min(40,r.width()-2),(r.top+r.bottom)//2));time.sleep(.2)
    dialogs=[d for d in Desktop(backend='win32').windows() if d.process_id()==w.process_id() and d.class_name()=='#32770' and d.window_text().endswith('属性') and d.is_visible()]
    for _ in range(12):
        if len(dialogs)==1:break
        if _==6 and not dialogs and not q.get('resume'):
            obj=find()
            if obj:
                fresh=obj.rectangle();box=tree.rectangle()
                if 0<fresh.height()<60 and box.left<=fresh.left<fresh.right<=box.right and max(box.top,wr.top+240)<=fresh.top<fresh.bottom<=min(box.bottom,wr.bottom-50):
                    mouse.double_click(coords=(fresh.left+min(40,fresh.width()-2),(fresh.top+fresh.bottom)//2))
        time.sleep(.15)
        dialogs=[d for d in Desktop(backend='win32').windows() if d.process_id()==w.process_id() and d.class_name()=='#32770' and d.window_text().endswith('属性') and d.is_visible()]
    if len(dialogs)!=1:raise ValueError('Expected one source properties dialog')
    d=Desktop(backend='uia').window(handle=dialogs[0].handle).wrapper_object()
    result={'page':page_id,'object':name,'dialog_title':d.window_text(),'tabs':{},'read_only_target':target}
    try:
        if q.get('only_color'):
            key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)
            previous=ROOT/'evidence'/('target-object-properties' if target else 'source-object-properties')/f'{page_id:03d}_{key.group(1)}.json'
            result=json.loads(previous.read_text(encoding='utf8'))
        tab_items=[c for c in d.descendants(control_type='TabItem') if c.is_visible()]
        tab_names=[c.window_text()for c in tab_items]
        native_tabs=Desktop(backend='win32').window(handle=d.handle).descendants(class_name='SysTabControl32')
        native_tab=None
        if len(native_tabs)==1:
            from pywinauto.controls.common_controls import TabControlWrapper
            candidate=TabControlWrapper(native_tabs[0].handle)
            if candidate.tab_count()==len(tab_items):native_tab=candidate
        for tab_name in ([] if q.get('only_color') else dict.fromkeys(tab_names)):
            matches=[c for c in tab_items if c.window_text()==tab_name]
            if len(matches)!=1:continue
            index=tab_names.index(tab_name)
            if native_tab is not None:
                from eb_native_messages import msg
                if msg(native_tab.handle,0x130B)!=index:native_tab.select(index)
                if msg(native_tab.handle,0x130B)!=index:raise ValueError('Source tab native selection differs')
            else:matches[0].select()
            time.sleep(.06)
            result['tabs'][tab_name]=rows(d)
            if tab_name=='标签':
                states=[c for c in d.descendants(control_type='ComboBox') if c.element_info.name=='状态 :' and c.is_visible()]
                if len(states)==1 and states[0].element_info.class_name=='ComboBox':
                    native=ComboBoxWrapper(states[0].element_info.handle)
                    values=native.item_texts()
                    if len(values)<=16:
                        result['label_states']={}
                        for value in values:
                            native.select(value);time.sleep(.04)
                            result['label_states'][value]=rows(d)
        reuse_numeric=False
        if page_id==202 and not target and re.search(r'(?:^|\])\s*NE_(?:[1-9]\d*)',name):
            bp=ROOT/'evidence/source-object-properties/202_NE_0.json'
            if bp.exists():
                base=json.loads(bp.read_text(encoding='utf8'))
                sig=lambda rs:[(r['type'],r['name'],r['value']) for r in rs if 'value' in r]
                if all(sig(result['tabs'][tabname])==sig(base['tabs'][tabname]) for tabname in ['格式','数值输入','安全','图片','字体']) and base.get('colors') and base.get('vector_identity'):
                    result['colors']=base['colors'];result['vector_identity']=base['vector_identity'];result['appearance_inherited_from']='202_NE_0 after equal native tab values';reuse_numeric=True
        if page_id in (200,201,202,204,206,210,212,218,221,224,235) and not target and not reuse_numeric and not q.get('basic_only'):
            object_kind=re.search(r'(?:^|\])\s*([A-Z]+)_\d+',name)[1]
            if object_kind=='TX':q.update(colors=[label for label in ('颜色 :','背景颜色 :') if any(r['type']=='Text' and r['name']==label for r in result['tabs']['文字/批注'])],color_tab='文字/批注')
            elif object_kind in ('SP','NE','ND'):q.update(colors=['图案颜色 :','颜色 :'],color_tab='图片')
            elif object_kind=='SW':q.update(colors=['颜色 :'],color_tab='图片')
            elif object_kind in ('TS','BL'):
                labels=['颜色 :'] if object_kind=='TS' else ['颜色 :','图案颜色 :']
                q['state_color_probe']={'tab':'图片','state':'0','labels':labels}
        if q.get('page201_complex_colors'):
            observed_key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)[1]
            if page_id!=201 or not re.fullmatch(r'(OL_[01]|SW_0|FK_0)',observed_key):raise ValueError('Reviewed201 complex color cache only')
            from eb_native_form import tab
            from eb_color_picker import probe
            if name.startswith('OL_'):
                tab(d,'项目选单');result['menu_colors']={'项目选单':{label:probe(d,label)for label in ('背景颜色 :','选择颜色 :')}}
                tab(d,'标签');result['menu_colors']['标签']={'颜色 :':probe(d,'颜色 :')}
            else:
                result['state_colors']={}
                for scope in ('图片','标签'):
                    tab(d,scope);boxes=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name=='状态 :'and c.is_visible()and c.element_info.class_name=='ComboBox']
                    if len(boxes)!=1:raise ValueError('Unique complex color state required')
                    box=ComboBoxWrapper(boxes[0].handle)
                    for state in box.item_texts():
                        box.select(state);result['state_colors'].setdefault(scope,{})[state]={'颜色 :':probe(d,'颜色 :')}
        if q.get('table_detail_probe'):
            if page_id not in (200,201,202,204,206,210,212,218,221,224,235) or not re.fullmatch(r'TB_[01]',name):raise ValueError('Only reviewed page200 table')
            from eb_native_form import tab
            from eb_color_picker import probe
            tab(d,'一般属性')
            cs=[c for c in d.descendants(control_type='ComboBox') if c.window_text()=='样式 :' and c.is_visible()]
            if len(cs)!=2:raise ValueError('Two original table line styles required')
            result['line_style_indices']=[ComboBoxWrapper(c.handle).selected_index() for c in cs]
            result['table_line_colors']=[probe(d,'颜色 :',i) for i in (0,2)]
        if q.get('colors'):
            from eb_native_form import tab
            from eb_color_picker import probe
            if any(label not in ('图案颜色 :','颜色 :','外框颜色 :','背景颜色 :','文字颜色 : ','背景颜色 : ') for label in q['colors']):raise ValueError('Unreviewed color selector')
            color_tab=q.get('color_tab','图片')
            if color_tab not in ('图片','报警','文字/批注',' 形状','形状','标题','标签'):raise ValueError('Unreviewed color property tab')
            tab(d,color_tab);result.setdefault('colors',{}).update({label:probe(d,label) for label in q['colors']})
        if q.get('state_color_probe'):
            key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)[1]
            if page_id not in (16,200,201,202,204,206,210,212,218,221,224,235) or not (re.fullmatch(r'(?:BL|TS)_\d+',key) or page_id in (200,201,202,204,206,210,212,218,221,224,235) and key=='FK_0'):raise ValueError('Reviewed page16 bit appearance only')
            qcolor=q['state_color_probe'];color_tab=qcolor['tab'];state=qcolor['state'];labels=qcolor['labels']
            if color_tab not in ('图片','标签') or state not in ('0','1') or any(x not in ('颜色 :','图案颜色 :') for x in labels):raise ValueError('Unreviewed bit appearance fields')
            from eb_native_form import tab
            from eb_color_picker import probe
            jobs=[(color_tab,state,labels)]
            if key.startswith('TS_') and color_tab=='标签' and state=='0':
                jobs=[('标签',v,labels) for v in ('0','1')]
            if target and key.startswith('BL_') and color_tab=='图片' and state=='0':
                jobs=[('图片',v,labels) for v in ('0','1')]
                if qcolor.get('collect_labels') and any(r['name']=='使用文字标签' and r.get('value')==1 for r in result['tabs']['标签']):jobs.extend(('标签',v,['颜色 :']) for v in ('0','1'))
            # Cache both states during the same read-only properties visit.
            # The existing controller detects the cache and skips later visits.
            if not target and key.startswith('BL_') and int(key[3:]) in range(33) and color_tab=='图片' and state=='0' and set(labels)=={'颜色 :','图案颜色 :'}:
                jobs=[('图片',v,labels) for v in ('0','1')]
                if any(r['name']=='使用文字标签' and r.get('value')==1 for r in result['tabs']['标签']):jobs.extend(('标签',v,['颜色 :']) for v in ('0','1'))
            if page_id in (200,201,202,204,206,210,212,218,221,224,235):
                jobs=[('图片',v,qcolor['labels']) for v in ('0','1')]
                if any(r['name']=='使用文字标签' and r.get('value')==1 for r in result['tabs']['标签']):jobs.extend(('标签',v,['颜色 :']) for v in ('0','1'))
            for color_tab,state,labels in jobs:
                tab(d,color_tab)
                if color_tab=='图片' and state=='0':
                    metadata=[]
                    for item in d.descendants(control_type='MenuItem'):
                        if not item.is_visible():continue
                        box=item.rectangle();entry={'name':item.element_info.name,'class':item.element_info.class_name,'rect':[box.left,box.top,box.right,box.bottom]}
                        try:entry['legacy_value']=item.iface_legacy_iaccessible.CurrentValue;entry['legacy_state']=item.iface_legacy_iaccessible.CurrentState
                        except Exception:pass
                        metadata.append(entry)
                    result['picture_menu_metadata']=metadata
                states=[c for c in d.descendants(control_type='ComboBox') if c.element_info.name=='状态 :' and c.is_visible() and c.element_info.class_name=='ComboBox']
                if len(states)!=1:raise ValueError('Unique bit appearance state required')
                ComboBoxWrapper(states[0].handle).select(state)
                result.setdefault('state_colors',{}).setdefault(color_tab,{}).setdefault(state,{}).update({label:probe(d,label) for label in labels})
                if qcolor.get('all_occurrences'):
                    for label in labels:
                        cs=[c for c in d.descendants(control_type='Text') if c.is_visible() and c.element_info.name==label]
                        for occurrence in range(1,len(cs)):
                            result['state_colors'][color_tab][state][label+'#'+str(occurrence)]=probe(d,label,occurrence)
        if q.get('appearance_probe'):
            from eb_native_form import tab
            from eb_color_picker import probe
            if page_id!=103:raise ValueError('Reviewed background appearance only')
            result['appearance_colors']={}
            for color_tab in ('图片','标签'):
                if color_tab not in result['tabs']:continue
                tab(d,color_tab)
                visible=[c for c in d.descendants(control_type='Text') if c.window_text()=='颜色 :' and c.is_visible()]
                if len(visible)!=1:
                    picture_names=[r['name'] for r in result['tabs'][color_tab] if r['type']=='Text']
                    if color_tab=='图片' and 'picture51' in picture_names and 'BMP' in picture_names:
                        result['custom_bitmap_pending']={'name':'picture51','format':'BMP','size':'120x60'}
                        continue
                    raise ValueError('One appearance color label required: '+color_tab)
                states=[c for c in d.descendants(control_type='ComboBox') if c.element_info.name=='状态 :' and c.is_visible() and c.element_info.class_name=='ComboBox']
                if len(states)>1:raise ValueError('One state selector required')
                native=ComboBoxWrapper(states[0].handle) if states else None
                values=native.item_texts() if native else ['common']
                if len(values)>2:raise ValueError('Reviewed two-state appearance only')
                result['appearance_colors'][color_tab]={}
                for value in values:
                    if native:native.select(value)
                    result['appearance_colors'][color_tab][value]=probe(d,'颜色 :')
        if page_id in (200,201,202,204,206,210,212,218,221,224,235) and name.startswith('DW_0'):q['rectangle_probe']=True
        if q.get('shape_menu_probe'):
            if page_id!=204 or not name.startswith('DW_0'):raise ValueError('Reviewed rectangle menu probe only')
            from eb_native_form import tab
            tab(d,' 形状');result['shape_menu_metadata']=[]
            for c in d.descendants(control_type='MenuItem'):
                if not c.is_visible():continue
                v={'name':c.element_info.name}
                try:v['value']=c.iface_legacy_iaccessible.CurrentValue;v['legacy_name']=c.iface_legacy_iaccessible.CurrentName
                except Exception:v['value']=None
                result['shape_menu_metadata'].append(v)
        if q.get('rectangle_probe'):
            if page_id not in (10,103,200,201,202,204,206,210,212,218,221,224,235) or not(name.startswith('DW_0')or page_id==201 and name.startswith('DW_1')):raise ValueError('Reviewed background rectangle only')
            from eb_native_form import tab
            from eb_color_picker import probe
            tab(d,' 形状')
            unfilled=any(r['name']=='填充' and r.get('value')==0 for r in result['tabs'].get(' 形状',[]))
            result['rectangle_colors']={'border':probe(d,'颜色 :',0)} if unfilled else {'fill':probe(d,'颜色 :',0),'border':probe(d,'颜色 :',1)}
        if page_id in (200,201,202,204,206,210,212,218,221,224,235) and not target and not reuse_numeric and not q.get('basic_only') and (re.search(r'(?:^|\])\s*(SP|BL|NE|ND|FK)_\d+',name) or page_id==201 and name.startswith(('TS_','SW_'))):
            from eb_native_form import tab,typed_children
            from eb_object_ui import dialog
            from eb_page26_shapes import cancel as cancel_gallery
            tab(d,'图片')
            buttons=[c for c in typed_children(d,'Button') if c.element_info.name=='图库...' and c.is_visible() and c.is_enabled()]
            is_fk=bool(re.search(r'(?:^|\])\s*FK_0',name)) or page_id==201 and name.startswith(('TS_','SW_'))
            if len(buttons)!=1:raise ValueError('Unique source vector gallery required')
            buttons[0].click_input();g=dialog(w.process_id(),'图片管理' if is_fk else '向量图管理');Desktop(backend='win32').window(handle=g.handle).set_focus();time.sleep(.15)
            try:
                observed=g.descendants(cache_enable=True);gr=g.rectangle();shot=g.capture_as_image();selected=[]
                families=[c.element_info.name for c in observed if c.element_info.control_type=='MenuItem' and c.element_info.name and c.is_visible() and c.rectangle().top<gr.top+150]
                for c in observed:
                    if c.element_info.control_type!='Group' or not c.element_info.name.isdigit() or not c.is_visible():continue
                    cr=c.rectangle();left=max(0,cr.left-gr.left);top=max(0,cr.top-gr.top);right=min(shot.width,cr.right-gr.left)
                    strip=shot.crop((left,top,right,min(top+22,shot.height))).convert('RGB')
                    if sum(1 for red,green,blue in strip.getdata() if red>230 and green>230 and blue<70)>200:selected.append(c.element_info.name)
                if len(selected)!=1 or len(families)!=1:raise ValueError('Source vector identity must be uniquely observed')
                result['picture_identity' if is_fk else 'vector_identity']={'family':families[0],'index':selected[0],'method':'local selected-thumbnail yellow header; no image transmitted'}
            finally:cancel_gallery(g)
        path=ROOT/'evidence'/('target-object-properties' if target else 'source-object-properties')
        path.mkdir(exist_ok=True)
        key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)
        filename=f'{page_id:03d}_{key.group(1) if key else "object"}.json'
        result['elapsed_seconds']=round(time.monotonic()-started,3)
        if not q.get('resume'):
            result['native_filter_used']=False
            result['directory_scope_filter_used']=True
            result['native_tree_used']=len(native_trees)==1
            result['directory_scope_used']=directory!=w
        (path/filename).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
        (ROOT/'evidence'/'extract-result.json').write_text(json.dumps({'page':page_id,'object':name,'file':filename,'tabs':len(result['tabs']),'elapsed_seconds':round(time.monotonic()-started,3)},ensure_ascii=False),encoding='utf8')
    finally:
        cancel=[] if q.get('keep_open') or not ctypes.windll.user32.IsWindowVisible(d.handle) else [c for c in d.descendants(control_type='Button') if c.window_text()=='取消' and c.is_visible()]
        if len(cancel)==1:
            from pywinauto.controls.win32_controls import ButtonWrapper
            ButtonWrapper(cancel[0].element_info.handle).send_message_timeout(0x00F5,timeout=2)
        elif not q.get('keep_open') and ctypes.windll.user32.IsWindowVisible(d.handle):raise ValueError('Source cancel button not uniquely exposed')





