"""Create a blank numbered target page from source settings, never copy objects."""
import json,re,time,ctypes
from pathlib import Path
from pywinauto import Desktop
from pywinauto.controls.win32_controls import EditWrapper,ComboBoxWrapper,ButtonWrapper
from pywinauto.keyboard import send_keys
from eb_extract import rows
ROOT=Path(__file__).resolve().parent.parent

def run(handle,request):
    page=int(request['create_target_page'])
    if page not in (*range(19,46),47,48,49,103,200,201,202,203,204,205,206,208,210,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,228,229,230,231,232,235,236,237,302,313):raise ValueError('Reviewed blank page range only')
    native=Desktop(backend='win32').window(handle=handle).wrapper_object()
    if '组装机_MT8106iP.emtp' not in native.window_text():raise ValueError('Target only')
    pid=native.process_id()
    settings=json.loads((ROOT/'evidence'/'source-pages-settings'/f'{page:03d}.json').read_text(encoding='utf8'))
    src=settings['controls']
    # User selected page 31 as the background reference for subsequent flow pages.
    reference=json.loads((ROOT/'evidence'/'source-pages-settings'/'031.json').read_text(encoding='utf8')) if 32<=page<=49 else settings
    background=reference['background_rgb']
    values={c['name']:c['value'] for c in src if c['type']=='Edit' and c['name'] in ('窗口名称 :','窗口编号 :','宽度 :','高度 :')}
    if page==103:
        if values.get('高度 :')!='768' or 'background_color_occurrence' not in settings:raise ValueError('Fresh reviewed source background and dimensions required')
        values['高度 :']='600'
    if values.get('窗口编号 :')!=str(page) or not 1<=int(values['宽度 :'])<=1024 or not 1<=int(values['高度 :'])<=600:raise ValueError('Source page needs adaptation')
    for c in src:
        if c['type']=='ComboBox' and c['name'] in ('打开窗口时执行 :','循环执行 :','关闭窗口时执行 :') and c.get('value')!='停用':
            from eb_flow_model import counts
            counts(page)
            match=re.fullmatch(r'\[ID:(\d{3})\] (.+)',c.get('value',''))
            if not match:raise ValueError('Unknown source macro hook')
            cached=json.loads((ROOT/'evidence/formal-macros-reopened-uia.json').read_text(encoding='utf8'))
            identity=f'[ID : {match[1]}]\t{match[2]}'
            if not any(row.get('name')==identity for row in cached):raise ValueError('Source macro identity not found in reopened target')
    if not request.get('resume'):
        w=Desktop(backend='uia').window(handle=handle).wrapper_object()
        r=native.rectangle()
        if page in (205,213,214,215,216,217,219,220,221,222,223,224,225,226,228,229,230,231,232,235,236,237,302,313):
            ts=[c for c in w.descendants(control_type='TabItem')if c.is_visible()and c.window_text()=='目录树']
            if len(ts)!=1:raise ValueError('Unique directory tab required')
            native.set_focus();ts[0].click_input();time.sleep(.15)
        from eb_directory import scope
        directory=scope(w)
        filters=[c for c in directory.descendants(control_type='Edit')if c.is_visible()]
        if len(filters)!=1:raise ValueError('Unique tree filter required')
        native.set_focus()
        import win32clipboard
        win32clipboard.OpenClipboard()
        try:win32clipboard.EmptyClipboard();win32clipboard.SetClipboardText(str(page),win32clipboard.CF_UNICODETEXT)
        finally:win32clipboard.CloseClipboard()
        filters[0].click_input();filters[0].set_focus();send_keys('^a^v',pause=.05);time.sleep(.15)
        if filters[0].get_value()!=str(page):raise ValueError('Create page filter readback mismatch')
        observed=directory.descendants(control_type='TreeItem',cache_enable=True)
        nodes=[c for c in observed if c.element_info.name==str(page) or re.match(r'^'+str(page)+r'\s*:',c.element_info.name)]
        (ROOT/'evidence'/'new-page-tree-observed.json').write_text(json.dumps([c.element_info.name for c in observed],ensure_ascii=False),encoding='utf8')
        if len(nodes)!=1:raise ValueError('Unique numbered slot required')
        if nodes[0].window_text()!=str(page):raise ValueError('Page already exists; inspect instead of duplicate')
        nodes[0].click_input(button='right',coords=(40,nodes[0].rectangle().height()//2));time.sleep(.1)
        entries=[]
        for p in Desktop(backend='win32').windows():
            if p.process_id()==pid and p.class_name().startswith('Qt5QWindowPopup') and p.is_visible():
                u=Desktop(backend='uia').window(handle=p.handle).wrapper_object()
                entries.extend(c for c in u.descendants(control_type='MenuItem') if c.window_text()=='新增' and c.is_visible() and c.is_enabled())
        if len(entries)!=1:raise ValueError('Unique enabled new-page action required')
        entries[0].click_input();time.sleep(.2)
    ds=[]
    for _ in range(20):
        ds=[d for d in Desktop(backend='win32').windows() if d.process_id()==pid and d.window_text()=='窗口设置' and d.is_visible()]
        if len(ds)==1:break
        time.sleep(.1)
    if len(ds)!=1:raise ValueError('New-page settings required')
    d=Desktop(backend='uia').window(handle=ds[0].handle).wrapper_object()
    cached=d.descendants(cache_enable=True)
    fields=[c for c in cached if c.element_info.control_type=='Edit']
    def edit(name):
        matches=[c for c in fields if c.element_info.name==name and c.is_visible()]
        if len(matches)!=1:raise ValueError('Unique page field required: '+name)
        return EditWrapper(matches[0].handle)
    if edit('窗口编号 :').window_text()!=str(page):raise ValueError('Numbered slot changed')
    for name in ('窗口名称 :','宽度 :','高度 :'):
        e=edit(name);e.set_edit_text(values[name])
        if e.window_text()!=values[name]:raise ValueError('Page field readback mismatch')
    for name in ('底层 :','中层 :','顶层 :','打开窗口时执行 :','循环执行 :','关闭窗口时执行 :'):
        value=next(c['value'] for c in src if c['type']=='ComboBox' and c['name']==name)
        controls=[c for c in cached if c.element_info.control_type=='ComboBox' and c.element_info.name==name and c.is_visible()]
        if len(controls)!=1:raise ValueError('Unique layer or macro combo required')
        combo=ComboBoxWrapper(controls[0].handle)
        if combo.selected_text()!=value:
            if name.endswith('执行 :') and value.startswith('[ID:'):
                from eb_macro_picker import choose
                choose(controls[0],value,pid)
            else:combo.select(value)
        if combo.selected_text()!=value:raise ValueError('Page combo readback mismatch')
    from eb_color_picker import set_rgb,probe
    from eb_native_form import fields as apply_fields
    border=[c for c in src if c['type']=='ComboBox' and c['name']=='宽度 :']
    if border:apply_fields(d,border)
    fill=[dict(c,name='填充') for c in src if c['type']=='CheckBox' and c['name']=='填色']
    if fill:apply_fields(d,fill)
    # MT hides the background selector when Fill is off; temporarily enable only on reviewed203.
    temporary_fill=page in (203,205) and bool(fill) and fill[0]['value']==0
    if temporary_fill:apply_fields(d,[dict(fill[0],value=1)])
    label='背景颜色 :' if page in (103,200,201,202,203,204,205,206,208,210,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,228,229,230,231,232,235,236,237,302,313) else '颜色 :'
    set_rgb(d,background,label)
    if probe(d,label)!=background:raise ValueError('New page background mismatch')
    if temporary_fill:apply_fields(d,fill)
    evidence=rows(d)
    ok=[c for c in cached if c.element_info.control_type=='Button' and c.element_info.name=='确定' and c.is_visible()]
    if len(ok)!=1:raise ValueError('Unique page OK required')
    ButtonWrapper(ok[0].handle).send_message_timeout(0x00F5,timeout=2) # BM_CLICK, independent of hit-test coordinates.
    for _ in range(20):
        if not ctypes.windll.user32.IsWindow(ds[0].handle) or not ctypes.windll.user32.IsWindowVisible(ds[0].handle):break
        time.sleep(.1)
    else:raise ValueError('New-page confirmation did not close settings dialog')
    native.set_focus();send_keys('^s',pause=.01)
    report={'page':page,'created_blank_page':True,'fields':values,'controls':evidence,'saved_requested':True,'dialog_closed_verified':True}
    (ROOT/'evidence'/f'target-page-{page:03d}-created.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    (ROOT/'evidence'/f'target-page-{page:03d}-size.json').write_text(json.dumps({'page':page,'after':{k:values[k] for k in ('宽度 :','高度 :')},'saved_requested':True},ensure_ascii=False,indent=2),encoding='utf8')
    (ROOT/'evidence'/f'target-page-{page:03d}-color.json').write_text(json.dumps({'page':page,'rgb':background,'target_process_id':pid,'saved_requested':True,'chooser_reopened_verified':True,'project_reopened_verified':False},ensure_ascii=False),encoding='utf8')

