"""Rebuild the half-auto header vector with exact source fill and border RGB."""
import json
from eb_extract import ROOT,rows
from eb_object_ui import target,dialog,placed_properties,save
from eb_native_form import tab,fields,confirm
from eb_layout import geometry
from eb_color_picker import set_rgb,probe
def run(handle,q):
    page,n=int(q['page']),int(q['build_sp'])
    if (page,n) not in ((10,0),(11,0),(17,0),(103,0),(200,0),(200,1),(201,0),(201,1),(202,0),(202,1)) and not (page==101 and n in range(8)):raise ValueError('Unreviewed background vector')
    mapping={1:0,0:1,2:2,3:3,4:4,5:5,6:6,7:7}
    target_key=f'SP_{mapping[n]}' if page==101 else f'SP_{n}'
    source=json.loads((ROOT/'evidence'/'source-object-properties'/f'{page:03d}_SP_{n}.json').read_text(encoding='utf8'))
    if page in (200,201,202) and source.get('vector_identity',{}).get('family')!='System Frame':raise ValueError('Page200 source vector family requires review')
    if page in (200,201,202) and source['vector_identity']['index']!='0':raise ValueError('Page200 source vector index requires review')
    colors=source['colors']
    if set(colors)!={'图案颜色 :','颜色 :'}:raise ValueError('Both exact source vector colors required')
    if page in (10,11):
        if (ROOT/f'evidence/target-{page:03d}-SP{n}-built.json').exists():raise ValueError('Saved vector exists; audit instead')
        audit=json.loads((ROOT/f'evidence/target-page{page}-audit.json').read_text(encoding='utf8'))
        if f'SP_{n}' not in audit['missing']:raise ValueError('Fresh missing-vector audit required')
    root,w=target(handle,page)
    if page==101:
        verified=json.loads((ROOT/'evidence/page-101-vector-sample-reopened.json').read_text(encoding='utf8'))
        if not verified['ok']:raise ValueError('Accepted vector pilot verification required')
        if (ROOT/f'evidence/target-101-SP{n}-built.json').exists():raise ValueError('Saved vector exists; never create duplicate')
    if not q.get('resume'):
        if page in (10,11,101,103,200,201,202):
            from eb_ribbon import create
            create(root,'SP','新增 向量图')
        else:root.set_focus();root.click_input(coords=(427,63));root.click_input(coords=(250,138))
    d=dialog(root.process_id(),'新增 向量图');tab(d,'图片');fields(d,source['tabs']['图片'])
    if page in (10,11,101,103,200,201,202) and not q.get('resume'):
        from eb_frame_vector import choose
        choose(d,root.process_id())
        fields(d,source['tabs']['图片'])
    for label,value in colors.items():
        set_rgb(d,value,label)
        if probe(d,label)!=value:raise ValueError('Vector color mismatch: '+label)
    picture=rows(d);tab(d,'安全');fields(d,source['tabs']['安全']);confirm(d)
    d,name=placed_properties(root,w,target_key,'向量图的属性')
    tab(d,'轮廓');shape=geometry(source);fields(d,[{'type':'Edit','name':k,'value':v} for k,v in shape.items()]);shape_readback=rows(d)
    confirm(d);save(root)
    report={'page':page,'source':source['object'],'target':name,'picture':picture,'colors':colors,'geometry':shape_readback,'saved_requested':True,'z_order_review_pending':True,'vector_shape_identity_review_pending':True}
    if page==101:report.update(source_key=f'SP_{n}',target_key=target_key,library='System Frame',library_item=0)
    (ROOT/'evidence'/f'target-{page:03d}-SP{n}-built.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
