"""Repair only existing page202 button picture colors, preserving labels and geometry."""
import json
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save
from eb_native_form import tab,confirm
from eb_color_picker import set_rgb,probe

def run(handle,q):
 kind=q['kind'];n=int(q['number'])
 if not ((kind=='TS' and n in range(12)) or (kind=='BL' and n in range(14)) or (kind=='SW' and n==0)):raise ValueError('Reviewed page202 bit controls only')
 key=f'{kind}_{n}';source=json.loads((ROOT/f'evidence/source-object-properties/202_{key}.json').read_text(encoding='utf8'))
 root,w=target(handle,202)
 title='多状态设置的属性' if kind=='SW' else ('位状态指示灯/位状态切换开关的属性' if kind=='BL' else '位状态切换开关/位状态指示灯的属性')
 d,_=properties(root,w,key,title);tab(d,'图片')
 choices=[c for c in d.descendants(control_type='ComboBox') if c.is_visible() and c.window_text()=='状态 :']
 if len(choices)!=1:raise ValueError('Unique picture state selector required')
 states=source.get('state_colors',{}).get('图片') if kind in ('TS','BL') else {'0':source['colors']}
 checks=[]
 for state,colors in states.items():
  ComboBoxWrapper(choices[0].handle).select(state)
  for label,rgb in colors.items():
   set_rgb(d,rgb,label)
   if probe(d,label)!=rgb:raise ValueError('Button picture color mismatch')
 confirm(d);save(root)
 d,_=properties(root,w,key,title);tab(d,'图片')
 choices=[c for c in d.descendants(control_type='ComboBox') if c.is_visible() and c.window_text()=='状态 :']
 for state,colors in states.items():
  ComboBoxWrapper(choices[0].handle).select(state)
  for label,rgb in colors.items():
   actual=probe(d,label)
   if actual!=rgb:raise ValueError('Saved button color mismatch')
   checks.append({'state':state,'label':label,'source':rgb,'saved_readback':actual})
 # No change in the reopened form; cancel rather than resave.
 buttons=[c for c in d.descendants(control_type='Button') if c.window_text()=='取消' and c.is_visible()]
 if len(buttons)!=1:raise ValueError('Unique cancel required')
 buttons[0].invoke()
 p=ROOT/f'evidence/target-202-{kind}{n}-built.json';report=json.loads(p.read_text(encoding='utf8'))
 report['saved_picture_rgb_checks']=checks;report['picture_colors_verified']=True
 p.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
