"""Repair labels in existing lamps only; serial worker requests and local reports."""
import json,re
from pathlib import Path
from eb_rebuild_page import call
ROOT=Path(__file__).resolve().parent.parent

def main():
    lock=ROOT/'tools'/'batch.lock'
    with lock.open('x',encoding='utf8'):pass
    repaired=[]
    try:
        call('snapshot')
        windows=json.loads((ROOT/'evidence'/'windows.json').read_text(encoding='utf8'))
        target=[w['handle'] for w in windows if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
        if len(target)!=1:raise ValueError('Exactly one target required')
        handle=target[0]
        for page in (12,13,14,15,18,19,20,21,22,23,24,25):
            candidates=[]
            for path in sorted((ROOT/'evidence'/'source-object-properties').glob(f'{page:03d}_BL_*.json')):
                src=json.loads(path.read_text(encoding='utf8'))
                if any(c['type']=='CheckBox' and c['name']=='使用文字标签' and c.get('value')==1 for c in src['tabs']['标签']):
                    candidates.append(int(re.search(r'_BL_(\d+)',path.stem)[1]))
            call('uia',handle,json.dumps({'open_target_page':page}))
            call('uia',handle,json.dumps({'target_page_audit':page}))
            for n in candidates:
                report=ROOT/'evidence'/f'target-{page:03d}-BL{n}-labels-fixed.json'
                if not report.exists():call('uia',handle,json.dumps({'page':page,'fix_bl_labels':n}))
                repaired.append({'page':page,'object':f'BL_{n}'})
                (ROOT/'evidence'/'label-repair-progress.json').write_text(json.dumps({'completed':repaired,'ok':False},ensure_ascii=False,indent=2),encoding='utf8')
        (ROOT/'evidence'/'label-repair-progress.json').write_text(json.dumps({'completed':repaired,'ok':True},ensure_ascii=False,indent=2),encoding='utf8')
        print(json.dumps({'ok':True,'labelled_lamps':len(repaired)},ensure_ascii=False))
    finally:lock.unlink(missing_ok=True)

if __name__=='__main__':main()
