"""Copy a directory-selected control with explicit canvas focus; never paste."""
import re,time,ctypes,json,hashlib,os
from pywinauto import mouse
from pywinauto.keyboard import send_keys
from eb_rebuild_page import ROOT
from eb_object_ui import object_item
from eb_directory import scope
from eb_copy_200_style_object import native_clipboard_data

def copy_control(root,w,key,reuse=True):
    proof=json.loads((ROOT/'evidence/direct-copy-trial.json').read_text(encoding='utf8'))
    if proof.get('stage')!='trial-removed' or not proof.get('copied_fields_equal'):raise ValueError('Direct copy trial not verified')
    if not root.is_enabled():raise ValueError('Modal dialog present; copy not sent')
    page=re.search(r'\[(\d+) - ',root.window_text())
    if '组装机_MT8106iP.emtp' not in root.window_text() or not page:raise ValueError('Exact target document/page required')
    cache_path=ROOT/'evidence/direct-native-copy-cache.json'
    lock=ROOT/'tools/batch.lock'
    batch_scope={'lock_mtime_ns':lock.stat().st_mtime_ns,'lock_sha256':hashlib.sha256(lock.read_bytes()).hexdigest()} if lock.exists() else {'copy_process':os.getpid()}
    identity={'handle':root.handle,'pid':root.process_id(),'page':int(page[1]),'key':key,'batch_scope':batch_scope}
    sequence=lambda:int(ctypes.windll.user32.GetClipboardSequenceNumber())
    if reuse and cache_path.exists():
        cached=json.loads(cache_path.read_text(encoding='utf8'))
        if cached.get('identity')==identity and cached.get('sequence')==sequence():
            data=native_clipboard_data()
            if hashlib.sha256(data).hexdigest()==cached.get('sha256'):return data
    root.set_focus();item=object_item(w,key)
    trees=[t for t in scope(w).descendants(control_type='Tree') if t.is_visible()]
    if len(trees)!=1:raise ValueError('Unique directory viewport required')
    viewport=trees[0].rectangle();box=item.rectangle()
    if not(0<box.height()<60 and viewport.left<=box.left<box.right<=viewport.right and viewport.top<=box.top<box.bottom<=viewport.bottom):raise ValueError('Object row outside safe viewport; no copy sent')
    views=[c for c in root.descendants(class_name='AfxFrameOrView140u') if c.window_text().startswith(page[1]+' - ')]
    if len(views)!=1:raise ValueError('Unique target canvas required')
    # Qt may not reselect the canvas object when its already-selected tree row is clicked again.
    alternatives=[c for c in trees[0].descendants(control_type='TreeItem',cache_enable=True) if re.search(r'(?:^|\])\s*[A-Z]+_\d+(?:\s|$)',c.element_info.name) and c.element_info.name!=item.element_info.name and viewport.top<=c.rectangle().top<c.rectangle().bottom<=viewport.bottom]
    if alternatives:
        other=alternatives[0].rectangle()
        mouse.click(coords=(other.left+min(40,other.width()-2),(other.top+other.bottom)//2))
        box=item.rectangle()
    mouse.click(coords=(box.left+min(40,box.width()-2),(box.top+box.bottom)//2))
    root.set_focus()
    u=ctypes.windll.user32;current=ctypes.windll.kernel32.GetCurrentThreadId();thread=u.GetWindowThreadProcessId(views[0].handle,None)
    if not u.AttachThreadInput(current,thread,True):raise ValueError('Canvas focus attachment failed')
    try:
        u.SetFocus(views[0].handle)
        if u.GetFocus()!=views[0].handle:raise ValueError('Canvas focus readback mismatch')
    finally:u.AttachThreadInput(current,thread,False)
    import win32clipboard as clipboard
    clipboard.OpenClipboard()
    try:clipboard.EmptyClipboard()
    finally:clipboard.CloseClipboard()
    send_keys('^c',pause=.01);time.sleep(.15)
    fallback=False
    try:data=native_clipboard_data()
    except ValueError:
        # Copy has no project side effect; a missing native format permits the proven selection fallback.
        from eb_object_ui import properties
        from eb_page26_shapes import cancel
        titles={'NE':'数值的属性','ND':'数值的属性','TS':'位状态切换开关/位状态指示灯的属性'}
        if key.split('_')[0] not in titles:raise
        d,_=properties(root,w,key,titles[key.split('_')[0]]);cancel(d)
        root.set_focus();send_keys('^c',pause=.01);time.sleep(.15)
        data=native_clipboard_data();fallback=True
    cache_path.write_text(json.dumps({'identity':identity,'sequence':sequence(),'sha256':hashlib.sha256(data).hexdigest(),'selection_fallback':fallback},ensure_ascii=False,indent=2),encoding='utf8')
    return data
