"""Open a defined target page with an exact prefix filter, avoiding empty slots."""
import re,time
from pywinauto import Desktop
from pywinauto.keyboard import send_keys

from eb_timing import timed

@timed
def run(handle,request):
    page=int(request['open_target_page'])
    native=Desktop(backend='win32').window(handle=handle).wrapper_object()
    if '组装机_MT8106iP.emtp' not in native.window_text():raise ValueError('Target project only')
    if f'[{page} - ' in native.window_text():return
    w=Desktop(backend='uia').window(handle=handle).wrapper_object();r=native.rectangle()
    from eb_directory import scope
    directory=scope(w)
    fields=[c for c in directory.descendants(control_type='Edit') if c.is_visible()]
    if len(fields)!=1:raise ValueError('Unique target filter required')
    native.set_focus();fields[0].click_input();fields[0].set_focus()
    import win32clipboard
    prefix=str(page)+' :'
    win32clipboard.OpenClipboard()
    try:win32clipboard.EmptyClipboard();win32clipboard.SetClipboardText(prefix,win32clipboard.CF_UNICODETEXT)
    finally:win32clipboard.CloseClipboard()
    send_keys('^a^v',pause=.03);time.sleep(.15)
    if fields[0].get_value()!=prefix:raise ValueError('Target page filter readback mismatch')
    if f'[{page} - ' in native.window_text():return
    from pywinauto import mouse
    trees=[c for c in directory.descendants(control_type='Tree') if c.is_visible()]
    if len(trees)==1:
        box=trees[0].rectangle();mouse.scroll(coords=((box.left+box.right)//2,(box.top+box.bottom)//2),wheel_dist=60);time.sleep(.2)
    nodes=[c for c in directory.descendants(control_type='TreeItem') if re.match(r'^'+str(page)+r'\s*:',c.window_text())]
    if not nodes:
        from pywinauto import mouse
        trees=[c for c in directory.descendants(control_type='Tree') if c.is_visible()]
        if len(trees)!=1:raise ValueError('Unique target tree required to restore viewport')
        box=trees[0].rectangle();mouse.scroll(coords=((box.left+box.right)//2,(box.top+box.bottom)//2),wheel_dist=60);time.sleep(.2)
        nodes=[c for c in directory.descendants(control_type='TreeItem') if re.match(r'^'+str(page)+r'\s*:',c.window_text())]
    if len(nodes)!=1:raise ValueError('Exact prefix did not identify a defined page')
    import json
    from eb_rebuild_page import ROOT
    (ROOT/'evidence/page-switch-probe.json').write_text(json.dumps({'page':page,'name':nodes[0].window_text(),'rect':str(nodes[0].rectangle()),'tree':str(trees[0].rectangle()),'root':str(r),'enabled':native.is_enabled()},ensure_ascii=False),encoding='utf8')
    if f'[{page} - ' not in native.window_text():
        nodes[0].double_click_input(coords=(40,nodes[0].rectangle().height()//2));time.sleep(.3)
    # Page activation can finish after large graphic libraries redraw.
    # Wait for the actual title instead of issuing another double-click.
    for _ in range(100):
        if f'[{page} - ' in native.window_text():return
        time.sleep(.1)
    raise ValueError('Target page did not become active')
