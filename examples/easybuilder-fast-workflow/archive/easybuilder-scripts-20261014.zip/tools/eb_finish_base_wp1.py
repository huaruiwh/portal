import json
from pywinauto import Desktop
from eb_extract import ROOT,rows
from eb_native_form import tab,fields,confirm
from eb_object_ui import save
from eb_layout import geometry

def run(handle,q):
 page=int(q['finish_base_wp1'])
 if page!=11:raise ValueError('Reviewed interrupted page11 reset only')
 phase=json.loads((ROOT/'evidence/target-011-WP1-copy-phase.json').read_text(encoding='utf8'))
 audit=json.loads((ROOT/'evidence/target-page11-audit.json').read_text(encoding='utf8'))
 if not phase['pasted'] or audit['target_count']!=32 or audit['unexpected'] or 'WP_1' in audit['missing']:raise ValueError('Verified single pasted reset required')
 root=Desktop(backend='win32').window(handle=handle).wrapper_object()
 ds=[d for d in Desktop(backend='win32').windows() if d.process_id()==root.process_id() and d.is_visible() and d.window_text()=='间接窗口的属性']
 if len(ds)!=1:raise ValueError('One unfinished reset property required')
 d=Desktop(backend='uia').window(handle=ds[0].handle).wrapper_object();source=json.loads((ROOT/'evidence/source-object-properties/011_WP_1.json').read_text(encoding='utf8'))
 tab(d,'一般属性');fields(d,source['tabs']['一般属性'],skip=(('ComboBox','类型 :'),('ComboBox','开始 :'),('ComboBox','结束 :')));actual=rows(d)
 names={'设备 :','Static',' Down','使用窗口编号偏移量'}
 select=lambda rs:[(r['type'],r['name'],r['value']) for r in rs if r['name'] in names and 'value' in r]
 if select(actual)!=select(source['tabs']['一般属性']):raise ValueError('Indirect LW0 fields mismatch')
 tab(d,'位置');fields(d,source['tabs']['位置'],skip=(('CheckBox','动态位置'),('RadioButton','')))
 tab(d,'轮廓');expected=geometry(source);fields(d,[{'type':'Edit','name':k,'value':v} for k,v in expected.items()]);shape=rows(d)
 if {r['name']:r['value'] for r in shape if r['type']=='Edit' and r['name'] in expected}!=expected:raise ValueError('Reset finish geometry mismatch')
 confirm(d);save(root)
 (ROOT/'evidence/target-011-WP1-built.json').write_text(json.dumps({'page':11,'source':source['object'],'target':'WP_1 (M-26.0)','template':17,'geometry':shape,'saved_requested':True,'style_mapping':'cMT弹出窗口 -> MT间接窗口，自动调整尺寸保留；锚定/弹出运行待验证','count_verified':True,'general_reopened_verified':False,'offline_simulation_verified':False},ensure_ascii=False,indent=2),encoding='utf8')
