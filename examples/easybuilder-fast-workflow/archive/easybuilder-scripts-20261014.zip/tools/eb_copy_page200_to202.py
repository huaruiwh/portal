import json,time,shutil
from pywinauto import Desktop
from pywinauto.keyboard import send_keys
from eb_rebuild_page import ROOT
from eb_object_ui import target,save
from eb_create_page import run as create
from eb_page_audit import run as audit

def run(handle,q):
 path=ROOT/'evidence/page202-whole-page-copy.json'
 if path.exists():raise ValueError('Copy phase already recorded; inspect instead of duplicate paste')
 root,w=target(handle,200)
 backup=ROOT/'backup/200页复制202前_20261011.emtp';backup.parent.mkdir(exist_ok=True)
 if not backup.exists():shutil.copy2(ROOT/'output/组装机_MT8106iP.emtp',backup)
 if not (ROOT/'evidence/target-page-202-created.json').exists():create(handle,{'create_target_page':202})
 def activate(page):
  w=Desktop(backend='uia').window(handle=handle).wrapper_object()
  tabs=[c for c in w.descendants(control_type='TabItem') if c.is_visible() and c.window_text().startswith(str(page)+' - ')]
  if len(tabs)!=1:raise ValueError('Unique opened page tab required')
  root.set_focus();tabs[0].click_input();time.sleep(.3)
  if f'[{page} - ' not in root.window_text():raise ValueError('Copied page activation mismatch')
 from eb_open_page import run as open_page
 open_page(handle,{'open_target_page':202})
 activate(202)
 try:audit(handle,{'target_page_audit':202})
 except ValueError as e:
  if 'Target object audit incomplete' not in str(e):raise
 a=json.loads((ROOT/'evidence/target-page202-audit.json').read_text(encoding='utf8'))
 if a['target_count']!=0:raise ValueError('Empty destination required')
 activate(200);root.click_input(coords=(963,367));send_keys('^a^c',pause=.15);time.sleep(.2)
 from eb_open_page import run as open_page
 open_page(handle,{'open_target_page':202})
 activate(202);root.click_input(coords=(963,367))
 phase={'template':200,'destination':202,'stage':'paste_requested','copied_controls_verified':False,'addresses_rewritten':False}
 path.write_text(json.dumps(phase,ensure_ascii=False,indent=2),encoding='utf8')
 send_keys('^v',pause=.15);time.sleep(.5);send_keys('{ESC}',pause=.05);save(root)
 try:audit(handle,{'target_page_audit':202})
 except ValueError as e:
  if 'Target object audit incomplete' not in str(e):raise
 a=json.loads((ROOT/'evidence/target-page202-audit.json').read_text(encoding='utf8'));phase.update(stage='saved',target_count=a['target_count'],copied_controls_verified=a['target_count']==74)
 path.write_text(json.dumps(phase,ensure_ascii=False,indent=2),encoding='utf8')
 if not phase['copied_controls_verified']:raise ValueError('Copy count differs from 74')

