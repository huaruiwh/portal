import json
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
with lock.open('x'):pass
try:
 call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'));w=next(w for w in ws if w['class']=='EasyBuilderPro' and '_MT8106iP_' in w['title']);h=w['handle']
 for p in (100,101,102):
  call('uia',h,json.dumps({'page_settings':p,'target_readonly':True,'apply_source_layers':True}))
  call('uia',h,json.dumps({'page_settings':p,'target_readonly':True}))
  d=json.loads((ROOT/f'evidence/target-pages-settings/{p:03d}.json').read_text(encoding='utf8'));path=ROOT/f'evidence/target-page-{p:03d}-layers.json';v=json.loads(path.read_text(encoding='utf8'));actual={x['name']:x.get('value') for x in d['controls'] if x['type']=='ComboBox' and x['name'] in v['layers']}
  v['property_reopened_verified']=actual==v['layers'];path.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8')
  if not v['property_reopened_verified']:raise ValueError('Layer property reopen mismatch')
  print(p,'verified',flush=True)
 call('uia',h,json.dumps({'compile_target':True,'start_only':True}));call('uia',h,json.dumps({'compile_target':True,'capture_result':True,'expected_pid':w['pid']}))
 print('compiled',flush=True)
finally:lock.unlink(missing_ok=True)
