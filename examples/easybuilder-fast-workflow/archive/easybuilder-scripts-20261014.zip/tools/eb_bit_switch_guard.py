"""Admit the separately reviewed momentary PLC reset switch on half-auto page17."""
import json
from eb_template_guard import ROOT
def validate(page,n):
    if (page,n)!=(17,0):raise ValueError('Unreviewed PLC switch')
    source=json.loads((ROOT/'evidence'/'source-object-properties'/f'{page:03d}_TS_{n}.json').read_text(encoding='utf8'))
    rows=source['tabs']['一般属性']
    checks={('RadioButton','位状态切换开关'):1,('CheckBox','读取/写入使用不同的地址'):0,('CheckBox','输出反向'):0,('CheckBox','触发宏指令'):0,('ComboBox','操作模式 :'):'复归型',('ComboBox','设备 :'):'Siemens S7-1200/S7-1500',('ComboBox',' Down'):'M',('Edit','Static'):'26.0'}
    for (typ,name),expected in checks.items():
        values=[r.get('value') for r in rows if r['type']==typ and r['name']==name]
        if values!=[expected]:raise ValueError('Unsupported reset-switch behavior: '+name)
    for row in source['tabs']['安全']:
        if row['type']=='CheckBox' and row.get('value')!=0:raise ValueError('Reset switch safety option requires review')
        if row['type']=='ComboBox' and row.get('value')!='无':raise ValueError('Reset switch user restriction requires review')
    if not any(r['name']=='picture51' for r in source['tabs']['图片']):raise ValueError('Unreviewed switch picture')
    return source
