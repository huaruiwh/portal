import json,time,re
from eb_rebuild_page import ROOT
from eb_copy_200_style_object import read_audit
from eb_object_ui import target,properties,save
from eb_page26_shapes import cancel
from pywinauto.keyboard import send_keys

def run(h,q):
 key=q['replace_218_numerics']
 if key=='center':return center(h)
 if key not in ['NE_'+str(i)for i in range(9)]+['TS_'+str(i)for i in range(8)]+['FK_0','SW_0']:raise ValueError('Unapproved deletion')
 root,w=target(h,218);before=read_audit(h,218)
 found=[x for x in before['objects']if re.search(r'(?:^|\])\s*'+key+r'(?:\s|$)',x)]
 if not found and key in before['missing']:return # Already absent: do not send Delete to another control.
 if len(found)!=1:raise ValueError('Exact numeric identity required')
 d,_=properties(root,w,key,{'NE':'数值的属性','TS':'位状态切换开关/位状态指示灯的属性','FK':'功能键的属性','SW':'多状态设置的属性'}[key.split('_')[0]]);cancel(d)
 root.set_focus();send_keys('{DELETE}',pause=.02);time.sleep(.2)
 after=read_audit(h,218)
 if after['target_count']!=before['target_count']-1 or key not in after['missing']:raise ValueError('Delete readback failed')
 save(root)

def center(h):
 from eb_scale_post200 import geo
 from eb_native_form import tab,fields,confirm
 from eb_live_fields import capture
 import math
 root,w=target(h,218);d,_=properties(root,w,'TB_0','表格的属性')
 try:
  g=geo(d);tab(d,'一般属性');a=capture(d,[('Edit','垂直 :'),('Edit','水平 :'),('ComboBox','间距 :')]);v={r['name']:r['value']for r in a}
  if v['垂直 :']!='6'or v['水平 :']!='3'or v['间距 :']!='均等':raise ValueError('Center requires verified 6x3 equal table')
 finally:cancel(d)
 result=[]
 for i in range(9):
  key='NE_'+str(i);d,_=properties(root,w,key,'数值的属性')
  try:
   before=geo(d);x,y,ww,hh=[int(before[n])for n in ['X :',' Y :',' 宽度 :','高度 :']];tx,ty,tw,th=[int(g[n])for n in ['X :',' Y :',' 宽度 :','高度 :']]
   col=math.floor((x+ww/2-tx)/(tw/3));row=math.floor((y+hh/2-ty)/(th/6))
   if col not in [1,2]or row not in range(1,6):raise ValueError('Numeric is outside expected data cell')
   after=dict(before);after['X :']=str(round(tx+(col+.5)*tw/3-ww/2));after[' Y :']=str(round(ty+(row+.5)*th/6-hh/2))
   tab(d,'轮廓');fields(d,[{'type':'Edit','name':n,'value':v}for n,v in after.items()],commit_edits=True);confirm(d);d=None;save(root)
  finally:
   if d is not None:cancel(d)
  d,_=properties(root,w,key,'数值的属性')
  try:
   actual=geo(d)
   if actual!=after:raise ValueError('Centered saved geometry differs')
  finally:cancel(d)
  result.append({'key':key,'before':before,'after':after,'row':row,'column':col,'saved_reopened_verified':True})
  (ROOT/'evidence/page218-numerics-centered.json').write_text(json.dumps({'table':g,'controls':result,'finished':len(result)==9},ensure_ascii=False,indent=2),encoding='utf8')
