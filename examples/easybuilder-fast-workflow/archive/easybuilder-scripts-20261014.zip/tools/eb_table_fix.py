"""Fix custom-spacing table grids on the reviewed later pages so every row fits its scaled frame.

Only the target project is touched. Two operations:
  {'table_fix':{'page':P,'key':'TB_n','op':'probe'}}  read-only: counts, spacing value, real option list
  {'table_fix':{'page':P,'key':'TB_n','op':'apply','set':LABEL}}  write the chosen spacing mode

The probe reads the option list by physically opening the observed combo popup and cancelling it,
so the applied label is never guessed.
"""
import json,re,time,ctypes
from pathlib import Path
from pywinauto import Desktop,mouse
from pywinauto.keyboard import send_keys
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save
from eb_native_form import tab,fields,confirm
from eb_page26_shapes import cancel
from eb_live_fields import capture
from eb_page203_rewrite import TITLES

PAGES=(210,212,218,221,224,235)

def counts(d):
    tab(d,'一般属性')
    rs=capture(d,[('Edit','垂直 :'),('Edit','水平 :')])
    return {r['name']:r['value'] for r in rs}

def hints(d):
    tab(d,'一般属性')
    out=[]
    for c in d.descendants(control_type='Text'):
        if not c.is_visible():continue
        t=c.window_text()
        if t and ('间距' in t or '自由' in t or '对齐' in t):out.append(t)
    return out

def spacing_combo(d):
    cs=[]
    for c in d.descendants(control_type='ComboBox'):
        if not c.is_visible():continue
        if c.element_info.name=='间距 :':cs.append(c)
    if len(cs)!=1:raise ValueError('Unique spacing combo required')
    return cs[0]

def option_list(d,c):
    """Open the observed popup and read the real items; the dialog is left unchanged."""
    pops_before=len([w for w in Desktop(backend='win32').windows()
                     if w.process_id()==d.process_id() and w.class_name().startswith('Qt5QWindowPopup') and w.is_visible()])
    r=c.rectangle()
    mouse.click(coords=(r.right-10,(r.top+r.bottom)//2));time.sleep(.35)
    items=[]
    for _ in range(20):
        items=[v.window_text() for v in Desktop(backend='uia').window(handle=d.handle).wrapper_object()
               .descendants(control_type='ListItem') if v.is_visible()]
        if items:break
        time.sleep(.1)
    if not items:
        for w in Desktop(backend='win32').windows():
            if w.process_id()==d.process_id() and w.class_name().startswith('Qt5QWindowPopup') and w.is_visible():
                items.extend(v.window_text() for v in Desktop(backend='uia').window(handle=w.handle).wrapper_object()
                             .descendants(control_type='ListItem') if v.is_visible())
    send_keys('{ESC}',pause=.02);time.sleep(.2)
    return list(dict.fromkeys([i for i in items if i]))

def run(handle,q):
    req=q['table_fix'];page=int(req['page']);key=req['key'];op=req.get('op','probe')
    if page not in PAGES:raise ValueError('Reviewed later pages only')
    if not re.fullmatch(r'TB_\d+',key):raise ValueError('Table objects only')
    from eb_open_page import run as open_page
    open_page(handle,{'open_target_page':page})
    root,w=target(handle,page)
    d,_=properties(root,w,key,TITLES['TB'])
    out={'page':page,'key':key,'op':op}
    try:
        out['counts_before']=counts(d)
        out['hints_before']=hints(d)
        c=spacing_combo(d)
        out['spacing_before']=c.selected_text()
        pf=ROOT/f'evidence/table-fix-probe-{page}-{key}.json'
        known=json.loads(pf.read_text(encoding='utf8')).get('options') if pf.exists() else None
        out['options']=known if known else option_list(d,c)
        if op=='probe':
            cancel(d);d=None
            (ROOT/f'evidence/table-fix-probe-{page}-{key}.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
            return
        want=req['set']
        if want not in out['options']:raise ValueError('Requested spacing option not observed: '+want)
        out['set_to']=want
        fields(d,[{'type':'ComboBox','name':'间距 :','value':want}])
        out['counts_after_write']=counts(d)
        out['hints_after_write']=hints(d)
        out['spacing_after_write']=spacing_combo(d).selected_text()
        if out['counts_after_write']!=out['counts_before']:raise ValueError('Row/column count changed while setting spacing')
        if out['spacing_after_write']!=want:raise ValueError('Spacing readback mismatch before save')
        confirm(d);d=None;save(root)
    finally:
        if d is not None:cancel(d)
    d,_=properties(root,w,key,TITLES['TB'])
    try:
        out['counts_reopened']=counts(d)
        out['spacing_reopened']=spacing_combo(d).selected_text()
        out['hints_reopened']=hints(d)
        out['saved_reopened_verified']=bool(out['spacing_reopened']==out.get('set',out['spacing_before'])
                                           and out['counts_reopened']==out['counts_before'])
    finally:cancel(d)
    (ROOT/f'evidence/table-fix-{page}-{key}.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
    if not out['saved_reopened_verified']:raise ValueError('Table spacing fix not verified after reopen: %s %s'%(page,key))
