"""One serial supervisor for the authorized later-page pipeline and layout tasks."""
import json,subprocess,sys,time,os
from datetime import datetime,timezone,timedelta
from pathlib import Path
from eb_rebuild_page import ROOT
from continue_scale_post200 import load,put
S=ROOT/'evidence/later-pages-continuation.json'
PAGES=[int(v)for v in sys.argv[1:]] if len(sys.argv)>1 else [212,218,221,224,235]
if not PAGES or any(v not in [212,218,221,224,235]for v in PAGES):raise ValueError('Unapproved continuation pages')

def archive(d):
    d['updated_at']=datetime.now(timezone(timedelta(hours=8))).isoformat(timespec='seconds')
    marker='\n### 2026-10-11：后续页面连续处理与速度排查'
    text=marker+'\n\n用户授权210页完成后连续处理后续页面。串行队列212、218、221、224、235；每页先恢复原控件复制流程，再适配890×469。已建件按真实saved_reopened_verified证据跳过；粘贴结果未知时停止该步骤做目录检查，禁止盲目重复粘贴。原件只读，下载/宏/运行验收均不执行。现有外观待办保持登记，不能把基础参数通过说成外观全部通过。\n\n'
    text+='实际状态：'+json.dumps(d,ensure_ascii=False)+'\n\n'
    text+='速度问题：一般属性全量UIA枚举耗时较长，改为精确读地址、设备、地址类型，字段回退使用cache_enable=True；保持原生读回。复制完整控件原调用缺少build_bit_general标志，被worker误分到55秒超时；请求已加`build_bit_general: 0`，早分发仍先走copy_200_style_object，worker完整任务限制300秒。报错原文：`timed out after 55 seconds`；212/BL_0已保存但未验证时按saved-unverified恢复，未再次粘贴。当前标签已经选中时跳过重复Select；字体写入前不再读取随后不用的旧字号，写入后继续读回。\n\n'
    text+='恢复命令：`& "C:\\Users\\wei\'ke\\.cache\\codex-runtimes\\codex-primary-runtime\\dependencies\\python\\python.exe" tools/continue_later_pages.py`。队列控制器tools/later-pages-supervisor.lock和GUI控制器tools/batch.lock分开：已运行GUI控制器时监督器只等待，绝不并发操作。日志evidence/later-pages-continuation.json、各页pageNNN-build-workflow.json与scale-890x469/workflow-NNN.json。每个阶段刷新同一文档。\n'
    for f in [ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md']:
        old=f.read_text(encoding='utf8')
        if marker in old:
            st=old.index(marker);end=old.find('\n### ',st+len(marker));old=old[:st]+(old[end:] if end>=0 else '')
        f.write_text(old+text,encoding='utf8')
    cp=ROOT/'evidence/resume-checkpoint.json';c=load(cp);c.update(later_pages=d,next='连续处理后续页面，运行tools/continue_later_pages.py恢复',batch_running=(ROOT/'tools/batch.lock').exists());put(cp,c)

def execute(args,d):
    d['command']=[sys.executable]+args;put(S,d);archive(d)
    proc=subprocess.Popen([sys.executable]+args,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace',env={**os.environ,'PYTHONIOENCODING':'utf-8'})
    with (ROOT/'evidence/later-pages-controller.log').open('a',encoding='utf8') as log:
        for line in proc.stdout:
            log.write(line);log.flush()
            try:r=json.loads(line)
            except json.JSONDecodeError:continue
            if 'built' in r or 'verified' in r or 'stage' in r or 'error' in r:
                d['progress']=r;put(S,d);archive(d);print(json.dumps({'page':d['active_page'],'phase':d['phase'],'progress':r},ensure_ascii=True),flush=True)
    return proc.wait()

def main():
    lock=ROOT/'tools/later-pages-supervisor.lock'
    with lock.open('x',encoding='utf8') as f:f.write(json.dumps({'pid':os.getpid(),'scope':PAGES}))
    d=load(S) if S.exists() else {'date':'2026-10-11','scope':PAGES,'completed':[],'finished':False,'runtime_verified':False}
    try:
        while (ROOT/'tools/batch.lock').exists():time.sleep(1)
        for page in PAGES:
            if page in d['completed']:continue
            d.update(active_page=page,phase='build');put(S,d);archive(d)
            wf=ROOT/f'evidence/page{page}-build-workflow.json'
            if not wf.exists() or not load(wf).get('finished'):
                if execute(['tools/page_pipeline.py',str(page)],d):raise RuntimeError(f'Page{page} build failed; inspect workflow before recovery')
            d['build_result']=load(wf);d['phase']='scale';put(S,d);archive(d)
            scale=ROOT/f'evidence/scale-890x469/workflow-{page}.json'
            if not scale.exists() or not load(scale).get('finished'):
                if execute(['tools/continue_scale_page210.py',str(page)],d):raise RuntimeError(f'Page{page} scale failed; inspect immutable layout checkpoints')
            d.setdefault('results',{})[str(page)]={'built':len(load(wf).get('built',[])),'scale':load(scale)}
            d['completed'].append(page);put(S,d);archive(d)
        d['finished']=True;d.pop('error',None);put(S,d);archive(d)
    except Exception as e:
        d['error']=str(e);d['finished']=False;put(S,d);archive(d);raise
    finally:lock.unlink(missing_ok=True)

if __name__=='__main__':main()
