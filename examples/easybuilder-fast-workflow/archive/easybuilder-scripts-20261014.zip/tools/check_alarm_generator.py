"""Exercise the upstream XLSX writer with two synthetic alarms, offline."""
import sys,json
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
root=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(root/'research'/'EasyBuider_AlarmsImport'/'src'))
from symbol import Symbol
from alarm import Alarm
from category_settings import CategorySettings
from xls_write import write_xls_from_alarms
settings=[CategorySettings(name='Offline test',regex='^TestAlarm_')]
alarms=[Alarm(Symbol('TestAlarm_1','BOOL','离线测试报警1'),settings[0].alarm_category),
        Alarm(Symbol('TestAlarm_2','BOOL','离线测试报警2'),settings[0].alarm_category)]
path=root/'output'/'试验'/'开源报警生成器_原始格式.xlsx'
write_xls_from_alarms(str(path),'Offline Test PLC',alarms,settings)
ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with ZipFile(path) as z:
 strings=ET.fromstring(z.read('xl/sharedStrings.xml'))
 texts=[''.join(si.itertext()) for si in strings]
 sheet=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
 values={}
 for c in sheet.findall('.//s:c',ns):
  v=c.find('s:v',ns)
  if v is not None:values[c.attrib['r']]=texts[int(v.text)] if c.attrib.get('t')=='s' else v.text
assert values['A1']=='VERSION' and values['B1']=='4'
assert values['D1']=='159'
assert values['H3']=='TestAlarm_1' and values['H4']=='TestAlarm_2'
assert values['U3']=='离线测试报警1' and values['U4']=='离线测试报警2'
report={'generated':True,'alarm_rows':2,'bytes':path.stat().st_size,
 'template_version':values['B1'],'hardware_version':values['D1'],
 'address_type':values['E3'],'font':values['X3'],
 'native_template_compared':False,'easybuilder_imported':False,
 'note':'Synthetic symbols only; must adapt to MT/S7 absolute address template before production.'}
(root/'evidence'/'github-alarm-generator-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(report,ensure_ascii=False))
