"""Select a custom address-type popup by its observed item name."""
import time
import ctypes
from pywinauto import Desktop
from pywinauto.controls.win32_controls import ComboBoxWrapper

def live_windows(pid):
    from eb_color_picker import native_window_handles
    from pywinauto.controls.hwndwrapper import InvalidWindowHandle
    result=[]
    for handle in native_window_handles(pid):
        try:result.append(Desktop(backend='win32').window(handle=handle).wrapper_object())
        except InvalidWindowHandle:continue
    return result
def choose(combo,value,pid):
    if combo.element_info.class_name=='ComboBox':
        native=ComboBoxWrapper(combo.element_info.handle)
        if native.selected_text()!=value:native.select(value)
        if native.selected_text()!=value:raise ValueError('Address type selection mismatch')
        return
    if combo.selected_text()==value:return
    previous=combo.selected_text()
    box=combo.rectangle();combo.click_input(coords=(box.width()-12,box.height()//2))
    if combo.window_text()=='用户限制 Down' and value in ('类别 : A','类别 : B','类别 : C','无'):
        from eb_popup_local_ocr import observe
        for _ in range(20):
            ps=[w for w in live_windows(pid) if w.is_visible() and w.class_name().startswith('Qt5QWindowPopup')]
            if len(ps)>1:raise ValueError('Ambiguous live permission popup')
            if len(ps)==1:break
            time.sleep(.1)
        else:raise ValueError('Permission popup did not open')
        popup,ocr=observe(pid)
        token='无' if value=='无' else value[-1]
        candidates=[w for w in ocr['words'] if w['text']==token]
        if len(candidates)==1:
            item=candidates[0];popup.click_input(coords=(int(item['x']+item['width']/2),int(item['y']+item['height']/2)));time.sleep(.15)
            if combo.selected_text()==value:return
            raise ValueError('Permission OCR choice readback mismatch')
    matches=[];observed=[]
    for _ in range(12):
        matches=[]
        for win in live_windows(pid):
            if win.process_id()!=pid or not win.is_visible():continue
            if (win.class_name()=='#32770' and win.window_text()=='') or win.class_name().startswith('Qt5QWindowPopup'):
                popup=Desktop(backend='uia').window(handle=win.handle).wrapper_object()
                children=popup.descendants(cache_enable=True)
                observed=[{'name':c.element_info.name,'type':c.element_info.control_type,'visible':c.is_visible()} for c in children]
                matches.extend(c for c in children if c.element_info.control_type in ('ListItem','MenuItem') and c.element_info.name==value and c.is_visible())
        def identity(c):
            rid=c.element_info.runtime_id
            return tuple(rid) if isinstance(rid,(list,tuple)) else rid
        matches=list({identity(c):c for c in matches}.values())
        if len(matches)==1:break
        time.sleep(.1)
    if len(matches)!=1:
        import json
        from eb_extract import ROOT
        windows=[{'handle':w.handle,'class':w.class_name(),'title':w.window_text()} for w in live_windows(pid) if w.process_id()==pid and w.is_visible()]
        (ROOT/'evidence'/'combo-popup-latest.json').write_text(json.dumps({'previous':previous,'current':combo.selected_text(),'foreground':ctypes.windll.user32.GetForegroundWindow(),'items':observed,'windows':windows},ensure_ascii=False),encoding='utf8')
        if combo.window_text()=='显示 Down' and previous=='速度 5' and value=='速度 4':
            foreground=Desktop(backend='win32').window(handle=ctypes.windll.user32.GetForegroundWindow()).wrapper_object()
            menus=[w for w in live_windows(pid) if w.process_id()==pid and w.is_visible() and w.class_name().startswith('Qt5QWindowPopup')]
            if foreground.process_id()==pid and len(menus)==1:
                rect=menus[0].rectangle()
                profile={(102,252):(30,87),(100,212):(30,73)}
                if (rect.width(),rect.height()) not in profile:
                    raise ValueError('Unreviewed Qt speed popup geometry')
                # Observed speed1..10 popup: speed4 row center is y=87.
                menus[0].click_input(coords=profile[(rect.width(),rect.height())])
                if combo.selected_text()==value:return
        if value in ('类别 : A','无') and combo.window_text()=='用户限制 Down':
            from eb_popup_local_ocr import observe
            popup,ocr=observe(pid)
            token='A' if value=='类别 : A' else '无'
            candidates=[w for w in ocr['words'] if w['text']==token]
            if len(candidates)==1:
                item=candidates[0];popup.click_input(coords=(int(item['x']+item['width']/2),int(item['y']+item['height']/2)));time.sleep(.15)
                if combo.selected_text()==value:return
        if value=='类别 : B' and combo.window_text()=='用户限制 Down':
            from eb_popup_local_ocr import observe
            popup,ocr=observe(pid)
            bs=[w for w in ocr['words'] if w['text']=='B']
            if len(bs)==1:
                y=bs[0]['y']+bs[0]['height']/2
                popup.click_input(coords=(int(bs[0]['x']+bs[0]['width']/2),int(y)));time.sleep(.15)
                if combo.selected_text()==value:return
            aa=[w for w in ocr['words'] if w['text']=='A'];cc=[w for w in ocr['words'] if w['text']=='C']
            if not bs and len(aa)==len(cc)==1 and 24<cc[0]['y']-aa[0]['y']<60:
                # Highlighted B may be omitted by OCR; it is the one row
                # between observed A/C. Exact full UIA readback remains required.
                y=(aa[0]['y']+aa[0]['height']/2+cc[0]['y']+cc[0]['height']/2)/2
                popup.click_input(coords=(int(aa[0]['x']+aa[0]['width']/2),int(y)));time.sleep(.15)
                if combo.selected_text()==value:return
        if value=='51. Keypad 2 - Integer' and combo.window_text()==' Down':
            from eb_popup_local_ocr import observe
            popup,ocr=observe(pid)
            ids=[w for w in ocr['words'] if w['text']=='51' and w['x']<20]
            if len(ids)==1:
                y=ids[0]['y']+ids[0]['height']/2
                line=[w for w in ocr['words'] if abs(w['y']+w['height']/2-y)<8]
                caption=''.join(w['text'] for w in sorted(line,key=lambda w:w['x']))
                if 'Keypad2' in caption:
                    popup.click_input(coords=(40,int(y)));time.sleep(.15)
                    if combo.selected_text()==value:return
        raise ValueError('Unique observed address type item required: '+value)
    item=matches[0];container=item.parent().rectangle();rect=item.rectangle()
    if not item.is_visible() or rect.top<container.top or rect.bottom>container.bottom:
        try:item.scroll_into_view()
        except Exception as error:raise ValueError('Observed menu item cannot be brought into view: '+value) from error
        rect=item.rectangle();container=item.parent().rectangle()
    if not item.is_visible() or rect.width()<=0 or rect.height()<=0 or rect.top<container.top or rect.bottom>container.bottom:
        raise ValueError('Menu item outside observed viewport: '+value)
    item.click_input()
    for _ in range(10):
        if combo.selected_text()==value:return
        time.sleep(.1)
    raise ValueError('Custom address type readback mismatch')
