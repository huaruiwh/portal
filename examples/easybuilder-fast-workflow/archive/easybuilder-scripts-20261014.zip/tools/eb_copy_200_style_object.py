"""Copy one approved 200-page control, then bind the observed original page.

Every paste is journaled before input. Unknown paste outcomes require inspection.
The original project is never edited; this module operates only in the target.
"""
import json,re,time,ctypes,hashlib
from pywinauto.keyboard import send_keys
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save
from eb_open_page import run as open_page
from eb_page_audit import run as audit
from eb_extract import rows
from eb_native_form import tab,fields,confirm,commit_text,typed_children
from eb_page26_shapes import cancel
from eb_layout import geometry

PAGES=(204,206,210,212,218,221,224,235)
TITLES={'SP':'向量图的属性','TX':'文字/批注的属性','TS':'位状态切换开关/位状态指示灯的属性','BL':'位状态指示灯/位状态切换开关的属性','NE':'数值的属性','SW':'多状态设置的属性','DW':'矩形元件属性','TB':'表格的属性','FK':'功能键的属性'}

CMT_ONLY_VALUE_ROWS={('CheckBox','显示上下限值'),('CheckBox','显示当前数值'),('RadioButton','系统键盘'),('RadioButton','自定义键盘')}
MT_ONLY_VALUE_ROWS={('CheckBox','若输入数值超出范围时重新启动键盘')}
def numeric_adapter(rs,is_target):
 drop=MT_ONLY_VALUE_ROWS if is_target else CMT_ONLY_VALUE_ROWS
 return [r for r in rs if (r['type'],r['name']) not in drop]
def values(rs):return [(r['type'],r['name'],r['value']) for r in rs if 'value' in r]

def native_clipboard_data():
    import win32clipboard as c
    fmt=c.RegisterClipboardFormat('EBClipboardObject')
    # Clipboard ownership can change while EasyBuilder publishes its format.
    # Retry reads only; this never sends another copy or paste operation.
    last=None
    for attempt in range(4):
        opened=False
        try:
            c.OpenClipboard(ctypes.windll.user32.GetForegroundWindow())
            opened=True
            if not c.IsClipboardFormatAvailable(fmt):
                raise ValueError('Native EBClipboardObject format required; no paste sent')
            data=c.GetClipboardData(fmt)
            if not isinstance(data,bytes) or not data:
                raise ValueError('Native control clipboard data required')
            return data
        except Exception as exc:
            last=exc
        finally:
            if opened:
                try:c.CloseClipboard()
                except Exception:pass
        if attempt<3:time.sleep(.15)
    raise last

def native_clipboard_digest():return hashlib.sha256(native_clipboard_data()).hexdigest()

def restore_native_clipboard(data):
    import win32clipboard as c
    fmt=c.RegisterClipboardFormat('EBClipboardObject');c.OpenClipboard(ctypes.windll.user32.GetForegroundWindow())
    try:c.EmptyClipboard();c.SetClipboardData(fmt,data)
    finally:c.CloseClipboard()
    if native_clipboard_digest()!=hashlib.sha256(data).hexdigest():raise ValueError('Restored native control clipboard differs; no paste sent')

def read_audit(handle,page):
    try:audit(handle,{'target_page_audit':page})
    except ValueError as e:
        if str(e)!='Target object audit incomplete':raise
    return json.loads((ROOT/f'evidence/target-page{page}-audit.json').read_text(encoding='utf8'))

def run(handle,q):
    deferred=json.loads((ROOT/'tools/original-style-deferred.json').read_text(encoding='utf8'))['pages'] if (ROOT/'tools/original-style-deferred.json').exists() else []
    if int(q.get('page',0)) in deferred:q['deferred_original_appearance']=True
    if (ROOT/'tools/original-style-required.json').exists() and not q.get('local_original_template') and not q.get('deferred_original_appearance') and not (q.get('bootstrap_remaining') and q.get('page')==204 and q.get('copy_200_style_object') in ('SW_0','DW_0')) and not (q.get('bootstrap_original_lamp') and q.get('page')==204 and q.get('copy_200_style_object')=='BL_0'):raise ValueError('Latest user requires original appearance; validate original-style adapter before further copy')
    from pywinauto.timings import Timings
    Timings.after_clickinput_wait=.03
    Timings.after_setfocus_wait=.02
    started=time.monotonic()
    import faulthandler
    trace=(ROOT/'evidence/200-style-copy-slow-stack.txt').open('w',encoding='utf8')
    faulthandler.dump_traceback_later(20,repeat=True,file=trace)
    page=int(q['page']);key=q['copy_200_style_object'];kind,n=key.split('_');n=int(n)
    if page not in PAGES or kind not in TITLES:raise ValueError('Unapproved scope')
    from eb_flow_model import counts
    if n>=counts(page)[kind]:raise ValueError('Unobserved control')
    report=ROOT/f'evidence/target-{page:03d}-{kind}{n}-built.json'
    if report.exists():raise ValueError('Saved report exists; do not paste again')
    phase=ROOT/f'evidence/target-{page:03d}-{key}-copy-phase.json'
    s=json.loads((ROOT/f'evidence/source-object-properties/{page:03d}_{key}.json').read_text(encoding='utf8'))
    # Select the actual approved template with the same safety/mode semantics.
    candidates=[]
    for p in (ROOT/'evidence/source-object-properties').glob(f'200_{kind}_*.json'):
        b=json.loads(p.read_text(encoding='utf8'))
        if '安全' in s['tabs'] and values(s['tabs']['安全'])!=values(b['tabs']['安全']):continue
        if kind in ('TS','BL','NE','SW'):
            sig=lambda rs:[v for v in values(rs) if v[:2] not in (('Edit','Static'),('ComboBox','设备 :'),('ComboBox',' Down'))]
            if sig(s['tabs']['一般属性'])!=sig(b['tabs']['一般属性']):continue
        if kind=='NE' and any(values(s['tabs'][t])!=values(b['tabs'][t]) for t in ('格式','数值输入')):continue
        if kind=='FK':
            g=lambda rs:[v for v in values(rs) if v[1] not in ('显示关闭按钮',)]
            if g(s['tabs']['一般属性'])!=g(b['tabs']['一般属性']):continue
        candidates.append((int(p.stem.split('_')[-1]),b))
    operation_mode_adapter=False
    if not candidates and kind=='TS':
        desired_modes=[r['value'] for r in s['tabs']['一般属性'] if r['type']=='ComboBox' and r['name']=='操作模式 :']
        if desired_modes==['复归型']:
            for fp in (ROOT/'evidence/source-object-properties').glob('200_TS_*.json'):
                b=json.loads(fp.read_text(encoding='utf8'))
                safe=lambda rs:[v for v in values(rs) if v!=('CheckBox','操作前先确认',0)]
                if safe(s['tabs']['安全'])!=safe(b['tabs']['安全']):continue
                sig=lambda rs:[v for v in values(rs) if v[:2] not in (('Edit','Static'),('ComboBox','设备 :'),('ComboBox',' Down'),('ComboBox','操作模式 :')) and v!=('CheckBox','当按钮松开后发出指令',0)]
                if sig(s['tabs']['一般属性'])==sig(b['tabs']['一般属性']):candidates.append((int(fp.stem.split('_')[-1]),b))
            operation_mode_adapter=bool(candidates)
    if not candidates:raise ValueError(f'No verified 200 template matches source behavior: {page} {key}')
    _,base=sorted(candidates,key=lambda x:x[0])[0]
    basekey=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',base['object'])[1]
    basepage=200
    if q.get('bootstrap_original_lamp'):
        if page!=204 or key!='BL_0' or s.get('vector_identity')!=base.get('vector_identity') or s.get('state_colors')!=base.get('state_colors'):raise ValueError('Original lamp bootstrap identity/colors mismatch')
    if q.get('local_original_template'):
        if page!=204 or kind not in ('TS','BL') or n<1 or q['local_original_template']!=kind+'_0':raise ValueError('Local original appearance pilot scope 204 TS only')
        proof=json.loads((ROOT/f'evidence/original-style-204-{kind}_0.json').read_text(encoding='utf8'))
        if not proof.get('original_style_fields_verified'):raise ValueError('Local template original fields must be saved and read back')
        base=json.loads((ROOT/f'evidence/source-object-properties/204_{kind}_0.json').read_text(encoding='utf8'));basekey=kind+'_0';basepage=204
        if values(s['tabs']['安全'])!=values(base['tabs']['安全']) and not (key=='TS_21' and page==204):raise ValueError('Local template safety differs')
        signature=lambda rs:[v for v in values(rs) if v[:2] not in (('Edit','Static'),('ComboBox','设备 :'),('ComboBox',' Down'))]
        if signature(s['tabs']['一般属性'])!=signature(base['tabs']['一般属性']):raise ValueError('Local template behavior differs')
        label_sig=lambda rs:[v for v in values(rs) if v[:2] not in (('Edit',''),('ComboBox','状态 :'))]
        if s.get('state_colors')!=base.get('state_colors') or s['tabs']['图片']!=base['tabs']['图片']:
            # Property tabs contain unrelated window IDs/rectangles; compare meaningful fields and visible picture identity.
            picture=lambda x:(values(x['tabs']['图片']),[v['name'] for v in x['tabs']['图片'] if v['type']=='Text'])
            if s.get('state_colors')!=base.get('state_colors') or picture(s)!=picture(base):raise ValueError('Local template original picture/colors differ')
        if any(label_sig(rs)!=label_sig(base['label_states'][state]) for state,rs in s['label_states'].items()):raise ValueError('Local template original font/alignment differs')

    if q.get('bootstrap_remaining'):
        if page!=204 or key not in ('SW_0','DW_0'):raise ValueError('Remaining-control copy scope only204 SW0/DW0')
        tabs=('一般属性','安全','图片','标签') if kind=='SW' else (' 形状','安全')
        if any(values(s['tabs'][t])!=values(base['tabs'][t]) for t in tabs):raise ValueError('Original remaining control fields differ from200 template')
        if s.get('colors')!=base.get('colors') or s.get('rectangle_colors')!=base.get('rectangle_colors'):raise ValueError('Original remaining control color cache differs')
    clip_cache=ROOT/'evidence/200-style-native-clipboard-cache.json'
    seq=lambda:int(ctypes.windll.user32.GetClipboardSequenceNumber())
    open_page(handle,{'open_target_page':page});before=read_audit(handle,page)
    if phase.exists():
        p=json.loads(phase.read_text(encoding='utf8'))
        if not q.get('recover_existing') or p.get('stage') not in ('pasted','saved-unverified') or key in before['missing']:
            raise ValueError('Existing paste phase; inspect before recovery')
    else:
        if key not in before['missing']:raise ValueError('Existing object without report; no paste')
        existing=[int(re.search(r'(?:^|\])\s*'+kind+r'_(\d+)',x)[1]) for x in before['objects'] if re.search(r'(?:^|\])\s*'+kind+r'_\d+',x)]
        if existing!=list(range(n)):raise ValueError('Sequential native destination numbering required')
        cached=json.loads(clip_cache.read_text(encoding='utf8')) if clip_cache.exists() else {}
        reuse=cached.get('target_handle')==handle and cached.get('template')==basekey and cached.get('sequence')==seq() and cached.get('verified') is True
        if not reuse:
            open_page(handle,{'open_target_page':basepage});root,w=target(handle,basepage)
            d,_=properties(root,w,basekey,TITLES[kind]);cancel(d)
            for _ in range(20):
                if root.is_enabled():break
                time.sleep(.1)
            else:raise ValueError('Template dialog did not close; no copy sent')
            root.set_focus();time.sleep(.15);send_keys('^c',pause=.04);time.sleep(.2)
        copied_data=native_clipboard_data();copied_digest=hashlib.sha256(copied_data).hexdigest();copied_sequence=seq()
        open_page(handle,{'open_target_page':page});root,w=target(handle,page)
        restore_native_clipboard(copied_data)
        if native_clipboard_digest()!=copied_digest:raise ValueError('Native control clipboard changed while switching page; no paste sent')
        root.click_input(coords=(963,367))
        phase.write_text(json.dumps({'page':page,'key':key,'template':basekey,'stage':'paste_requested'}),encoding='utf8')
        send_keys('^v',pause=.04);time.sleep(.2);root.click_input(coords=(963,367));send_keys('{ESC}',pause=.02)
        after=read_audit(handle,page)
        if after['target_count']!=before['target_count']+1 or key in after['missing'] or after['unexpected']:
            raise ValueError('Paste count mismatch; inspect journal, do not repeat')
        phase.write_text(json.dumps({'page':page,'key':key,'template':basekey,'stage':'pasted'}),encoding='utf8')
    root,w=target(handle,page);d,_=properties(root,w,key,TITLES[kind]);expected={};captured={}
    from eb_page26_shapes import native_rows
    if page==204 and key=='TS_21':
        tab(d,'安全')
        desired=[r for r in s['tabs']['安全'] if r['type']=='CheckBox' and r['name']=='使用寄存器状态/数值']
        if len(desired)!=1 or desired[0]['value']!=0:raise ValueError('OriginalTS21 register-enable condition not reviewed')
        fields(d,desired);time.sleep(.2)
    tab(d,'轮廓');copied_bounds={r['name']:r['value'] for r in native_rows(d) if r['type']=='Edit' and r['name'] in (' 宽度 :','高度 :')}
    if kind in ('TS','BL','NE','SW'):
        tab(d,'一般属性')
        if operation_mode_adapter:
            fields(d,[r for r in s['tabs']['一般属性'] if r['type']=='ComboBox' and r['name']=='操作模式 :'])
            expected['operation_mode']='复归型'
        for typ,name in [('ComboBox','设备 :'),('ComboBox',' Down'),('Edit','Static')]:
            wanted=[r for r in s['tabs']['一般属性'] if (r['type'],r['name'])==(typ,name)]
            same=values(wanted)==values([r for r in base['tabs']['一般属性'] if (r['type'],r['name'])==(typ,name)])
            if not (q.get('local_original_template') and same):fields(d,wanted)
        expected['一般属性']=[r['value'] for r in s['tabs']['一般属性'] if r['type']=='Edit' and r['name']=='Static']
    if kind=='TX':
        tab(d,'文字/批注');want=next(r['value'] for r in s['tabs']['文字/批注'] if r['type']=='Edit' and r.get('class')=='RichEdit20W')
        editor=next(r for r in rows(d) if r['type']=='Edit' and r.get('class')=='RichEdit20W');commit_text(d,editor['name'],want);expected['caption']=want
    if kind in ('TS','BL','SW','FK'):
        tab(d,'标签');use=next(r for r in s['tabs']['标签'] if r['type']=='CheckBox' and r['name']=='使用文字标签');fields(d,[use])
        if use['value']:
            states=[c for c in typed_children(d,'ComboBox') if c.window_text()=='状态 :' and c.is_visible()]
            if len(states)!=1:raise ValueError('Unique label state required')
            expected['labels']={}
            for state,rs in s.get('label_states',{'0':s['tabs']['标签']}).items():
                ComboBoxWrapper(states[0].handle).select(state);time.sleep(.2)
                want=next(r['value'] for r in rs if r['type']=='Edit' and r['name']=='')
                if q.get('bootstrap_original_lamp'):
                    from eb_original_style_existing import label_fields
                    fields(d,[r for r in label_fields(rs) if (r['type'],r['name'])!=('Edit','')])
                commit_text(d,'',want);send_keys('{TAB}',pause=.02);time.sleep(.1);expected['labels'][state]=want
    if kind=='TB':
        tab(d,'一般属性');fields(d,s['tabs']['一般属性'],skip=(('ComboBox','样式 :'),))
        expected['table']=[r for r in s['tabs']['一般属性'] if r['type']=='Edit']
    # Labels first, then restore observed source bounds. Numeric native height
    # uses the approved 200 template's saved minimum (30px).
    tab(d,'轮廓');shape=geometry(s)
    if q.get('rebuild_original_buttons'):
        layout=json.loads((ROOT/'evidence/scale-890x469/page-218.json').read_text(encoding='utf8'))
        ratio=469/int(layout['before']['高度 :'])
        shape[' Y :']=str(round(int(shape[' Y :'])*ratio))
        shape['高度 :']=str(max(1,round(int(shape['高度 :'])*ratio)))
    if page==204 and kind=='BL' and shape[' 宽度 :']=='15':shape[' 宽度 :']='16'
    if page==204 and key in ('BL_6','BL_7','BL_8','BL_9') and shape['高度 :']=='46':shape['高度 :']='52'
    if kind=='NE' and q.get('rebuild_original_numeric'):
        tab(d,'字体')
        fields(d,[r for r in s['tabs']['字体'] if r['type']=='ComboBox' and r['name']!='尺寸 :'])
        from eb_scale_post200 import fonts
        layout=json.loads((ROOT/'evidence/scale-890x469/218_TB_0.json').read_text(encoding='utf8'))
        ratio=int(layout['after']['高度 :'])/int(layout['before']['高度 :'])
        source_size=next(r['value']for r in s['tabs']['字体']if r['type']=='ComboBox'and r['name']=='尺寸 :')
        fonts(d,['字体'],{'字体':{'None':{'size':source_size}}},ratio)
        source_height=int(shape['高度 :']);native_height=max(30,round(source_height*ratio))
        center=int(layout['after'][' Y :'])+(int(shape[' Y :'])+source_height/2-int(layout['before'][' Y :']))*ratio
        shape[' Y :']=str(round(center-native_height/2))
        shape['高度 :']=str(native_height)
        tab(d,'轮廓')
    elif kind=='NE':shape.update({' 宽度 :':'74','高度 :':'30'})
    elif kind in ('TS','SW','FK') and not q.get('rebuild_original_buttons') and not q.get('local_original_template') and not q.get('bootstrap_remaining'):shape.update(copied_bounds)
    fields(d,[{'type':'Edit','name':k,'value':v} for k,v in shape.items()]);expected['shape']=shape
    confirm(d);save(root)
    phase.write_text(json.dumps({'page':page,'key':key,'template':basekey,'stage':'saved-unverified'}),encoding='utf8')
    d,_=properties(root,w,key,TITLES[kind])
    if kind in ('TS','BL','NE','SW'):
        tab(d,'一般属性')
        from eb_live_fields import capture
        wants=[('Edit','Static'),('ComboBox','设备 :'),('ComboBox',' Down')]
        if kind=='TS':wants.append(('ComboBox','操作模式 :'))
        captured['一般属性']=capture(d,wants)
        if kind=='TS' and [r['value'] for r in captured['一般属性'] if r['name']=='操作模式 :']!=[r['value'] for r in s['tabs']['一般属性'] if r['name']=='操作模式 :' and r['type']=='ComboBox']:raise ValueError('Saved switch operation mode differs from original')
        if [r['value'] for r in captured['一般属性'] if r['type']=='Edit' and r['name']=='Static']!=expected['一般属性']:raise ValueError('Saved address differs')
        for name in ('设备 :',' Down'):
            if [r['value'] for r in captured['一般属性'] if r['type']=='ComboBox' and r['name']==name]!=[r['value'] for r in s['tabs']['一般属性'] if r['type']=='ComboBox' and r['name']==name]:raise ValueError('Saved address device/type differs')
    if kind=='TX':
        tab(d,'文字/批注');captured['文字/批注']=rows(d)
        if not any(r.get('class')=='RichEdit20W' and r.get('value')==expected['caption'] for r in captured['文字/批注']):raise ValueError('Saved caption differs')
    if 'labels' in expected:
        tab(d,'标签');states=[c for c in typed_children(d,'ComboBox') if c.window_text()=='状态 :' and c.is_visible()]
        for state,want in expected['labels'].items():
            ComboBoxWrapper(states[0].handle).select(state);time.sleep(.2)
            from eb_original_style_existing import form_rows
            observed=form_rows(d)
            if not any(r['type']=='Edit' and r['name']=='' for r in observed):observed=rows(d)
            if not any(r['type']=='Edit' and r['name']=='' and str(r.get('value','')).replace('\r\n','\n').replace('\r','\n')==want.replace('\r\n','\n').replace('\r','\n') for r in observed):raise ValueError('Saved label differs')
            if kind in ('TS','SW','FK'):
                captured.setdefault('deferred_appearance',{}).setdefault('label_size',[]).append([r.get('value') for r in observed if r['name']=='尺寸 :'])
                if not any(r['name']=='尺寸 :' and r.get('value')=='13' for r in observed) and not q.get('deferred_original_appearance'):raise ValueError('Copied button label is not approved 13pt')
                captured.setdefault('deferred_appearance',{}).setdefault('label_font',[]).append([r.get('value') for r in observed if r['name']=='字体 :'])
                if not any(r['name']=='字体 :' and r.get('value')=='微软正黑体 Light' for r in observed) and not q.get('deferred_original_appearance'):raise ValueError('Copied button font differs from page200')
    if kind=='NE':
        for t in ('格式','数值输入','字体'):
            tab(d,t)
            from eb_original_style_existing import form_rows
            captured[t]=form_rows(d)
            if t!='字体' and values(numeric_adapter(captured[t],True))!=values(numeric_adapter(s['tabs'][t],False)):captured[t]=rows(d)
            if t!='字体':
                captured.setdefault('presentation_adapter',{})[t]='reviewed cMT/MT numeric input row adapter'
                if values(numeric_adapter(captured[t],True))!=values(numeric_adapter(s['tabs'][t],False)):raise ValueError('Copied numeric format/input behavior differs')
        captured.setdefault('deferred_appearance',{})['numeric_font_size']=[r.get('value') for r in captured['字体'] if r['name']=='尺寸 :']
        if not any(r['name']=='尺寸 :' and r.get('value')=='13' for r in captured['字体']) and not q.get('deferred_original_appearance'):raise ValueError('Copied numeric font size differs from page200')
    if kind=='TB':
        tab(d,'一般属性')
        if page==204 and kind=='BL':
            from eb_live_fields import capture
            captured['一般属性']=capture(d,[('Edit','Static'),('ComboBox','设备 :'),('ComboBox',' Down')])
        else:captured['一般属性']=rows(d)
        if values([r for r in captured['一般属性'] if r['type']=='Edit'])!=values(expected['table']):raise ValueError('Saved table row/column counts differ')
    if '安全' in s['tabs']:
        tab(d,'安全')
        from eb_original_style_existing import form_rows
        captured['安全']=form_rows(d)
        if operation_mode_adapter and not any(r['name']=='操作前先确认' and 'value' in r for r in s['tabs']['安全']):
            extras=[r for r in captured['安全'] if r['type']=='CheckBox' and r['name']=='操作前先确认']
            if any(r.get('value')!=0 for r in extras):raise ValueError('Unexpected active confirmation condition after reset-mode adaptation')
            captured['inactive_mode_controls']=extras
            captured['安全']=[r for r in captured['安全'] if r not in extras]
        # Compare to already verified actual template, allowing cMT's absent
        # extra bit/word selector only through its previously recorded adapter.
        expected_safety=values(s['tabs']['安全'])
        if values(captured['安全'])!=expected_safety:
            down=0;adapted=[]
            for v in expected_safety:
                if v[:2]==('ComboBox',' Down'):
                    down+=1
                    if down==5 and v[2]=='位':continue
                if v[:2]==('CheckBox','使用控制权'):continue
                adapted.append(v)
            captured['safety_adapted_rows']=[list(v[:2]) for v in expected_safety if v[:2] not in [x[:2] for x in values(captured['安全'])]]
            if values(captured['安全'])!=adapted:
                captured['安全']=rows(d)
                if operation_mode_adapter and not any(r['name']=='操作前先确认' and 'value' in r for r in s['tabs']['安全']):
                    if any(r.get('value')!=0 for r in captured['安全'] if r['type']=='CheckBox' and r['name']=='操作前先确认'):raise ValueError('Unexpected active confirmation condition')
                    captured['安全']=[r for r in captured['安全'] if not(r['type']=='CheckBox' and r['name']=='操作前先确认')]
                if values(captured['安全'])not in (expected_safety,adapted):raise ValueError('Saved safety differs from original')
    tab(d,'轮廓')
    from eb_speed_benchmark import cached_edits,native_edit_read
    captured['轮廓']=[{'type':'Edit','name':k,'value':v}for k,v in native_edit_read(cached_edits(d,tuple(shape))).items()]
    if {r['name']:r['value'] for r in captured['轮廓'] if r['type']=='Edit' and r['name'] in shape}!=shape:raise ValueError('Saved geometry differs')
    cancel(d)
    report.write_text(json.dumps({'page':page,'source':s['object'],'target':key,'template':f'{basepage}/{basekey}','expected':expected,'tabs':captured,'saved_requested':True,'saved_reopened_verified':True,'appearance_inherited_from_user_approved_200':basepage==200,'original_appearance_deferred':bool(q.get('deferred_original_appearance')),'original_style_fields_verified':basepage==204,'gallery_identity_review_pending':basepage==204,'table_custom_grid_review_pending':kind=='TB','runtime_verified':False,'elapsed_seconds':round(time.monotonic()-started,3)},ensure_ascii=False,indent=2),encoding='utf8')
    phase.write_text(json.dumps({'page':page,'key':key,'template':basekey,'stage':'verified'}),encoding='utf8')
    if not q.get('recover_existing') and native_clipboard_digest()==copied_digest:
        clip_cache.write_text(json.dumps({'target_handle':handle,'template':basekey,'sequence':seq(),'sha256':copied_digest,'verified':True,'proof':report.name}),encoding='utf8')
