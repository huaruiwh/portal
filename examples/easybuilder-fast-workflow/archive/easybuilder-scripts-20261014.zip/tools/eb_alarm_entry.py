"""Observed 120-DPI ribbon entry, scoped to alarm/background target pages."""
import json,time
from pywinauto import Desktop
from eb_object_ui import target,dialog
from eb_extract import ROOT,rows
def run(handle,q):
    page=int(q['page']);root,w=target(handle,page)
    if page not in (10,11,102,103) or (root.rectangle().width(),root.rectangle().height())!=(1848,1281):raise ValueError('Reviewed page/window required')
    root.set_focus()
    if q['alarm_entry']=='history_tab':root.click_input(coords=(437,52))
    elif q['alarm_entry'] in ('ED','AB'):
        kind=q['alarm_entry']
        if kind=='ED' and page!=102 or kind=='AB' and page not in (10,11,103):raise ValueError('Reviewed kind/page required')
        root.click_input(coords=(437,52));time.sleep(.15)
        root.click_input(coords=(346,145 if kind=='ED' else 87))
        d=dialog(root.process_id(),'新增 事件显示' if kind=='ED' else '新增 报警条')
        from eb_native_form import tab
        tabs={}
        for name in [c.window_text() for c in d.descendants(control_type='TabItem') if c.is_visible()]:
            tab(d,name);tabs[name]=rows(d)
        (ROOT/'evidence'/f'new-{page}-{kind}-defaults.json').write_text(json.dumps({'tabs':tabs,'handle':d.handle},ensure_ascii=False,indent=2),encoding='utf8')
    else:raise ValueError('Unreviewed entry')
    time.sleep(.2)

def details(handle,q):
    d=Desktop(backend='uia').window(handle=handle).wrapper_object()
    if d.window_text() not in ('事件显示的属性','新增 事件显示','新增 功能键','新增 报警条','新增 日期/时间'):raise ValueError('Observed reviewed dialog required')
    from eb_native_form import tab
    result={}
    for name in q['event_details']:
        tab(d,name)
        result[name]=[]
        for c in d.descendants(cache_enable=True):
            if not c.is_visible():continue
            r={'type':c.element_info.control_type,'name':c.window_text(),'class':c.element_info.class_name,'handle':c.handle,'rect':[c.rectangle().left,c.rectangle().top,c.rectangle().right,c.rectangle().bottom]}
            if r['type']=='DataItem':
                for attr in ('iface_value','iface_toggle'):
                    try:r[attr]=c.iface_value.CurrentValue if attr=='iface_value' else c.iface_toggle.CurrentToggleState
                    except Exception:pass
            result[name].append(r)
        result[name].append({'native_rows':rows(d)})
    (ROOT/'evidence'/('event-source-details.json' if d.window_text()=='事件显示的属性' else 'event-target-details.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
