"""Build only reviewed local test pages, compile and reopen sample properties."""
import json,time
from eb_rebuild_page import ROOT,call,run as build

def run(verify_only=False):
    review=json.loads((ROOT/'evidence/local-tests-48-49-source-review.json').read_text(encoding='utf8'))
    if not review['ok']:raise ValueError('Source template validation required')
    def target():
        call('snapshot')
        ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
        found=[w for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
        if len(found)!=1:raise ValueError('One exact target required')
        return found[0]
    def ui(w,q):return call('uia',w['handle'],json.dumps(q,ensure_ascii=False))
    w=target();ui(w,{'restore_target_window':True,'reviewed_size':True})
    if not verify_only:
        for page in (48,49):
            build(page);w=target();ui(w,{'page':page,'order_sp':0,'kind':'SW'})
            print(json.dumps({'page':page,'saved_directory':True}),flush=True)
        w=target();ui(w,{'compile_target':True,'start_only':True});time.sleep(2)
        ui(w,{'compile_target':True,'capture_result':True,'expected_pid':w['pid']})
    else:
        compilation=json.loads((ROOT/'evidence/latest-project-compile.json').read_text(encoding='utf8'))
        if not compilation['ok'] or not compilation['compilation_succeeded']:raise ValueError('Successful saved compile required')
    old=w['pid'];call('keys',w['handle'],'%{F4}');call('launch',value=str(ROOT/'output/组装机_MT8106iP.emtp'))
    for _ in range(20):
        try:
            w=target()
            if w['pid']!=old:break
        except ValueError:pass
        time.sleep(.5)
    else:raise ValueError('New target process required')
    ui(w,{'restore_target_window':True,'reviewed_size':True})
    from eb_verify_local_reopened import run as verify_reopened
    verify_reopened()

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--verify-only',action='store_true')
    run(parser.parse_args().verify_only)
