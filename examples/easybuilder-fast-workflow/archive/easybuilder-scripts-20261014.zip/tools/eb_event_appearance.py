"""Read/synchronize event acknowledgment colors on existing ED0/AB0 only."""
import json
from pywinauto import Desktop
from eb_extract import ROOT
from eb_native_form import tab,confirm
from eb_color_picker import probe,set_rgb
from eb_object_ui import target,properties,save

def run(handle,q):
 key=q['event_appearance'];page=102 if key=='ED_0' else 103
 if key not in ('ED_0','AB_0'):raise ValueError('Reviewed alarm object required')
 spec=json.loads((ROOT/f'evidence/source-object-properties/{page}_{key}.json').read_text(encoding='utf8'))
 source=bool(q.get('source_open'))
 if source:
  d=Desktop(backend='uia').window(handle=handle).wrapper_object()
  roots=[w.window_text() for w in Desktop(backend='win32').windows(visible_only=False) if w.process_id()==d.process_id() and w.class_name()=='EasyBuilderPro']
  if not any('组装机2台15工位取消.cmtp' in t for t in roots) or d.window_text()!=spec['dialog_title']:raise ValueError('Reviewed source property dialog required')
 else:
  root,w=target(handle,page);d,_=properties(root,w,key,spec['dialog_title'])
 name='事件显示' if key=='ED_0' else '报警';tab(d,name)
 result={'object':key,'page':page,'colors':[],'source':source}
 try:
  for i in (0,1):
   before=probe(d,'文字颜色 :',i)
   if not source and not q.get('verify_only'):
    expected=json.loads((ROOT/f'evidence/source-{key}-event-colors.json').read_text(encoding='utf8'))['colors'][i]['rgb']
    if before!=expected:set_rgb(d,expected,'文字颜色 :',i)
    after=probe(d,'文字颜色 :',i) if before!=expected else before
    if after!=expected:raise ValueError('Event acknowledgment RGB mismatch')
   else:
    after=before
    if not source:
     expected=json.loads((ROOT/f'evidence/source-{key}-event-colors.json').read_text(encoding='utf8'))['colors'][i]['rgb']
     if after!=expected:raise ValueError('Reopened event acknowledgment RGB mismatch')
   result['colors'].append({'state':'acknowledged' if i==0 else 'returned_normal','rgb':after,'before':before})
  if source or q.get('verify_only'):
   cs=[c for c in d.descendants(control_type='Button') if c.window_text()=='取消' and c.is_visible()]
   if len(cs)!=1:raise ValueError('Cancel required')
   cs[0].click_input()
  else:confirm(d);save(root)
 except Exception:raise
 (ROOT/f'evidence/{"source" if source else "target"}-{key}-event-colors.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
