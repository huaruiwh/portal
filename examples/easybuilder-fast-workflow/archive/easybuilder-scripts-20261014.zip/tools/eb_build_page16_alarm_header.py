"""Render the cMT alarm title using three ordinary MT objects, with source colours."""
import json,re,time
from pywinauto import Desktop
from pywinauto.keyboard import send_keys
from eb_extract import ROOT,rows
from eb_object_ui import target,dialog,properties,placed_properties,save
from eb_native_form import tab,fields,confirm,commit_text
from eb_color_picker import set_rgb,probe

def run(handle,q):
 source=json.loads((ROOT/'evidence/source-object-properties/016_AL_0.json').read_text(encoding='utf8'))
 body=json.loads((ROOT/'evidence/target-016-AL0-built.json').read_text(encoding='utf8'))
 if not body['saved_requested'] or body['header_height']!=24:raise ValueError('Saved adapted native alarm body required')
 root,w=target(handle,16);whole=body['whole_source_geometry'];x=int(whole['X :']);y=int(whole[' Y :']);width=int(whole[' 宽度 :'])
 p=ROOT/'evidence/page16-alarm-header-adaptation.json'
 plan=json.loads(p.read_text(encoding='utf8')) if p.exists() else {'source':'AL_0','objects':['DW_5','TX_31','TX_32'],'completed':[],'ok':False,'source_header_text_colour':source['colors']['文字颜色 : '],'source_header_background':source['colors']['背景颜色 : '],'header_height':24,'model_reason':'MT native alarm lacks cMT header settings; preserve visible header as static components'}
 p.write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf8')
 def colour(d,label,rgb,occurrence=0):
  result=set_rgb(d,rgb,label,occurrence);actual=result['after'] if result.get('already_equal') else probe(d,label,occurrence)
  if actual!=rgb:raise ValueError('Alarm header native RGB mismatch')
  return actual
 if q['header_part']=='background':
  if 'DW_5' in plan['completed']:raise ValueError('Saved header background exists; never create again')
  if not q.get('resume'):
   palettes=[v for v in Desktop(backend='win32').windows() if v.process_id()==root.process_id() and v.is_visible() and v.window_text()=='属性']
   if not palettes:
    root.set_focus();send_keys('{ESC}',pause=.01);root.click_input(coords=(373,52));root.click_input(coords=(54,118))
    for _ in range(15):
     palettes=[v for v in Desktop(backend='win32').windows() if v.process_id()==root.process_id() and v.is_visible() and v.window_text()=='属性']
     if palettes:break
     time.sleep(.1)
   if len(palettes)!=1:raise ValueError('Unique rectangle palette required')
   palettes[0].move_window(x=1900,y=40);root.click_input(coords=(600,500));root.click_input(coords=(700,550));send_keys('{ESC}',pause=.01)
  d,name=properties(root,w,'DW_5','矩形元件属性');shape_tabs=[c.window_text() for c in d.descendants(control_type='TabItem') if c.is_visible() and c.window_text().strip()=='形状']
  if len(shape_tabs)!=1:raise ValueError('One header shape tab required')
  tab(d,shape_tabs[0])
  fields(d,[{'type':'CheckBox','name':'填充','value':1},{'type':'ComboBox','name':'圆角宽度 :','value':'0'}])
  colours={'fill':colour(d,'颜色 :',source['colors']['背景颜色 : '],0),'border':colour(d,'颜色 :',source['colors']['外框颜色 :'],1)}
  tab(d,'安全');fields(d,[{'type':'CheckBox','name':'使用寄存器状态/数值','value':0}]);safety=rows(d)
  tab(d,'轮廓');expected={'X :':str(x),' Y :':str(y),' 宽度 :':str(width),'高度 :':'24'};fields(d,[{'type':'Edit','name':k,'value':v} for k,v in expected.items()]);readback=rows(d)
  actual={r['name']:r['value'] for r in readback if r['type']=='Edit' and r['name'] in expected}
  if actual!=expected:raise ValueError('Header background geometry mismatch')
  confirm(d);save(root);plan['background']={'target':name,'colours':colours,'geometry':actual,'safety':safety,'saved_requested':True};plan['completed'].append('DW_5')
 elif q['header_part']=='text':
  n=int(q['header_text']);key=f'TX_{n}'
  if n not in (31,32) or key in plan['completed']:raise ValueError('Only unsaved header text may be created')
  if 'DW_5' not in plan['completed']:raise ValueError('Saved header background required')
  if not q.get('resume'):
   from eb_ribbon import create
   create(root,'TX','新增 文字/批注')
  d=dialog(root.process_id(),'新增 文字/批注');tab(d,'文字/批注')
  font=next(r['value'] for r in source['tabs']['字体'] if r['type']=='ComboBox' and r['name']=='字体 :')
  font=re.sub(r'\s*\[.*$','',font);size=next(r['value'] for r in source['tabs']['字体'] if r['type']=='ComboBox' and r['name']=='尺寸 :')
  caption='时间' if n==31 else '讯息'
  fields(d,[{'type':'CheckBox','name':'使用文字库 ','value':0},{'type':'ComboBox','name':'字体 :','value':font},{'type':'ComboBox','name':'尺寸 :','value':size},{'type':'CheckBox','name':'斜体','value':0},{'type':'CheckBox','name':'下划线','value':0}]);commit_text(d,'内容',caption)
  rgb=colour(d,'颜色 :',source['colors']['文字颜色 : ']);text_readback=rows(d)
  tab(d,'安全');fields(d,[{'type':'CheckBox','name':'使用寄存器状态/数值','value':0},{'type':'ComboBox','name':'用户限制 Down','value':'无'}]);safety=rows(d);confirm(d)
  d,name=placed_properties(root,w,key,'文字/批注的属性');tab(d,'文字/批注')
  if next(r['value'] for r in rows(d) if r['type']=='Edit' and r['name']=='内容')!=caption:raise ValueError('Header caption readback mismatch')
  tab(d,'轮廓');expected={'X :':str(x+(10 if n==31 else 94)),' Y :':str(y+3)};fields(d,[{'type':'Edit','name':k,'value':v} for k,v in expected.items()]);readback=rows(d)
  actual={r['name']:r['value'] for r in readback if r['type']=='Edit' and r['name'] in expected}
  if actual!=expected:raise ValueError('Header caption geometry mismatch')
  confirm(d);save(root);plan[key]={'target':name,'caption':caption,'font':font,'size':size,'colour':rgb,'geometry':actual,'text':text_readback,'safety':safety,'saved_requested':True};plan['completed'].append(key)
 else:raise ValueError('Unreviewed header stage')
 plan['ok']=set(plan['completed'])==set(plan['objects']);p.write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf8')
 if plan['ok']:
  body['header_pending']=False;body['header_adaptation']=str(p.relative_to(ROOT));(ROOT/'evidence/target-016-AL0-built.json').write_text(json.dumps(body,ensure_ascii=False,indent=2),encoding='utf8')
