"""Build only the validated SW/BL subset on a mixed page; never claim page completion."""
import json,re,sys
from eb_rebuild_page import ROOT,call
def run(page):
    if page!=17:raise ValueError('Only reviewed mixed page17 supported')
    lock=ROOT/'tools'/'batch.lock'
    with lock.open('x'):pass
    path=ROOT/'evidence'/f'page-{page}-subset-workflow.json'
    report={'page':page,'completed':[],'ok':False,'whole_page_complete':False}
    def save():path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    try:
        call('snapshot');ws=json.loads((ROOT/'evidence'/'windows.json').read_text(encoding='utf8'))
        hs=[w['handle'] for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
        if len(hs)!=1:raise ValueError('Unique target required')
        h=hs[0]
        def ui(q):call('uia',h,json.dumps(q,ensure_ascii=False))
        inv=json.loads((ROOT/'evidence'/'source-pages-inventory.json').read_text(encoding='utf8'))
        names=next(p['observed_objects'] for p in inv['pages'] if p['id']==page)
        from eb_template_guard import validate_object
        objects=[re.match(r'^(SW|BL)_(\d+)\s',name).groups() for name in names if re.match(r'^(SW|BL)_\d+\s',name)]
        for kind,n in objects:validate_object(page,kind,int(n))
        if not (ROOT/'evidence'/f'target-page-{page:03d}-size.json').exists():ui({'target_page_size':page})
        ui({'open_target_page':page})
        for kind in ('SW','BL'):
            for n in sorted(int(n) for k,n in objects if k==kind):
                report['stage']=f'{kind}_{n}';save()
                if not (ROOT/'evidence'/f'target-{page:03d}-{kind}{n}-built.json').exists():ui({'page':page,'build_'+kind.lower():n})
                report['completed'].append(f'{kind}_{n}');save()
        from eb_verify_page import run as verify
        verify(page,subset=True)
        report['ok']=True;report['stage']='saved subset parameters audited';save()
        print(json.dumps({'ok':True,'page':page,'subset_objects':len(report['completed']),'whole_page_complete':False}))
    except Exception as e:
        report['error']=str(e);save();print(json.dumps({'ok':False,'stage':report.get('stage'),'report':str(path)}));raise
    finally:lock.unlink(missing_ok=True)
if __name__=='__main__':run(int(sys.argv[1]))
