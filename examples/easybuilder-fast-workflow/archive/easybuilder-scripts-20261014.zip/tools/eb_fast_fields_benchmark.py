"""Read-only comparison on the saved TS_1; no paste, edits, or project save."""
import json,time
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties
from eb_native_form import tab
from eb_page26_shapes import cancel
from eb_live_fields import capture as old_capture
from eb_fast_fields import bind,read

def run(handle,q):
    if q.get('compact_capture'):
        from eb_compact_capture_trial import run as trial
        return trial(handle,q)
    root,w=target(handle,201)
    if not root.is_enabled():raise ValueError('Modal present; no benchmark started')
    if q.get('final_audit'):
        from eb_copy_200_style_object import read_audit
        read_audit(handle,201)
        return
    if q.get('geometry_write_comparison'):
        geometry_write_comparison(root,w,q)
        return
    if q.get('geometry_save_roundtrip'):
        geometry_save_roundtrip(root,w)
        return
    if q.get('duration_inspect'):
        d,_=properties(root,w,'TS_1','位状态切换开关/位状态指示灯的属性')
        try:
            tab(d,'安全')
            if q.get('duration_select'):
                cs=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name==' Down'and c.is_visible()]
                if len(cs)!=1:raise ValueError('Unique duration combo required')
                c=cs[0]
                if q.get('duration_expand'):c.expand()
                items=[v for v in c.descendants()if v.element_info.control_type=='ListItem']
                data={'before':c.selected_text(),'items':[{'name':v.element_info.name,'visible':v.is_visible()}for v in items]}
                candidates=[v for v in items if v.element_info.name=='1']
                if len(candidates)==1:
                    if candidates[0].is_visible():candidates[0].click_input()
                    else:candidates[0].select()
                    data['after']=c.selected_text()
                    data['fresh']=old_capture(d,[('ComboBox',' Down')])
                    data['selected']=[v.element_info.name for v in c.descendants(control_type='ListItem')if v.is_selected()]
                (ROOT/'evidence/duration-selection-probe.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
                return
            rows=[]
            for c in d.descendants(cache_enable=True):
                if c.is_visible() and c.element_info.control_type in ('Edit','ComboBox'):
                    rows.append({'type':c.element_info.control_type,'name':c.element_info.name,'class':c.element_info.class_name,'handle':c.element_info.handle,'rect':[c.rectangle().left,c.rectangle().top,c.rectangle().right,c.rectangle().bottom],'children':[{'type':v.element_info.control_type,'name':v.element_info.name,'class':v.element_info.class_name,'handle':v.element_info.handle}for v in c.children()]})
            (ROOT/'evidence/duration-fields-inspection.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
        finally:cancel(d)
        return
    result={'page':201,'object':'TS_1','changed':False,'tabs':[]}
    if q.get('native_ids'):
        return native_benchmark(root,w)
    d,_=properties(root,w,'TS_1','位状态切换开关/位状态指示灯的属性')
    try:
        jobs=[('一般属性',[('Edit','Static'),('ComboBox','设备 :'),('ComboBox',' Down'),('ComboBox','操作模式 :'),('CheckBox','输出反向'),('CheckBox','触发宏指令')]),('标签',[('Edit',''),('ComboBox','字体 :'),('ComboBox','尺寸 :')]),('轮廓',[('Edit',v)for v in ('X :',' Y :',' 宽度 :','高度 :')])]
        for name,wants in jobs:
            tab(d,name);row={'tab':name}
            start=time.perf_counter();expected=old_capture(d,wants);row['old_capture_seconds']=time.perf_counter()-start
            start=time.perf_counter();refs=bind(d,wants);row['bind_seconds']=time.perf_counter()-start
            times=[]
            for _ in range(2):
                start=time.perf_counter();actual=read(refs);times.append(time.perf_counter()-start)
                if actual!=expected:raise ValueError('Fast fields differ '+name)
            row.update(read_seconds=times,fields_equal=True,fields=expected);result['tabs'].append(row)
    finally:cancel(d)
    (ROOT/'evidence/fast-fields-benchmark.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')

def native_benchmark(root,w):
    from eb_native_id_fields import learn,read as native_read
    jobs=[('一般属性',[('Edit','Static'),('ComboBox','设备 :'),('ComboBox','操作模式 :')]),('标签',[('Edit',''),('ComboBox','字体 :'),('ComboBox','尺寸 :')]),('轮廓',[('Edit',v)for v in ('X :',' Y :',' 宽度 :','高度 :')])]
    result={'page':201,'object':'TS_1','changed':False,'tabs':[]};schemas={};expected_by_tab={}
    d,_=properties(root,w,'TS_1','位状态切换开关/位状态指示灯的属性')
    try:
        for name,wants in jobs:
            tab(d,name);start=time.perf_counter();expected=old_capture(d,wants);row={'tab':name,'old_capture_seconds':time.perf_counter()-start}
            expected_by_tab[name]=expected
            start=time.perf_counter();schema=learn(d,wants);row['learn_seconds']=time.perf_counter()-start;schemas[name]=schema
            times=[]
            for _ in range(2):
                start=time.perf_counter();actual=native_read(d,schema);times.append(time.perf_counter()-start)
                if actual!=expected:raise ValueError('Native identity read differs '+name)
            row.update(read_seconds=times,fields_equal=True,native_fields=len(schema['fields']),fallback_fields=schema['fallback']);result['tabs'].append(row)
    finally:cancel(d)
    # A new dialog must resolve fresh HWNDs by the learned identity, never reuse old handles.
    d,_=properties(root,w,'TS_1','位状态切换开关/位状态指示灯的属性')
    try:
        for name,wants in jobs:
            tab(d,name);start=time.perf_counter();actual=native_read(d,schemas[name]);seconds=time.perf_counter()-start
            if actual!=expected_by_tab[name]:raise ValueError('Reopened native identity differs '+name)
            next(v for v in result['tabs']if v['tab']==name).update(reopened_read_seconds=seconds,reopened_equal=True)
    finally:cancel(d)
    (ROOT/'evidence/native-id-fields-benchmark.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
    (ROOT/'evidence/button-native-field-schema.json').write_text(json.dumps(schemas,ensure_ascii=False,indent=2),encoding='utf8')

def geometry_write_comparison(root,w,q):
    """Paired actual edits in an unsaved dialog; restore, validate, then cancel."""
    import statistics
    from eb_native_form import fields
    from eb_native_id_fields import write_edits,read as native_read
    schema=json.loads((ROOT/'evidence/button-native-field-schema.json').read_text(encoding='utf8'))['轮廓']
    d,_=properties(root,w,'TS_1','位状态切换开关/位状态指示灯的属性')
    methods=('old','native','messages')if q.get('three_routes')else ('old','native')
    result={'page':201,'object':'TS_1','saved':False,'trials':[]}
    try:
        tab(d,'轮廓');original=native_read(d,schema)
        changed=[dict(r,value=str(int(r['value'])+1))if r['name']=='X :'else dict(r)for r in original]
        for n in range(3):
            for method in (methods if n%2==0 else tuple(reversed(methods))):
                start=time.perf_counter()
                if method=='old':fields(d,changed)
                else:
                    if write_edits(d,schema,changed,native_messages=method=='messages'):raise ValueError('Unexpected native geometry fallback')
                elapsed=time.perf_counter()-start
                if native_read(d,schema)!=changed:raise ValueError('Paired geometry write mismatch')
                write_edits(d,schema,original)
                if native_read(d,schema)!=original:raise ValueError('Geometry restoration mismatch')
                result['trials'].append({'method':method,'seconds':elapsed,'written_verified':True,'restored_verified':True})
        result['median_seconds']={method:statistics.median(v['seconds']for v in result['trials']if v['method']==method)for method in methods}
    finally:cancel(d)
    d,_=properties(root,w,'TS_1','位状态切换开关/位状态指示灯的属性')
    try:
        tab(d,'轮廓')
        if native_read(d,schema)!=original:raise ValueError('Saved original geometry changed after cancel')
        result['reopened_original_verified']=True
    finally:cancel(d)
    filename='geometry-write-three-route-comparison.json'if q.get('three_routes')else 'geometry-write-comparison.json'
    (ROOT/'evidence'/filename).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')

def geometry_save_roundtrip(root,w):
    from eb_native_id_fields import write_edits,read as native_read
    from eb_native_form import confirm
    from eb_object_ui import save
    schema=json.loads((ROOT/'evidence/button-native-field-schema.json').read_text(encoding='utf8'))['轮廓']
    path=ROOT/'evidence/native-message-save-roundtrip.json'
    state={'page':201,'object':'TS_3','stage':'started'}
    def persist():path.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf8')
    d,_=properties(root,w,'TS_3','位状态切换开关/位状态指示灯的属性');tab(d,'轮廓')
    original=native_read(d,schema)
    changed=[dict(r,value=str(int(r['value'])+1))if r['name']=='X :'else dict(r)for r in original]
    state.update(original=original,temporary=changed,stage='temporary-write-requested');persist()
    write_edits(d,schema,changed,native_messages=True);confirm(d);save(root)
    state['stage']='temporary-saved';persist()
    d,_=properties(root,w,'TS_3','位状态切换开关/位状态指示灯的属性');tab(d,'轮廓')
    actual=native_read(d,schema);state['temporary_reopened_verified']=actual==changed
    # Restore the real original even when the first save did not retain changes.
    write_edits(d,schema,original,native_messages=True);confirm(d);save(root)
    state['stage']='original-restored-saved';persist()
    d,_=properties(root,w,'TS_3','位状态切换开关/位状态指示灯的属性')
    try:
        tab(d,'轮廓');state['original_reopened_verified']=native_read(d,schema)==original
    finally:cancel(d)
    state['stage']='finished';persist()
    if not state['temporary_reopened_verified']or not state['original_reopened_verified']:raise ValueError('Native message save roundtrip mismatch')

