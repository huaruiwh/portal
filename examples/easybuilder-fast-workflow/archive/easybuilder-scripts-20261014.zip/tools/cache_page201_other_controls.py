import json,re,os
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
with lock.open('x',encoding='utf8')as f:f.write(json.dumps({'pid':os.getpid(),'task':'201 other cache'}))
try:
    call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'));h=next(w['handle']for w in ws if w['class']=='EasyBuilderPro'and'组装机2台15工位取消.cmtp'in w['title'])
    inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(p['observed_objects']for p in inv['pages']if p['id']==201)
    for key in ('SP_0','SP_1','DW_0','DW_1','OL_0','OL_1','SW_0','FK_0'):
        p=ROOT/f'evidence/source-object-properties/201_{key}.json'
        if not p.exists():
            name=next(v for v in names if re.search(r'(?:^|\])\s*'+key+r'(?:\s|$)',v));call('uia',h,json.dumps({'extract':{'page':201,'object':name}},ensure_ascii=False))
        s=json.loads(p.read_text(encoding='utf8'));print(json.dumps({'key':key,'tabs':list(s['tabs']),'vector':s.get('vector_identity'),'picture':s.get('picture_identity'),'colors':s.get('colors'),'rectangle':s.get('rectangle_colors')},ensure_ascii=True),flush=True)
finally:lock.unlink()
