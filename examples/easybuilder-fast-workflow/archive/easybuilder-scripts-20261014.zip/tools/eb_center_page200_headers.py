"""Center delay headers from actual rendered black glyph bounds; no image transfer."""
import json,time
from PIL import ImageGrab
from pywinauto import mouse
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save
from eb_native_form import tab,fields,confirm
from eb_extract import rows
from eb_page26_shapes import cancel

def run(handle,q):
 root,w=target(handle,200);g=json.loads((ROOT/'evidence/page200-table-grid-target.json').read_text(encoding='utf8'));xs,ys=g['vertical_lines'],g['horizontal_lines'];ox,oy=g['origin'];sx,sy=g['scale'];out=[]
 def bounds(col):
  root.set_focus();mouse.click(coords=(round(ox+880*sx),round(oy+570*sy)));time.sleep(.1)
  box=[round(ox+(xs[col]+2)*sx),round(oy+(ys[0]+2)*sy),round(ox+(xs[col+1]-2)*sx),round(oy+(ys[1]-2)*sy)]
  im=ImageGrab.grab(bbox=tuple(box)).convert('RGB');p=[(xx,yy) for yy in range(im.height) for xx in range(im.width) if max(im.getpixel((xx,yy)))<90]
  if len(p)<20:raise ValueError('Insufficient rendered header glyphs')
  return [(box[0]+min(x for x,y in p)-ox)/sx,(box[1]+min(y for x,y in p)-oy)/sy,(box[0]+max(x for x,y in p)-ox)/sx,(box[1]+max(y for x,y in p)-oy)/sy]
 for key,text,col in [('TX_11','ON延时',1),('TX_10','OFF延时',2)]:
  d,_=properties(root,w,key,'文字/批注的属性');tab(d,'文字/批注');rs=rows(d)
  if not any(r.get('value')==text for r in rs):raise ValueError('Caption identity differs')
  size=int(next(r['value'] for r in rs if r['name']=='尺寸 :' and r['type']=='ComboBox'))
  tab(d,'轮廓');before=rows(d);cancel(d)
  b=bounds(col);dx=round((xs[col]+xs[col+1]-b[0]-b[2])/2);dy=round((ys[0]+ys[1]-b[1]-b[3])/2)
  x=int(next(r['value'] for r in before if r['type']=='Edit' and r['name']=='X :'))+dx;y=int(next(r['value'] for r in before if r['type']=='Edit' and r['name']==' Y :'))+dy
  d,_=properties(root,w,key,'文字/批注的属性');tab(d,'轮廓');fields(d,[{'type':'Edit','name':'X :','value':str(x)},{'type':'Edit','name':' Y :','value':str(y)}]);confirm(d);save(root)
  d,_=properties(root,w,key,'文字/批注的属性');tab(d,'轮廓');after=rows(d)
  if any(next(r['value'] for r in after if r['type']=='Edit' and r['name']==k)!=str(v) for k,v in [('X :',x),(' Y :',y)]):raise ValueError('Saved caption position differs')
  cancel(d);final=bounds(col);error=[(final[0]+final[2]-xs[col]-xs[col+1])/2,(final[1]+final[3]-ys[0]-ys[1])/2]
  if max(abs(e) for e in error)>1.5:raise ValueError('Rendered header center differs')
  out.append({'key':key,'text':text,'column':col,'font_size':size,'rendered_bounds_before':b,'rendered_bounds_after':final,'center_error':error,'cell':[xs[col],ys[0],xs[col+1],ys[1]],'position':[x,y],'before':before,'after':after,'saved_reopened_verified':True,'image_transmitted':False})
 (ROOT/'evidence/page200-delay-header-centering.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
