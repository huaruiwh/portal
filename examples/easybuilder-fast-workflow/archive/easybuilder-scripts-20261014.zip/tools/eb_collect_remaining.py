"""Cache remaining source pages read-only; never edit or save the source."""
import json,re
from eb_rebuild_page import ROOT,call

def run():
    call('snapshot')
    ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
    found=[w for w in ws if w['class']=='EasyBuilderPro' and '组装机2台15工位取消.cmtp' in w['title']]
    if len(found)!=1:raise ValueError('Unique source required')
    def ui(q):return call('uia',found[0]['handle'],json.dumps(q,ensure_ascii=False))
    inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
    progress={'pages':{},'source_readonly':True,'ok':False}
    path=ROOT/'evidence/remaining-source-cache.json'
    for page in (100,101,102,103):
        settings=ROOT/f'evidence/source-pages-settings/{page:03d}.json'
        if not settings.exists() or 'background_rgb' not in json.loads(settings.read_text(encoding='utf8')):ui({'page_settings':page,'color_probe':True})
        names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==page)
        for name in names:
            key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)[1]
            cached=ROOT/f'evidence/source-object-properties/{page:03d}_{key}.json'
            request={'page':page,'object':name}
            if key.startswith('TX_'):request.update(colors=['颜色 :'],color_tab='文字/批注')
            if not cached.exists():ui({'extract':request})
            elif key.startswith('TX_') and 'colors' not in json.loads(cached.read_text(encoding='utf8')):
                request['only_color']=True;ui({'extract':request})
            progress['current']=f'{page}:{key}';path.write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf8')
        progress['pages'][str(page)]={'objects':len(names),'cached':True}
        print(json.dumps({'page':page,'cached':len(names)},ensure_ascii=False),flush=True)
    progress['ok']=True;path.write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf8')

if __name__=='__main__':run()
