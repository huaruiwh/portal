import json,time
from PIL import ImageFont
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save,object_item,menu
from eb_native_form import tab,fields,confirm
from eb_extract import rows
from eb_page26_shapes import cancel

def run(handle,q):
 root,w=target(handle,200)
 from pywinauto import Desktop
 for win in Desktop(backend='win32').windows():
  if win.process_id()==root.process_id() and win.is_visible() and win.window_text()=='文字/批注的属性':cancel(Desktop(backend='uia').window(handle=win.handle).wrapper_object())
 if q.get('title_render_probe'):
  from PIL import ImageGrab
  from pywinauto import mouse
  g=json.loads((ROOT/'evidence/page200-table-grid-target.json').read_text(encoding='utf8'));ox,oy=g['origin'];sx,sy=g['scale']
  root.set_focus();mouse.click(coords=(round(ox+880*sx),round(oy+570*sy)));time.sleep(.1)
  box=[round(ox+185*sx),round(oy+45*sy),round(ox+370*sx),round(oy+64*sy)]
  im=ImageGrab.grab(bbox=tuple(box)).convert('RGB');cs=[]
  for xx in range(im.width):
   canvasx=(box[0]+xx-ox)/sx
   if abs(canvasx-199)<2 or abs(canvasx-319)<2:continue
   if sum(1 for yy in range(im.height) if max(im.getpixel((xx,yy)))<90)>=2:cs.append(canvasx)
  if not cs:raise ValueError('No rendered title pixels detected')
  result={'rendered_x_bounds':[min(cs),max(cs)],'rendered_center':(min(cs)+max(cs))/2,'SP1_center':259,'suggested_shift':round(259-(min(cs)+max(cs))/2),'image_transmitted':False}
  (ROOT/'evidence/page200-title-render-probe.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8');return
 d,_=properties(root,w,'SP_1','向量图的属性');tab(d,'轮廓');sp=rows(d);cancel(d)
 vals={r['name']:int(r['value']) for r in sp if r['type']=='Edit' and r['name'] in ('X :',' Y :',' 宽度 :','高度 :')}
 d,_=properties(root,w,'TX_0','文字/批注的属性');tab(d,'文字/批注');rs=rows(d)
 caption='6-内体1气动'
 if not any(str(r.get('value','')).strip()==caption for r in rs):raise ValueError('Title identity differs')
 size=int(next(r['value'] for r in rs if r['name']=='尺寸 :' and r['type']=='ComboBox'))
 f=ImageFont.truetype(r'C:\Windows\Fonts\msjhl.ttc',round(size*96/72));tw=f.getlength(caption);a,b=f.getmetrics();th=a+b
 x=round(vals['X :']+(vals[' 宽度 :']-tw)/2);y=round(vals[' Y :']+(vals['高度 :']-th)/2)
 tab(d,'轮廓');before=rows(d)
 if q.get('correct_render_center'):
  probe=json.loads((ROOT/'evidence/page200-title-render-probe.json').read_text(encoding='utf8'));x=int(next(r['value'] for r in before if r['type']=='Edit' and r['name']=='X :'))+probe['suggested_shift'];y=int(next(r['value'] for r in before if r['type']=='Edit' and r['name']==' Y :'))
 fields(d,[{'type':'Edit','name':'X :','value':str(x)},{'type':'Edit','name':' Y :','value':str(y)}]);confirm(d)
 d,_=properties(root,w,'TX_0','文字/批注的属性');tab(d,'轮廓');after=rows(d)
 if any(next(r['value'] for r in after if r['type']=='Edit' and r['name']==k)!=str(v) for k,v in [('X :',x),(' Y :',y)]):raise ValueError('Title position readback differs')
 cancel(d);item=object_item(w,'TX_0');root.set_focus();item.click_input(coords=(30,item.rectangle().height()//2));root.click_input(coords=(232,52));time.sleep(.1);menu(root,(981,133),'移至顶层');save(root)
 label=object_item(w,'TX_0').window_text()
 report={'page':200,'key':'TX_0','caption':caption,'SP1_geometry':sp,'font_size':size,'measured_text_size':[tw,th],'position':[x,y],'before':before,'after':after,'order_command':'移至顶层','directory_label':label,'saved_requested':True,'position_readback_verified':True}
 (ROOT/'evidence/page200-title-centered-front.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')



