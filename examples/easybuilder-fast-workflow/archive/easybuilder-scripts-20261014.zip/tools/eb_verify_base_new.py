"""Fresh read-only checks after reopening saved base-page additions."""
import json
from eb_rebuild_page import ROOT,call
from eb_roundtrip_audit import run as audit
def run():
 lock=ROOT/'tools/batch.lock'
 with lock.open('x'):pass
 r={'ok':False,'completed':[]};path=ROOT/'evidence/base-new-reopened-workflow.json'
 def persist():path.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
 try:
  call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'));w=next(w for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title'])
  if w['pid']==10168:raise ValueError('Fresh reopened process required')
  if path.exists():
   old=json.loads(path.read_text(encoding='utf8'))
   if old.get('target_pid')==w['pid']:r['completed']=old.get('completed',[])
  r['target_pid']=w['pid'];r['target_handle']=w['handle']
  inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
  for page in (10,11):
   call('uia',w['handle'],json.dumps({'open_target_page':page}))
   for name in next(p['observed_objects'] for p in inv['pages'] if p['id']==page):
    key=name.split(']')[-1].strip().split()[0]
    kind,n=key.split('_')
    if not (ROOT/f'evidence/target-{page:03d}-{kind}{n}-built.json').exists():continue
    if any(v['page']==page and v['object']==key for v in r['completed']):continue
    r['stage']={'page':page,'object':key};persist()
    call('uia',w['handle'],json.dumps({'extract':{'page':page,'object':name,'target_readonly':True}}))
    if kind in ('SW','BL'):audit(page,[key])
    r['completed'].append({'page':page,'object':key,'read_only_properties_cached':True,'local_fields_verified':kind in ('SW','BL')});persist();print(page,key,'read',flush=True)
   try:call('uia',w['handle'],json.dumps({'target_page_audit':page}))
   except RuntimeError as e:
    if 'Target object audit incomplete' not in str(e):raise
  r['ok']=True;persist()
 except Exception as e:r['error']=str(e);persist();raise
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':run()
