"""Set observed property fields by exact names, with native readback and no guessed IDs."""
import re,time
from pywinauto.controls.win32_controls import EditWrapper,ComboBoxWrapper,ButtonWrapper
from pywinauto.keyboard import send_keys
from pywinauto import Desktop
from eb_timing import timed
_tab_names={}

@timed
def typed_children(d,typ):
    """Enumerate HWNDs first; retain provider names/types and visibility checks."""
    classes={'Edit':'Edit','ComboBox':'ComboBox','CheckBox':'Button','RadioButton':'Button','Button':'Button'}
    if typ not in classes:return d.descendants(control_type=typ)
    from eb_live_inventory import current
    found=[c for h,control_type,name,c in current(d)if control_type==typ]

    return found
def commit_text(d,name,value,occurrence=None):
    matches=[c for c in typed_children(d,'Edit') if c.window_text()==name and c.is_visible()]
    if not matches:
        from eb_live_inventory import virtual_fields
        matches=[c for c in virtual_fields(d,'Edit') if c.window_text()==name and c.is_visible()]
    if occurrence is None:
        if len(matches)!=1:raise ValueError('Unique text editor required: '+name)
        occurrence=0
    if not 0<=occurrence<len(matches):raise ValueError('Observed text editor occurrence required')
    editor=matches[occurrence];editor.click_input();send_keys('^a',pause=.01)
    escapes={'{':'{{}','}':'{}}','+':'{+}','^':'{^}','%':'{%}','(':'{(}',')':'{)}','\n':'{ENTER}'}
    normalized=value.replace('\r\n','\n').replace('\r','\n')
    send_keys(''.join(escapes.get(c,c) for c in normalized),with_spaces=True,pause=.01);send_keys('{TAB}',pause=.01)
    # Submitting Qt/RichEdit text can replace its native HWND. Rebind the
    # observed editor after submission rather than reading a destroyed handle.
    from eb_live_inventory import clear
    if editor.element_info.handle:clear(d.handle)
    live=[c for c in typed_children(d,'Edit') if c.window_text()==name and c.is_visible()]
    if len(live)<=occurrence:
        from eb_live_inventory import virtual_fields
        live=[c for c in virtual_fields(d,'Edit') if c.window_text()==name and c.is_visible()]
    if len(live)<=occurrence:raise ValueError('Submitted editor disappeared: '+name)
    editor=live[occurrence]
    stable=0
    for _ in range(20):
        stable=stable+1 if editor.get_value().replace('\r\n','\n').replace('\r','\n').rstrip('\n')==value.replace('\r\n','\n').replace('\r','\n').rstrip('\n') else 0
        if stable>=(1 if name.startswith('Row ') and not editor.element_info.handle else 3):break
        time.sleep(.1)
    else:raise ValueError('Text submission mismatch: '+name+' requested='+repr(value)+' actual='+repr(editor.get_value()))
@timed
def tab(d,name):
    native=Desktop(backend='win32').window(handle=d.handle).wrapper_object()
    native.set_focus()
    tabs=[c for c in native.descendants(class_name='SysTabControl32') if c.is_visible()]
    if len(tabs)!=1:raise ValueError('Unique native tab control required')
    from eb_native_messages import msg
    key=(d.handle,tabs[0].handle)
    count=msg(tabs[0].handle,0x1304)
    names=_tab_names.get(key)
    if names is None or len(names)!=count:
        parent=Desktop(backend='uia').window(handle=tabs[0].handle).wrapper_object()
        observed=parent.children(control_type='TabItem')
        names=[c.window_text() for c in observed]
        if len(names)!=count:raise ValueError('Native tab count differs from observed names')
        _tab_names[key]=names
    if names.count(name)!=1:raise ValueError('Unique observed tab required: '+name)
    selected_index=names.index(name)
    if msg(tabs[0].handle,0x130B)==selected_index:return
    from eb_live_inventory import clear
    clear(d.handle)
    from pywinauto.controls.common_controls import TabControlWrapper
    TabControlWrapper(tabs[0].handle).select(selected_index)
    time.sleep(.15)
    clear(d.handle)
    if msg(tabs[0].handle,0x130B)!=selected_index:raise ValueError('Native selected tab readback differs')
@timed
def fields(d,source_rows,skip=(),mapping=None,commit_edits=False):
    mapping=mapping or {};result=[]
    expected=[r for r in source_rows if r['type'] in ('Edit','ComboBox','CheckBox','RadioButton') and 'value' in r and (r['type'],r['name']) not in skip]
    occurrences={};pending_radios=[];typed_controls={}
    for row in expected:
        typ,name=row['type'],row['name'];key=(typ,name)
        # Native editable font combos expose their child Edit too.
        if typ=='Edit' and any(r['type']=='ComboBox' and r['name']==name for r in expected):continue
        index=occurrences.get(key,0);occurrences[key]=index+1
        if typ not in typed_controls:
            typed_controls[typ]=[(c,c.window_text()) for c in typed_children(d,typ) if c.is_visible()]
        candidates=[c for c,label in typed_controls[typ] if label==name]
        if index>=len(candidates):
            from eb_live_inventory import virtual_fields
            candidates=[c for c in virtual_fields(d,typ) if c.window_text()==name and c.is_visible()]
        if index>=len(candidates):raise ValueError('Source field absent on target: '+str(key))
        c=candidates[index];value=mapping.get((typ,name,row['value']),row['value'])
        if typ=='Edit':
            if commit_edits and c.is_enabled():
                from eb_native_messages import text as read_native_text
                current=read_native_text(c.element_info.handle) if c.element_info.handle else c.get_value()
                if str(current).rstrip('\r\n')!=str(value).rstrip('\r\n'):
                    commit_text(d,name,str(value),occurrence=index)
            if c.element_info.handle:
                native=EditWrapper(c.element_info.handle)
                if native.window_text().rstrip('\r\n')!=str(value):
                    if not c.is_enabled():raise ValueError('Different source value on disabled target field: '+name)
                    native.set_edit_text(str(value))
                actual=native.window_text().rstrip('\r\n')
            else:
                if c.get_value().rstrip('\r\n')!=str(value):
                    try:c.set_edit_text(str(value))
                    except Exception as error:
                        if type(error).__name__!='COMError':raise
                        commit_text(d,name,str(value),occurrence=index)
                actual=c.get_value().rstrip('\r\n')
        elif typ=='ComboBox':
            if c.element_info.class_name!='ComboBox':
                actual=c.selected_text()
                if actual!=value:
                    from eb_address_type import choose
                    choose(c,value,d.process_id());actual=c.selected_text()
            else:
                from eb_native_messages import combo_text,combo_select
                actual=combo_text(c.handle)
                if actual!=value:
                    native=ComboBoxWrapper(c.handle);choices=native.item_texts()
                    if name=='字体 :' and value not in choices:
                        value=re.sub(r'\s*\[.*$','',str(value))
                    if value not in choices:raise ValueError('Source combo choice unavailable: '+name+' = '+str(value))
                    combo_select(c.handle,choices.index(value))
                    actual=combo_text(c.handle)
        else:
            if typ=='RadioButton' and not value:
                pending_radios.append((c,name));continue
            if c.element_info.handle:
                native=ButtonWrapper(c.element_info.handle)
                if native.get_check_state()!=int(value):native.send_message_timeout(0x00F5,timeout=2);time.sleep(.03)
                actual=native.get_check_state()
            elif typ=='CheckBox':
                if c.get_toggle_state()!=value:c.toggle()
                actual=c.get_toggle_state()
            else:
                if not c.is_selected():c.select()
                actual=c.is_selected()
        if actual!=value:raise ValueError('Native property readback mismatch: '+name+(' requested='+repr(value)+' actual='+repr(actual)if name.startswith('Row ')else ''))
        result.append({'type':typ,'name':name,'value':actual,'source_value':row['value']})
        if typ=='RadioButton' or (typ=='ComboBox' and name in ('模式 :','设备 :')):
            typed_controls.clear()
            from eb_live_inventory import clear
            clear(d.handle)
    for c,name in pending_radios:
        actual=ButtonWrapper(c.element_info.handle).get_check_state() if c.element_info.handle else c.is_selected()
        if actual:raise ValueError('Unchecked radio source mismatch: '+name)
        result.append({'type':'RadioButton','name':name,'value':0,'source_value':0})
    return result
def confirm(d):
    native=Desktop(backend='win32').window(handle=d.handle).wrapper_object()
    matches=[c for c in native.descendants(class_name='Button') if c.window_text()=='确定' and c.is_visible() and c.is_enabled()]
    if len(matches)!=1:raise ValueError('Unique confirmation required')
    ButtonWrapper(matches[0].handle).send_message_timeout(0x00F5,timeout=2)
