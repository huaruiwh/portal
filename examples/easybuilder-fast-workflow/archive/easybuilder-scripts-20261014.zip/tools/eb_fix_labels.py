"""Commit identical source texts to all states of an existing target bit lamp."""
import json,time,ctypes
from pathlib import Path
from pywinauto import Desktop
from pywinauto.controls.win32_controls import ComboBoxWrapper,EditWrapper,ButtonWrapper
from pywinauto.keyboard import send_keys
ROOT=Path(__file__).resolve().parent.parent

def run(handle,request):
    page=int(request['page']);n=int(request['fix_bl_labels'])
    from eb_template_guard import validate_object
    source=validate_object(page,'BL',n)
    enabled=next(c['value'] for c in source['tabs']['标签'] if c['type']=='CheckBox' and c['name']=='使用文字标签')
    if not enabled:raise ValueError('No source label to repair')
    texts=[next(c['value'] for c in source['label_states'][state] if c['type']=='Edit' and c['name']=='') for state in ('0','1')]
    native=Desktop(backend='win32').window(handle=handle).wrapper_object()
    if '组装机_MT8106iP.emtp' not in native.window_text() or f'[{page} - ' not in native.window_text():raise ValueError('Expected target page')
    pid=native.process_id();w=Desktop(backend='uia').window(handle=handle).wrapper_object()
    nodes=[c for c in w.descendants(control_type='TreeItem') if c.window_text().startswith(f'BL_{n} ')]
    if len(nodes)!=1:raise ValueError('Existing lamp required, refusing to recreate')
    native.set_focus();nodes[0].double_click_input(coords=(40,nodes[0].rectangle().height()//2))
    ds=[]
    for _ in range(20):
        ds=[d for d in Desktop(backend='win32').windows() if d.process_id()==pid and d.window_text()=='位状态指示灯/位状态切换开关的属性' and d.is_visible()]
        if len(ds)==1:break
        time.sleep(.1)
    if len(ds)!=1:raise ValueError('Lamp properties required')
    d=Desktop(backend='uia').window(handle=ds[0].handle).wrapper_object()
    def unique(typ,name):
        cs=[c for c in d.descendants(control_type=typ) if c.window_text()==name and c.is_visible()]
        if len(cs)!=1:raise ValueError('Unique label control required: '+name)
        return cs[0]
    unique('TabItem','标签').select()
    state=ComboBoxWrapper(unique('ComboBox','状态 :').handle);state.select('0');time.sleep(.1)
    text=unique('Edit','')
    if EditWrapper(text.handle).window_text().rstrip('\r\n')!=texts[0]:raise ValueError('Current state0 text differs from source; inspect before modifying')
    from eb_label_commit import commit
    commit(d,texts)
    actual=EditWrapper(unique('Edit','').handle).window_text().rstrip('\r\n')
    if actual!=texts[1]:raise ValueError('All-state label action did not populate state1')
    ok=unique('Button','确定');ButtonWrapper(ok.handle).send_message_timeout(0x00F5,timeout=2)
    for _ in range(20):
        if not ctypes.windll.user32.IsWindow(ds[0].handle) or not ctypes.windll.user32.IsWindowVisible(ds[0].handle):break
        time.sleep(.1)
    else:raise ValueError('Lamp confirmation did not close')
    native.set_focus();send_keys('^s',pause=.01)
    report={'page':page,'object':f'BL_{n}','texts':texts,'state1_live_verified':True,'saved_requested':True,'reopened_verification_pending':True}
    (ROOT/'evidence'/f'target-{page:03d}-BL{n}-labels-fixed.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
