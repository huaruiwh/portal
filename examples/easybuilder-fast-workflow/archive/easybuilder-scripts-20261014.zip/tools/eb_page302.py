"""Single-control native203 templates for the different-layout302 page."""
import json,time,re
from pathlib import Path
from pywinauto.keyboard import send_keys
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save
from eb_native_form import tab,fields,confirm,commit_text,typed_children
from eb_page26_shapes import cancel
from eb_layout import geometry
from eb_live_fields import capture
from eb_original_style_existing import verify_fields
from eb_copy_200_style_object import native_clipboard_data,restore_native_clipboard,read_audit
from eb_open_page import run as open_page
from eb_page203_rewrite import plan,TITLES

def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')

from eb_timing import timed

@timed
def template(source):
 kind=re.search(r'(?:^|\])\s*([A-Z]+)_\d+',source['object'])[1];candidates=[]
 source_key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',source['object'])[1]
 journal=ROOT/f'evidence/target-302-{source_key}-copy-phase.json'
 prior=json.loads(journal.read_text(encoding='utf8'))if journal.exists()else {}
 template_page=prior.get('template_page',228)
 template_pages=[template_page] if prior else [228]
 paths=[p for page in template_pages for p in sorted((ROOT/'evidence/source-object-properties').glob(f'{page}_{kind}_*.json'))]
 for p in paths:
  if prior.get('stage')in ('pasted','saved-unverified')and p.stem.split('_',1)[1]!=prior['template']:continue
  b=json.loads(p.read_text(encoding='utf8'));edits,unknown=plan(source,b)
  binding=[u for u in unknown if u['scope']in ('一般属性','项目选单','源数据')and u['identity']in [('ComboBox',' Down'),('ComboBox','设备 :')]]
  unknown=[u for u in unknown if u not in binding]
  reviewed=[]
  sourcekey=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',source['object'])[1]
  for u in list(unknown):
   ident=u['identity'];scope=u['scope']
   if kind in ('NE','ND') and scope=='字体' and ident==('Edit','内容'):
    unknown.remove(u);continue # Derived format preview is verified after applying the format.
   allowed=(kind=='TB' and scope=='一般属性' and ident[0]in ('Edit','ComboBox'))or(kind=='TS' and scope=='安全' and ident==('ComboBox','用户限制 Down') and len(u['after'])==1 and u['after'][0]in ('类别 : A','类别 : B','类别 : C','无'))or(kind in ('NE','ND') and scope=='格式' and ident[0] in ('Edit','ComboBox'))or(kind=='OL'and scope=='状态设置'and ident[0]=='Edit'and re.fullmatch(r'Row \d+, Column [123]',ident[1]))or(kind=='OL'and scope=='源数据'and ident==('ComboBox','预设 Down')and len(u['after'])==1 and str(u['after'][0]).isdigit())or(sourcekey in ('TS_17','TS_18')and scope=='安全'and ident==('ComboBox',' Down')and u['before']==['1']and u['after']==['0.1'])or(sourcekey=='SW_0'and scope=='图片'and ident==('CheckBox','调整对象尺寸为图片原尺寸')and u['after'] in ([0],[1]))
   if kind=='BL' and scope=='一般属性' and ident==('CheckBox','若当前状态无相对应的图片时, 不显示图片') and u['after'] in ([0],[1]):allowed=True
   if sourcekey=='TS_8' and scope=='安全' and ((ident==('CheckBox','使用寄存器状态/数值') and u['before']==[1] and u['after']==[0]) or (ident==('ComboBox',' Down') and u['before']==['I','0.1','关闭时不执行任何操作','ON','位'] and u['after']==['0.1'])):allowed=True
   if kind in ('NE','ND') and scope=='图片' and ident==('CheckBox','外框') and u['after'] in ([0],[1]):allowed=True
   if allowed:
    reviewed.append({'scope':scope,'state':None,'rows':[r for r in source['tabs'][scope]if (r['type'],r['name'])==ident]});unknown.remove(u)
  if unknown:continue
  # Increase item count before editing the generated option table cells.
  edits=sorted(reviewed,key=lambda e:0 if e['scope']=='源数据' or (e['scope']=='安全' and any(r['name']=='使用寄存器状态/数值' for r in e['rows'])) else 1)+edits
  for u in binding:edits.insert(0,{'scope':u['scope'],'state':None,'rows':[r for r in source['tabs'][u['scope']]if (r['type'],r['name'])==u['identity']]})
  def order(e):
   if e['scope']not in ('一般属性','项目选单','源数据'):return 3
   identities={(r['type'],r['name'])for r in e['rows']}
   return 0 if ('ComboBox','设备 :')in identities else 1 if ('ComboBox',' Down')in identities else 2
  forced=[]
  for scope in ('一般属性','项目选单','源数据'):
   for ident in [('ComboBox','设备 :'),('ComboBox',' Down'),('Edit','Static')]:
    rows=[r for r in source['tabs'].get(scope,[])if (r['type'],r['name'])==ident]
    if not rows:continue
    edits=[e for e in edits if not(e['scope']==scope and any((r['type'],r['name'])==ident for r in e['rows']))]
    forced.append({'scope':scope,'state':None,'rows':rows})
  edits=forced+edits
  edits.sort(key=order)
  merged=[]
  for e in edits:
   if merged and e['scope'] in ('一般属性','格式','状态设置') and e['state'] is None and merged[-1]['scope']==e['scope'] and merged[-1]['state'] is None:
    previous={(r['type'],r['name'])for r in merged[-1]['rows']}
    incoming={(r['type'],r['name'])for r in e['rows']}
    if not previous.intersection(incoming):
     merged[-1]['rows']+=e['rows'];continue
   merged.append(dict(e,rows=list(e['rows'])))
  edits=merged
  candidates.append((len(binding),len(edits),int(p.stem.rsplit('_',1)[1]),p,b,edits))
 if not candidates:raise ValueError('No reviewed template with matching original302 safety/behavior: '+source['object'])
 _,_,_,p,b,edits=min(candidates,key=lambda x:x[:3]);return p.stem.split('_',1)[1],b,edits,int(p.stem.split('_',1)[0])

@timed
def verify_saved(handle,key):
 from collections import defaultdict
 from pywinauto import Desktop
 rp=ROOT/f'evidence/target-302-{key}-built.json';phase=ROOT/f'evidence/target-302-{key}-copy-phase.json'
 if not rp.exists()or not phase.exists():return False
 report=json.loads(rp.read_text(encoding='utf8'));state=json.loads(phase.read_text(encoding='utf8'))
 if state.get('stage')=='session-verified-saved' and report.get('property_session_verified') and report.get('saved'):return True
 if state.get('stage')!='saved-unverified':return False
 root,w=target(handle,302);ds=[v for v in Desktop(backend='win32').windows()if v.process_id()==root.process_id()and v.is_visible()and v.window_text()==TITLES[key.split('_')[0]]]
 if len(ds)>1:raise ValueError('Ambiguous saved-control dialog')
 d=Desktop(backend='uia').window(handle=ds[0].handle).wrapper_object()if ds else properties(root,w,key,TITLES[key.split('_')[0]])[0]
 try:
  groups=defaultdict(list)
  for e in report['edits']:groups[(e['scope'],e['state'])].extend(e['rows'])
  for (scope,st),rs in groups.items():
   tab(d,scope)
   if st is not None:
    cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :'];ComboBoxWrapper(cs[0].handle).select(st);time.sleep(.1)
   observed=capture(d,list(dict.fromkeys((r['type'],r['name'])for r in rs)))
   try:verify_fields(observed,rs)
   except ValueError:
    write(ROOT/f'evidence/page302-{key}-readback-difference.json',{'scope':scope,'state':st,'expected':rs,'actual':observed});raise
  if key.startswith(('NE_','ND_')):
   source=json.loads((ROOT/f'evidence/source-object-properties/302_{key}.json').read_text(encoding='utf8'))
   tab(d,'格式');rs=[r for r in source['tabs']['格式']if 'value'in r and r['type']in ('Edit','ComboBox','CheckBox','RadioButton')]
   observed=capture(d,list(dict.fromkeys((r['type'],r['name'])for r in rs)))
   try:verify_fields(observed,rs)
   except ValueError:
    write(ROOT/f'evidence/page302-{key}-readback-difference.json',{'scope':scope,'state':st,'expected':rs,'actual':observed});raise
   tab(d,'字体');time.sleep(.1);preview=[r for r in source['tabs']['字体']if r['type']=='Edit'and r['name']=='内容']
   if preview:verify_fields(capture(d,[('Edit','内容')]),preview)
   from eb_font_policy import apply as apply_font_policy
   report['standard_font_verified']=apply_font_policy(d,source,verify_only=True)
  if key.startswith('OL_'):
   source=json.loads((ROOT/f'evidence/source-object-properties/302_{key}.json').read_text(encoding='utf8'))
   from eb_font_policy import apply as apply_font_policy
   report['standard_font_verified']=apply_font_policy(d,source,verify_only=True)
  tab(d,'轮廓');g=report['geometry'];verify_fields(capture(d,[('Edit',n)for n in g]),[{'type':'Edit','name':n,'value':v}for n,v in g.items()])
 finally:cancel(d)
 report.update(saved_reopened_verified=True,original_text_preserved=True,verification_recovered_without_rewrite=True);write(rp,report);state['stage']='verified';write(phase,state);return True

def place_deferred(handle,key):
 source=json.loads((ROOT/f'evidence/source-object-properties/302_{key}.json').read_text(encoding='utf8'));g=geometry(source)
 settings=json.loads((ROOT/'evidence/source-pages-settings/302.json').read_text(encoding='utf8'));height=int(next(r['value']for r in settings['controls']if r['type']=='Edit'and r['name']=='高度 :'));ratio=469/height
 g[' Y :']=str(round(int(g[' Y :'])*ratio))
 if '高度 :'in g:g['高度 :']=str(max(30 if key.startswith(('NE_','ND_'))else 1,round(int(g['高度 :'])*ratio)))
 root,w=target(handle,302);d,_=properties(root,w,key,TITLES[key.split('_')[0]])
 try:
  from eb_font_policy import apply as font_policy
  font_policy(d,source)
  tab(d,'轮廓');fields(d,[{'type':'Edit','name':n,'value':v}for n,v in g.items()],commit_edits=True);confirm(d);d=None;save(root)
 finally:
  if d is not None:cancel(d)
 d,_=properties(root,w,key,TITLES[key.split('_')[0]])
 try:
  tab(d,'轮廓');verify_fields(capture(d,[('Edit',n)for n in g]),[{'type':'Edit','name':n,'value':v}for n,v in g.items()])
 finally:cancel(d)
 write(ROOT/f'evidence/target-302-{key}-deferred-layout.json',{'key':key,'geometry':g,'layout_saved_reopened_verified':True,'binding_verified':False,'type_pending':True})
 (ROOT/'evidence/page302-serial-directory-ledger.json').unlink(missing_ok=True)


def run(handle,q):
 if q.get('repair_saved_labels'):
  key=q['repair_saved_labels'];source=json.loads((ROOT/f'evidence/source-object-properties/302_{key}.json').read_text(encoding='utf8'));root,w=target(handle,302);d,_=properties(root,w,key,TITLES[key.split('_')[0]])
  try:
   from eb_font_policy import apply as apply_font_policy
   apply_font_policy(d,source);tab(d,'标签')
   cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']
   for st,rs in source['label_states'].items():
    ComboBoxWrapper(cs[0].handle).select(st);time.sleep(.2)
    commit_text(d,'',next(r['value']for r in rs if r['type']=='Edit'and r['name']==''))
   report=json.loads((ROOT/f'evidence/target-302-{key}-built.json').read_text(encoding='utf8'));g=report['geometry'];tab(d,'轮廓');fields(d,[{'type':'Edit','name':n,'value':v}for n,v in g.items()],commit_edits=True);confirm(d);d=None;save(root)
  finally:
   if d is not None:cancel(d)
  return
 if q.get('place_deferred_type'):return place_deferred(handle,q['place_deferred_type'])
 if q.get('numeric_probe'):
  key=q['numeric_probe'];root,w=target(handle,302);d,_=properties(root,w,key,TITLES['NE'])
  try:
   tab(d,'格式');fmt=capture(d,[('ComboBox','资料格式 :'),('Edit','小数点以上位数 :'),('Edit','小数点以下位数 :'),('Edit','设备上限 :'),('Edit','输入上限 :')])
   tab(d,'字体');preview=capture(d,[('Edit','内容')])
   write(ROOT/'evidence/page302-numeric-probe.json',{'format':fmt,'preview':preview})
  finally:cancel(d)
  return
 if q.get('page302_safety_probe'):
  root,w=target(handle,302);d,_=properties(root,w,'TS_17',TITLES['TS'])
  try:
   tab(d,'安全');cs=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name==' Down'and c.is_visible()]
   out=[]
   for c in cs:
    children=[]
    for v in c.descendants():
     e=v.element_info;item={'type':e.control_type,'name':e.name,'class':e.class_name,'handle':e.handle,'rect':str(v.rectangle())}
     if e.control_type=='Edit':item['value']=v.get_value()
     children.append(item)
    out.append({'value':c.selected_text(),'rect':str(c.rectangle()),'children':children})
   write(ROOT/'evidence/page302-safety-probe.json',out)
  finally:cancel(d)
  return
 if q.get('page302_count_probe'):
  from pywinauto import Desktop,mouse
  from eb_color_picker import native_window_handles
  root,w=target(handle,302);d,_=properties(root,w,'OL_2',TITLES['OL'])
  try:
   tab(d,'源数据');cs=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name=='预设 Down'and c.is_visible()]
   if len(cs)!=1:raise ValueError('Unique count probe')
   c=cs[0];r=c.rectangle();out={'class':c.element_info.class_name,'handle':c.handle,'value':c.selected_text(),'rect':[r.left,r.top,r.right,r.bottom]}
   mouse.click(coords=(r.right-10,(r.top+r.bottom)//2));time.sleep(.2)
   out['items']=[{'name':v.element_info.name,'type':v.element_info.control_type,'rect':str(v.rectangle()),'visible':v.is_visible()}for v in c.descendants()if v.element_info.control_type=='ListItem'][:12]
   out['windows']=[{'title':v.window_text(),'class':v.class_name(),'rect':str(v.rectangle())}for h in native_window_handles(d.process_id())for v in [Desktop(backend='win32').window(handle=h).wrapper_object()]]
   write(ROOT/'evidence/page302-count-probe.json',out)
  finally:
   import ctypes
   if ctypes.windll.user32.IsWindowVisible(d.handle):cancel(d)
  return
 keys=q['page302_controls']
 keys=[key for key in keys if not verify_saved(handle,key)]
 if not keys:return
 if all((ROOT/f'evidence/target-302-{key}-built.json').exists()and json.loads((ROOT/f'evidence/target-302-{key}-built.json').read_text(encoding='utf8')).get('saved_reopened_verified')for key in keys):return
 if not keys or len(keys)>4:raise ValueError('Reviewed302 batch up to4')
 inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));observed=[re.search(r'(?:^|\])\s*([A-Z]+_\d+)',s)[1]for s in next(x['observed_objects']for x in inv['pages']if x['id']==302)]
 if not set(keys)<=set(observed)or len(observed)!=54:raise ValueError('Unobserved302 key')
 # A timed-out scripted property dialog disables the directory. Cancel only
 # the exact pasted-control dialog; source fields are reapplied after audit.
 from pywinauto import Desktop
 for key in keys:
  phase=ROOT/f'evidence/target-302-{key}-copy-phase.json'
  if not phase.exists()or json.loads(phase.read_text(encoding='utf8')).get('stage')!='pasted':continue
  root=Desktop(backend='win32').window(handle=handle).wrapper_object()
  ds=[v for v in Desktop(backend='win32').windows()if v.process_id()==root.process_id()and v.is_visible()and v.window_text()==TITLES[key.split('_')[0]]]
  if len(ds)>1:raise ValueError('Ambiguous302 scripted property dialog before audit')
  if len(ds)==1:cancel(Desktop(backend='uia').window(handle=ds[0].handle).wrapper_object())
 open_page(handle,{'open_target_page':302})
 # One initial audit per batch, not per individual object.
 ledger_path=ROOT/'evidence/page302-serial-directory-ledger.json'
 ledger=json.loads(ledger_path.read_text(encoding='utf8'))if ledger_path.exists()else {}
 safe_ledger=ledger.get('handle')==handle and ledger.get('page')==302
 # Recovery always checks the real entire directory before trusting a paste.
 if any((ROOT/f'evidence/target-302-{key}-copy-phase.json').exists() for key in keys):safe_ledger=False
 if safe_ledger:
  for prior_key in ledger.get('keys',[]):
   proof_path=ROOT/f'evidence/target-302-{prior_key}-built.json'
   proof=json.loads(proof_path.read_text(encoding='utf8'))if proof_path.exists()else {}
   layout_path=ROOT/f'evidence/target-302-{prior_key}-deferred-layout.json'
   layout=json.loads(layout_path.read_text(encoding='utf8'))if layout_path.exists()else {}
   if not(proof.get('saved_reopened_verified')or(proof.get('property_session_verified')and proof.get('saved'))or layout.get('layout_saved_reopened_verified')):safe_ledger=False;break
 if safe_ledger:
  actualkeys=set(ledger['keys'])
 else:
  actual=read_audit(handle,302);actualkeys={re.search(r'(?:^|\])\s*([A-Z]+_\d+)',n)[1]for n in actual['objects']}
  if actual['unexpected']:raise ValueError('Unexpected302 objects')
 for key in keys:
  rp=ROOT/f'evidence/target-302-{key}-built.json';phase=ROOT/f'evidence/target-302-{key}-copy-phase.json'
  if rp.exists()and json.loads(rp.read_text(encoding='utf8')).get('saved_reopened_verified'):continue
  source=json.loads((ROOT/f'evidence/source-object-properties/302_{key}.json').read_text(encoding='utf8'));basekey,b,edits,template_page=template(source);kind,n=key.split('_');n=int(n)
  if phase.exists():template_page=json.loads(phase.read_text(encoding='utf8')).get('template_page',template_page)
  g=geometry(source)
  settings=json.loads((ROOT/'evidence/source-pages-settings/302.json').read_text(encoding='utf8'))
  original_height=int(next(r['value']for r in settings['controls']if r['type']=='Edit'and r['name']=='高度 :'))
  ratio=469/original_height
  g[' Y :']=str(round(int(g[' Y :'])*ratio))
  if '高度 :'in g:g['高度 :']=str(max(30 if kind in ('NE','ND')else 1,round(int(g['高度 :'])*ratio)))
  if key=='SW_0' and any(r['type']=='CheckBox' and r['name']=='调整对象尺寸为图片原尺寸' and r.get('value')==1 for r in source['tabs'].get('图片',[])):
   g['高度 :']=geometry(source)['高度 :']
   if int(g['高度 :'])>469:raise ValueError('Original-image SW height exceeds page')
   if int(g[' Y :'])+int(g['高度 :'])>469:g[' Y :']=str(469-int(g['高度 :']))
  if key=='FK_0' and int(g[' Y :'])<0:g[' Y :']='0'
  if phase.exists():
   state=json.loads(phase.read_text(encoding='utf8'))
   if state['stage']not in ('pasted','saved-unverified')or key not in actualkeys:raise ValueError('Unknown302 paste phase; inspect, do not repeat: '+key)
   if state['template']!=basekey:raise ValueError('302 recovery template differs')
  else:
   if key in actualkeys:raise ValueError('Existing302 without report; no paste')
   samekind={int(k.split('_')[1])for k in actualkeys if k.startswith(kind+'_')}
   if samekind!=set(range(n)):raise ValueError('Sequential302 destination numbering required '+key)
   cp=ROOT/f'evidence/native{template_page}-template-for302-{basekey}-{handle}.bin'
   if cp.exists():data=cp.read_bytes()
   else:
    # Reuse exact 228/template clipboard from previously verified destination
    # controls. Never substitute another template's safety/behavior identity.
    reused=None
    for oldpage in (235,232,231,230,229):
     candidate=ROOT/f'evidence/native{template_page}-template-for{oldpage}-{basekey}-{handle}.bin'
     if not candidate.exists():continue
     proven=False
     for proof_path in (ROOT/'evidence').glob(f'target-{oldpage}-*-built.json'):
      proof=json.loads(proof_path.read_text(encoding='utf8'))
      if (proof.get('saved_reopened_verified') or (proof.get('property_session_verified') and proof.get('saved'))) and proof.get('template_page')==template_page and proof.get('template')==basekey:proven=True;break
     if proven:reused=candidate;break
    if reused is not None:
     data=reused.read_bytes();cp.write_bytes(data)
     write(ROOT/f'evidence/page302-{key}-clipboard-reuse.json',{'template_page':template_page,'template':basekey,'reused_from':str(reused),'verified_prior_destination':True,'template_page_opened':False})
    else:
     open_page(handle,{'open_target_page':template_page});root,w=target(handle,template_page);d,_=properties(root,w,basekey,TITLES[kind]);cancel(d);root.set_focus();send_keys('^c',pause=.04);time.sleep(.15);data=native_clipboard_data();cp.write_bytes(data)
   open_page(handle,{'open_target_page':302});root,w=target(handle,302);placement_started=time.monotonic();restore_native_clipboard(data);root.click_input(coords=(963,367))
   write(phase,{'page':302,'key':key,'template_page':template_page,'template':basekey,'stage':'paste-requested'})
   root.set_focus();send_keys('^v',pause=.04);time.sleep(.8);root.click_input(coords=(963,367));time.sleep(.3);send_keys('{ESC}',pause=.02)
   # Resolve exact new property identity; do not perform another full-page scan.
   write(phase,{'page':302,'key':key,'template_page':template_page,'template':basekey,'stage':'pasted'})
   write(ROOT/f'evidence/page302-{key}-placement-time.json',{'key':key,'placement_seconds':round(time.monotonic()-placement_started,3),'measurement':'cached clipboard restore through paste/place/ESC; actual object identity checked next','identity_verified':False})
  root,w=target(handle,302)
  from pywinauto import Desktop
  existing=[v for v in Desktop(backend='win32').windows()if v.process_id()==root.process_id()and v.is_visible()and v.window_text()==TITLES[kind]]
  if len(existing)>1:raise ValueError('Ambiguous302 property recovery dialog')
  d=Desktop(backend='uia').window(handle=existing[0].handle).wrapper_object()if existing else properties(root,w,key,TITLES[kind])[0]
  placement_report=ROOT/f'evidence/page302-{key}-placement-time.json'
  if placement_report.exists():
   placed=json.loads(placement_report.read_text(encoding='utf8'));placed['identity_verified']=True;write(placement_report,placed)
  try:
   from eb_font_policy import apply as apply_font_policy
   template_report=ROOT/f'evidence/target-{template_page}-{basekey}-built.json'
   template_proof=json.loads(template_report.read_text(encoding='utf8'))if template_report.exists()else {}
   inherited=template_proof.get('standard_font_verified',{})
   font=json.loads((ROOT/'tools/font-policy.json').read_text(encoding='utf8'))['font']
   font_values=[str(value).split(' [')[0]for states in inherited.values()for value in states.values()]
   if template_proof.get('saved_reopened_verified')and font_values and all(v==font for v in font_values):
    standard_fonts=inherited # Approved native template already has policy font.
   else:standard_fonts=apply_font_policy(d,source)
   # Consolidate binding scopes so each is entered only once.
   grouped=[];positions={}
   for item in edits:
    if item['scope'] in ('一般属性','项目选单','源数据') and item['state'] is None:
     scope_key=item['scope']
     if scope_key not in positions:positions[scope_key]=len(grouped);grouped.append(dict(item,rows=[]))
     for row in item['rows']:
      if row not in grouped[positions[scope_key]]['rows']:grouped[positions[scope_key]]['rows'].append(row)
    else:grouped.append(item)
   edits=grouped
   for e in edits:
    tab(d,e['scope'])
    if e['state']is not None:
     cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']
     if len(cs)!=1:raise ValueError('Unique302 label state required')
     ComboBoxWrapper(cs[0].handle).select(e['state']);time.sleep(.2)
    rs=e['rows'];verification_rows=e['rows']
    if template_proof.get('saved_reopened_verified') and e['scope'] in ('一般属性','项目选单','源数据'):
     # Omit only unchanged binding writes from the verified clipboard template.
     # The original full e.rows remains in report and saved readback below.
     same=[]
     for row in rs:
      ident=(row['type'],row['name'])
      base=[v for v in b['tabs'].get(e['scope'],[]) if (v['type'],v['name'])==ident and 'value'in v]
      if ident in (('ComboBox','设备 :'),('ComboBox',' Down')) and len(base)==1 and base[0]['value']==row.get('value'):same.append(row)
     rs=[row for row in rs if row not in same]
     verification_rows=[row for row in e['rows'] if row not in same]
     if same:e['inherited_binding_from_verified_template']=same
     if not rs:continue
    if e['scope']in ('文字/批注','标签'):commit_text(d,rs[0]['name'],rs[0]['value'])
    elif (e['scope']=='源数据'and rs[0]['name']=='预设 Down')or(e['scope']=='安全'and rs[0]['type']=='ComboBox'and rs[0]['name']==' Down'):
     cs=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name==rs[0]['name']and c.is_visible()]
     if len(cs)!=1:raise ValueError('Unique302 option item count required')
     c=cs[0];want=str(rs[0]['value'])
     if c.selected_text()!=want:
      from pywinauto import mouse,Desktop
      from eb_color_picker import native_window_handles
      r=c.rectangle();mouse.click(coords=(r.right-10,(r.top+r.bottom)//2));time.sleep(.2)
      items=[];pops=[]
      for _ in range(20):
       pops=native_window_handles(d.process_id(),class_prefix='Qt5QWindowPopup')
       fresh=[v for v in d.descendants(control_type='ComboBox')if v.element_info.name==rs[0]['name']and v.is_visible()]
       items=[v for v in fresh[0].descendants(control_type='ListItem')if v.element_info.name==want]if len(fresh)==1 else []
       if len(items)==len(pops)==1:break
       time.sleep(.05)
      if len(items)!=1 or len(pops)!=1:raise ValueError('Unique302 physical count popup/item required')
      item=items[0];ir=item.rectangle();pr=Desktop(backend='win32').window(handle=pops[0]).rectangle()
      write(ROOT/f'evidence/page302-combo-selection-{key}.json',{'scope':e['scope'],'name':rs[0]['name'],'wanted':want,'before':c.selected_text(),'item_rect':[ir.left,ir.top,ir.right,ir.bottom],'popup_rect':[pr.left,pr.top,pr.right,pr.bottom],'reported_visible':item.is_visible()})
      if not(pr.left<=ir.left<ir.right<=pr.right and pr.top<=ir.top<ir.bottom<=pr.bottom):raise ValueError('302 count item outside observed popup')
      mouse.click(coords=((ir.left+ir.right)//2,(ir.top+ir.bottom)//2));time.sleep(.2);send_keys('{TAB}',pause=.01)
     if c.selected_text()!=want:raise ValueError('302 option count readback failed')
    else:
     binding_only=e['scope'] in ('一般属性','项目选单','源数据') and all((r['type'],r['name']) in (('ComboBox','设备 :'),('ComboBox',' Down'),('Edit','Static'))for r in rs)
     fields(d,rs,commit_edits=not binding_only)
    if verification_rows:verify_fields(capture(d,[(row['type'],row['name']) for row in verification_rows]),verification_rows)
   tab(d,'轮廓');fields(d,[{'type':'Edit','name':k,'value':v}for k,v in sorted(g.items(),key=lambda pair:pair[0] in ('X :',' Y :'))],commit_edits=False)
   tab(d,'轮廓');actualg={r['name']:r['value']for r in capture(d,[('Edit',k)for k in g])}
   if actualg!=g:raise ValueError('302 saved geometry differs '+key)
   if kind in ('NE','ND'):
    tab(d,'格式')
    fmt=[r for r in source['tabs']['格式'] if 'value' in r and r['type'] in ('Edit','ComboBox','CheckBox','RadioButton')]
    verify_fields(capture(d,list(dict.fromkeys((r['type'],r['name'])for r in fmt))),fmt)
   from eb_font_policy import apply as apply_font_policy
   standard_fonts=apply_font_policy(d,source,verify_only=True)
   if kind in ('NE','ND'):
    tab(d,'字体')
    preview=[r for r in source['tabs']['字体']if r['type']=='Edit'and r['name']=='内容']
    if preview:
     time.sleep(.1);verify_fields(capture(d,[('Edit','内容')]),preview)
   confirm(d);d=None;save(root)
  finally:
   if d is not None:cancel(d)
  report={'page':302,'key':key,'template_page':template_page,'template':basekey,'geometry':g,'edits':edits,'source_safety_equal_to_template':not any(e['scope']=='安全'for e in edits),'reviewed_safety_changes':[e for e in edits if e['scope']=='安全'],'font_style_from228':True,'standard_font_verified':standard_fonts,'property_session_verified':True,'saved':True,'saved_reopened_verified':False,'original_text_preserved':True,'runtime_verified':False}
  write(rp,report);state=json.loads(phase.read_text(encoding='utf8'));state['stage']='session-verified-saved';write(phase,state);actualkeys.add(key)
  write(ledger_path,{'page':302,'handle':handle,'keys':sorted(actualkeys),'last_verified_key':key,'mode':'serial increment after actual identity and all fields verified; recovery performs full audit'})
