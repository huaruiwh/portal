from pathlib import Path
p=Path(__file__).parent/'eb_fix_flow_appearances.py'
s=p.read_text(encoding='utf8')
s=s.replace("'runtime_verified':False,'controller_pid'","'runtime_verified':False,'pending_vector_objects':[],'controller_pid'")
s=s.replace('仅既有TS按钮','仅既有TS按钮及已实查Lamp - Flat图片指示灯；向量待单独核实')
s=s.replace("switches=[(int(re.match(r'^TS_(\\d+)\\s',name)[1]),name) for name in names if re.match(r'^TS_\\d+\\s',name)]", """switches=[]
   for name in names:
    m=re.match(r'^(TS|BL)_(\\d+)\\s',name)
    if not m:continue
    kind,n=m[1],int(m[2])
    if kind=='BL':
     src=read(f'evidence/source-object-properties/{page:03d}_{kind}_{n}.json')
     pic=src['tabs']['图片']
     if any(r['name']=='使用向量图' and r.get('value')==1 for r in pic):
      report['pending_vector_objects'].append(f'{page}:{kind}_{n}');continue
     if not any(r['name']=='Lamp - Flat' for r in pic):raise ValueError(f'Unreviewed lamp family {page}:{kind}_{n}')
    switches.append((kind,n,name))""")
s=s.replace('for n,name in switches:', 'for kind,n,name in switches:')
s=s.replace('f\'{page}:TS_{n}\'', 'f\'{page}:{kind}_{n}\'')
s=s.replace('page{page}-TS{n}', 'page{page}-{kind}{n}')
s=s.replace("'page':page,'n':n,'build_bit_general':n", "'page':page,'kind':kind,'n':n,'build_bit_general':n")
s=s.replace("f'{page}:TS{n} shape/RGB saved'", "f'{page}:{kind}{n} shape/RGB saved'")
s=s.replace("已完成页面{report['completed_pages']}","已完成图片修正页面{report['completed_pages']}，待核实向量{report['pending_vector_objects']}")
p.write_text(s,encoding='utf8')
compile(s,str(p),'exec')
print('queue extended: TS and reviewed image lamps; vectors explicitly pending')
