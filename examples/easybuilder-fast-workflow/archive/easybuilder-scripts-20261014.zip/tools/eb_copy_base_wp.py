"""Reuse the user-approved target WP0 only, never copy from the source project."""
import json,time
from pywinauto.keyboard import send_keys
from eb_extract import ROOT,rows
from eb_object_ui import target,object_item,properties,save
from eb_native_form import tab,fields,confirm
from eb_layout import geometry

def run(handle,q):
 page=int(q['page']);phase=q['copy_base_wp']
 if page!=11:raise ValueError('Reviewed missing reset pages only')
 path=ROOT/f'evidence/target-{page:03d}-WP0-built.json'
 if path.exists():raise ValueError('Saved reset exists; no duplicate')
 source=json.loads((ROOT/f'evidence/source-object-properties/{page:03d}_WP_0.json').read_text(encoding='utf8'))
 template=json.loads((ROOT/'evidence/target-object-properties/017_WP_0.json').read_text(encoding='utf8'))
 names={'设备 :','Static','操作模式 :','读取/写入使用不同的地址','触发宏指令','输出反向'}
 def selected(s):return [(r['type'],r['name'],r['value']) for r in s['tabs']['一般属性'] if r['name'] in names and 'value' in r]
 if source['tabs']['一般属性'] and not any(r.get('value')=='嵌入父窗口' for r in source['tabs']['一般属性']):raise ValueError('Embedded source window required')
 audit=json.loads((ROOT/f'evidence/target-page{page}-audit.json').read_text(encoding='utf8'))
 if 'WP_0' not in audit['missing']:raise ValueError('Verified missing reset required')
 phase_path=ROOT/f'evidence/target-{page:03d}-WP0-copy-phase.json'
 if phase=='copy':
  root,w=target(handle,17)
  d,_=properties(root,w,'WP_0','间接窗口的属性')
  actual=rows(d)
  if [(r['type'],r['name'],r['value']) for r in actual if r['name'] in names and 'value' in r]!=selected(template):raise ValueError('Template property identity mismatch')
  from eb_native_form import typed_children
  from eb_native_messages import msg
  cancel=[b for b in typed_children(d,'Button') if b.window_text()=='取消']
  if len(cancel)!=1:raise ValueError('One read-only template cancel required')
  msg(cancel[0].handle,245);time.sleep(.2)
  status=[c for c in w.children() if c.element_info.class_name.startswith('EBRibbonStatusBar')]
  if len(status)!=1:raise ValueError('One selection status bar required')
  texts=[c.window_text() for c in status[0].descendants(control_type='Text') if c.is_visible()]
  if not any('(163, 109)-(962, 499)' in t for t in texts):raise ValueError('Single reset bounding box not selected: '+str(texts))
  send_keys('^c',pause=.05)
  phase_path.write_text(json.dumps({'template':17,'target':page,'copied':True,'pasted':False}),encoding='utf8');return
 if phase!='paste':raise ValueError('Reviewed copy/paste phases only')
 phase_report=json.loads(phase_path.read_text(encoding='utf8'))
 if not phase_report['copied'] or phase_report['pasted']:raise ValueError('Fresh unconsumed clipboard phase required')
 root,w=target(handle,page)
 if any(c.window_text().startswith('WP_0 ') for c in w.descendants(control_type='TreeItem')):raise ValueError('Reset already present; inspect before retry')
 root.set_focus();root.click_input(coords=(963,367));send_keys('^v',pause=.05);time.sleep(.3);root.click_input(coords=(963,367));send_keys('{ESC}',pause=.01)
 phase_report['pasted']=True;phase_path.write_text(json.dumps(phase_report),encoding='utf8')
 from eb_page_audit import run as directory_audit
 try:directory_audit(handle,{'target_page_audit':page})
 except ValueError as e:
  if 'Target object audit incomplete' not in str(e):raise
 after=json.loads((ROOT/f'evidence/target-page{page}-audit.json').read_text(encoding='utf8'))
 if after['unexpected'] or after['target_count']!=audit['target_count']+1 or 'WP_0' in after['missing']:
  send_keys('^z',pause=.01);save(root)
  raise ValueError('Copy count guard rejected paste; Undo restored pre-paste state')
 d,name=properties(root,w,'WP_0','间接窗口的属性');fields(d,source['tabs']['一般属性'],skip=(('ComboBox','类型 :'),('ComboBox','开始 :'),('ComboBox','结束 :')))
 actual=rows(d)
 if [(r['type'],r['name'],r['value']) for r in actual if r['name'] in names and 'value' in r]!=selected(source):raise ValueError('Copied reset general mismatch')
 tab(d,'安全');fields(d,source['tabs']['安全']);safety=rows(d)
 tab(d,'轮廓');expected=geometry(source);fields(d,[{'type':'Edit','name':k,'value':v} for k,v in expected.items()]);shape=rows(d)
 if {r['name']:r['value'] for r in shape if r['type']=='Edit' and r['name'] in expected}!=expected:raise ValueError('Copied reset geometry mismatch')
 confirm(d);save(root)
 path.write_text(json.dumps({'page':page,'source':source['object'],'target':name,'template':17,'general':actual,'safety':safety,'geometry':shape,'saved_requested':True,'embedded_mapping_from_verified_page17':True,'macro_executed':False,'offline_simulation_verified':False},ensure_ascii=False,indent=2),encoding='utf8')
