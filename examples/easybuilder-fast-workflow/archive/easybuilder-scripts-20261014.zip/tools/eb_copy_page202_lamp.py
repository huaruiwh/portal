"""User-authorized same-page lamp copies; change address, caption and bounds only."""
import json,time
from pywinauto.keyboard import send_keys
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_rebuild_page import ROOT
from eb_extract import rows
from eb_object_ui import target,properties,save
from eb_native_form import tab,fields,confirm,typed_children
from eb_native_messages import msg
from eb_layout import geometry

def run(handle,q):
 n=int(q['copy_page202_lamp'])
 if n not in range(4,14):raise ValueError('Only remaining page202 lamps authorized')
 key=f'BL_{n}';path=ROOT/f'evidence/target-202-BL{n}-built.json'
 if path.exists():raise ValueError('Saved lamp exists; no duplicate copy')
 from eb_page_audit import run as audit
 def read_audit():
  try:audit(handle,{'target_page_audit':202})
  except ValueError as e:
   if 'Target object audit incomplete' not in str(e):raise
  return json.loads((ROOT/'evidence/target-page202-audit.json').read_text(encoding='utf8'))
 before=read_audit()
 if key not in before['missing']:raise ValueError('Lamp already exists without saved report; inspect')
 root,w=target(handle,202);title='位状态指示灯/位状态切换开关的属性'
 source=json.loads((ROOT/f'evidence/source-object-properties/202_{key}.json').read_text(encoding='utf8'))
 template=json.loads((ROOT/'evidence/target-202-BL0-built.json').read_text(encoding='utf8'))
 if not template.get('picture_colors_verified'):raise ValueError('Verified lamp template required')
 d,_=properties(root,w,'BL_0',title)
 cancel=[c for c in typed_children(d,'Button') if c.window_text()=='取消']
 if len(cancel)!=1:raise ValueError('One template cancel required')
 msg(cancel[0].handle,245);time.sleep(.15)
 send_keys('^c',pause=.03)
 root.set_focus();root.click_input(coords=(963,367));send_keys('^v',pause=.03);time.sleep(.2)
 root.click_input(coords=(963,367));send_keys('{ESC}',pause=.01)
 phase=ROOT/f'evidence/target-202-BL{n}-copy-phase.json'
 phase.write_text(json.dumps({'template':'BL_0','pasted':True,'saved':False}),encoding='utf8')
 after=read_audit()
 if after['target_count']!=before['target_count']+1 or key in after['missing'] or after['unexpected']:
  send_keys('^z',pause=.01);save(root)
  raise ValueError('Copy count guard rejected paste; Undo restored previous state')
 d,name=properties(root,w,key,title);tab(d,'一般属性')
 general=source['tabs']['一般属性']
 for group in ([r for r in general if r['name'] not in ('设备 :',' Down','Static')],[r for r in general if r['type']=='ComboBox' and r['name']=='设备 :'],[r for r in general if r['type']=='ComboBox' and r['name']==' Down'],[r for r in general if r['type']=='Edit' and r['name']=='Static']):fields(d,group)
 created=rows(d)
 expected=[r['value'] for r in general if r['type']=='Edit' and r['name']=='Static']
 if [r['value'] for r in created if r['type']=='Edit' and r['name']=='Static']!=expected:raise ValueError('Copied lamp address mismatch')
 tab(d,'标签');states=source.get('label_states') or {'0':source['tabs']['标签'],'1':source['tabs']['标签']}
 texts=[next(r['value'] for r in states[v] if r['type']=='Edit' and r['name']=='') for v in ('0','1')]
 from eb_label_commit import commit
 commit(d,texts)
 selectors=[c for c in d.descendants(control_type='ComboBox') if c.window_text()=='状态 :' and c.is_visible()]
 if len(selectors)!=1:raise ValueError('One copied lamp state selector required')
 labels={}
 for i,v in enumerate(('0','1')):
  ComboBoxWrapper(selectors[0].handle).select(v);labels[v]=rows(d)
  if next(r['value'] for r in labels[v] if r['type']=='Edit' and r['name']=='')!=texts[i]:raise ValueError('Copied lamp label mismatch')
 tab(d,'安全');fields(d,source['tabs']['安全']);safety=rows(d)
 tab(d,'轮廓');shape=geometry(source);fields(d,[{'type':'Edit','name':k,'value':v} for k,v in shape.items()]);bounds=rows(d)
 if {r['name']:r['value'] for r in bounds if r['type']=='Edit' and r['name'] in shape}!=shape:raise ValueError('Copied lamp bounds mismatch')
 confirm(d);save(root)
 report={'page':202,'source':source['object'],'target':name,'template':'BL_0','general':created,'labels':labels,'safety':safety,'geometry':bounds,'saved_requested':True,'picture_colors_verified':True,'picture_color_verification_method':'copied verified BL_0; user explicitly confirms identical colors','saved_picture_rgb_checks':template['saved_picture_rgb_checks'],'user_authorized_same_colors':True,'offline_simulation_verified':False}
 path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 phase.write_text(json.dumps({'template':'BL_0','pasted':True,'saved':True}),encoding='utf8')
