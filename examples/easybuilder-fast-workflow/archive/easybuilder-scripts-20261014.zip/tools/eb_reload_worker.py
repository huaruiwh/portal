import os,sys,json,subprocess
from eb_rebuild_page import ROOT

def run(q):
 old=q['worker_timeout_reload']
 ready=json.loads((ROOT/'evidence/worker-ready.json').read_text(encoding='utf8'))
 if ready['pid']!=old:return
 code="import time,os,signal,subprocess,sys;time.sleep(3);os.kill(int(sys.argv[1]),signal.SIGTERM);subprocess.Popen([sys.executable,sys.argv[2],'worker'],cwd=sys.argv[3],creationflags=0x08000000)"
 subprocess.Popen([sys.executable,'-c',code,str(old),str(ROOT/'tools/eb_ui.py'),str(ROOT)],cwd=ROOT,creationflags=0x08000000)
