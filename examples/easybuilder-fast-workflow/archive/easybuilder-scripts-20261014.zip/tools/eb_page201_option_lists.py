import json,time
from eb_rebuild_page import ROOT
from eb_object_ui import target,dialog,properties,save
from eb_native_form import tab,fields,confirm
from eb_extract import rows
from eb_page26_shapes import cancel
from eb_layout import geometry
from eb_color_picker import set_rgb,probe
from eb_original_style_existing import verify_fields
from eb_live_fields import capture
from eb_copy_200_style_object import read_audit
from eb_page208 import write
from pywinauto.keyboard import send_keys

def adapted(scope,rs):
    out=[]
    for r in rs:
        if'value'not in r:continue
        if scope=='项目选单'and r['name']in ('字段高度 :','字体尺寸 :','类型 :'):continue
        v=dict(r)
        if scope=='标签'and v['name']=='字体 :':v['value']='微软正黑体 Light'
        if scope=='标签'and v['name']=='尺寸 :':v['value']='12'
        out.append(v)
    return out

def run(handle,q):
    if q.get('inspect_item_count_popup'):
        from eb_popup_local_ocr import observe
        root,w=target(handle,201);popup,ocr=observe(root.process_id())
        write(ROOT/'evidence/page201-item-count-popup.json',{'ocr':ocr,'uia':rows(popup)});return
    if q.get('inspect_count_form'):
        root,w=target(handle,201);send_keys('{ESC}',pause=.01);d=dialog(root.process_id(),'新增 项目选单');tab(d,'源数据')
        out=[]
        for c in d.descendants(control_type='ComboBox'):
            if c.is_visible():
                out.append({'name':c.element_info.name,'value':c.selected_text(),'rect':list(c.rectangle()),'children':[{'type':v.element_info.control_type,'name':v.element_info.name,'handle':v.element_info.handle,'class':v.element_info.class_name}for v in c.descendants()]})
        write(ROOT/'evidence/page201-item-count-form.json',out);return
    if q['page201_option_lists']!=[0,1]:raise ValueError('Original201 lists only')
    a=read_audit(handle,201)
    for n in (0,1):
        key=f'OL_{n}';rp=ROOT/f'evidence/target-201-OL{n}-built.json';pp=ROOT/f'evidence/target-201-OL{n}-phase.json'
        if rp.exists()and json.loads(rp.read_text(encoding='utf8')).get('saved_reopened_verified'):continue
        s=json.loads((ROOT/f'evidence/source-object-properties/201_{key}.json').read_text(encoding='utf8'));root,w=target(handle,201)
        expected={scope:adapted(scope,s['tabs'][scope])for scope in ('项目选单','源数据','状态设置','安全','标签')}
        if not rp.exists():
            if pp.exists()and root.is_enabled()and key in a['missing']and json.loads(pp.read_text(encoding='utf8'))['stage']=='new-modal':
                write(ROOT/f'evidence/target-201-OL{n}-cancelled-uncreated.json',{'stage':'new-modal-cancelled','actual_directory_missing':True});pp.unlink()
            if pp.exists():
                phase=json.loads(pp.read_text(encoding='utf8'))
                if phase['stage']!='new-modal':raise ValueError('Unknown list creation stage; inspect')
                d=dialog(root.process_id(),'新增 项目选单')
            else:
                if key not in a['missing']:raise ValueError('Existing list; no duplicate')
                observed=json.loads((ROOT/'evidence/page201-ribbon-local-ocr.json').read_text(encoding='utf-8-sig'))['words'];words=[v for v in observed if 800<v['x']<900 and 130<v['y']<155 and v['text']in ('目','选','单')]
                if len(words)!=3:raise ValueError('Observed ribbon label required')
                root.set_focus();root.click_input(coords=(373,52));root.click_input(coords=(round(sum(v['x']+v['width']/2 for v in words)/3),round(sum(v['y']+v['height']/2 for v in words)/3)));d=dialog(root.process_id(),'新增 项目选单');write(pp,{'stage':'new-modal'})
            for scope,rs in expected.items():
                tab(d,scope)
                if scope=='项目选单':
                    initial=[r for r in rs if r['type']=='ComboBox'and r['name']in ('设备 :',' Down')];fields(d,initial);rs=[r for r in rs if r not in initial]
                if scope=='源数据':
                    count=[r for r in rs if r['name']=='预设 Down'];fields(d,[r for r in rs if r not in count])
                    if len(count)!=1:raise ValueError('Unique source menu count required')
                    boxes=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name=='预设 Down'and c.is_visible()]
                    if len(boxes)!=1:raise ValueError('Unique target count control required')
                    c=boxes[0];value=count[0]['value']
                    if c.selected_text()!=value:
                        c.expand();items=[v for v in c.descendants(control_type='ListItem')if v.element_info.name==value]
                        if len(items)!=1:raise ValueError('Unique observed count item required')
                        if items[0].is_visible():items[0].click_input()
                        else:items[0].select()
                        for _ in range(10):
                            if c.selected_text()==value:break
                            time.sleep(.1)
                        else:raise ValueError('Count selection readback mismatch')
                else:fields(d,rs,commit_edits=True)
                for label,rgb in s.get('menu_colors',{}).get(scope,{}).items():set_rgb(d,rgb,label)
            confirm(d);write(pp,{'stage':'placement-requested'});root.set_focus();root.click_input(coords=(963,367));send_keys('{ESC}',pause=.01)
            d,_=properties(root,w,key,'项目选单的属性');tab(d,'轮廓');fields(d,[{'type':'Edit','name':k,'value':v}for k,v in geometry(s).items()]);confirm(d);save(root);write(rp,{'saved_requested':True,'saved_reopened_verified':False});write(pp,{'stage':'saved-unverified'})
        d,_=properties(root,w,key,'项目选单的属性')
        try:
            for scope,rs in expected.items():
                tab(d,scope);wanted=[r for r in rs if not(r['type']=='Edit'and r['name']=='字体 :')];verify_fields(capture(d,[(r['type'],r['name'])for r in wanted]),wanted)
                for label,rgb in s.get('menu_colors',{}).get(scope,{}).items():
                    if probe(d,label)!=rgb:raise ValueError('Saved menu RGB mismatch')
            tab(d,'轮廓');g=geometry(s);verify_fields(capture(d,[('Edit',k)for k in g]),[{'type':'Edit','name':k,'value':v}for k,v in g.items()])
        finally:cancel(d)
        write(rp,{'page':201,'key':key,'saved_reopened_verified':True,'font':'微软正黑体 Light','font_size':12,'original_state_rows':expected['状态设置'],'colors':s['menu_colors'],'geometry':g,'model_adaptation':'cMT-only field height/font-size mode/simple type absent in MT; original fixed height retained; font12','runtime_verified':False});write(pp,{'stage':'verified'})
    a=read_audit(handle,201);write(ROOT/'evidence/page201-option-lists-batch.json',{'finished':True,'count':a['target_count'],'remaining':len(a['missing'])})
