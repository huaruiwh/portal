"""Exclusive, resumable layout batches. Never copies or changes bindings."""
import json,re,shutil,time,os
from datetime import datetime
from eb_rebuild_page import ROOT,call
from pathlib import Path
DIR=ROOT/'evidence/scale-890x469';DIR.mkdir(exist_ok=True)
def put(p,d):
 tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8');tmp.replace(p)
def load(p):return json.loads(p.read_text(encoding='utf8'))
def archive(out):
 project=ROOT/'output/组装机_MT8106iP.emtp'
 text='\n### 2026-10-11：200及以后页面适配890×469\n\n'
 text+='按用户要求对已重建页面调整位置、尺寸与字号。原件只读；使用目标工程当前真实属性作为不可变缩放基准，保留用户排版、文字、地址、图形、颜色、安全条件及层次。横向比例890/原宽度，纵向比例469/原高度；边界四舍五入，细线至少1像素，字号先缩小再写轮廓。每件保存并重开读回字号及几何，verified跳过，write-requested恢复按同一基准写入，禁止重复缩放。\n\n'
 text+='实际状态：'+json.dumps(out,ensure_ascii=False)+'\n\n'
 text+='补充规律：表格“垂直/水平”是行列数，必须保留14行3列，只缩放外框；本轮曾误写11行，已恢复14并重开读回。内部自定义分割线按原已验证投影同比例适配，使用本地内存像素检测，不保存或回传图片；内部线容限1.8画布单位，外边缘含旧标定与像素取整误差容限2.5。100px鼠标标定导致约1%取整误差，改为400px取样。202表格原生继承200，缩放前几何完全相同且整页复制映射已验证，因此复用200原投影，不假造不存在的202旧投影。\n\n'
 text+='字号降至6仍被软件撑高的窄灯保留实际原生最小高度（42的比例目标实际需46），只在不大于原尺寸且仍位于页内时接受，记录native_minimum_bounds；同列灯因最小高度重叠时，按原先非重叠证明微移上一灯，保存重开核对，至少留1px间隙。不是所有灯都能机械缩至比例高度。\n\n'
 text+='目录树曾变为浮动BCGPMiniFrame导致Unique target tree required to restore viewport；按真实窗口标题、进程、客户区及非客户命中测试确认自绘标题栏后双击恢复停靠，记录floating-directory-repair.json。属性窗口偶发Dialog not ready，snapshot确认无遗留弹窗后，仅恢复未完成件。旧重建脚本的原始几何是历史证据，不可用于还原本轮完成页。后续新页使用890×469工作区与原页比例直接定位；引用本次已缩小模板时不得再次按比例缩小字号和尺寸。\n\n'
 text+='脚本：tools/eb_scale_post200.py、tools/continue_scale_post200.py、tools/finalize_scale_post200.py；逐件基准与断点evidence/scale-890x469，worker早分发保持完整控件300秒。备份路径见workflow.backup。恢复前确认管理员worker运行且无其它控制器/batch.lock，命令原文：\n'
 text+='`& "C:\\Users\\wei\'ke\\.cache\\codex-runtimes\\codex-primary-runtime\\dependencies\\python\\python.exe" tools/continue_scale_post200.py`\n\n'
 text+='`& "C:\\Users\\wei\'ke\\.cache\\codex-runtimes\\codex-primary-runtime\\dependencies\\python\\python.exe" tools/finalize_scale_post200.py`\n\n'
 text+='问题记录：目录树TabItem.Select报COMError，改用真实观察到的目录树标签click_input；目录滚动到底时Unique scale page header required，滚回真实树视口顶部后查找页头。BL_2/BL_3的三行标签导致保存自动撑高49而目标47，降低两态字号至6后目标尺寸保存读回通过，native_auto_fit保留实际修正记录。首次补充表格间距代码出现SyntaxError: expected else after if expression，修正后py_compile通过并按断点恢复。几何优先沿用既有灯调整脚本的原生Edit写入，保存读回不符时仅该件采用输入提交回退，再检查字号自动撑大；几何原始基准不变。最终编译取本次真实结果；未进行运行验收、下载或执行宏。工程当前实际'+str(project.stat().st_size)+'字节。\n'
 marker='\n### 2026-10-11：200及以后页面适配890×469'
 for p in (ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md'):
  old=p.read_text(encoding='utf8');p.write_text(old.split(marker)[0]+text,encoding='utf8')
 cp=ROOT/'evidence/resume-checkpoint.json';data=load(cp);data.update({'date':'2026-10-11','status':'scale-890x469-complete'if out.get('finished')else'scale-890x469-in-progress','bytes':project.stat().st_size,'layout_scale':out,'next':'用户查看890×469页面，尚未运行验收'if out.get('finished')else'运行tools/continue_scale_post200.py，已verified不重复缩放'});put(cp,data)
def main():
 lock=ROOT/'tools/batch.lock'
 with lock.open('x',encoding='utf8')as f:f.write(json.dumps({'pid':os.getpid(),'task':'scale890x469'}))
 wp=DIR/'workflow.json';out=None
 try:
  out=load(wp)if wp.exists()else{'date':'2026-10-11','finished':False,'pages':{}}
  call('snapshot');ws=load(ROOT/'evidence/windows.json');ts=[w for w in ws if '组装机_MT8106iP.emtp'in w['title']and w['class']=='EasyBuilderPro']
  if len(ts)!=1:raise ValueError('Unique live target required')
  h=ts[0]['handle']
  if 'backup'not in out:
   backup=ROOT/'backup'/('890x469缩放前_'+datetime.now().strftime('%Y%m%d_%H%M%S'));backup.mkdir(parents=True)
   for ext in ('emtp','exob'):shutil.copy2(ROOT/f'output/组装机_MT8106iP.{ext}',backup)
   out['backup']=str(backup);out['project_before_bytes']=(ROOT/'output/组装机_MT8106iP.emtp').stat().st_size
   out['scope']=[200,201,202,203,204,205,208];put(wp,out);archive(out)
  for page in out['scope']:
   pp=DIR/f'page-{page}.json'
   if not pp.exists():call('uia',h,json.dumps({'scale_post200':{'page':page,'mode':'prepare'},'build_bit_general':0}))
   p=load(pp);out['active_page']=page
   for i in range(0,len(p['keys']),3):
    batch=p['keys'][i:i+3];pending=[k for k in batch if k not in load(pp)['verified']]
    if pending:
     out['current_batch']=pending;put(wp,out)
     call('uia',h,json.dumps({'scale_post200':{'page':page,'keys':pending},'build_bit_general':0}))
    if not pending:continue
    p=load(pp);out['pages'][str(page)]={'before':p['before'],'after':p['after'],'verified':len(p['verified']),'total':len(p['keys']),'page_size_verified':p['page_size_verified']};put(wp,out);archive(out)
    print(json.dumps({'page':page,'verified':len(p['verified']),'total':len(p['keys'])}),flush=True)
   if not p['page_size_verified']:call('uia',h,json.dumps({'scale_post200':{'page':page,'mode':'size'},'build_bit_general':0}))
   p=load(pp);out['pages'][str(page)]['page_size_verified']=p['page_size_verified'];put(wp,out);archive(out)
  call('uia',h,json.dumps({'compile_target':True}));out['compile']=load(ROOT/'evidence/latest-project-compile.json');out['finished']=bool(out['compile']['ok']);out['runtime_verified']=False;out.pop('error',None)
  call('uia',h,json.dumps({'open_target_page':200}));put(wp,out);archive(out)
 except Exception as e:
  out=out or {};out['error']=str(e);put(wp,out);archive(out);raise
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':main()
