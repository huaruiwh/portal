"""Complete only the 11 freshly inventoried missing page16 static texts."""
import json,re
from eb_rebuild_page import ROOT,call

def run():
 lock=ROOT/'tools/batch.lock'
 with lock.open('x'):pass
 report={'page':16,'completed':[],'ok':False}
 path=ROOT/'evidence/page16-missing-text-workflow.json'
 def persist():path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 try:
  cached=json.loads((ROOT/'evidence/page-16-source-collection.json').read_text(encoding='utf8'))
  if not cached['ok'] or len(cached['completed'])!=101:raise ValueError('Complete source cache required')
  call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
  def handle(title):
   a=[w['handle'] for w in ws if w['class']=='EasyBuilderPro' and title in w['title']]
   if len(a)!=1:raise ValueError('Unique exact project required '+title)
   return a[0]
  source=handle('组装机2台15工位取消.cmtp');target=handle('组装机_MT8106iP.emtp')
  def ui(h,q):return call('uia',h,json.dumps(q,ensure_ascii=False))
  def audit():
   try:ui(target,{'target_page_audit':16})
   except RuntimeError as e:
    if 'Target object audit incomplete' not in str(e):raise
   a=json.loads((ROOT/'evidence/target-page16-audit.json').read_text(encoding='utf8'))
   if a['source_count']!=101 or a['unexpected']:raise ValueError('Unexpected page16 directory')
   return a
  inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
  names=next(p['observed_objects'] for p in inv['pages'] if p['id']==16)
  for n in range(20,31):
   key=f'TX_{n}';report['stage']=key;persist();a=audit()
   if key not in a['missing']:
    if not (ROOT/f'evidence/target-016-TX{n}-built.json').exists():raise ValueError('Existing text without saved report requires readback '+key)
    report['completed'].append(key);persist();continue
   p=ROOT/f'evidence/source-object-properties/016_{key}.json';d=json.loads(p.read_text(encoding='utf8'))
   name=next(s for s in names if re.search(r'(?:^|\])\s*'+key+r'(?:\s|$)',s))
   if 'colors' not in d:ui(source,{'extract':{'page':16,'object':name,'colors':['颜色 :'],'color_tab':'文字/批注','only_color':True}})
   ui(target,{'page':16,'build_tx':n})
   a=audit()
   if key in a['missing']:raise ValueError('Saved text absent '+key)
   report['completed'].append(key);report['target_count']=a['target_count'];persist()
  report['ok']=True;persist();print(json.dumps(report,ensure_ascii=False))
 except Exception as e:report['error']=str(e);persist();raise
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':run()
