"""First201 numeric: copy a saved200 control, apply original201 parameters."""
import json,time,re
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save
from eb_open_page import run as op
from eb_copy_200_style_object import native_clipboard_data,restore_native_clipboard
from eb_native_form import tab,fields,confirm
from eb_page26_shapes import cancel
from eb_original_style_existing import form_rows as rows
from eb_layout import geometry
from eb_page208 import shape,write
from pywinauto.keyboard import send_keys

def run(handle,q):
 if q.get('first_axis_numeric')=='inspect':
  root,w=target(handle,201);d,_=properties(root,w,'NE_0','数值的属性')
  try:write(ROOT/'evidence/page201-NE0-current-shape.json',shape(d))
  finally:cancel(d)
  return
 started=time.monotonic()
 key=q.get('first_axis_numeric')
 if key not in ['NE_'+str(i) for i in range(12)]+['ND_'+str(i) for i in range(4)]:raise ValueError('Reviewed201 numeric only')
 kind=key.split('_')[0];n=int(key.split('_')[1])
 report=ROOT/f'evidence/target-201-{kind}{n}-built.json'
 if report.exists() and json.loads(report.read_text(encoding='utf8')).get('saved_reopened_verified'):return
 phase=ROOT/f'evidence/target-201-{kind}{n}-copy-phase.json'
 s=json.loads((ROOT/f'evidence/source-object-properties/201_{key}.json').read_text(encoding='utf8'))
 basepage=200 if key=='NE_0' else 201;templatekey='NE_0'
 sig=lambda rs:[(r['type'],r['name'],r['value']) for r in rs if 'value' in r]
 if key!='NE_0':
  candidates=[]
  for candidatekey in ['NE_'+str(i) for i in range(12)]+['ND_'+str(i) for i in range(4)]:
   ck,cn=candidatekey.split('_')
   cp=ROOT/f'evidence/target-201-{ck}{cn}-built.json';sp=ROOT/f'evidence/source-object-properties/201_{candidatekey}.json'
   if candidatekey==key or not cp.exists() or not sp.exists() or not json.loads(cp.read_text(encoding='utf8')).get('saved_reopened_verified'):continue
   candidate=json.loads(sp.read_text(encoding='utf8'))
   if candidate.get('vector_identity')!=s.get('vector_identity'):continue
   score=sum(weight for name,weight in [('一般属性',5),('格式',20),('安全',10),('字体',5)] if sig(candidate['tabs'][name])!=sig(s['tabs'][name]))
   score+=30 if candidate.get('colors')!=s.get('colors') else 0
   candidates.append((score,candidatekey))
  if not candidates:raise ValueError('No verified same-style numeric template')
  templatekey=min(candidates)[1]
 if phase.exists():
  previous=json.loads(phase.read_text(encoding='utf8'))
  basepage=previous.get('basepage',200 if key=='NE_0' else 201);templatekey=previous.get('templatekey','NE_0')
 base=json.loads((ROOT/f'evidence/source-object-properties/{basepage:03d}_{templatekey}.json').read_text(encoding='utf8'))
 if s.get('vector_identity')!=base.get('vector_identity'):raise ValueError('Original201 numeric vector differs from200; adapter needed')
 changed_colors={k:v for k,v in s['colors'].items() if base.get('colors',{}).get(k)!=v}
 values=lambda rs:[(r['type'],r['name'],r['value']) for r in rs if 'value' in r]
 if kind=='NE' and values(s['tabs']['数值输入'])!=values(base['tabs'].get('数值输入',[])):raise ValueError('Numeric keypad differs from template; adapter required before paste')
 security_changed=values(s['tabs']['安全'])!=values(base['tabs']['安全'])
 base_security={(r['type'],r['name']):r['value'] for r in base['tabs']['安全'] if 'value' in r}
 for r in s['tabs']['安全']:
  if 'value' in r and r['name']!='用户限制 Down' and (r['type'],r['name']) in base_security and r['value']!=base_security[(r['type'],r['name'])]:raise ValueError('Unreviewed numeric safety difference before paste')
 user_row=[r for r in s['tabs']['安全'] if r['name']=='用户限制 Down' and r['type']=='ComboBox']
 if len(user_row)!=1:raise ValueError('Original numeric permission required')
 from eb_page_audit import run as audit
 op(handle,{'open_target_page':201});root,w=target(handle,201)
 if phase.exists():
  state=json.loads(phase.read_text(encoding='utf8'))
  if state['stage'] not in ('pasted','saved-unverified'):raise ValueError('Unknown paste state; inspect before recovery')
 else:
  try:audit(handle,{'target_page_audit':201})
  except ValueError as e:
   if str(e)!='Target object audit incomplete':raise
  a=json.loads((ROOT/'evidence/target-page201-audit.json').read_text(encoding='utf8'))
  if key not in a['missing']:raise ValueError('Original201 NE0 must be absent')
  op(handle,{'open_target_page':basepage});root,w=target(handle,basepage)
  from eb_native_copy import copy_control
  data=copy_control(root,w,templatekey)
  op(handle,{'open_target_page':201});root,w=target(handle,201)
  try:clipboard_equal=native_clipboard_data()==data
  except ValueError:clipboard_equal=False
  if not clipboard_equal:restore_native_clipboard(data)
  pasted_kind=templatekey.split('_')[0]
  nums=[int(m[1]) for item in a['objects'] for m in [re.search(r'(?:^|\])\s*'+pasted_kind+r'_(\d+)',item)] if m]
  pastedkey=pasted_kind+'_'+str(max(nums,default=-1)+1)
  root.click_input(coords=(963,367));write(phase,{'stage':'paste_requested','basepage':basepage,'templatekey':templatekey,'pastedkey':pastedkey})
  send_keys('^v',pause=.03);time.sleep(.2);send_keys('{ESC}',pause=.02)
  write(phase,{'stage':'pasted','basepage':basepage,'templatekey':templatekey,'pastedkey':pastedkey})
 state=json.loads(phase.read_text(encoding='utf8'));editablekey=state.get('pastedkey',key) if state['stage']=='pasted' else key
 d,_=properties(root,w,editablekey,'数值的属性')
 tab(d,'一般属性')
 g=s['tabs']['一般属性']
 for name in ('启用输入功能','设备 :',' Down','Static'):
  fields(d,[r for r in g if r['name']==name])
 format_changed=basepage==200 or values(s['tabs']['格式'])!=values(base['tabs']['格式'])
 if format_changed:tab(d,'格式');fields(d,s['tabs']['格式'],commit_edits=True)
 if security_changed:tab(d,'安全');fields(d,user_row)
 font=[]
 for r in s['tabs']['字体']:
  if r['type'] not in ('ComboBox','CheckBox') or 'value' not in r:continue
  r=dict(r)
  if r['name']=='字体 :':r['value']=r['value'].split(' [')[0]
  if r['name']=='尺寸 :':r['value']='13'
  font.append(r)
 basefont=[]
 for r in base['tabs']['字体']:
  if r['type'] not in ('ComboBox','CheckBox') or 'value' not in r:continue
  r=dict(r)
  if r['name']=='字体 :':r['value']=r['value'].split(' [')[0]
  if r['name']=='尺寸 :':r['value']='13'
  basefont.append(r)
 font_changed=basepage==200 or values(font)!=values(basefont)
 if font_changed:tab(d,'字体');fields(d,font)
 if changed_colors:
  from eb_color_picker import set_rgb,probe
  tab(d,'图片')
  for label,rgb in changed_colors.items():
   set_rgb(d,rgb,label)
   if probe(d,label)!=rgb:raise ValueError('Numeric original color write mismatch')
 bounds=geometry(s);tab(d,'轮廓');fields(d,[{'type':'Edit','name':n,'value':v} for n,v in bounds.items()])
 confirm(d);save(root);write(phase,{'stage':'saved-unverified','basepage':basepage,'templatekey':templatekey})
 d,_=properties(root,w,key,'数值的属性');captured={}
 try:
  for name in ['一般属性']+(['格式'] if format_changed else [])+(['字体'] if font_changed else []):
   tab(d,name);captured[name]=rows(d)
  wanted_input=[r['value'] for r in g if r['type']=='CheckBox' and r['name']=='启用输入功能']
  actual_input=[r['value'] for r in captured['一般属性'] if r['type']=='CheckBox' and r['name']=='启用输入功能']
  if wanted_input!=actual_input:raise ValueError('Saved numeric editable/read-only mode differs')
  expected=[r['value'] for r in g if r['type']=='Edit' and r['name']=='Static']
  if [r['value'] for r in captured['一般属性'] if r['type']=='Edit' and r['name']=='Static']!=expected:raise ValueError('Numeric saved address mismatch')
  from eb_original_style_existing import verify_fields
  if format_changed:verify_fields(captured['格式'],[r for r in s['tabs']['格式'] if 'value' in r])
  if font_changed:verify_fields(captured['字体'],font)
  if security_changed:
   from eb_native_form import typed_children
   tab(d,'安全');cs=[c for c in d.descendants(control_type='ComboBox') if c.is_visible() and c.element_info.name=='用户限制 Down']
   if len(cs)!=1 or cs[0].selected_text()!=user_row[0]['value']:raise ValueError('Saved numeric permission differs')
  if changed_colors:
   tab(d,'图片')
   for label,rgb in changed_colors.items():
    if probe(d,label)!=rgb:raise ValueError('Saved numeric original color differs')
  actual=shape(d)
  if actual!=bounds:raise ValueError('Numeric saved bounds mismatch')
 finally:cancel(d)
 write(report,{'page':201,'key':key,'template':f'{basepage}/{templatekey}','saved_reopened_verified':True,'source_format_verified':True,'source_font_verified':True,'keypad_applicable':kind=='NE','source_keypad_equal_to_template':kind=='NE','security_changed':security_changed,'permission_verified':user_row[0]['value'],'original_colors':s['colors'],'shape':actual,'fields':captured,'format_inherited':not format_changed,'font_inherited':not font_changed,'elapsed_seconds':round(time.monotonic()-started,3),'runtime_verified':False})
 write(phase,{'stage':'verified','basepage':basepage,'templatekey':templatekey})
