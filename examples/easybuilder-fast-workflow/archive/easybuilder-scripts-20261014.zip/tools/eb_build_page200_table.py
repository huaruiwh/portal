"""Observe page200 table creation entry before drawing; no guessed table coordinates."""
from eb_object_ui import target
from eb_compile_ocr import run as ocr
import json,time
from pywinauto import Desktop,mouse
from eb_rebuild_page import ROOT

def run(handle,q):
 if not q.get('probe_table_entry') and not q.get('probe_table_new'):
  return build(handle,q)
 root,w=target(handle,200)
 root.set_focus();root.click_input(coords=(373,52))
 if q.get('probe_table_new'):
  root.click_input(coords=(177,145));time.sleep(.3)
  from eb_color_picker import native_window_handles
  from eb_extract import rows
  result=[]
  for h in native_window_handles(root.process_id()):
   v=Desktop(backend='win32').window(handle=h).wrapper_object()
   if v.class_name()=='#32770':
    ui=Desktop(backend='uia').window(handle=h).wrapper_object()
    result.append({'handle':h,'title':v.window_text(),'rows':rows(ui)})
  (ROOT/'evidence/page200-table-new-probe.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
  return
 if q.get('probe_table_entry'):
  from eb_color_picker import native_window_handles
  observations=[];r=root.rectangle()
  for y in (88,118,145):
   for x in (25,54,77,100,125,154,177,200,225):
    mouse.move(coords=(r.left+x,r.top+y));time.sleep(.8)
    tips=[]
    for h in native_window_handles(root.process_id()):
     v=Desktop(backend='win32').window(handle=h).wrapper_object()
     if 'tooltip' in v.class_name().lower():
      text=v.window_text()
      if not text or text=='EasyBuilder Pro':
       ui=Desktop(backend='uia').window(handle=h).wrapper_object()
       text=' '.join(c.window_text() for c in ui.descendants(control_type='Text'))
      tips.append(text)
    observations.append({'point':[x,y],'tips':tips})
    if any('表格' in t for t in tips):break
   if any('表格' in t for t in tips):break
  (ROOT/'evidence/page200-table-entry-probe.json').write_text(json.dumps(observations,ensure_ascii=False,indent=2),encoding='utf8')
  return
 ocr(handle,{'compile_ribbon_ocr':True})
 raise ValueError('Page200 table entry requires review of current local ribbon OCR')

def build(handle,q):
 from eb_object_ui import dialog,placed_properties,properties,save
 from eb_native_form import tab,fields,confirm,typed_children
 from eb_extract import rows
 from eb_color_picker import set_rgb,probe
 from eb_layout import geometry
 from pywinauto.controls.win32_controls import ComboBoxWrapper
 from eb_native_messages import msg
 path=ROOT/'evidence/target-200-TB0-built.json'
 if path.exists():raise ValueError('Saved table exists; inspect instead of duplicate')
 s=json.loads((ROOT/'evidence/source-object-properties/200_TB_0.json').read_text(encoding='utf8'))
 if s.get('line_style_indices')!=[0,0] or not s.get('table_line_colors'):raise ValueError('Original table styles/colors required')
 root,w=target(handle,200)
 if not q.get('resume'):
  root.click_input(coords=(373,52));root.click_input(coords=(177,145))
 d=dialog(root.process_id(),'新增 表格')
 fields(d,s['tabs']['一般属性'],skip=(('ComboBox','样式 :'),))
 cs=[c for c in d.descendants(control_type='ComboBox') if c.window_text()=='样式 :' and c.is_visible()]
 if len(cs)!=2:raise ValueError('Two target line styles required')
 for c,index in zip(cs,s['line_style_indices']):
  ComboBoxWrapper(c.handle).select(index)
  if ComboBoxWrapper(c.handle).selected_index()!=index:raise ValueError('Table line style mismatch')
 for i,color in zip((0,2),s['table_line_colors']):
  set_rgb(d,color,'颜色 :',i)
  if probe(d,'颜色 :',i)!=color:raise ValueError('Table line color mismatch')
 confirm(d)
 d,name=placed_properties(root,w,'TB_0','表格的属性')
 tab(d,'轮廓');shape=geometry(s);fields(d,[{'type':'Edit','name':k,'value':v} for k,v in shape.items()])
 confirm(d);save(root)
 d,_=properties(root,w,'TB_0','表格的属性');tab(d,'一般属性');general=rows(d)
 for key in ('垂直 :','水平 :','宽度 :'):
  expected=[r['value'] for r in s['tabs']['一般属性'] if r['type']=='Edit' and r['name']==key]
  actual=[r['value'] for r in general if r['type']=='Edit' and r['name']==key]
  if actual!=expected:raise ValueError('Saved table count/line width mismatch')
 colors=[probe(d,'颜色 :',i) for i in (0,2)]
 if colors!=s['table_line_colors']:raise ValueError('Saved table color mismatch')
 tab(d,'轮廓');bounds=rows(d)
 if {r['name']:r['value'] for r in bounds if r['type']=='Edit' and r['name'] in shape}!=shape:raise ValueError('Saved table geometry mismatch')
 bs=[b for b in typed_children(d,'Button') if b.window_text()=='取消'];msg(bs[0].handle,245)
 report={'page':200,'source':'TB_0','target':name,'general':general,'geometry':bounds,'line_colors':colors,'line_style_indices':s['line_style_indices'],'saved_requested':True,'saved_reopened_verified':True,'custom_cell_sizes_review_pending':True,'runtime_verified':False}
 path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
