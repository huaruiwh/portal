"""Finalize one page's 890x469 layout: page size + bounds + directory audit, then a real compile.

Usage:  python tools/scale_finalize.py 218

Requires every object of that page to be verified already. Touches no other page and does not
re-verify objects; the page-size step itself audits the whole page directory and page bounds.
"""
import json,sys,os,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'tools'))
from eb_rebuild_page import call

PAGE=int(sys.argv[1])
TGT_TITLE='组装机_MT8106iP.emtp'
REVIEWED=(1848,1281)
DIR=ROOT/'evidence/scale-890x469'
WF=DIR/('page-%d-finalize.json'%PAGE)

def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
def load(p):return json.loads(p.read_text(encoding='utf8'))

def main():
    lock=ROOT/'tools/batch.lock'
    with lock.open('x',encoding='utf8') as fh:fh.write(json.dumps({'pid':os.getpid(),'task':'finalize%d'%PAGE},ensure_ascii=False))
    out=None
    try:
        out={'page':PAGE,'date':time.strftime('%Y-%m-%dT%H:%M:%S'),'finished':False,'other_pages_untouched':True}
        pp=DIR/('page-%d.json'%PAGE)
        if not pp.exists():raise ValueError('No scaling baseline for page %d'%PAGE)
        p=load(pp)
        out['before']=p['before'];out['after']=p['after']
        out['verified_objects']=[len(p['verified']),len(p['keys'])]
        if len(p['verified'])!=len(p['keys']):raise ValueError('Not all objects verified: %d/%d'%(len(p['verified']),len(p['keys'])))
        ws=[w for w in call('snapshot')['windows'] if w.get('title')]
        t=[w for w in ws if TGT_TITLE in w['title']]
        if len(t)!=1:raise ValueError('Unique target window required')
        h=t[0]['handle']
        size=(t[0]['rect'][2]-t[0]['rect'][0],t[0]['rect'][3]-t[0]['rect'][1])
        if size!=REVIEWED:
            call('uia',h,json.dumps({'restore_target_window':True,'reviewed_size':True}))
        if not p.get('page_size_verified'):
            print(json.dumps({'stage':'page-size','from':p['before'],'to':p['after']},ensure_ascii=False),flush=True)
            call('uia',h,json.dumps({'scale_post200':{'page':PAGE,'mode':'size'}}))
        p=load(pp)
        out.update({'page_size_verified':p.get('page_size_verified'),'bounds_verified':p.get('bounds_verified'),
                    'directory_count_verified':p.get('directory_count_verified'),
                    'minimum_lamp_gaps_verified':p.get('minimum_lamp_gaps_verified')})
        write(WF,out)
        print(json.dumps({'page_state':{k:out[k] for k in ('page','before','after','page_size_verified','bounds_verified','directory_count_verified')}},ensure_ascii=False),flush=True)
        print(json.dumps({'stage':'compile'},ensure_ascii=False),flush=True)
        call('uia',h,json.dumps({'compile_target':True}))
        out['compile']=load(ROOT/'evidence/latest-project-compile.json')
        out['finished']=bool(out.get('page_size_verified') and out['compile'].get('ok'))
        write(WF,out)
        print(json.dumps({'finished':out['finished'],'messages':out['compile']['messages'],
                          'project_bytes':out['compile']['project_bytes'],'exob_bytes':out['compile']['exob_bytes']},ensure_ascii=False),flush=True)
    except Exception as e:
        out=(out or {});out['error']=traceback.format_exc();write(WF,out)
        print(json.dumps({'error':str(e)[:600]},ensure_ascii=False),flush=True)
        raise
    finally:
        lock.unlink(missing_ok=True)

if __name__=='__main__':main()
