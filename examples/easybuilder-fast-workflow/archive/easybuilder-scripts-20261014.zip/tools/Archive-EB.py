"""Create a local restart archive; never control GUI or change automation state."""
import hashlib,json,zipfile
from pathlib import Path
from datetime import datetime,timezone,timedelta

ROOT=Path(__file__).resolve().parent.parent
stamp=datetime.now(timezone(timedelta(hours=8))).strftime('%Y%m%d_%H%M%S')
destination=ROOT/'archive';destination.mkdir(exist_ok=True)
files=[ROOT/'README.md',*sorted((ROOT/'docs').glob('*.md'))]
files += [p for p in (ROOT/'tools').iterdir() if p.is_file() and p.suffix in ('.py','.ps1','.json')]
files += [p for p in (ROOT/'evidence').rglob('*') if p.is_file() and p.suffix.lower() in ('.json','.txt','.log','.err','.csv','.tsv')]
files += [p for p in (ROOT/'source').rglob('*') if p.is_file()]
files += [ROOT/'output/组装机_MT8106iP.emtp',ROOT/'output/组装机_MT8106iP.exob']
files += [p for p in (ROOT/'backup/page29_script_baseline').glob('*.py')]
files += [p for p in (ROOT/'backup/before_page29_native_form_20261009').glob('*.py')]
files=sorted(set(p for p in files if p.exists()))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
manifest={'date':stamp,'purpose':'Local restart checkpoint, scripts, documents, source and saved output',
          'excluded':['tools/python-libs','external Python runtime','screenshots','older output backups'],
          'restore_note':'Keep the existing task directory/runtime; do not run archived request.json automatically.',
          'files':[{'path':str(p.relative_to(ROOT)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]}
manifest_path=destination/f'manifest-{stamp}.json'
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
bundle=destination/f'威纶通_暂停归档_{stamp}.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for p in files:archive.write(p,p.relative_to(ROOT))
    archive.write(manifest_path,'archive-manifest.json')
with zipfile.ZipFile(bundle) as archive:
    bad=archive.testzip()
    if bad:raise RuntimeError('Archive CRC failure: '+bad)
print(json.dumps({'archive':str(bundle),'files':len(files),'bytes':bundle.stat().st_size,'sha256':sha(bundle),'crc':'passed','manifest':str(manifest_path)},ensure_ascii=False))
