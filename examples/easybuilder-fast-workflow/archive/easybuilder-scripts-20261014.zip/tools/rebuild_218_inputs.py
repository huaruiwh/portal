import sys,json,os,shutil,datetime,traceback
from pathlib import Path
from eb_rebuild_page import ROOT,call
r=ROOT;lock=r/'tools/batch.lock';wf=r/'evidence/page218-inputs-rebuild.json'
def put(d):wf.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
def archive(d):
 note='\n### 2026-10-12：218页按钮及数值重做\n用户确认仅删除重做218页按钮和数值，灯、表格及其他控件不删除，其他队列暂停。先工程备份，再按编号逆序删除、顺序重建；每件保存及读回地址、模式、安全、输入格式和轮廓。数值按原件字体及双向居中设置适配表格比例；按钮按原件尺寸位置适配。实际断点：'+json.dumps(d,ensure_ascii=False)+'\n'
 for f in ['README.md','docs/MT8106iP重建-实现记录.md']:
  p=r/f;s=p.read_text(encoding='utf8');marker='\n### 2026-10-12：218页按钮及数值重做';idx=s.find(marker)
  if idx>=0:
   end=s.find('\n### ',idx+len(marker));s=s[:idx]+(s[end:]if end>=0 else '')
  p.write_text(s+note,encoding='utf8')
if lock.exists()or(r/'tools/later-pages-supervisor.lock').exists():raise RuntimeError('Existing controller')
lock.write_text(json.dumps({'pid':os.getpid(),'task':'rebuild218inputs'}),encoding='utf8')
d=json.loads(wf.read_text(encoding='utf8'))if wf.exists()else {'deleted':[],'built':[],'finished':False}
d.pop('error',None)
try:
 stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S');backup=Path(d['backup'])if d.get('backup')else r/('backup/218按钮数值重做前_'+stamp)
 if not backup.exists():
  backup.mkdir()
  for f in (r/'output').glob('组装机_MT8106iP.*'):shutil.copy2(f,backup/f.name)
 d['backup']=str(backup);put(d);archive(d)
 call('snapshot');ws=json.loads((r/'evidence/windows.json').read_text(encoding='utf8'));h=next(x['handle']for x in ws if '组装机_MT8106iP.emtp'in x['title'])
 keys=['NE_'+str(i)for i in range(9)]+['TS_'+str(i)for i in range(8)]+['FK_0','SW_0']
 for key in reversed(keys):
  if key in d['deleted']:continue
  call('uia',h,json.dumps({'replace_218_numerics':key,'build_bit_general':0}))
  for f in [r/f'evidence/target-218-{key.replace("_","")}-built.json',r/f'evidence/target-218-{key}-copy-phase.json']:
   if f.exists():shutil.move(str(f),str(backup/f.name))
  d['deleted'].append(key);put(d);archive(d)
 for key in keys:
  if key in d['built']:continue
  call('uia',h,json.dumps({'page':218,'copy_200_style_object':key,'recover_existing':(r/f'evidence/target-218-{key}-copy-phase.json').exists(),'rebuild_original_numeric':key.startswith('NE_'),'rebuild_original_buttons':not key.startswith('NE_'),'build_bit_general':0}))
  d['built'].append(key);put(d);archive(d)
 call('uia',h,json.dumps({'compile_target':True}))
 d['finished']=True;put(d);archive(d)
except Exception as e:
 d['error']=str(e);put(d);archive(d);raise
finally:lock.unlink(missing_ok=True)
