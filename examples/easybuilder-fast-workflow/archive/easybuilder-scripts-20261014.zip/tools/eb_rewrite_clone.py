"""Rewrite one copied target control using the original page's cached values."""
import json,re
from eb_extract import ROOT,rows
from eb_object_ui import target,properties,save,dialog
from eb_native_form import tab,fields,confirm,commit_text
from eb_layout import geometry

def values(items):return [(r['type'],r['name'],r['value']) for r in items if r['type'] in ('Edit','ComboBox','CheckBox','RadioButton') and 'value' in r]
def delta(source,base):
    changed=set();seen={}
    old={}
    for r in base:
        if 'value' not in r:continue
        k=(r['type'],r['name']);i=seen.get(k,0);seen[k]=i+1;old[(k,i)]=r['value']
    seen={}
    for r in source:
        if 'value' not in r:continue
        k=(r['type'],r['name']);i=seen.get(k,0);seen[k]=i+1
        if old.get((k,i),object())!=r['value']:changed.add(k)
    return [r for r in source if (r['type'],r['name']) in changed and 'value' in r]

def run(handle,q):
    page=int(q['rewrite_clone']);key=q['object']
    if page!=31 or not re.fullmatch(r'(TS|BL|MS|SW|TX)_\d+',key):raise ValueError('Copy trial page31 only')
    def checkpoint(stage):(ROOT/'evidence/clone-rewrite-stage.json').write_text(json.dumps({'page':page,'object':key,'stage':stage}),encoding='utf8')
    checkpoint('load source')
    source=json.loads((ROOT/f'evidence/source-object-properties/031_{key}.json').read_text(encoding='utf8'))
    template=json.loads((ROOT/f'evidence/source-object-properties/026_{key}.json').read_text(encoding='utf8'))
    kind=key.split('_')[0]
    titles={'TS':'位状态切换开关/位状态指示灯的属性','BL':'位状态指示灯/位状态切换开关的属性','MS':'多状态切换开关/多状态指示灯的属性','SW':'多状态设置的属性','TX':'文字/批注的属性'}
    checkpoint('target access')
    root,w=target(handle,page)
    checkpoint('open properties')
    if q.get('resume'):d=dialog(root.process_id(),titles[kind]);name=key
    else:d,name=properties(root,w,key,titles[kind])
    from pywinauto import Desktop
    Desktop(backend='win32').window(handle=d.handle).set_focus()
    report={'page':page,'object':key,'copied_from':26,'changes':[],'saved_requested':False}
    if kind!='TX':
        general=source['tabs']['一般属性']
        if any(r['name']=='触发宏指令' and r.get('value') for r in general):raise ValueError('Control macro requires review')
        checkpoint('general tab');tab(d,'一般属性');checkpoint('general fields')
        if values(general)!=values(template['tabs']['一般属性']):
            changed=delta(general,template['tabs']['一般属性'])
            ordinary=[r for r in changed if r['name'] not in ('设备 :',' Down','Static')]
            if ordinary:fields(d,ordinary)
            for typ,field in (('ComboBox','设备 :'),('ComboBox',' Down'),('Edit','Static')):
                group=[r for r in changed if r['type']==typ and r['name']==field]
                if group:fields(d,group)
            report['changes'].append('general')
        checkpoint('general readback');actual=rows(d)
        expected=[r['value'] for r in general if r['type']=='Edit' and r['name']=='Static']
        if [r['value'] for r in actual if r['type']=='Edit' and r['name']=='Static']!=expected:raise ValueError('Copied read/write address mismatch')
        report['general']=actual
        label_source=source.get('label_states',{})
        def captions(states):return {k:[r.get('value') for r in v if r['type']=='Edit' and r['name']==''] for k,v in states.items()}
        if captions(label_source)!=captions(template.get('label_states',{})):
            checkpoint('labels');tab(d,'标签')
            use=next(r['value'] for r in source['tabs']['标签'] if r['type']=='CheckBox' and r['name']=='使用文字标签')
            old_use=next(r['value'] for r in template['tabs']['标签'] if r['type']=='CheckBox' and r['name']=='使用文字标签')
            if use!=old_use:fields(d,[{'type':'CheckBox','name':'使用文字标签','value':use}])
            if use:
                from pywinauto.controls.win32_controls import ComboBoxWrapper
                states=[c for c in d.descendants(control_type='ComboBox',cache_enable=True) if c.element_info.name=='状态 :' and c.is_visible()]
                if len(states)!=1 or set(label_source)!={'0','1'}:raise ValueError('Two source labels required')
                texts=[]
                for state in ('0','1'):
                    ComboBoxWrapper(states[0].handle).select(state)
                    # The user requests copied appearance, with addresses and captions changed.
                    # Retain template typography; update the caption states only.
                    texts.append(next(r['value'] for r in label_source[state] if r['type']=='Edit' and r['name']==''))
                from eb_label_commit import commit
                commit(d,texts)
            report['changes'].append('labels')
    else:
        tab(d,'文字/批注');expected=source['tabs']['文字/批注']
        if values(expected)!=values(template['tabs']['文字/批注']):
            adapted=[dict(r,name='水平 :') if r['name']=='多行 :' else r for r in expected]
            old=[dict(r,name='水平 :') if r['name']=='多行 :' else r for r in template['tabs']['文字/批注']]
            changes=delta(adapted,old)
            if changes:fields(d,changes,skip=(('CheckBox','使用字符串表'),('Edit','内容')))
            commit_text(d,'内容',next(r['value'] for r in expected if r['type']=='Edit' and r['name']=='内容'))
            report['changes'].append('text')
        report['text']=rows(d)
    if values(source['tabs']['安全'])!=values(template['tabs']['安全']):
        if any(r['name']=='使用寄存器状态/数值' and r.get('value') for r in source['tabs']['安全']):raise ValueError('Copied visibility requires review')
        tab(d,'安全')
        from eb_press_safety import apply
        apply(d,source);fields(d,source['tabs']['安全'],skip=(('CheckBox','最短按压时间'),('ComboBox',' Down')))
        report['changes'].append('safety')
    checkpoint('geometry');tab(d,'轮廓');shape=geometry(source)
    current={r['name']:r['value'] for r in rows(d) if r['type']=='Edit' and r['name'] in shape}
    if current!=shape:
        fields(d,[{'type':'Edit','name':k,'value':v} for k,v in shape.items()],commit_edits=True);report['changes'].append('geometry')
    actual={r['name']:r['value'] for r in rows(d) if r['type']=='Edit' and r['name'] in shape}
    if actual!=shape:raise ValueError('Copied geometry mismatch')
    checkpoint('confirm and save');report['geometry']=actual;confirm(d);save(root);report.update(saved_requested=True,visual_style_inherited=True,font_inherited_from_template=True,offline_simulation_verified=False)
    (ROOT/f'evidence/target-031-{key}-clone-rewritten.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
