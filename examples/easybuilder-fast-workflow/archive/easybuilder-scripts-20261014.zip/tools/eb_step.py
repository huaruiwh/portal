"""Single serial worker request; compact output for resumable manual stages."""
import json,sys
from eb_rebuild_page import ROOT,call
if __name__=='__main__':
    call('snapshot')
    ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
    kind=sys.argv[1] if len(sys.argv)>1 else 'snapshot'
    if kind=='snapshot':
        print(json.dumps([w for w in ws if 'EasyBuilder' in w.get('class','') or '新增' in w.get('title','')],ensure_ascii=False))
    elif kind=='handle':
        print(json.dumps(call('uia',int(sys.argv[2]),sys.argv[3]),ensure_ascii=False))
    else:
        title='组装机2台15工位取消.cmtp' if kind=='source' else '组装机_MT8106iP.emtp'
        matches=[w for w in ws if title in w['title'] and w['class']=='EasyBuilderPro']
        if len(matches)!=1:raise ValueError('One current project required')
        q=json.loads(sys.argv[2]);r=call('uia',matches[0]['handle'],json.dumps(q,ensure_ascii=False))
        print(json.dumps(r,ensure_ascii=False))
