import json,time
from pywinauto import Desktop
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_extract import ROOT
from eb_object_ui import dialog,target,properties,save
from eb_native_form import tab,typed_children,fields,confirm
from eb_page26_shapes import native_rows,cancel
from eb_color_picker import probe,set_rgb
from eb_uia_inventory import descendants as cached

def run(handle,q):
 root=Desktop(backend='win32').window(handle=handle).wrapper_object();pid=root.process_id()
 if q['flow_vector']=='source-cancel':
  if '组装机2台15工位取消.cmtp' not in root.window_text():raise ValueError('Source-only cancel')
  from eb_color_picker import native_color_handles,close
  from types import SimpleNamespace
  for h in native_color_handles(pid):close(SimpleNamespace(handle=h),'Cancel')
  from pywinauto.keyboard import send_keys
  d=dialog(pid,'位状态指示灯/位状态切换开关的属性');Desktop(backend='win32').window(handle=d.handle).set_focus()
  for _ in range(3):
   popups=[v for v in Desktop(backend='win32').windows(process=pid) if v.is_visible() and v.class_name().startswith('Qt5QWindowPopup')]
   if not popups:break
   send_keys('{ESC}');time.sleep(.1)
  cancel(d);return
 if q['flow_vector']=='target-repair':
  page=int(q.get('page',44));n=int(q.get('n',3));key=f'BL_{n}'
  if page!=44 or n not in (3,4,5,6):raise ValueError('Reviewed44 BL3-BL6 only')
  original=json.loads((ROOT/f'evidence/page{page}-{key}-source-vector.json').read_text(encoding='utf8'))
  if original.get('gallery_family')!='System Frame' or original.get('gallery_index')!='0':raise ValueError('Observed vector identity required')
  root,w=target(handle,page);d,_=properties(root,w,key,'位状态指示灯/位状态切换开关的属性')
  before={}
  for scope in ('一般属性','轮廓','标签'):
   tab(d,scope);before[scope]=native_rows(d)
  tab(d,'图片');flags=[r for r in original['picture'] if r['type']=='CheckBox' and r['name'] in ('使用图片','使用向量图','内部','外框','调整对象尺寸为图片原尺寸')]
  fields(d,flags)
  bs=[c for c in typed_children(d,'Button') if c.element_info.name=='图库...' and c.is_visible() and c.is_enabled()]
  if len(bs)!=1:raise ValueError('One enabled target vector gallery required')
  bs[0].click_input();g=dialog(pid,'向量图管理');Desktop(backend='win32').window(handle=g.handle).set_focus()
  observed=cached(g)
  if not any(c.element_info.control_type=='MenuItem' and c.element_info.name=='System Frame' and c.is_visible() for c in observed):raise ValueError('Observed System Frame category required')
  gs=[c for c in observed if c.element_info.control_type=='Group' and c.element_info.name=='0' and c.is_visible()]
  if len(gs)!=1:raise ValueError('Unique Frame0 required')
  from pywinauto import mouse
  r=gs[0].rectangle();mouse.click(coords=(r.left+60,r.top+70));time.sleep(.15);confirm(g)
  tab(d,'图片');cs=[c for c in typed_children(d,'ComboBox') if c.element_info.name=='状态 :']
  if len(cs)!=1:raise ValueError('Unique target state selector required')
  for state in ('0','1'):
   ComboBoxWrapper(cs[0].handle).select(state)
   for field,anchor in [('internal','内部'),('border','外框')]:
    want=original['colors'][state][field]
    if set_rgb(d,want,{'anchor_type':'CheckBox','anchor_name':anchor})['after']!=want:raise ValueError('Vector RGB write/read mismatch')
  confirm(d);save(root);d,_=properties(root,w,key,'位状态指示灯/位状态切换开关的属性')
  vals=lambda rs:[(r['type'],r['name'],r.get('value')) for r in rs if 'value' in r]
  for scope in before:
   tab(d,scope)
   if vals(before[scope])!=vals(native_rows(d)):raise ValueError('Vector changed address/geometry/label '+scope)
  tab(d,'图片');actual=native_rows(d)
  for f in flags:
   if not any(r['type']==f['type'] and r['name']==f['name'] and r.get('value')==f['value'] for r in actual):raise ValueError('Saved vector flags mismatch')
  cs=[c for c in typed_children(d,'ComboBox') if c.element_info.name=='状态 :']
  for state in ('0','1'):
   ComboBoxWrapper(cs[0].handle).select(state)
   for field,anchor in [('internal','内部'),('border','外框')]:
    if probe(d,{'anchor_type':'CheckBox','anchor_name':anchor})!=original['colors'][state][field]:raise ValueError('Saved vector original RGB mismatch')
  cancel(d)
  (ROOT/f'evidence/page{page}-{key}-vector-correction.json').write_text(json.dumps({'page':page,'object':key,'family':'System Frame','gallery_index':'0','colors':original['colors'],'saved':True,'reopened_rgb_verified':True,'general_geometry_labels_unchanged':True,'runtime_verified':False},ensure_ascii=False,indent=2),encoding='utf8');return
 if q['flow_vector'] not in ('source-inspect','source-layout') or '组装机2台15工位取消.cmtp' not in root.window_text():raise ValueError('Source-only vector inspection')
 page=int(q.get('page',44));n=int(q.get('n',3));key=f'BL_{n}'
 d=dialog(pid,'位状态指示灯/位状态切换开关的属性');tab(d,'图片');before=native_rows(d)
 if q['flow_vector']=='source-layout':
  entries=[]
  for c in cached(d):
   if c.is_visible() and c.element_info.control_type in ('Text','MenuItem','CheckBox'):
    r=c.rectangle();entries.append({'type':c.element_info.control_type,'name':c.element_info.name,'rect':[r.left,r.top,r.right,r.bottom]})
  (ROOT/'evidence/flow-vector-layout.json').write_text(json.dumps({'rows':before,'layout':entries},ensure_ascii=False,indent=2),encoding='utf8');return
 if not any(r['name']=='使用向量图' and r.get('value')==1 for r in before):raise ValueError('Source vector must be enabled')
 cs=[c for c in typed_children(d,'ComboBox') if c.element_info.name=='状态 :']
 if len(cs)!=1:raise ValueError('Unique vector state required')
 colors={}
 for state in ('0','1'):
  ComboBoxWrapper(cs[0].handle).select(state)
  colors[state]={'internal':probe(d,{'anchor_type':'CheckBox','anchor_name':'内部'}),'border':probe(d,{'anchor_type':'CheckBox','anchor_name':'外框'})}
 bs=[c for c in typed_children(d,'Button') if c.element_info.name=='图库...' and c.is_visible() and c.is_enabled()]
 if len(bs)!=1:raise ValueError('Exactly one enabled source vector gallery required')
 bs[0].click_input();g=dialog(pid,'向量图管理')
 Desktop(backend='win32').window(handle=g.handle).set_focus();time.sleep(.2)
 entries=[]
 gallery_observed=cached(g)
 for c in gallery_observed:
  if c.element_info.control_type not in ('Group','MenuItem','Text') or not c.is_visible():continue
  r={'type':c.element_info.control_type,'name':c.element_info.name}
  try:r['selected']=bool(c.iface_selection_item.CurrentIsSelected)
  except Exception:pass
  try:r['legacy_state']=c.iface_legacy_iaccessible.CurrentState
  except Exception:pass
  entries.append(r)
 screenshot=g.capture_as_image();screenshot.save(str(ROOT/f'evidence/page{page}-{key}-source-vector-local.png'))
 gr=g.rectangle();candidates=[]
 for c in gallery_observed:
  if c.element_info.control_type!='Group' or not c.element_info.name.isdigit() or not c.is_visible():continue
  cr=c.rectangle();left=max(0,cr.left-gr.left);top=max(0,cr.top-gr.top);right=min(screenshot.width,cr.right-gr.left)
  strip=screenshot.crop((left,top,right,min(top+22,screenshot.height))).convert('RGB')
  yellow=sum(1 for red,green,blue in strip.getdata() if red>230 and green>230 and blue<70)
  if yellow>200:candidates.append(c.element_info.name)
 if len(candidates)!=1:raise ValueError('Original selected vector identity not uniquely observed')
 report={'page':page,'object':key,'picture':before,'colors':colors,'gallery':entries,'source_modified':False,'gallery_index':candidates[0],'gallery_family':next((r['name'] for r in entries if r['type']=='MenuItem' and r['name']),None),'identity_method':'original selected thumbnail header yellow highlight, unique gallery Group rectangle'}
 (ROOT/f'evidence/page{page}-{key}-source-vector.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 cancel(g);cancel(d)
