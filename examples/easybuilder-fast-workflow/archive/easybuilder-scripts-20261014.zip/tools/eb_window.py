"""Read source page size, layers and macro hooks through settings; cancel only."""
import re,json,time
from pathlib import Path
from pywinauto import Desktop
from pywinauto.keyboard import send_keys
from eb_extract import rows
ROOT=Path(__file__).resolve().parent.parent
def read_cancel(w,d,page_id,request,target):
    from pywinauto.controls.win32_controls import ButtonWrapper
    import ctypes
    try:
        result={'id':page_id,'controls':rows(d)}
        color_label='背景颜色 :' if target and any(c['type']=='Text' and c['name']=='背景颜色 :' for c in result['controls']) else '颜色 :'
        result['background_color_label']=color_label
        color_occurrence=0
        if not target:
            source_labels=[c for c in d.descendants(control_type='Text') if c.window_text()=='颜色 :' and c.is_visible()]
            # cMT provider order: window color first, border color second.
            # The picker sorts vertically, so retain identity through that sort.
            if len(source_labels)==2:
                color_occurrence=sorted(source_labels,key=lambda c:c.rectangle().top).index(source_labels[0])
        if request.get('color_probe'):
            from eb_color_picker import probe
            result['background_rgb']=probe(d,color_label,color_occurrence)
            result['background_color_label']=color_label
            result['background_color_occurrence']=color_occurrence
        if request.get('apply_source_background'):
            if not target:raise ValueError('Source background must never be edited')
            src=json.loads((ROOT/'evidence'/'source-pages-settings'/f'{page_id:03d}.json').read_text(encoding='utf8'))
            rgb=src['background_rgb']
            from eb_color_picker import set_rgb,probe
            result['background_change']=set_rgb(d,rgb,color_label)
            if probe(d,color_label)!=rgb:raise ValueError('Target color chooser reopening mismatch')
            result['background_rgb']=rgb
            if request.get('apply_source_border'):
                from eb_native_form import fields
                border=[c for c in src['controls'] if c['type']=='ComboBox' and c['name']=='宽度 :']
                if len(border)!=1:raise ValueError('One original border-width setting required')
                fields(d,border)
                result['controls']=rows(d)
        if request.get('apply_source_layers'):
            if not target or page_id not in (100,101,102):raise ValueError('Reviewed target layer repair only')
            src=json.loads((ROOT/'evidence/source-pages-settings'/f'{page_id:03d}.json').read_text(encoding='utf8'))
            names=[chr(24213)+chr(23618)+' :',chr(20013)+chr(23618)+' :',chr(39030)+chr(23618)+' :']
            expected=[x for x in src['controls'] if x['type']=='ComboBox' and x['name'] in names]
            if len(expected)!=3:raise ValueError('Three source layer settings required')
            from eb_native_form import fields
            fields(d,expected);result['controls']=rows(d)
            result['layers_expected']={x['name']:x['value'] for x in expected}
            actual={x['name']:x.get('value') for x in result['controls'] if x['type']=='ComboBox' and x['name'] in names}
            if actual!=result['layers_expected']:raise ValueError('Layer readback mismatch')
            result['layers_verified']=True
        path=ROOT/'evidence'/('target-pages-settings' if target else 'source-pages-settings');path.mkdir(exist_ok=True)
        (path/f'{page_id:03d}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
        if request.get('apply_source_layers'):
            from eb_native_form import confirm
            from eb_object_ui import save
            confirm(d);save(Desktop(backend='win32').window(handle=w.handle).wrapper_object())
            (ROOT/f'evidence/target-page-{page_id:03d}-layers.json').write_text(json.dumps({'page':page_id,'layers':result['layers_expected'],'saved_requested':True,'property_reopened_verified':False},ensure_ascii=False,indent=2),encoding='utf8')
            return
        if request.get('apply_source_background'):
            ok=[c for c in d.descendants(control_type='Button') if c.window_text()=='确定' and c.is_visible()]
            if len(ok)!=1:raise ValueError('Unique target settings confirmation required')
            ButtonWrapper(ok[0].element_info.handle).send_message_timeout(0x00F5,timeout=2)
            for _ in range(10):
                if not ctypes.windll.user32.IsWindow(d.handle):break
                time.sleep(.1)
            else:raise ValueError('Target color settings did not close')
            w.set_focus();send_keys('^s',pause=.01)
            (ROOT/'evidence'/f'target-page-{page_id:03d}-color.json').write_text(json.dumps({'page':page_id,'rgb':rgb,'label':color_label,'target_process_id':w.process_id(),'saved_requested':True,'chooser_reopened_verified':True,'project_reopened_verified':False},ensure_ascii=False),encoding='utf8')
    finally:
        if ctypes.windll.user32.IsWindow(d.handle):
            cancel=[c for c in d.descendants(control_type='Button') if c.window_text()=='取消' and c.is_visible()]
            if len(cancel)!=1:raise ValueError('Source cancel must be unique')
            ButtonWrapper(cancel[0].element_info.handle).send_message_timeout(0x00F5,timeout=2)
            for _ in range(10):
                if not ctypes.windll.user32.IsWindow(d.handle):break
                time.sleep(.1)
            else:raise ValueError('Source settings cancellation did not close dialog')

def run(handle,request):
    w=Desktop(backend='uia').window(handle=handle).wrapper_object()
    target=(request.get('target_readonly') or request.get('apply_source_background')) and '组装机_MT8106iP.emtp' in w.window_text()
    if '组装机2台15工位取消.cmtp' not in w.window_text() and not target:raise ValueError('Known source or explicit read-only target only')
    page_id=request['page_settings'];wr=w.rectangle()
    if request.get('resume_settings'):
        dialogs=[v for v in Desktop(backend='win32').windows() if v.process_id()==w.process_id() and v.window_text()=='窗口设置' and v.is_visible()]
        if len(dialogs)!=1:raise ValueError('Existing source settings required')
        d=Desktop(backend='uia').window(handle=dialogs[0].handle).wrapper_object()
        number=[c['value'] for c in rows(d) if c['type']=='Edit' and c['name']=='窗口编号 :']
        if number!=[str(page_id)]:raise ValueError('Existing source page number mismatch')
        read_cancel(w,d,page_id,request,target);return
    from eb_directory import scope
    fields=[c for c in scope(w).descendants(control_type='Edit',cache_enable=True) if c.is_visible()]
    if len(fields)!=1:raise ValueError('Source page filter must be unique')
    w.set_focus()
    import win32clipboard
    win32clipboard.OpenClipboard()
    try:win32clipboard.EmptyClipboard();win32clipboard.SetClipboardText(str(page_id)+' :',win32clipboard.CF_UNICODETEXT)
    finally:win32clipboard.CloseClipboard()
    fields[0].click_input();fields[0].set_focus();send_keys('^a^v',pause=.05);time.sleep(.15)
    if fields[0].get_value()!=str(page_id)+' :':raise ValueError('Window settings filter readback mismatch')
    if page_id>=200:
        from pywinauto import mouse
        trees=[c for c in w.descendants(control_type='Tree') if c.is_visible()]
        if len(trees)!=1:raise ValueError('Unique settings tree required')
        tr=trees[0].rectangle();mouse.scroll(coords=((tr.left+tr.right)//2,(tr.top+tr.bottom)//2),wheel_dist=80);time.sleep(.15)
    headers=[]
    for attempt in range(3):
        fresh=Desktop(backend='uia').window(handle=handle).wrapper_object()
        headers=[c for c in scope(fresh).descendants(control_type='TreeItem')if re.match(r'^'+str(page_id)+r'\s*:',c.element_info.name)]
        if len(headers)==1:break
        w.set_focus();time.sleep(.2)
        mouse.scroll(coords=((tr.left+tr.right)//2,(tr.top+tr.bottom)//2),wheel_dist=80);time.sleep(.2)
    if len(headers)!=1:raise ValueError('Unique refreshed window settings page header required')
    page=headers[0]
    page.click_input(button='right',coords=(40,page.rectangle().height()//2));time.sleep(.1)
    matches=[]
    for _ in range(15):
        matches=[]
        for popup in Desktop(backend='win32').windows(process=w.process_id()):
            if popup.process_id()==w.process_id() and (popup.class_name().startswith('Qt5QWindowPopup') or popup.class_name()=='#32768') and popup.is_visible():
                ui=Desktop(backend='uia').window(handle=popup.handle).wrapper_object()
                matches.extend(c for c in ui.descendants(control_type='MenuItem') if c.window_text()=='设置...' and c.is_visible())
        if len(matches)==1:break
        time.sleep(.1)
    if len(matches)!=1:raise ValueError('Expected one source Settings menu action')
    matches[0].click_input();time.sleep(.2)
    dialogs=[]
    for _ in range(20):
        dialogs=[d for d in Desktop(backend='win32').windows() if d.process_id()==w.process_id() and d.window_text()=='窗口设置' and d.is_visible()]
        if len(dialogs)==1:break
        time.sleep(.1)
    if len(dialogs)!=1:raise ValueError('Expected one source window settings dialog')
    d=Desktop(backend='uia').window(handle=dialogs[0].handle).wrapper_object()
    read_cancel(w,d,page_id,request,target)


