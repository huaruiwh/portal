"""Read source page/object inventory by its tree filter; never save source."""
import json,re,time
from pathlib import Path
from pywinauto import Desktop
from pywinauto.keyboard import send_keys
ROOT=Path(__file__).resolve().parent.parent

def run(handle,request):
    w=Desktop(backend='uia').window(handle=handle).wrapper_object()
    if '组装机2台15工位取消.cmtp' not in w.window_text():raise ValueError('Original source only')
    pages=request['inventory']
    if not 1<=len(pages)<=5:raise ValueError('Read 1..5 pages per batch')
    path=ROOT/'evidence'/'source-pages-inventory.json'
    data=json.loads(path.read_text(encoding='utf-8-sig'))
    byid={p['id']:p for p in data['pages']}
    wr=w.rectangle()
    native=Desktop(backend='win32').window(handle=handle).wrapper_object()
    native.set_focus();time.sleep(.15)
    tabs=[c for c in w.descendants(control_type='TabItem') if c.window_text()=='目录树' and c.is_visible()]
    if len(tabs)==1:native.set_focus();tabs[0].click_input();time.sleep(.2)
    from eb_directory import scope
    directory=scope(w)
    fields=[c for c in directory.descendants(control_type='Edit') if c.is_visible()]
    if len(fields)!=1:raise ValueError('Source tree filter must be unique: '+str([(c.element_info.name,c.rectangle().__str__())for c in fields]))
    field=fields[0]
    trees=[c for c in w.descendants(control_type='Tree') if c.is_visible()]
    if len(trees)!=1:raise ValueError('Source directory tree must be unique')
    tree=trees[0]
    reports=[]
    try:
        for page_id in pages:
            native.set_focus()
            import win32clipboard
            win32clipboard.OpenClipboard()
            try:win32clipboard.EmptyClipboard();win32clipboard.SetClipboardText(str(page_id)+' :',win32clipboard.CF_UNICODETEXT)
            finally:win32clipboard.CloseClipboard()
            field.click_input();field.set_focus();send_keys('^a^v',pause=.05);time.sleep(.15)
            if field.get_value()!=str(page_id)+' :':raise ValueError('Inventory filter readback mismatch')
            def items():return [c for c in tree.descendants(control_type='TreeItem') if c.is_visible()]
            nodes=items()
            headers=[c for c in nodes if re.match(r'^'+str(page_id)+r'\s*:',c.window_text())]
            if len(headers)!=1:
                reports.append({'id':page_id,'defined':False});continue
            page=headers[0];name=page.window_text()
            page.double_click_input(coords=(40,page.rectangle().height()//2));time.sleep(.2)
            nodes=items();page=next(c for c in nodes if c.window_text()==name);index=nodes.index(page)
            following=nodes[index+1:]
            expanded=bool(following and not re.match(r'^\d+(?:\s*:|$)',following[0].window_text()))
            if not expanded:
                try:page.expand()
                except Exception:
                    rect=page.rectangle();parent=page.parent().rectangle()
                    x=rect.left-14;y=(rect.top+rect.bottom)//2
                    if not parent.left<=x<parent.right:raise ValueError('Expansion arrow outside tree')
                    from pywinauto import mouse
                    mouse.click(coords=(x,y))
                time.sleep(.15);nodes=items()
                page=next(c for c in nodes if c.window_text()==name);index=nodes.index(page)
            objects=[]
            for c in nodes[index+1:]:
                text=c.window_text()
                if re.match(r'^\d+(?:\s*:|$)',text):break
                if text:objects.append(text)
            record=byid.get(page_id,{'id':page_id,'close_macros':[]})
            record.update(observed_name=name,observed_objects=objects,inventory_filter_verified=True)
            byid[page_id]=record
            reports.append({'id':page_id,'objects':len(objects)})
            data['pages']=[byid[n] for n in sorted(byid)]
            data['observed_page_count']=len(byid)
            path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
    finally:
        w.set_focus();field.click_input();send_keys('^a{BACKSPACE}',pause=.01)
    (ROOT/'evidence'/'inventory-batch-result.json').write_text(json.dumps(reports,ensure_ascii=False),encoding='utf8')
