"""Read-only benchmark against live saved204 controls; all dialogs cancelled."""
import json,time,statistics
from pywinauto import Desktop
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,dialog
from eb_page26_shapes import cancel,native_rows
from eb_native_form import tab
from eb_extract import rows
from eb_native_messages import text

def cached_edits(d,names):
 out={}
 for c in Desktop(backend='win32').window(handle=d.handle).wrapper_object().descendants(class_name='Edit'):
  if not c.is_visible():continue
  u=Desktop(backend='uia').window(handle=c.handle).wrapper_object();name=u.element_info.name
  if name in names:
   if name in out:raise ValueError('Nonunique live geometry field '+name)
   out[name]=int(c.handle)
 if set(out)!=set(names):raise ValueError('Required live geometry fields absent')
 return out

def native_edit_read(handles):
 return {name:text(h).rstrip('\r\n')for name,h in handles.items()}

def run(handle,q):
 root,w=target(handle,204)
 if not root.is_enabled():cancel(dialog(root.process_id(),'位状态指示灯/位状态切换开关的属性'))
 if q.get('probe_shape'):
  key=q['probe_shape']
  if key not in ('BL_6','BL_7','BL_8','BL_9'):raise ValueError('Reviewed recovery probe only')
  d,_=properties(root,w,key,'位状态指示灯/位状态切换开关的属性')
  try:
   tab(d,'轮廓');actual=native_edit_read(cached_edits(d,('X :',' Y :',' 宽度 :','高度 :')))
   (ROOT/f'evidence/{key}-current-shape.json').write_text(json.dumps(actual,ensure_ascii=False),encoding='utf8')
  finally:cancel(d)
  return
 if q.get('benchmark_bound_fields'):
  return bound_benchmark(root,w)
 result={'page':204,'object':'BL_0','changed':False,'measurements':[]}
 d,_=properties(root,w,'BL_0','位状态指示灯/位状态切换开关的属性')
 try:
  tab(d,'轮廓');names=('X :',' Y :',' 宽度 :','高度 :')
  begin=time.perf_counter();handles=cached_edits(d,names);result['native_field_mapping_seconds']=round(time.perf_counter()-begin,6)
  expected=None
  for route in ('uia_full','native_full','native_fields'):
   times=[]
   for i in range(3):
    begin=time.perf_counter()
    if route=='native_fields':actual=native_edit_read(handles)
    else:actual={r['name']:r['value'] for r in (rows(d)if route=='uia_full'else native_rows(d))if r['type']=='Edit'and r['name']in names}
    times.append(time.perf_counter()-begin)
    if expected is None:expected=actual
    if actual!=expected:raise ValueError('Speed route value mismatch '+route)
   result['measurements'].append({'route':route,'seconds':times,'median_seconds':statistics.median(times),'same_values':True})
  result['observed_shape']=expected
 finally:cancel(d)
 # Reopen, rebuild live handles: never reuse HWND mapping across dialog lifetimes.
 d,_=properties(root,w,'BL_0','位状态指示灯/位状态切换开关的属性')
 try:
  tab(d,'轮廓');begin=time.perf_counter();actual=native_edit_read(cached_edits(d,names));result['fresh_dialog_native_fields_seconds']=time.perf_counter()-begin
  if actual!=expected:raise ValueError('Fresh-dialog value mismatch')
  result['reopened_same_values']=True
 finally:cancel(d)
 (ROOT/'evidence/live-speed-benchmark.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')


def bound_benchmark(root,w):
 from eb_live_fields import capture
 result={'page':204,'object':'BL_0','changed':False,'measurements':[]}
 d,_=properties(root,w,'BL_0','位状态指示灯/位状态切换开关的属性')
 try:
  for name,wants in [('一般属性',[('Edit','Static'),('ComboBox','设备 :'),('ComboBox',' Down')]),('安全',[('CheckBox','使用寄存器状态/数值'),('ComboBox','用户限制 Down')])]:
   tab(d,name);baseline=None
   for route in ('uia_full','required_fields'):
    times=[]
    for i in range(3):
     begin=time.perf_counter();rs=rows(d)if route=='uia_full'else capture(d,wants)
     actual=sorted((r['type'],r['name'],r['value'])for r in rs if(r['type'],r['name'])in wants and 'value'in r)
     times.append(time.perf_counter()-begin)
     if baseline is None:baseline=actual
     if actual!=baseline:raise ValueError('Bound field benchmark mismatch '+name+' '+route)
    result['measurements'].append({'tab':name,'route':route,'seconds':times,'median_seconds':statistics.median(times),'same_values':True,'fields':baseline})
 finally:cancel(d)
 (ROOT/'evidence/live-bound-fields-benchmark.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
