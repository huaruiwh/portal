"""Fetch UIA metadata in one provider cache request instead of lazy getters."""
from pywinauto.uia_defines import IUIA
from pywinauto.uia_element_info import UIAElementInfo
from pywinauto.controls.uiawrapper import UIAWrapper
def descendants(d,control_type=None):
    api=IUIA();cache=api.iuia.CreateCacheRequest()
    for field in ('Name','ControlType','NativeWindowHandle','ClassName','IsOffscreen'):
        cache.AddProperty(getattr(api.UIA_dll,'UIA_'+field+'PropertyId'))
    cache.TreeScope=api.tree_scope['element']
    cond=api.build_condition(control_type=control_type) if control_type else api.true_condition
    arr=d.element_info.element.FindAllBuildCache(api.tree_scope['descendants'],cond,cache)
    result=[]
    for i in range(arr.Length):
        elem=arr.GetElement(i);info=UIAElementInfo(elem,True)
        info._cached_name=elem.CachedName or ''
        info._cached_control_type=api.known_control_type_ids[elem.CachedControlType]
        # Qt controls without an HWND can expose a null cached property.
        # None is pywinauto's "not cached" sentinel and causes a fresh,
        # potentially blocking COM lookup for every wrapper construction.
        info._cached_handle=elem.CachedNativeWindowHandle or 0
        info._cached_class_name=elem.CachedClassName or ''
        info._cached_visible=not elem.CachedIsOffscreen
        result.append(UIAWrapper(info))
    return result
