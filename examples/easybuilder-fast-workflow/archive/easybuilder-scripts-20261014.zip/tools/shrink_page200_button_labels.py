import json,sys,os,traceback
from datetime import datetime
from eb_rebuild_page import ROOT,call
p=ROOT/'evidence/page200-button-label-reduction.json';lock=ROOT/'tools/batch.lock'
with lock.open('x',encoding='utf8') as f:json.dump({'pid':os.getpid(),'task':'page200 button label shrink'},f)
r={'date':datetime.now().isoformat(),'completed':[],'status':'running'}
try:
 for key in [f'TS_{n}' for n in range(12)]+['SW_0']:
  r['stage']=key;p.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
  for phase in ['edit','verify']:
   call('uia',10488686,json.dumps({'adjust_fonts':True,'page':200,'key':key,'size_decrement':1,'phase':phase,'build_bit_general':0}))
  a=json.loads((ROOT/f'evidence/font-adjustments/200_{key}.json').read_text(encoding='utf8'))
  r['completed'].append({'key':key,'verified':a['verified'],'sizes':{state:record.get('expected_size') for state,record in a['tabs']['标签'].items()}})
  p.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(r['completed'][-1]),flush=True)
 r['status']='completed'
except Exception:r['status']='needs-review';r['error']=traceback.format_exc();print(r['error'],flush=True)
finally:
 p.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8');lock.unlink(missing_ok=True)
