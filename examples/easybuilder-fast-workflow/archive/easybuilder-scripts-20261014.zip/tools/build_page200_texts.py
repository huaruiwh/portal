"""Serial page200 static texts only; reuse cached original text and native builders."""
import json,os,traceback,re
from datetime import datetime
from eb_rebuild_page import ROOT,call

def main():
 lock=ROOT/'tools/batch.lock'
 with lock.open('x',encoding='utf8') as f:json.dump({'pid':os.getpid(),'task':'page200 static texts'},f)
 p=ROOT/'evidence/page200-text-workflow.json'
 d={'date':datetime.now().isoformat(),'completed':[],'status':'running','total':17}
 def ui(h,q):return call('uia',h,json.dumps(q,ensure_ascii=False))
 def persist():p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
 try:
  audit=json.loads((ROOT/'evidence/target-page200-audit.json').read_text(encoding='utf8'))
  if audit.get('unexpected') or audit.get('label_mismatch'):raise ValueError('Review target directory before creation')
  inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
  names=next(x['observed_objects'] for x in inv['pages'] if x['id']==200)
  for n in range(17):
   key=f'TX_{n}';d['stage']=key;persist()
   rp=ROOT/f'evidence/target-200-TX{n}-built.json'
   sp=ROOT/f'evidence/source-object-properties/200_{key}.json'
   s=json.loads(sp.read_text(encoding='utf8'))
   if not rp.exists():
    if key not in audit['missing']:raise ValueError('Existing text without saved report; inspect '+key)
    if not s.get('colors'):
     name=next(x for x in names if re.search(r'(?:^|\])\s*'+re.escape(key)+r'(?:\s|$)',x))
     ui(133522,{'extract':{'page':200,'object':name}})
    ui(10488686,{'page':200,'build_tx':n})
   fp=ROOT/f'evidence/font-adjustments/200_{key}.json'
   font=json.loads(fp.read_text(encoding='utf8')) if fp.exists() else {}
   q={'adjust_fonts':True,'page':200,'key':key,'build_bit_general':0}
   if n:q['size_override']=12
   if not font.get('verified'):
    if not font.get('save_requested'):ui(10488686,dict(q,phase='edit'))
    ui(10488686,dict(q,phase='verify'))
   from eb_saved_progress import record
   record(200,f'TX{n}')
   d['completed'].append(key);persist()
   print(json.dumps({'saved_verified':key,'completed':len(d['completed'])}),flush=True)
  d['status']='static-texts-saved-verified'
 except Exception:
  d['status']='needs-review';d['error']=traceback.format_exc();print(d['error'],flush=True)
 finally:
  persist();lock.unlink(missing_ok=True)
  entry=f"\n\n2026-10-11：仅200页独立文本脚本 tools/build_page200_texts.py，状态{d['status']}，本轮保存且字体重开核对{len(d['completed'])}/17。原文字与颜色复用缓存，缺颜色才读取原件；新建前使用真实目录缺失清单，原件只读取消。字号先调整，再恢复轮廓。详细结果 evidence/page200-text-workflow.json；其余按钮、表格、数值输入及整页编译/运行验收未完成。\n"
  if d.get('error'):entry+='报错原文：\n```\n'+d['error']+'```\n'
  for path in [ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md']:
   with path.open('a',encoding='utf8') as f:f.write(entry)
  print(json.dumps({'status':d['status'],'completed':len(d['completed'])}),flush=True)

if __name__=='__main__':main()
