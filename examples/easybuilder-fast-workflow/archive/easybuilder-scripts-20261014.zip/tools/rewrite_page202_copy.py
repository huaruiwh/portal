import os,json,traceback
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
with lock.open('x',encoding='utf8') as f:json.dump({'pid':os.getpid(),'task':'rewrite202copy'},f)
p=ROOT/'evidence/page202-copy-rewrite-workflow.json';r={'completed':[],'status':'running'}
try:
 for key in [f'{kind}_{n}' for kind,count in [('TX',17),('TS',12),('BL',14),('NE',25),('SW',1)] for n in range(count)]:
  r['stage']=key;p.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8');dest=ROOT/f'evidence/target-202-{key}-copy-rewritten.json'
  if not dest.exists():call('uia',10488686,json.dumps({'rewrite_page202_copy':key,'build_bit_general':0}))
  if not json.loads(dest.read_text(encoding='utf8'))['saved_reopened_verified']:raise ValueError('Copied object verification missing')
  r['completed'].append(key);p.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps({'verified':key,'count':len(r['completed'])}),flush=True)
 r['status']='all-bindings-text-saved-reopened'
except Exception:r['status']='needs-review';r['error']=traceback.format_exc();print(r['error'],flush=True)
finally:p.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8');lock.unlink(missing_ok=True)
