"""Choose built-in System Button / Flat, group3 thumbnail; verify family."""
import time
from pywinauto import Desktop
def choose(d,pid):
    existing=[w for w in Desktop(backend='win32').windows() if w.process_id()==pid and w.window_text()=='图片管理' and w.is_visible()]
    if not existing:
        galleries=[c for c in d.descendants(control_type='Button',cache_enable=True) if c.element_info.name=='图库...' and c.is_visible()]
        if len(galleries)!=2:raise ValueError('Expected two picture-library controls')
        galleries[0].click_input()
    def named_window(name):
        for _ in range(15):
            matches=[w for w in Desktop(backend='win32').windows() if w.process_id()==pid and w.window_text()==name and w.is_visible()]
            if len(matches)==1:return Desktop(backend='uia').window(handle=matches[0].handle).wrapper_object()
            time.sleep(.1)
        raise ValueError('Expected dialog: '+name)
    g=named_window('图片管理')
    menu=[c for c in g.descendants(control_type='MenuItem',cache_enable=True) if c.element_info.name and c.is_visible() and c.rectangle().top<g.rectangle().top+150]
    if len(menu)!=1:raise ValueError('Expected one library-menu control')
    already_flat=menu[0].element_info.name=='System Button - Flat'
    if not already_flat:menu[0].click_input();time.sleep(.3)
    def menuitem(name):
        for _ in range(20):
            matches=[]
            for w in Desktop(backend='win32').windows():
                if w.process_id()==pid and w.class_name().startswith('Qt5QWindowPopup') and w.is_visible():
                    u=Desktop(backend='uia').window(handle=w.handle).wrapper_object()
                    matches.extend(c for c in u.descendants(control_type='MenuItem',cache_enable=True) if c.element_info.name==name and c.is_visible())
            if len(matches)==1:break
            time.sleep(.15)
        if len(matches)!=1:raise ValueError('Expected one menu entry: '+name)
        matches[0].click_input();time.sleep(.1)
    if not already_flat:menuitem('System Button');menuitem('Flat')
    groups=[c for c in g.descendants(control_type='Group',cache_enable=True) if c.element_info.name=='3' and c.is_visible()]
    if len(groups)!=1:raise ValueError('Expected Flat group3 thumbnail')
    box=groups[0].rectangle()
    if box.width()<120 or box.height()<90:raise ValueError('Thumbnail layout changed')
    groups[0].click_input(coords=(60,70))
    ok=[c for c in g.descendants(control_type='Button',cache_enable=True) if c.element_info.name=='确定' and c.is_visible()]
    if len(ok)!=1:raise ValueError('Expected unique gallery OK')
    ok[0].click_input()
    for _ in range(15):
        if any(c.element_info.name=='Button - Flat' for c in d.descendants(control_type='Text',cache_enable=True)):
            return
        time.sleep(.1)
    raise ValueError('Flat picture family verification failed')

def run(handle,request):
    native=Desktop(backend='win32').window(handle=handle).wrapper_object()
    pid=native.process_id()
    titles=[w.window_text() for w in Desktop(backend='win32').windows() if w.process_id()==pid and w.class_name()=='EasyBuilderPro']
    if len(titles)!=1 or '组装机_MT8106iP.emtp' not in titles[0]:raise ValueError('Target picture selection only')
    choose(Desktop(backend='uia').window(handle=handle).wrapper_object(),pid)
