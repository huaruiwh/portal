"""Normally reopen and inspect all 14 saved alarm/background controls."""
import json,re,time
from eb_rebuild_page import ROOT,call
from eb_layout import geometry
def run():
    def target():
        call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
        found=[w for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
        if len(found)!=1:raise ValueError('One current target required')
        return found[0]
    w=target();old=w['pid'];call('keys',w['handle'],'%{F4}');call('launch',value=str(ROOT/'output/组装机_MT8106iP.emtp'))
    for _ in range(30):
        try:
            w=target()
            if w['pid']!=old:break
        except ValueError:pass
        time.sleep(.5)
    else:raise ValueError('New target process required')
    def ui(q):return call('uia',w['handle'],json.dumps(q,ensure_ascii=False))
    ui({'restore_target_window':True,'reviewed_size':True})
    inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
    report={'previous_pid':old,'reopened_pid':w['pid'],'pages':{},'ok':False,'offline_simulation_verified':False}
    def persist():(ROOT/'evidence/pages-102-103-reopened.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    for page in (102,103):
        ui({'open_target_page':page});ui({'page_settings':page,'target_readonly':True,'color_probe':True})
        ss=json.loads((ROOT/f'evidence/source-pages-settings/{page:03d}.json').read_text(encoding='utf8'))
        ts=json.loads((ROOT/f'evidence/target-pages-settings/{page:03d}.json').read_text(encoding='utf8'))
        dims={r['name']:r['value'] for r in ts['controls'] if r['type']=='Edit' and r['name'] in ('宽度 :','高度 :')}
        p={'checks':[],'settings_verified':dims=={'宽度 :':'1024','高度 :':'600'} and ts['background_color_label']=='背景颜色 :' and ts['background_rgb']==ss['background_rgb'],'background_rgb':ts['background_rgb']};report['pages'][str(page)]=p;persist()
        for name in next(x['observed_objects'] for x in inv['pages'] if x['id']==page):
            key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)[1]
            ui({'extract':{'page':page,'object':name,'target_readonly':True}})
            src=json.loads((ROOT/f'evidence/source-object-properties/{page:03d}_{key}.json').read_text(encoding='utf8'))
            dst=json.loads((ROOT/f'evidence/target-object-properties/{page:03d}_{key}.json').read_text(encoding='utf8'))
            check={'object':key,'geometry_verified':geometry(src)=={r['name']:r['value'] for r in dst['tabs']['轮廓'] if r['type']=='Edit' and r['name'] in geometry(src)}}
            if key.startswith('FK'):
                mode=next(r['value'] for r in src['tabs']['一般属性'] if r['name']=='属性 Down')
                field=' Down' if mode=='窗口' else '执行宏指令 Down';expected=next(r['value'] for r in src['tabs']['一般属性'] if r['type']=='ComboBox' and r['name']==field)
                check['action_verified']=any(r['type']=='ComboBox' and str(r.get('value','')).strip()==expected.strip() for r in dst['tabs']['一般属性'])
            elif key in ('TS_0','ED_0'):
                keep={'设备 :','Static',' Down','操作模式 :','输出反向','触发宏指令','启用'}
                def selected(d):return [(r['type'],r['name'],r['value']) for r in d['tabs']['一般属性'] if r['name'] in keep and 'value'in r]
                check['address_action_verified']=selected(src)==selected(dst)
            if '标签' in src['tabs']:
                states=src.get('label_states',{'0':src['tabs']['标签']});actual=dst.get('label_states',{'0':dst['tabs']['标签']})
                def captions(rs):return [r['value'] for r in rs if r['type']=='Edit' and r['name']=='']
                check['captions_verified']=all(k in actual and captions(rs)==captions(actual[k]) for k,rs in states.items())
            if '文字/批注' in src['tabs']:
                def text(d):return [r['value'] for r in d['tabs']['文字/批注'] if r['type']=='Edit' and r['name']=='内容']
                check['text_verified']=text(src)==text(dst)
            if '安全' in src['tabs']:
                rs=[r for r in src['tabs']['安全'] if r['type'] in ('CheckBox','ComboBox') and 'value'in r]
                check['safety_verified']=all(any(x['type']==r['type'] and x['name']==r['name'] and x.get('value')==r['value'] for x in dst['tabs']['安全']) for r in rs)
            p['checks'].append(check);persist();print(str(page)+' '+key+' read back',flush=True)
        ui({'target_page_audit':page});audit=json.loads((ROOT/f'evidence/target-page{page}-audit.json').read_text(encoding='utf8'));p['directory_verified']=audit['tree_verified'];p['objects']=audit['target_count'];persist()
    report['ok']=all(p['settings_verified'] and p['directory_verified'] and all(all(v for k,v in c.items() if k.endswith('_verified')) for c in p['checks']) for p in report['pages'].values());persist()
    if not report['ok']:raise ValueError('Saved basic-parameter audit mismatch; inspect report without rebuilding')
if __name__=='__main__':run()
