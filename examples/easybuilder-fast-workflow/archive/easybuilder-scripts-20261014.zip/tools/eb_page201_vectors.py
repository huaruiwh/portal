import json
from eb_rebuild_page import ROOT
from eb_build_sp import run as build
from eb_order_sp import run as order
from eb_copy_200_style_object import read_audit
from eb_object_ui import target,properties
from eb_native_form import tab
from eb_page26_shapes import cancel
from eb_live_fields import capture
from eb_original_style_existing import verify_fields
from eb_layout import geometry
from eb_color_picker import probe
from eb_page208 import write

def run(handle,q):
    a=read_audit(handle,201)
    if a['unexpected']or a['address_name_mismatch']:raise ValueError('Initial directory mismatch')
    for n in (0,1):
        key=f'SP_{n}';p=ROOT/f'evidence/target-201-SP{n}-built.json';phase=ROOT/f'evidence/target-201-SP{n}-phase.json'
        if p.exists()and json.loads(p.read_text(encoding='utf8')).get('saved_reopened_verified'):continue
        if not p.exists():
            if phase.exists()or key not in a['missing']:raise ValueError('Unknown vector creation phase')
            write(phase,{'stage':'creation-requested'});build(handle,{'page':201,'build_sp':n})
        s=json.loads((ROOT/f'evidence/source-object-properties/201_{key}.json').read_text(encoding='utf8'));root,w=target(handle,201);d,_=properties(root,w,key,'向量图的属性')
        try:
            tab(d,'图片')
            for label,rgb in s['colors'].items():
                if probe(d,label)!=rgb:raise ValueError('Saved vector color mismatch')
            tab(d,'轮廓');g=geometry(s);verify_fields(capture(d,[('Edit',k)for k in g]),[{'type':'Edit','name':k,'value':v}for k,v in g.items()])
        finally:cancel(d)
        r=json.loads(p.read_text(encoding='utf8'));r.update(saved_reopened_verified=True,library='System Frame',library_item=0);write(p,r);write(phase,{'stage':'verified'})
    order(handle,{'page':201,'order_sp':1});order(handle,{'page':201,'order_sp':0})
    a=read_audit(handle,201)
    if not a['objects'][0].startswith('SP_0')or not a['objects'][1].startswith('SP_1'):raise ValueError('Background order differs')
    for n in (0,1):
        p=ROOT/f'evidence/target-201-SP{n}-built.json';r=json.loads(p.read_text(encoding='utf8'));r.update(z_order_review_pending=False,vector_shape_identity_review_pending=False);write(p,r)
    write(ROOT/'evidence/page201-vectors-batch.json',{'finished':True,'count':a['target_count'],'remaining':len(a['missing']),'background_order':['SP_0','SP_1']})
