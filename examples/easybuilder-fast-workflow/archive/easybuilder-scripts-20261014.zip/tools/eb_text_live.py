"""Read only literal text states; preserve all properties and cancel on exit."""
import json
from pywinauto import Desktop
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_extract import ROOT,rows
from eb_object_ui import target,properties,dialog
from eb_native_form import tab,typed_children
from eb_page26_shapes import cancel
def run(handle,q):
    root=Desktop(backend='win32').window(handle=handle).wrapper_object()
    if '组装机_MT8106iP.emtp' not in root.window_text():raise ValueError('Target only')
    if q.get('cancel_current_text'):
        cancel(dialog(root.process_id(),'文字/批注的属性'));return
    page=int(q['page']);key=q['key'];kind=key.split('_')[0]
    titles={'TX':'文字/批注的属性','TS':'位状态切换开关/位状态指示灯的属性','BL':'位状态指示灯/位状态切换开关的属性'}
    if kind not in titles:raise ValueError('Text kinds only')
    root,w=target(handle,page);d,name=properties(root,w,key,titles[kind])
    result={'page':page,'object':name,'tabs':{},'read_only_target':True,'label_states':{}}
    try:
        scope='文字/批注' if kind=='TX' else '标签';tab(d,scope);result['tabs'][scope]=rows(d)
        if kind!='TX':
            cs=[c for c in typed_children(d,'ComboBox') if c.element_info.name=='状态 :']
            if len(cs)!=1:raise ValueError('Unique text state selector required')
            native=ComboBoxWrapper(cs[0].handle);states=native.item_texts()
            if len(states)>16:raise ValueError('Unreviewed caption state count')
            for state in states:native.select(state);result['label_states'][state]=rows(d)
    finally:cancel(d)
    p=ROOT/f'evidence/target-text-readbacks/{page:03d}_{key}.json';p.parent.mkdir(exist_ok=True)
    p.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
