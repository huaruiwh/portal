"""Compile the rebuilt local project, without simulation or device download."""
import json,time,ctypes
from pathlib import Path
from pywinauto import Desktop
from pywinauto.keyboard import send_keys
from eb_color_picker import native_window_handles
ROOT=Path(__file__).resolve().parent.parent

def run(handle,request):
    root=Desktop(backend='win32').window(handle=handle).wrapper_object()
    def document_title(w):
        title=ctypes.create_unicode_buffer(2048)
        ctypes.windll.user32.GetWindowTextW(w.handle,title,2048)
        return title.value
    if '组装机_MT8106iP.emtp' not in document_title(root) and request.get('capture_result'):
        # The compiler can replace the document frame after the controller snapshot.
        matches=[]
        for _ in range(25):
            handles=[];u=ctypes.windll.user32
            callback=ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p)
            @callback
            def visit(h,_):
                observed_pid=ctypes.c_ulong();u.GetWindowThreadProcessId(h,ctypes.byref(observed_pid))
                if request.get('expected_pid') and observed_pid.value!=request['expected_pid']:return True
                cls=ctypes.create_unicode_buffer(256);u.GetClassNameW(h,cls,256)
                if cls.value=='EasyBuilderPro':
                    title=ctypes.create_unicode_buffer(2048);u.GetWindowTextW(h,title,2048)
                    if '组装机_MT8106iP.emtp' in title.value:handles.append(int(h))
                return True
            u.EnumWindows(visit,0)
            if len(handles)==1:
                matches=[Desktop(backend='win32').window(handle=handles[0]).wrapper_object()];break
            time.sleep(.2)
        if len(matches)!=1:raise ValueError('One live target document frame required')
        if request.get('expected_pid') and matches[0].process_id()!=request['expected_pid']:raise ValueError('Compiler target process changed')
        root=matches[0]
    if '组装机_MT8106iP.emtp' not in document_title(root):raise ValueError('Known target project only')
    if request.get('read_messages'):
        dialogs=[Desktop(backend='win32').window(handle=h).wrapper_object() for h in native_window_handles(root.process_id(),title_match='编译')]
        if len(dialogs)!=1:raise ValueError('One observed compiler required')
        native_rows=[]
        for control in dialogs[0].descendants():
            if control.class_name()=='SysListView32':
                native_rows.append({'handle':control.handle,'rows':[item.texts() for item in control.items()]})
        (ROOT/'evidence/compile-native-messages.json').write_text(json.dumps(native_rows,ensure_ascii=False,indent=2),encoding='utf8')
        return
    if not request.get('resume') and (abs(root.rectangle().width()-1848)>1 or abs(root.rectangle().height()-1281)>1):raise ValueError('Unreviewed compile ribbon layout')
    pid=root.process_id()
    if request.get('close_misopened_system_settings'):
        ds=[v for v in Desktop(backend='win32').windows()if v.process_id()==pid and v.is_visible()and v.window_text().strip()=='系统参数设置']
        if len(ds)!=1:raise ValueError('Exact misopened system settings required')
        ui=Desktop(backend='uia').window(handle=ds[0].handle).wrapper_object();buttons=[c for c in ui.descendants(control_type='Button')if c.window_text()=='取消' and c.is_visible()]
        if len(buttons)!=1:raise ValueError('Unique cancel required')
        buttons[0].click_input();return
    output=ROOT/'output'/'组装机_MT8106iP.exob'
    capture=bool(request.get('capture_result'))
    previous_report=ROOT/'evidence/latest-project-compile.json'
    pending_path=ROOT/'evidence/compile-pending.json'
    pending=json.loads(pending_path.read_text(encoding='utf8')) if pending_path.exists() else {}
    previous_mtime=pending['previous_output_mtime_ns'] if capture and pending.get('phase')=='started' else (previous_report.stat().st_mtime_ns if capture and previous_report.exists() else (output.stat().st_mtime_ns if output.exists() else 0))
    if not capture:root.set_focus();send_keys('^s',pause=.01)
    if not request.get('resume') and not capture:
        dpi=ctypes.windll.user32.GetDpiForWindow(root.handle)
        if request.get('entry_via_local_ocr'):
            from eb_compile_ocr import run as observe_ribbon
            from pywinauto import mouse
            observe_ribbon(root.handle,{})
            words=json.loads((ROOT/'evidence/compile-ribbon-ocr.json').read_text(encoding='utf-8-sig'))['words']
            project=[]
            for a in words:
                if a['text']=='工'and a['y']<80:
                    following=[b for b in words if b['text']=='程'and abs(a['y']-b['y'])<4 and 0<=b['x']-a['x']-a['width']<8]
                    if len(following)==1:project.append((a,following[0]))
            if len(project)==1:
                a,b=project[0];rr=root.rectangle();mouse.click(coords=(rr.left+int((a['x']+b['x']+b['width'])/2),rr.top+int(a['y']+a['height']/2)));time.sleep(.2)
                observe_ribbon(root.handle,{})
                words=json.loads((ROOT/'evidence/compile-ribbon-ocr.json').read_text(encoding='utf-8-sig'))['words']
            observed=[]
            for a in words:
                if not (70<a['y']<155 and a['x']<350):continue
                if a['text'].replace(' ','')=='编译':observed.append((a['x'],a['y'],a['x']+a['width'],a['y']+a['height']))
                if a['text']=='编':
                    bs=[b for b in words if b['text']=='译' and abs(a['y']-b['y'])<4 and 0<=b['x']-a['x']-a['width']<8]
                    if len(bs)==1:
                        b=bs[0];observed.append((a['x'],min(a['y'],b['y']),b['x']+b['width'],max(a['y']+a['height'],b['y']+b['height'])))
            if len(observed)!=1:raise ValueError('Unique observed compile label required; no click sent')
            x1,y1,x2,y2=observed[0];r=root.rectangle()
            mouse.click(coords=(r.left+int((x1+x2)/2),r.top+int((y1+y2)/2)))
        elif dpi==120:
            root.click_input(coords=(300,52));time.sleep(.2);root.click_input(coords=(178,95))
        elif dpi==144:
            root.click_input(coords=(347,63));time.sleep(.1);root.click_input(coords=(214,110))
        else:raise ValueError('Unreviewed compiler DPI')
    ds=[]
    for _ in range(200):
        ds=[Desktop(backend='win32').window(handle=h).wrapper_object() for h in native_window_handles(pid,title_match='编译')]
        if len(ds)==1:break
        time.sleep(.1)
    if len(ds)!=1:raise ValueError('Compile dialog not ready; inspect before retry')
    d=Desktop(backend='uia').window(handle=ds[0].handle).wrapper_object()
    if request.get('close_result_only'):
        close=[c for c in d.descendants(control_type='Button') if c.window_text().strip()=='关闭' and c.is_visible() and c.handle]
        if len(close)!=1:raise ValueError('Unique compile close action required: '+repr([(c.window_text(),c.is_visible(),c.handle)for c in d.descendants(control_type='Button')]))
        close[0].click_input();return
    start=[c for c in d.descendants(control_type='Button') if c.window_text()=='开始编译' and c.is_visible()]
    if not capture and len(start)!=1:raise ValueError('Unique compile action required')
    if capture:
        tabs=[c for c in d.descendants(control_type='TabItem') if c.window_text()=='导出' and c.is_visible()]
        if len(tabs)!=1:raise ValueError('Compiler result tab not uniquely exposed')
        d.set_focus();tabs[0].click_input();time.sleep(.3)
    else:
        pending={'phase':'started','previous_output_mtime_ns':previous_mtime,'project_bytes':(ROOT/'output/组装机_MT8106iP.emtp').stat().st_size}
        pending_path.write_text(json.dumps(pending),encoding='utf8')
        start[0].click_input()
        if request.get('start_only'):return
        tabs=[c for c in d.descendants(control_type='TabItem') if c.window_text()=='导出' and c.is_visible()]
        if len(tabs)!=1:raise ValueError('Compiler output tab not uniquely exposed')
        d.set_focus();tabs[0].click_input();time.sleep(.3)
    messages=[]
    for _ in range(8 if capture else 40):
        messages=[c.window_text() for c in d.descendants(control_type='ListItem') if c.window_text()]
        if '成功' in messages and any('错误' in t for t in messages) and output.exists() and output.stat().st_mtime_ns>previous_mtime:break
        time.sleep(.2)
    fresh=output.exists() and output.stat().st_mtime_ns>previous_mtime
    warning_messages=[]
    if any('0 错误,' in t and '警告' in t and t!='0 错误, 0 警告' for t in messages):
        tabs=[c for c in d.descendants(control_type='TabItem') if c.window_text()=='错误列表' and c.is_visible()]
        if len(tabs)!=1:raise ValueError('Compiler warning tab not uniquely exposed')
        d.set_focus();tabs[0].click_input();time.sleep(.3)
        warning_messages=[c.window_text() for c in d.descendants(control_type='ListItem') if c.window_text()]
    known_warning=warning_messages==['1. [窗口 16] GP_0 : 选择 "设为原尺寸" 以加快画面显示速度.']
    success='成功' in messages and fresh
    report={'messages':messages,'warning_details':warning_messages,'compilation_succeeded':success,'zero_warnings':'0 错误, 0 警告' in messages,'ok':success and ('0 错误, 0 警告' in messages or known_warning),'output_updated':fresh,'project_bytes':(ROOT/'output'/'组装机_MT8106iP.emtp').stat().st_size,'exob_bytes':output.stat().st_size if output.exists() else None,'offline_simulation_verified':False}
    (ROOT/'evidence'/'latest-project-compile.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    if not report['ok']:raise ValueError('Compile did not report success with zero errors and warnings')
    if pending.get('phase')=='started':
        pending.update(phase='completed',output_mtime_ns=output.stat().st_mtime_ns)
        pending_path.write_text(json.dumps(pending),encoding='utf8')
    close=[c for c in d.descendants(control_type='Button') if c.window_text().strip()=='关闭' and c.is_visible() and c.handle]
    if len(close)!=1:raise ValueError('Unique compile close action required')
    close[0].click_input()
