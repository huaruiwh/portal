"""Archive the user's pause without further GUI inputs."""
import json,hashlib,zipfile,os
from datetime import datetime
from eb_rebuild_page import ROOT
now=datetime.now();date=now.isoformat(timespec='seconds')
output=ROOT/'output/组装机_MT8106iP.emtp'
size=output.stat().st_size;sha=hashlib.sha256(output.read_bytes()).hexdigest()
audit=json.loads((ROOT/'evidence/text-content-audit.json').read_text(encoding='utf8'))
pending=sorted(set((r['page'],r['object']) for r in audit['pending']))
fresh=list((ROOT/'evidence/target-text-readbacks').glob('*.json'))
pause={'date':date,'paused_by_user':True,'reason':'用户明确要求暂停','gui_inputs_stopped':True,'text_compared':audit['cached_checks'],'text_matched':audit['cached_passed'],'mismatches':len(audit['mismatches']),'pending_text_objects':pending,'fresh_readback_files':len(fresh),'project_bytes':size,'project_sha256':sha}
(ROOT/'tools/work-paused.json').write_text(json.dumps(pause,ensure_ascii=False,indent=2),encoding='utf8')
cp=json.loads((ROOT/'evidence/resume-checkpoint.json').read_text(encoding='utf8'))
cp.update(date=date,status='paused-by-user',paused=True,batch_running=False,controller_pid=None,bytes=size,last_saved_output=str(output),last_saved_bytes=size,last_saved_sha256=sha,text_audit_pause=pause,next='用户明确继续后，先核对实际窗口及worker/request/response，清除work-paused.json。只读补查31 TS1/TS4/TX1-TX4和48 BL0/BL6；已完成文字文件跳过。恢复编译及其余向量灯，旧EXOB不视为新编译。')
(ROOT/'evidence/resume-checkpoint.json').write_text(json.dumps(cp,ensure_ascii=False,indent=2),encoding='utf8')
archives=ROOT/'archives';archives.mkdir(exist_ok=True)
archive=archives/f'暂停归档_{now:%Y%m%d_%H%M%S}.zip'
text=f"""
### {date} 用户暂停与文字核对断点归档

已停止工作，不再发送鼠标/键盘或控件修改动作。文字只读队列在31 TS_1结束时取消属性遇到已销毁句柄，错误原文`pywinauto.controls.hwndwrapper.InvalidWindowHandle: Handle 7407722 is not a vaild window handle`，未生成该控件完成证据，不计完成；控制器已退出，batch.lock已释放。本次暂停不保存原件、不关闭用户软件或处理用户自行打开的提示。

文字记录对照{audit['cached_checks']}条，匹配{audit['cached_passed']}条，已发现内容差异{len(audit['mismatches'])}条；本轮重新读取{len(fresh)}个控件文件，证据evidence/target-text-readbacks。待补读{len(audit['pending'])}条状态/文字，涉及{len(pending)}个控件：{json.dumps(pending,ensure_ascii=False)}。结果不包含画面截断或HMI实际运行验收。

47页9个图片控件已全部保存重开核对，45页10个、44页11个图片控件同样已完成；44 BL_3至BL_6另4个向量灯已完成，其余向量仍待。最新编译请求没有成功打开编译弹窗，不能用旧0错误1警告结果代替本轮；新本机OCR入口尚未进行实际编译验证。暂停期间不继续修复或编译。

当前磁盘EMTP：{size}字节，SHA256 `{sha}`。这是磁盘已保存文件归档，未把窗口中的未确认内容当作已保存。归档文件：{archive}；包括EMTP、同README/实现记录、tools顶层脚本/协议文件和evidence JSON/JSONL，排除第三方运行库和截图。

恢复先读本README、同实现记录、evidence/resume-checkpoint.json、tools/work-paused.json、worker-ready.json、request/response和实际窗口；用户明确继续前保持暂停。重新启动软件后要重新解析句柄，不重放旧请求。补查入口`Python tools/check_pending_texts.py`，先运行`Python tools/audit_text_content.py`更新待查列表；成功的target-text-readbacks优先读取，无需重复新增。当前唯一常驻worker PID18672待命，管理员状态以前实查true；下次仍需核实进程。其余恢复命令与脚本规律已在前文记录。
"""
for rel in ('README.md','docs/MT8106iP重建-实现记录.md'):
    p=ROOT/rel;p.write_text(p.read_text(encoding='utf8')+'\n'+text,encoding='utf8')
files=[output,ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md']
files+=list((ROOT/'evidence').rglob('*.json'))+list((ROOT/'evidence').glob('*.jsonl'))
files+=[p for p in (ROOT/'tools').iterdir() if p.is_file() and p.suffix.lower() in ('.py','.ps1','.json','.cmd','.bat')]
files=sorted(set(files))
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files:z.write(p,str(p.relative_to(ROOT)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None;assert len(z.namelist())==len(files)
result={**pause,'archive':str(archive),'archive_bytes':archive.stat().st_size,'file_count':len(files),'zip_crc_verified':True}
(ROOT/'evidence/pause-archive-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
for rel in ('README.md','docs/MT8106iP重建-实现记录.md'):
    p=ROOT/rel;p.write_text(p.read_text(encoding='utf8')+f"\n归档校验：{len(files)}个文件，ZIP {archive.stat().st_size}字节，CRC全部通过；归档后本行另记于当前文档。\n",encoding='utf8')
print(json.dumps(result,ensure_ascii=False))
