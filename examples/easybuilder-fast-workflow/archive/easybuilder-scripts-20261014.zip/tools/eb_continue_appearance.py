"""Read original state colors and repair existing controls in one serial queue."""
import json
from eb_rebuild_page import ROOT,call
def run():
    lock=ROOT/'tools/batch.lock'
    with lock.open('x'):pass
    p={'completed':[],'ok':False};path=ROOT/'evidence/page-103-appearance-workflow.json'
    def persist():path.write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf8')
    try:
        call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
        def handle(name):
            x=[w for w in ws if name in w['title'] and w['class']=='EasyBuilderPro']
            if len(x)!=1:raise ValueError('One project required')
            return x[0]['handle']
        sh=handle('组装机2台15工位取消.cmtp');th=handle('组装机_MT8106iP.emtp')
        inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(x['observed_objects'] for x in inv['pages'] if x['id']==103)
        for key in [f'FK_{n}' for n in range(7)]+['TS_0','DC_0']:
            source=json.loads((ROOT/f'evidence/source-object-properties/103_{key}.json').read_text(encoding='utf8'))
            p['stage']='read '+key;persist()
            if 'appearance_colors' not in source:
                name=next(s for s in names if s==key or s.startswith(key+' '))
                call('uia',sh,json.dumps({'extract':{'page':103,'object':name,'only_color':True,'appearance_probe':True}},ensure_ascii=False))
            p['stage']='sync '+key;persist()
            if not (ROOT/f'evidence/target-103-{key}-appearance.json').exists():call('uia',th,json.dumps({'sync_existing_appearance':key}))
            p['completed'].append(key);persist();print(key+' appearance saved',flush=True)
        p['ok']=True;p['stage']='saved; roundtrip pending';persist()
    except Exception as e:p['error']=str(e);persist();raise
    finally:lock.unlink(missing_ok=True)
if __name__=='__main__':run()
