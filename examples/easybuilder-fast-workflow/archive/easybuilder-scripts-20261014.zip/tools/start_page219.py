import json,time,os,subprocess,sys
from eb_rebuild_page import ROOT,call
r=ROOT;lock=r/'tools/later-pages-supervisor.lock';wf=r/'evidence/page219-start-workflow.json'
with lock.open('x',encoding='utf8')as f:f.write(json.dumps({'pid':os.getpid(),'task':'page219-after-cache'}))
d={'page':219,'phase':'waiting-source-cache','finished':False}
def record():wf.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
try:
 record()
 while (r/'tools/batch.lock').exists():time.sleep(2)
 cache=json.loads((r/'evidence/page219-cache-workflow.json').read_text(encoding='utf8'))
 if not cache['finished']:raise ValueError('219 source cache failed; inspect before build')
 call('snapshot');ws=json.loads((r/'evidence/windows.json').read_text(encoding='utf8'));src=next(w['handle']for w in ws if '.cmtp'in w['title']);h=next(w['handle']for w in ws if '组装机_MT8106iP.emtp'in w['title'])
 d['phase']='source-settings';record()
 if not (r/'evidence/source-pages-settings/219.json').exists():call('uia',src,json.dumps({'page_settings':219,'color_probe':True}))
 d['phase']='create';record()
 if not (r/'evidence/target-page-219-created.json').exists():call('uia',h,json.dumps({'create_target_page':219}))
 call('uia',h,json.dumps({'open_target_page':219}))
 if not (r/'evidence/scale-890x469/page-219-initial-height.json').exists():call('uia',h,json.dumps({'scale_post200':{'page':219,'mode':'blank_height'},'build_bit_general':0}))
 d['phase']='build';record();p=subprocess.run([sys.executable,str(r/'tools/continue_page219.py')],cwd=r)
 if p.returncode:raise ValueError('219 build stopped; inspect workflow')
 d['finished']=True;record()
except Exception as e:
 d['error']=str(e);record();raise
finally:lock.unlink(missing_ok=True)
