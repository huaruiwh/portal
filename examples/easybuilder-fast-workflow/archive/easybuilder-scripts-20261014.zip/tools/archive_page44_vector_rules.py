"""Archive verified page44 results and the exact resume method."""
import json,re
from datetime import datetime
from eb_rebuild_page import ROOT

rows=[]
for n in (3,4,5,6):
    p=ROOT/f'evidence/page44-BL_{n}-vector-correction.json'
    r=json.loads(p.read_text(encoding='utf8'))
    assert all(r.get(k) for k in ('saved','reopened_rgb_verified','general_geometry_labels_unchanged'))
    src=json.loads((ROOT/f'evidence/page44-BL_{n}-source-vector.json').read_text(encoding='utf8'))
    rows.append(f"- BL_{n}：{src.get('gallery_family')} / {src.get('gallery_index')}；两状态RGB原文：{json.dumps(src['colors'],ensure_ascii=False)}。保存、重开RGB、地址/轮廓/标签不变验证全部通过；运行验证仍未做。")
output=ROOT/'output/组装机_MT8106iP.emtp'
section=f"""<!-- PAGE44-VECTOR-RULES -->
### {datetime.now().isoformat(timespec='seconds')} 44页四个向量灯完成与恢复规律

修正BL_3、BL_4、BL_5、BL_6，共4个，均有真实保存后重开证据。归档时EMTP为{output.stat().st_size}字节；后续队列保存可能继续改变大小。

{chr(10).join(rows)}

规律：源属性只读采集图库编号、内部/外框各状态颜色，目标仅改相应图片标志、图库及颜色；不复用其它灯的RGB。颜色标签可能为空，改用“内部”“外框”CheckBox定位对应色块；Qt“更多颜色...”不支持SelectionItem/Invoke，原报错`NoPatternInterfaceError`及`_ctypes.COMError: (-2146233083, None, (None, None, None, 0, None))`，改为实际观察矩形中心点击，并确认原生Colors确实打开后读写。每次切换项目先原生激活并检查前景窗口，筛选框输入先确认焦点、清空读回，再输入和读回，避免重叠窗口键盘误落。

BL_6首次报错`Source object not currently exposed`。关闭源窗口并重开任务source磁盘副本后BL_6再次出现并完成采集；旧源窗口曾出现保存更改询问，未发出保存源命令。仅凭此次现象不能断言缺失原因，后续继续保持原件只读，不使用旧缓存代替实际对象。源副本SHA256实际为419C6F13054971CDF985188AE72BD993F19DD47015CB4C9849A084E8992A7E89，和Desktop原件不同，不混用版本。

复现：运行现有Python解释器加`tools/eb_fix_page44_vectors.py`；先确认无其它控制器、request/response同ID及无遗留弹窗。已通过四灯报告跳过，然后串行接续44、45、47图片队列。验证证据为`evidence/page44-BL_<n>-vector-correction.json`；源码`tools/eb_flow_vector.py`、`tools/eb_color_picker.py`、`tools/eb_extract.py`。未完成：其余页向量灯、剩余图片队列、新编译及整屏交互验收；四灯保存核对不代表整屏运行验收。
<!-- /PAGE44-VECTOR-RULES -->"""
for rel in ('README.md','docs/MT8106iP重建-实现记录.md'):
    p=ROOT/rel;t=p.read_text(encoding='utf8')
    pattern=r'<!-- PAGE44-VECTOR-RULES -->.*?<!-- /PAGE44-VECTOR-RULES -->'
    t=re.sub(pattern,lambda _:section,t,flags=re.S) if re.search(pattern,t,flags=re.S) else t+'\n'+section+'\n'
    p.write_text(t,encoding='utf8')
print('4 verified vectors archived')
