"""Update existing text font only; fit point size and verify saved readback."""
import json,re,time,ctypes
from datetime import datetime
from PIL import ImageFont
from pywinauto import Desktop
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_extract import ROOT,rows
from eb_object_ui import target,properties,save
from eb_native_form import tab,fields,confirm,typed_children
from eb_page26_shapes import cancel
FONT='微软正黑体 Light'
FONTFILE=r'C:\Windows\Fonts\msjhl.ttc'
def valued(rs,name,typ=None):
    return next((r['value'] for r in rs if r['name']==name and 'value' in r and (typ is None or r['type']==typ)),None)
def signature(rs):
    return [(r['type'],r['name'],r['value']) for r in rs if 'value' in r and r['name'] not in ('字体 :','尺寸 :')]
def fitted(rs,g,page,ceiling=None):
    original=int(valued(rs,'尺寸 :','ComboBox'))
    editors=[r for r in rs if r['type']=='Edit' and 'value' in r and (r['name'] in ('内容','文字 :','文字') or r.get('class')=='RichEdit20W')]
    if len(editors)>1:raise ValueError('Unique literal text editor required for fitting')
    text=str(editors[0]['value']) if editors else ''
    size=max(8,round(original*(600/768 if page in (10,11,16,17,100,101,102,103) else 1)))
    if ceiling is not None:size=min(size,int(ceiling))
    width=valued(g,' 宽度 :','Edit');height=valued(g,'高度 :','Edit')
    if text and (not width or not height):
        px=valued(g,'X :','Edit');py=valued(g,' Y :','Edit')
        if px is not None and py is not None:
            pw,ph=(800,500) if 26<=page<=48 else (1024,600)
            width=str(pw-int(px));height=str(ph-int(py))
    if not text or not width or not height:return size,False
    w,h=max(1,int(width)-6),max(1,int(height)-4)
    for n in range(size,5,-1):
        f=ImageFont.truetype(FONTFILE,max(1,round(n*96/72)))
        lines=text.replace('\r\n','\n').replace('\r','\n').rstrip('\n').split('\n')
        a,de=f.getmetrics()
        if max(f.getlength(s) for s in lines)<=w and (a+de)*len(lines)<=h:return n,True
    raise ValueError('Text requires layout review; cannot fit legibly: '+repr(text))
def run(handle,q):
    if q.get('page_geometry_audit'):
        page=int(q['page_geometry_audit']);root,w=target(handle,page);checks=[]
        for source_path in sorted((ROOT/'evidence/source-object-properties').glob(f'{page:03d}_*.json')):
            source=json.loads(source_path.read_text(encoding='utf8'));key=source_path.stem.split('_',1)[1]
            bp=ROOT/f'evidence/target-{page:03d}-{key.replace("_", "")}-built.json'
            baseline=json.loads(bp.read_text(encoding='utf8'))['geometry']
            expected={r['name']:r['value'] for r in baseline if r['type']=='Edit' and r['name'] in (' 宽度 :','高度 :')}
            d,name=properties(root,w,key,source['dialog_title'])
            try:
                tab(d,'轮廓');before=rows(d)
                actual={r['name']:r['value'] for r in before if r['type']=='Edit' and r['name'] in expected}
                changed=actual!=expected
                if changed:
                    fields(d,[{'type':'Edit','name':n,'value':v} for n,v in expected.items()],commit_edits=True)
                    after=rows(d)
                    if {r['name']:r['value'] for r in after if r['type']=='Edit' and r['name'] in expected}!=expected:raise ValueError('Original adapted dimensions restore failed')
                    confirm(d);d=None;save(root)
                    d,name=properties(root,w,key,source['dialog_title']);tab(d,'轮廓')
                reopened=rows(d)
                verified={r['name']:r['value'] for r in reopened if r['type']=='Edit' and r['name'] in expected}==expected
                if not verified:raise ValueError('Original adapted dimensions saved readback failed')
                checks.append({'key':key,'expected_dimensions':expected,'before_dimensions':actual,'restored':changed,'verified':verified})
            finally:
                if d is not None and ctypes.windll.user32.IsWindow(d.handle):cancel(d)
        (ROOT/f'evidence/page-{page}-font-dimensions-audit.json').write_text(json.dumps({'page':page,'checks':checks,'verified':all(c['verified'] for c in checks),'runtime_verified':False},ensure_ascii=False,indent=2),encoding='utf8')
        return
    if q.get('directory_probe'):
        from eb_directory import scope
        root=Desktop(backend='uia').window(handle=handle).wrapper_object();d=scope(root)
        if q.get('directory_filter') is not None:
            if '组装机_MT8106iP.emtp' not in root.window_text() and not (q.get('read_source_directory') and '组装机2台15工位取消.cmtp' in root.window_text()):raise ValueError('Known project directory only')
            editors=[c for c in d.descendants(control_type='Edit') if c.is_visible() and c.is_enabled()]
            if len(editors)!=1:raise ValueError('Unique directory filter required')
            try:editors[0].set_edit_text(q['directory_filter'])
            except Exception as error:
                if type(error).__name__!='COMError':raise
                from pywinauto.keyboard import send_keys
                root.set_focus();editors[0].click_input();send_keys('^a'+q['directory_filter'],with_spaces=True,pause=.01)
            time.sleep(.2)
            if editors[0].get_value()!=q['directory_filter']:raise ValueError('Directory filter readback failed')
        if q.get('ensure_page_directory'):
            m=re.search(r'\[(\d+) - ',root.window_text())
            nodes=d.descendants(control_type='TreeItem',cache_enable=True)
            headers=[c for c in nodes if m and c.element_info.name.startswith(m[1]+' :')]
            has_objects=any(re.search(r'(?:^|\])\s*[A-Z]{2}_\d+',c.element_info.name) for c in nodes)
            if not has_objects:
                if len(headers)!=1:raise ValueError('Unique actual page header required')
                root.set_focus();headers[0].click_input(double=True);time.sleep(.3)
        if q.get('directory_scroll'):
            from pywinauto import mouse
            trees=[c for c in d.descendants(control_type='Tree') if c.is_visible()]
            if len(trees)!=1:raise ValueError('Unique observed directory tree required for scrolling')
            box=trees[0].rectangle();root.set_focus()
            mouse.scroll(coords=((box.left+box.right)//2,(box.top+box.bottom)//2),wheel_dist=int(q['directory_scroll']));time.sleep(.2)
        out=[]
        for c in d.descendants(cache_enable=True):
            if c.element_info.control_type in ('Edit','Tree','TreeItem'):
                x={'type':c.element_info.control_type,'name':c.element_info.name,'rect':str(c.rectangle())}
                if x['type']=='Edit':x['value']=c.get_value()
                out.append(x)
        (ROOT/'evidence/font-directory-probe.json').write_text(json.dumps(out,ensure_ascii=False),encoding='utf8');return
    page=int(q['page']);key=q['key'];phase=q.get('phase','edit')
    source=json.loads((ROOT/f'evidence/source-object-properties/{page:03d}_{key}.json').read_text(encoding='utf8'))
    root,w=target(handle,page);d,name=properties(root,w,key,source['dialog_title'])
    if q.get('probe'):
        out={}
        try:
            for scope,rs in source['tabs'].items():
                if valued(rs,'字体 :','ComboBox') is not None:tab(d,scope);out[scope]=rows(d)
        finally:cancel(d)
        (ROOT/'evidence/font-probe.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');return
    reportpath=ROOT/f'evidence/font-adjustments/{page:03d}_{key}.json';reportpath.parent.mkdir(exist_ok=True)
    try:
        tab(d,'轮廓');geo=rows(d)
        if phase=='edit' and page==25:
            baseline=ROOT/f'evidence/target-025-{key.replace("_", "")}-built.json'
            old=json.loads(baseline.read_text(encoding='utf8'))['geometry']
            dimensions={r['name']:r['value'] for r in old if r['type']=='Edit' and r['name'] in (' 宽度 :','高度 :')}
            for r in geo:
                if r['type']=='Edit' and r['name'] in dimensions:r['value']=dimensions[r['name']]
        report={'date':datetime.now().isoformat(timespec='seconds'),'page':page,'key':key,'target':name,'font':FONT,'geometry_before':geo,'tabs':{},'verified':False,'runtime_verified':False,'layout_render_verified':False,'fit_policy_version':2}
        if phase=='verify':
            report=json.loads(reportpath.read_text(encoding='utf8'))
            expected_geo=report['geometry_before']
            if [(r['name'],r.get('value')) for r in geo if 'value' in r]!=[(r['name'],r.get('value')) for r in expected_geo if 'value' in r]:
                raise ValueError('Saved geometry differs from pre-font geometry; restore dimensions before continuing')
        for scope,srs in source['tabs'].items():
            if valued(srs,'字体 :','ComboBox') is None:continue
            tab(d,scope)
            statecombos=[c for c in typed_children(d,'ComboBox') if c.element_info.name=='状态 :']
            states=ComboBoxWrapper(statecombos[0].handle).item_texts() if len(statecombos)==1 else [None]
            if len(states)>32:raise ValueError('Unreviewed font state count')
            report['tabs'].setdefault(scope,{})
            for state in states:
                if state is not None:ComboBoxWrapper(statecombos[0].handle).select(state)
                before=rows(d);sid=str(state)
                if phase=='edit':
                    selected=source.get('label_states',{}).get(state,srs)
                    if valued(before,'使用文字标签','CheckBox')==0:
                        report['tabs'][scope][sid]={'skipped':'disabled label'};continue
                    ceiling=valued(before,'尺寸 :','ComboBox')
                    if reportpath.exists():
                        previous=json.loads(reportpath.read_text(encoding='utf8'))
                        previous_state=previous.get('tabs',{}).get(scope,{}).get(sid,{})
                        ceiling=min(int(ceiling),int(valued(previous_state.get('before',before),'尺寸 :','ComboBox')))
                    size,measured=fitted(selected,geo,page,ceiling)
                    if q.get('uniform_button_size') is not None:
                        requested=int(q['uniform_button_size'])
                        if page not in (200,202) or key not in [f'TS_{i}' for i in range(12)]+['SW_0'] or requested!=13:raise ValueError('Unreviewed uniform button size')
                        size=requested
                    if q.get('size_decrement') is not None:
                        decrement=int(q['size_decrement'])
                        if decrement!=1:raise ValueError('Only one-point label reduction reviewed')
                        size=min(size,max(6,int(valued(before,'尺寸 :','ComboBox'))-decrement))
                    if q.get('size_override') is not None:
                        requested=int(q['size_override'])
                        if not 6<=requested<=int(ceiling) and not (q.get('restore_mistaken_TX10') and page==200 and key=='TX_10' and requested==12):raise ValueError('Explicit text size must not enlarge current text')
                        size=min(size,requested)
                    elif 26<=page<=48 and any(r.get('value') in ('单次','循环','屏蔽','检测') for r in selected if r['type']=='Edit' and (r['name']=='内容' or r.get('class')=='RichEdit20W')):
                        size=min(size,12)
                    font_selectable=valued(before,'字体 :','ComboBox') is not None
                    wanted=[{'type':'ComboBox','name':'尺寸 :','value':str(size)}]
                    if font_selectable:wanted.insert(0,{'type':'ComboBox','name':'字体 :','value':FONT})
                    fields(d,wanted)
                    after=rows(d)
                    if signature(before)!=signature(after):raise ValueError('Non-font text properties changed')
                    report['tabs'][scope][sid]={'before':before,'expected_size':str(size),'after':after,'measured_fit':measured,'font_selectable':font_selectable}
                else:
                    expected=report['tabs'][scope][sid]
                    if 'skipped' in expected:continue
                    if (expected.get('font_selectable',True) and valued(before,'字体 :','ComboBox')!=FONT) or str(valued(before,'尺寸 :','ComboBox'))!=expected['expected_size']:raise ValueError('Saved font or size mismatch')
                    if signature(before)!=signature(expected['before']):raise ValueError('Saved other text properties mismatch')
                    expected['reopened']=before
        tab(d,'轮廓');aftergeo=rows(d)
        geometry_values=lambda rs:[(r['name'],r.get('value')) for r in rs if 'value' in r]
        if phase=='edit':
            # Fit text first; restore the existing adapted bounds last.
            bounds=[r for r in geo if r['type']=='Edit' and r['name'] in ('X :',' Y :',' 宽度 :','高度 :') and 'value' in r]
            fields(d,bounds,commit_edits=True)
            aftergeo=rows(d)
            report['geometry_after_text_then_bounds']=aftergeo
            report['operation_order']='font-size, existing adapted bounds, save, reopen verification'
        if geometry_values(geo)!=geometry_values(aftergeo):raise ValueError('Font change affected geometry; review required')
        if phase=='edit':
            confirm(d);d=None;save(root);report['save_requested']=True
        else:
            cancel(d);d=None;report['verified']=True;report['verified_date']=datetime.now().isoformat(timespec='seconds')
        reportpath.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    finally:
        if d is not None and ctypes.windll.user32.IsWindow(d.handle):cancel(d)



