"""Verify the one-vector pilot; source SP1 was created as target SP0."""
import json,time
from eb_rebuild_page import ROOT,call
from eb_layout import geometry

def run():
    def target():
        call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
        found=[w for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
        if len(found)!=1:raise ValueError('Unique target required')
        return found[0]
    w=target()
    def ui(q):return call('uia',w['handle'],json.dumps(q,ensure_ascii=False))
    ui({'compile_target':True,'start_only':True});time.sleep(2);ui({'compile_target':True,'capture_result':True,'expected_pid':w['pid']})
    old=w['pid'];call('keys',w['handle'],'%{F4}');call('launch',value=str(ROOT/'output/组装机_MT8106iP.emtp'))
    for _ in range(20):
        try:
            w=target()
            if w['pid']!=old:break
        except ValueError:pass
        time.sleep(.5)
    else:raise ValueError('Normal reopen required')
    ui({'restore_target_window':True,'reviewed_size':True});ui({'open_target_page':101})
    ui({'extract':{'page':101,'object':'SP_0 (最下层)','target_readonly':True,'colors':['图案颜色 :','颜色 :'],'color_tab':'图片'}})
    source=json.loads((ROOT/'evidence/source-object-properties/101_SP_1.json').read_text(encoding='utf8'))
    saved=json.loads((ROOT/'evidence/target-object-properties/101_SP_0.json').read_text(encoding='utf8'))
    actual={c['name']:c['value'] for c in saved['tabs']['轮廓'] if c['type']=='Edit' and c['name'] in geometry(source)}
    def values(rows):return [(c['type'],c['name'],c['value']) for c in rows if 'value'in c]
    checks={'geometry_verified':geometry(source)==actual,'colors_verified':source['colors']==saved['colors'],'safety_verified':values(source['tabs']['安全'])==values(saved['tabs']['安全']),'fill_border_verified':values(source['tabs']['图片'])==values(saved['tabs']['图片'])}
    report={'page':101,'source':'SP_1','target':'SP_0','library':'System Frame','library_item':0,'checks':checks,'reopened_pid':w['pid'],'ok':all(checks.values()),'remaining_vectors':7,'whole_page_verified':False,'offline_simulation_verified':False}
    (ROOT/'evidence/page-101-vector-sample-reopened.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    if not report['ok']:raise ValueError('Vector sample mismatch')
    print(json.dumps(report,ensure_ascii=False),flush=True)

if __name__=='__main__':run()
