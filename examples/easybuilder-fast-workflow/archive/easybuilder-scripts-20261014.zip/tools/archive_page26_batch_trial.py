import json
from eb_rebuild_page import ROOT
def load(n):return json.loads((ROOT/'evidence'/n).read_text(encoding='utf-8-sig'))
r=load('page201-two-button-batch.json');a=load('target-page201-audit.json')
assert r['finished'] and a['target_count']==25 and len(a['missing'])==27 and not a['unexpected'] and not a['address_name_mismatch']
assert all(load(f'target-201-TS{n}-built.json')['saved_reopened_verified']for n in range(9))
size=(ROOT/'output/组装机_MT8106iP.emtp').stat().st_size
stages={f'TS_{n}':load(f'target-201-TS{n}-built.json')['stage_seconds']for n in (7,8)}
text=f'''

### 2026-10-11：对照26页流程，验证两按钮连续批次

用户要求找26页当时较快的方法。查tools/eb_rebuild_flow.py、eb_build_bit_general.py及26页built报告：当时串行原生新增，整页最后一次目录审计；初建报告custom_picture_review_pending=true、label_color_review_pending=true，未包含全部后续图库和颜色复核，也没有准确完整elapsed_seconds。因此不能声称26页完整验收只需几秒，也不能将未经颜色核对的初建速度作为当前完整制作基准。

本次借用批次审计策略，新增eb_page201_batch.py，限定201页TS_7/TS_8。原件参数从本地缓存读取，两件图库System Button - Flat/index1，图片两态RGB128/221/255，标签黑色；安全0.1秒、无权限，与已保存核对的201/TS_1模板严格匹配。同一batch.lock独占、同一worker子进程、原生剪贴板缓存，不编辑二进制。每件只写变化的一般参数、两态文字、位置尺寸；字体继承微软正黑体 Light13号。保持逐件保存后完整一般字段、标签字体、尺寸读回，安全和颜色只在严格匹配已verified模板时继承。批次开始与结束各一次目录审计，替代每件前后全目录扫描；精确新对象key由properties定位，不以盲坐标作为身份。每件paste-requested/pasted/saved-unverified/verified阶段独立保留，异常不得重贴。

实测：TS_7完整建件{r['items'][0]['seconds']:.9f}秒；TS_8完整建件{r['items'][1]['seconds']:.9f}秒；含首尾目录审计worker整批{r['seconds']:.9f}秒，含请求控制器整批{r['controller_wall_seconds']:.9f}秒，平均{r['controller_wall_seconds']/2:.9f}秒/件。相比此前最快成功完整样本TS_5控制器44.229814秒/件，本批平均减少{(1-r['controller_wall_seconds']/2/44.229814)*100:.3f}%，不同对象且仅两件样本，不能据此保证所有页面固定倍数，也不宣称全局最优或达到几秒。源参数首次缓存读取TS_7 13.823716秒、TS_8 13.7181977秒，合计27.5419137秒；若把该读取计入本次总成本，合计{r['controller_wall_seconds']+27.5419137:.9f}秒。后续同字段可直接复用缓存。

阶段实测秒数：{json.dumps(stages,ensure_ascii=False)}。

结果：201页25/52件，剩27，额外0、地址/名称差异0；TS_0至TS_8共9按钮保存重开核对；工程实际{size}字节。未新增编译或运行验收，未下载PLC/HMI、未执行控制宏。此轮apply_patch一次因上下文匹配失败返回“Failed to find expected lines”，该次未改文件，随后按实际源码匹配完成。Python语法检查及真实两件生产试验通过；无遗留属性弹窗或batch.lock。

复现命令（管理员worker已启动且没有其它控制器时）：
`& "C:\\Users\\wei'ke\\.cache\\codex-runtimes\\codex-primary-runtime\\dependencies\\python\\python.exe" tools/trial_page201_batch.py`
内部请求原文：{{"page201_batch":[7,8],"build_bit_general":0}}；单完整批次300秒。已verified的对象会跳过，重复运行不是新的速度测量。恢复先读两件copy-phase/built与target-page201-audit；任何未知paste-requested先查实际目录，禁止重新粘贴。测试入口仅允许7、8，不盲扩展。下一步先读取TS_9原件缺失参数，再按图库、安全、颜色及地址类型归类，将确实同模板的连续对象纳入新限定批次；不同外观、安全保持适配和核对。本轮记录是当前实测更快方案，仍需进一步降低属性窗口定位与读回成本。
'''
for p in (ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md'):
    with p.open('a',encoding='utf8')as f:f.write(text)
cp=ROOT/'evidence/resume-checkpoint.json';d=json.loads(cp.read_text(encoding='utf-8-sig'))
d.update(status='page201-nine-buttons-saved-batch-trial',page201_objects=25,page201_remaining_objects=27,project_bytes=size,target_project_bytes=size,batch_running=False,current_stage='TS_0..TS_8 saved and reopened verified; bounded batch trial finished',next_action='Read TS_9 original missing fields; classify exact verified templates. No duplicates TS_0..8. New batch must explicitly extend reviewed scope.',batch_trial_report='evidence/page201-two-button-batch.json',batch_average_complete_seconds=r['controller_wall_seconds']/2,seconds_level_goal_achieved=False)
cp.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
(ROOT/'evidence/page201-buttons-preview-workflow.json').write_text(json.dumps({'page':201,'verified':[f'TS_{n}'for n in range(9)],'status':'saved-batch-speed-trial','remaining':27,'batch_seconds':r['controller_wall_seconds'],'average_seconds':r['controller_wall_seconds']/2,'seconds_level_goal_achieved':False},ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'count':25,'remaining':27,'bytes':size,'docs_updated':2},ensure_ascii=False))
