"""Read or set exact RGB values through the observed native Colors dialog."""
import json,time,ctypes
from functools import wraps
from pywinauto import Desktop
from pywinauto.controls.win32_controls import ButtonWrapper
from eb_extract import ROOT
from eb_native_form import commit_text
from eb_native_form import typed_children
from eb_uia_inventory import descendants as cached_descendants

def timed(fn):
    @wraps(fn)
    def measured(*args,**kwargs):
        start=time.perf_counter();ok=False
        try:
            result=fn(*args,**kwargs);ok=True;return result
        finally:
            with (ROOT/'evidence/color-timing.jsonl').open('a',encoding='utf8') as f:
                f.write(json.dumps({'time':time.time(),'phase':fn.__name__,'seconds':round(time.perf_counter()-start,4),'ok':ok})+'\n')
    return measured

def native_window_handles(pid,title_match=None,class_prefix=None):
    """Only wrap the live Colors dialog, never transient unrelated windows."""
    u=ctypes.windll.user32;found=[]
    cb=ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p)
    @cb
    def visit(h,_):
        observed_pid=ctypes.c_ulong();u.GetWindowThreadProcessId(h,ctypes.byref(observed_pid))
        if observed_pid.value!=pid or not u.IsWindowVisible(h):return True
        title=ctypes.create_unicode_buffer(256);u.GetWindowTextW(h,title,256)
        cls=ctypes.create_unicode_buffer(256);u.GetClassNameW(h,cls,256)
        if title_match is not None and title.value!=title_match:return True
        if class_prefix is not None and not cls.value.startswith(class_prefix):return True
        if u.IsWindow(h):found.append(int(h))
        return True
    u.EnumWindows(visit,0)
    return found

def native_color_handles(pid):
    return native_window_handles(pid,title_match='Colors')

@timed
def open_picker(d,label='颜色 :',occurrence=0):
    native_dialog=Desktop(backend='win32').window(handle=d.handle).wrapper_object()
    native_dialog.set_focus()
    observed=cached_descendants(d)
    anchor_type=label.get('anchor_type','Text') if isinstance(label,dict) else 'Text'
    anchor_name=label['anchor_name'] if isinstance(label,dict) else label
    texts=[c for c in observed if c.element_info.control_type==anchor_type and c.element_info.name==anchor_name and c.is_visible()]
    texts.sort(key=lambda c:c.rectangle().top)
    if len(texts)<=occurrence:raise ValueError('Observed color label missing')
    r=texts[occurrence].rectangle()
    choices=[c for c in observed if c.element_info.control_type=='MenuItem' and c.element_info.name in ('','...') and c.is_visible() and ((c.rectangle().left>=r.right and abs((c.rectangle().top+c.rectangle().bottom-r.top-r.bottom)/2)<35) or c.rectangle()==r or (r.left<=c.rectangle().left and c.rectangle().right<=r.right and abs((c.rectangle().top+c.rectangle().bottom-r.top-r.bottom)/2)<35))]
    if len(choices)>1:
        vertical=[abs((c.rectangle().top+c.rectangle().bottom-r.top-r.bottom)/2) for c in choices]
        nearest_y=min(vertical);choices=[c for c,dy in zip(choices,vertical) if dy==nearest_y]
    if len(choices)>1:
        distances=[0 if c.rectangle()==r else c.rectangle().left-r.right for c in choices]
        nearest=min(distances)
        choices=[c for c,distance in zip(choices,distances) if distance==nearest]
    if len(choices)!=1:
        relevant=[c for c in d.descendants() if c.is_visible() and c.element_info.control_type in ('MenuItem','Text') and (c.element_info.control_type=='MenuItem' or c.element_info.name in (label,'颜色 :','图案颜色 :','图案类型 :','外框颜色 :','背景颜色 :'))]
        layout=[{'type':c.element_info.control_type,'name':c.element_info.name,'rect':[c.rectangle().left,c.rectangle().top,c.rectangle().right,c.rectangle().bottom]} for c in relevant]
        (ROOT/'evidence'/'color-selector-layout-latest.json').write_text(json.dumps(layout,ensure_ascii=False),encoding='utf8')
        raise ValueError('Color selector not unique')
    native_dialog.set_focus()
    from pywinauto import mouse
    r=choices[0].rectangle();mouse.click(coords=((r.left+r.right)//2,(r.top+r.bottom)//2))
    pid=d.process_id();matches=[]
    for _ in range(12):
        matches=[]
        for h in native_window_handles(pid,class_prefix='Qt5QWindowPopup'):
            ui=Desktop(backend='uia').window(handle=h).wrapper_object()
            matches.extend(c for c in cached_descendants(ui,control_type='MenuItem') if c.element_info.name=='更多颜色...' and c.is_visible())
        if len(matches)==1:break
        time.sleep(.1)
    if len(matches)!=1:raise ValueError('Observed More colors entry required')
    r=matches[0].rectangle()
    mouse.click(coords=((r.left+r.right)//2,(r.top+r.bottom)//2))
    for _ in range(12):
        ds=native_color_handles(pid)
        if len(ds)==1:break
        time.sleep(.1)
    else:
        diagnostic={'property_handle':d.handle,'property_title':d.window_text(),'label':label,'foreground':ctypes.windll.user32.GetForegroundWindow(),'more_rect':[r.left,r.top,r.right,r.bottom],'windows':[]}
        for h in native_window_handles(pid):
            v=Desktop(backend='win32').window(handle=h).wrapper_object();b=v.rectangle()
            diagnostic['windows'].append({'handle':h,'title':v.window_text(),'class':v.class_name(),'rect':[b.left,b.top,b.right,b.bottom]})
        (ROOT/'evidence/color-open-failure.json').write_text(json.dumps(diagnostic,ensure_ascii=False,indent=2),encoding='utf8')
        raise ValueError('Colors dialog required')
    color=Desktop(backend='uia').window(handle=ds[0]).wrapper_object()
    native_color=Desktop(backend='win32').window(handle=color.handle).wrapper_object()
    tab_controls=[c for c in native_color.descendants(class_name='SysTabControl32') if c.is_visible()]
    if len(tab_controls)!=1:raise ValueError('Unique native Colors tab required')
    tab_root=Desktop(backend='uia').window(handle=tab_controls[0].handle).wrapper_object()
    custom=[c for c in tab_root.children(control_type='TabItem') if c.element_info.name=='Custom']
    if len(custom)!=1:raise ValueError('Custom color tab required')
    custom[0].select()
    return color

@timed
def rgb(color):
    result=[]
    editors=typed_children(color,'Edit')
    for name in ('Red:','Green:','Blue:'):
        cs=[c for c in editors if c.element_info.name==name and c.is_visible()]
        if len(cs)!=1:raise ValueError('Unique RGB field required: '+name)
        from eb_native_messages import text
        value=int(text(cs[0].handle))
        if not 0<=value<=255:raise ValueError('Invalid RGB component')
        result.append(value)
    return result

@timed
def close(color,button):
    # Colors is a native modal dialog. Enumerating UIA during modal teardown
    # can stall; find the real visible native Button and use bounded messages.
    from eb_native_messages import text,msg
    found=[];u=ctypes.windll.user32
    callback=ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p)
    @callback
    def visit(h,_):
        cls=ctypes.create_unicode_buffer(256);u.GetClassNameW(h,cls,256)
        if cls.value=='Button' and u.IsWindowVisible(h) and text(h)==button:found.append(int(h))
        return True
    u.EnumChildWindows(color.handle,visit,0)
    if len(found)!=1:raise ValueError('Unique native color confirmation/cancel required')
    msg(found[0],0x00F5)
    for _ in range(10):
        if not ctypes.windll.user32.IsWindow(color.handle):return
        time.sleep(.1)
    raise ValueError('Color dialog did not close')

def probe(d,label='颜色 :',occurrence=0,deep=True):
    color=open_picker(d,label,occurrence)
    try:
        value=rgb(color)
        (ROOT/'evidence'/'color-read-latest.json').write_text(json.dumps({'rgb':value,'hex':'#'+''.join(f'{n:02X}' for n in value)},ensure_ascii=False),encoding='utf8')
        return value
    finally:close(color,'Cancel')

@timed
def set_rgb(d,value,label='颜色 :',occurrence=0):
    titles=[w.window_text() for w in Desktop(backend='win32').windows(visible_only=False,process=d.process_id()) if w.process_id()==d.process_id() and w.class_name()=='EasyBuilderPro']
    if len(titles)!=1 or '组装机_MT8106iP.emtp' not in titles[0]:raise ValueError('Color changes allowed only on target reconstruction')
    if len(value)!=3 or any(not isinstance(n,int) or not 0<=n<=255 for n in value):raise ValueError('Exact integer RGB required')
    color=open_picker(d,label,occurrence)
    try:
        before=rgb(color)
        if before==value:
            close(color,'Cancel')
            return {'before':before,'after':before,'already_equal':True}
        from eb_native_messages import put
        for name,n in zip(('Red:','Green:','Blue:'),value):
            editors=[c for c in typed_children(color,'Edit') if c.element_info.name==name and c.is_visible()]
            if len(editors)!=1:raise ValueError('Unique RGB editor required: '+name)
            put(editors[0].handle,str(n))
        after=rgb(color)
        if after!=value:raise ValueError('Color RGB readback mismatch')
    except Exception:
        close(color,'Cancel');raise
    close(color,'OK')
    return {'before':before,'after':after}
