"""Serial phases: no whole-dialog replay or long per-request work."""
import json,sys,time
from eb_rebuild_page import ROOT,call
page=int(sys.argv[1]);h=int(sys.argv[2])
source=json.loads((ROOT/f'evidence/source-object-properties/{page:03d}_MS_0.json').read_text(encoding='utf8'))
def step(action,**kw):
    name=action
    path=ROOT/f'evidence/target-{page:03d}-MS0-phases.json'
    if name=='field' and path.exists():
        progress=json.loads(path.read_text(encoding='utf8'))
        if kw['tab']+':'+str(kw['index']) in progress.get('readbacks',{}):return
    started=time.monotonic()
    call('uia',h,json.dumps({'page':page,'build_ms':0,'ms_step':name,**kw},ensure_ascii=False))
    with (ROOT/f'evidence/page-{page}-MS-step-times.jsonl').open('a',encoding='utf8') as f:
        f.write(json.dumps({'step':name,**kw,'seconds':round(time.monotonic()-started,3)},ensure_ascii=False)+'\n')
    print(json.dumps({'ms_step':name,**kw},ensure_ascii=False),flush=True)
if '--resume-geometry' in sys.argv:
    for field_name in ('X :',' Y :',' 宽度 :','高度 :'):step('geometry_field',name=field_name)
    step('geometry_save');sys.exit(0)
if '--resume-general' not in sys.argv:
    step('start');step('tab',tab='图片')
    for i,r in enumerate(source['tabs']['图片']):
        if r['type']=='CheckBox':step('field',tab='图片',index=i)
    step('picture_choose')
step('tab',tab='一般属性')
general=source['tabs']['一般属性']
ordered=[i for i,r in enumerate(general) if r['type'] in ('Edit','ComboBox','CheckBox','RadioButton') and 'value' in r and r['name'] not in ('设备 :',' Down','Static','偏移量 :')]
ordered += [i for name in ('设备 :',' Down','Static','偏移量 :') for i,r in enumerate(general) if r['name']==name and 'value' in r]
ordered=[i for i in ordered if general[i]['type']=='RadioButton' and general[i]['value']]+[i for i in ordered if not (general[i]['type']=='RadioButton' and general[i]['value'])]
for i in ordered:step('field',tab='一般属性',index=i)
step('tab',tab='图片');step('picture_verify')
step('tab',tab='标签')
assert next(r['value'] for r in source['tabs']['标签'] if r['name']=='使用文字标签' and r['type']=='CheckBox')==0
for i,r in enumerate(source['tabs']['标签']):
    if r['type']=='CheckBox':step('field',tab='标签',index=i)
step('tab',tab='安全')
for i,r in enumerate(source['tabs']['安全']):
    if r['type'] in ('Edit','ComboBox','CheckBox','RadioButton') and 'value' in r:step('field',tab='安全',index=i)
step('place');step('geometry_open')
for name in ('X :',' Y :',' 宽度 :','高度 :'):step('geometry_field',name=name)
step('geometry_save')
