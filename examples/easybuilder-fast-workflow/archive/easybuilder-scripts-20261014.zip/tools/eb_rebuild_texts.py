"""Review and recreate all static page16 texts serially with exact RGB."""
import json,re
from eb_rebuild_page import ROOT,call


def run():
    lock=ROOT/'tools'/'batch.lock'
    with lock.open('x'):pass
    path=ROOT/'evidence'/'page-16-text-workflow.json'
    report={'page':16,'completed':[],'ok':False}
    def persist():path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    try:
        call('snapshot');wins=json.loads((ROOT/'evidence'/'windows.json').read_text(encoding='utf8'))
        def resolve(title):
            candidates=[w for w in wins if w['class']=='EasyBuilderPro' and title in w['title']]
            if len(candidates)!=1:raise ValueError('Exactly one project required')
            return candidates[0]['handle']
        source=resolve('组装机2台15工位取消.cmtp');target=resolve('组装机_MT8106iP.emtp')
        inv=json.loads((ROOT/'evidence'/'source-pages-inventory.json').read_text(encoding='utf8'))
        names=next(p['observed_objects'] for p in inv['pages'] if p['id']==16)
        text_names={int(re.search(r'TX_(\d+)',name)[1]):name for name in names if re.search(r'TX_(\d+)',name)}
        if set(text_names)!=set(range(20)):raise ValueError('Reviewed text inventory0..19 required')
        # Review every source before creating any target: no skipped IDs.
        for n,name in sorted(text_names.items()):
            report['stage']='review TX_'+str(n);persist()
            filename=ROOT/'evidence'/'source-object-properties'/f'016_TX_{n}.json'
            data=json.loads(filename.read_text(encoding='utf8'))
            for tab in ('文字/批注','安全'):
                for row in data['tabs'][tab]:
                    guarded=('使用文字库 ','使用字符串表','仅作为批注使用 (不会显示于 HMI)','使用寄存器状态/数值')
                    if row['type']=='CheckBox' and row['name'] in guarded and row.get('value')!=0:
                        raise ValueError('Unreviewed text behavior on TX_'+str(n)+': '+row['name'])
            if not data.get('colors'):
                call('uia',source,json.dumps({'extract':{'page':16,'object':name,'only_color':True,'colors':['颜色 :'],'color_tab':'文字/批注'}},ensure_ascii=False))
        call('uia',target,json.dumps({'open_target_page':16}))
        for n in sorted(text_names):
            report['stage']='build TX_'+str(n);persist()
            if not (ROOT/'evidence'/f'target-016-TX{n}-built.json').exists():
                call('uia',target,json.dumps({'page':16,'build_tx':n}))
            report['completed'].append('TX_'+str(n));persist()
        report['ok']=True;report['stage']='texts saved; whole page remains incomplete';persist()
        print(json.dumps({'ok':True,'page':16,'texts':len(report['completed']),'whole_page_complete':False}))
    except Exception as exc:
        report['error']=str(exc);persist();raise
    finally:lock.unlink(missing_ok=True)


if __name__=='__main__':run()
