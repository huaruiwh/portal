"""Resume-safe serial switch shapes and original colors for reviewed flow pages."""
import json,re,os
from datetime import datetime
from eb_rebuild_page import ROOT,call

def run(pages):
 lock=ROOT/'tools/batch.lock'
 with lock.open('x',encoding='utf8') as f:json.dump({'pid':os.getpid(),'task':'flow switch appearance'},f)
 path=ROOT/'evidence/flow-appearance-workflow.json'
 report={'date':datetime.now().isoformat(),'pages':pages,'completed_pages':[],'completed_objects':[],'ok':False,'runtime_verified':False,'pending_vector_objects':[],'controller_pid':os.getpid()}
 def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8-sig'))
 def persist():
  report['date']=datetime.now().isoformat(timespec='seconds');path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 def document():
  cp=read('evidence/resume-checkpoint.json');cp.update(date=report['date'],flow_appearance=report,batch_running=not report['ok'] and 'error' not in report,controller_pid=os.getpid() if not report['ok'] and 'error' not in report else None,next='继续flow-appearance-workflow的未完成按钮；先核对worker/request/response及弹窗，不重复新增。')
  (ROOT/'evidence/resume-checkpoint.json').write_text(json.dumps(cp,ensure_ascii=False,indent=2),encoding='utf8')
  section=f"<!-- FLOW-APPEARANCE-LIVE -->\n### {report['date']} 流程页按钮图形与原色修正\n\n- 范围：{pages}，仅既有TS按钮及已实查Lamp - Flat图片指示灯；向量待单独核实；已完成图片修正页面{report['completed_pages']}，待核实向量{report['pending_vector_objects']}，已完成图片控件{len(report['completed_objects'])}。当前阶段{report.get('stage')}。\n- 规则：按源图片族名及尺寸，Standard / 3 / 143x64、Switch - Flat / 5 / 70x29或Lamp - Flat / 3 / 143x64；44、45额外按钮按实际族名判断。图形与原件0/1状态图片色、启用的标签色分别读取、保存、重开属性核对，保持地址与几何，禁止重复新增。\n- 入口：Python tools/eb_fix_flow_appearances.py {' '.join(map(str,pages))}；单串行batch.lock，每个动作request/response同ID，控件300秒其它55秒。原件只读，未知族名停止核对，用户103 TS0模板不在此范围。\n- 实际证据：evidence/page<N>-<TS或BL><M>-shape-correction.json与color-correction.json；保存报告存在才跳过。状态ok={report['ok']}，错误={report.get('error','无')}。本阶段不代表整屏运行交互验收；旧编译不能替代本阶段新编译。\n<!-- /FLOW-APPEARANCE-LIVE -->"
  for p in ('README.md','docs/MT8106iP重建-实现记录.md'):
   f=ROOT/p;text=f.read_text(encoding='utf8');pattern=r'<!-- FLOW-APPEARANCE-LIVE -->.*?<!-- /FLOW-APPEARANCE-LIVE -->'
   text=re.sub(pattern,lambda _:section,text,flags=re.S) if re.search(pattern,text,flags=re.S) else text+'\n\n'+section+'\n';f.write_text(text,encoding='utf8')
 try:
  report['stage']='initializing serial queue';persist();document()
  call('snapshot');ws=read('evidence/windows.json')
  def resolve(title):
   matches=[w for w in ws if w['class']=='EasyBuilderPro' and title in w['title']]
   if len(matches)!=1:raise ValueError('Unique project required')
   return matches[0]['handle']
  sh=resolve('组装机2台15工位取消.cmtp');th=resolve('组装机_MT8106iP.emtp')
  def ui(h,q):call('uia',h,json.dumps(q,ensure_ascii=False))
  for h in (sh,th):ui(h,{'op':'selecttab','type':'TabItem','name':'目录树','selector':True})
  inv=read('evidence/source-pages-inventory.json')
  for page in pages:
   if page not in (*range(26,46),47):raise ValueError('Reviewed flow pages only')
   ui(th,{'open_target_page':page});ui(th,{'target_page_audit':page})
   names=next(p['observed_objects'] for p in inv['pages'] if p['id']==page)
   switches=[]
   for name in names:
    m=re.match(r'^(TS|BL)_(\d+)\s',name)
    if not m:continue
    kind,n=m[1],int(m[2])
    if kind=='BL':
     src=read(f'evidence/source-object-properties/{page:03d}_{kind}_{n}.json')
     pic=src['tabs']['图片']
     if any(r['name']=='使用向量图' and r.get('value')==1 for r in pic):
      report['pending_vector_objects'].append(f'{page}:{kind}_{n}');continue
     if not any(r['name']=='Lamp - Flat' for r in pic):raise ValueError(f'Unreviewed lamp family {page}:{kind}_{n}')
    switches.append((kind,n,name))
   for kind,n,name in switches:
    report['stage']=f'{page}:{kind}_{n}';persist()
    shape=ROOT/f'evidence/page{page}-{kind}{n}-shape-correction.json'
    original=ROOT/f'evidence/page{page}-{kind}{n}-source-colors.json'
    if not original.exists():
     ui(sh,{'extract':{'page':page,'object':name,'keep_open':True}})
     ui(sh,{'page26_shapes':'source-colors','page':page,'kind':kind,'n':n,'build_bit_general':n})
    color=ROOT/f'evidence/page{page}-{kind}{n}-color-correction.json'
    shape_ok=shape.exists() and read(str(shape.relative_to(ROOT))).get('saved')
    color_ok=color.exists() and read(str(color.relative_to(ROOT))).get('native_reopened_rgb_verified')
    # New objects combine shape and colors in one save/reopen verification.
    # A previously verified shape retains the original colors-only route.
    if not shape_ok:ui(th,{'page26_shapes':'repair-all','page':page,'kind':kind,'n':n,'build_bit_general':n})
    elif not color_ok:ui(th,{'page26_shapes':'target-colors','page':page,'kind':kind,'n':n,'build_bit_general':n})
    key=f'{page}:{kind}_{n}'
    if key not in report['completed_objects']:report['completed_objects'].append(key)
    persist();document();print(f'{page}:{kind}{n} shape/RGB saved',flush=True)
   ui(th,{'target_page_audit':page});report['completed_pages'].append(page);persist();document()
  ui(th,{'compile_target':True});report['compile']=read('evidence/latest-project-compile.json');report['ok']=report['compile']['ok'];report['stage']='saved and compiled; runtime pending';persist();document()
 except Exception as e:report['error']=str(e);persist();document();raise
 finally:lock.unlink(missing_ok=True)

if __name__=='__main__':
 import sys
 run([int(x) for x in sys.argv[1:]] or [*range(26,46),47])
