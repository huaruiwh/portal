import json,re,os,time
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
with lock.open('x',encoding='utf8')as f:f.write(json.dumps({'pid':os.getpid(),'task':'201 text batches'}))
try:
    call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
    source=next(w['handle']for w in ws if w['class']=='EasyBuilderPro'and'组装机2台15工位取消.cmtp'in w['title']);target=next(w['handle']for w in ws if w['class']=='EasyBuilderPro'and'组装机_MT8106iP.emtp'in w['title'])
    inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(p['observed_objects']for p in inv['pages']if p['id']==201)
    for ids in ([0,1,2],[3,4,5],[6,7,8],[9,10,11,12]):
        for n in ids:
            p=ROOT/f'evidence/source-object-properties/201_TX_{n}.json'
            if not p.exists():
                name=next(v for v in names if re.search(r'(?:^|\])\s*TX_'+str(n)+r'(?:\s|$)',v));call('uia',source,json.dumps({'extract':{'page':201,'object':name}},ensure_ascii=False))
        call('uia',target,json.dumps({'open_target_page':201}))
        call('uia',target,json.dumps({'page201_text_batch':ids,'build_bit_general':0}))
        r=json.loads((ROOT/('evidence/page201-text-batch-'+ '-'.join(map(str,ids))+'.json')).read_text(encoding='utf8'));print(json.dumps(r),flush=True)
finally:lock.unlink()
