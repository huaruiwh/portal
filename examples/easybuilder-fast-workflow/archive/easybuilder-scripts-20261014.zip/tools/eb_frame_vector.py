"""Select the user-reviewed System Frame / 0 vector from observed gallery UI."""
import time
from pywinauto import Desktop
from eb_object_ui import dialog

def choose(d,pid):
    buttons=[c for c in d.descendants(control_type='Button',cache_enable=True) if c.element_info.name=='图库...' and c.is_visible() and c.is_enabled()]
    if len(buttons)!=1:raise ValueError('Unique vector gallery button required')
    buttons[0].click_input()
    g=dialog(pid,'向量图管理')
    tabs=[c for c in g.descendants(control_type='TabItem',cache_enable=True) if c.element_info.name=='图库' and c.is_visible()]
    if len(tabs)!=1:raise ValueError('Unique vector library tab required')
    tabs[0].click_input();time.sleep(.1)
    menus=[c for c in g.descendants(control_type='MenuItem',cache_enable=True) if c.element_info.name and c.is_visible() and c.rectangle().top<g.rectangle().top+150]
    if len(menus)!=1 or menus[0].element_info.name!='System Frame':raise ValueError('Reviewed System Frame category required')
    groups=[c for c in g.descendants(control_type='Group',cache_enable=True) if c.element_info.name=='0' and c.is_visible()]
    if len(groups)!=1:raise ValueError('Unique System Frame 0 thumbnail required')
    groups[0].click_input(coords=(60,70))
    ok=[c for c in g.descendants(control_type='Button',cache_enable=True) if c.element_info.name=='确定' and c.is_visible()]
    if len(ok)!=1:raise ValueError('Unique vector gallery OK required')
    ok[0].click_input()
