"""Reviewed user-authorized 201 -> 203 native whole-page copy; never repeat paste."""
import json,re,time,shutil
from pywinauto.keyboard import send_keys
from eb_rebuild_page import ROOT
from eb_object_ui import target,save
from eb_open_page import run as open_page
from eb_copy_200_style_object import read_audit,native_clipboard_data,restore_native_clipboard

def run(handle,q):
 p=ROOT/'evidence/page203-whole-page-copy.json'
 if p.exists():raise ValueError('203 copy journal exists; inspect instead of repeating paste')
 inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
 def keys(n):return {re.search(r'(?:^|\])\s*([A-Z]+_\d+)',s)[1]for s in next(x['observed_objects']for x in inv['pages']if x['id']==n)}
 if keys(201)!=keys(203) or len(keys(203))!=52:raise ValueError('Reviewed52 source key sets differ')
 if not (ROOT/'evidence/target-page-203-created.json').exists():raise ValueError('Saved destination page required')
 open_page(handle,{'open_target_page':203});a=read_audit(handle,203)
 if a['target_count']!=0:raise ValueError('Empty203 destination required')
 backup=ROOT/'backup/201复制203前_20261011.emtp'
 if not backup.exists():shutil.copy2(ROOT/'output/组装机_MT8106iP.emtp',backup)
 open_page(handle,{'open_target_page':201});root,w=target(handle,201)
 a=read_audit(handle,201)
 if a['target_count']!=52 or a['missing']or a['unexpected']or a['address_name_mismatch']:raise ValueError('Completed201 template required')
 root.click_input(coords=(963,367));send_keys('^a^c',pause=.04);time.sleep(.2);data=native_clipboard_data()
 open_page(handle,{'open_target_page':203});root,w=target(handle,203);restore_native_clipboard(data)
 root.click_input(coords=(963,367))
 p.write_text(json.dumps({'page':203,'template':201,'stage':'paste-requested','bindings_verified':False}),encoding='utf8')
 send_keys('^v',pause=.04);time.sleep(.3);send_keys('{ESC}',pause=.02);save(root)
 a=read_audit(handle,203)
 if a['target_count']!=52 or a['missing']or a['unexpected']:raise ValueError('Copied203 key count differs; inspect journal')
 p.write_text(json.dumps({'page':203,'template':201,'stage':'saved-bindings-pending','count':52,'bindings_verified':False,'runtime_verified':False,'address_name_mismatch':a['address_name_mismatch']},ensure_ascii=False,indent=2),encoding='utf8')
