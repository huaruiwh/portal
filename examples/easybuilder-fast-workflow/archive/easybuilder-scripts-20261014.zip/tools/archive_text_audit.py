import json,re
from datetime import datetime
from eb_rebuild_page import ROOT
r=json.loads((ROOT/'evidence/text-content-audit.json').read_text(encoding='utf8'))
fresh=list((ROOT/'evidence/target-text-readbacks').glob('*.json'))
counts={}
for c in r['checks']:counts[str(c['page'])]=counts.get(str(c['page']),0)+1
section=f"""<!-- TEXT-CONTENT-AUDIT -->
### {datetime.now().isoformat(timespec='seconds')} 文字内容专项核对

用户要求“文本检查一下”。脚本tools/audit_text_content.py按原件TX内容及TS/BL/SW/MS标签状态逐字对照，只规范CR/LF与控件尾部换行，不去掉空格、不改字词。实际已比较{r['cached_checks']}条文本/状态，匹配{r['cached_passed']}条，差异{len(r['mismatches'])}条；待补读记录{len(r['pending'])}条。每页计数：{json.dumps(counts,ensure_ascii=False)}。详细原文、差异及待查对象写evidence/text-content-audit.json；有旧记录的结果属于记录对照，不能称全部当前界面重开验收。

补查入口Python tools/check_pending_texts.py，batch.lock串行；tools/eb_text_live.py只开既有控件标签/文字页，读取各状态后取消退出，不保存或修改控件。实际补读文件{len(fresh)}个，目录evidence/target-text-readbacks；最新补读优先于旧built记录。当前47 TX_0标题实际“24-载具转运流程测试”与原件一致，字号17；用户确认当前属性没有待保存修改（回答1，选择首项），才取消其窗口进入其它控件检查。10/11 TS_0旧built没有标签记录，曾被初版规则误列为文字差异，已纠正规则：缺证据列待补读，不当作文字缺失；重新读取后核对。

验证范围为文字原文及有可用标志时的文字标签启用状态。渲染截断、实际HMI运行显示未验证；未修改103用户TS_0模板、PLC地址、宏或安全属性。本阶段最新编译入口仍待恢复：旧请求报`ValueError: Compile dialog not ready; inspect before retry`，不能引用旧EXOB作为本轮新编译。新增本机工具栏OCR，仅回传文字不回传图片；Read-LocalImageText.ps1直接执行曾报`running scripts is disabled on this system`，采用预存代码作为PowerShell命令参数执行，无ExecutionPolicy或系统安全设置修改；输出文件存在才算观察成功。编译按钮仅使用本轮实际唯一识别到“编译”标签的坐标，不猜测入口。

复现：先确保worker/request/response同ID、无其它控制器；运行audit_text_content.py查看差异/待查；需要补读时运行check_pending_texts.py。只完成文字内容核对不表示向量灯、整屏交互或编译全部通过，下一步继续未验证部分。
<!-- /TEXT-CONTENT-AUDIT -->"""
for rel in ('README.md','docs/MT8106iP重建-实现记录.md'):
    p=ROOT/rel;t=p.read_text(encoding='utf8');pat=r'<!-- TEXT-CONTENT-AUDIT -->.*?<!-- /TEXT-CONTENT-AUDIT -->'
    t=re.sub(pat,lambda _:section,t,flags=re.S) if re.search(pat,t,flags=re.S) else t+'\n'+section+'\n';p.write_text(t,encoding='utf8')
print(json.dumps({'compared':r['cached_checks'],'matched':r['cached_passed'],'mismatches':len(r['mismatches']),'pending':len(r['pending']),'fresh_files':len(fresh)},ensure_ascii=False))
