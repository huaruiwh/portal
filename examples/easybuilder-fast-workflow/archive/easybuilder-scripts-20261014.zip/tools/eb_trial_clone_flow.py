"""Finish only page31's copied controls, preserving local checkpoints."""
import json,re
from eb_rebuild_page import ROOT,call
def run():
    lock=ROOT/'tools/batch.lock'
    with lock.open('x'):pass
    p=ROOT/'evidence/page-31-copy-workflow.json';report={'page':31,'template':26,'completed':[],'ok':False}
    def save():p.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    try:
        call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
        targets=[w for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
        if len(targets)!=1:raise ValueError('Unique target required')
        h=targets[0]['handle']
        inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
        names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==31)
        keys=[re.search(r'(?:^|\])\s*([A-Z]+_\d+)',n)[1] for n in names]
        keys=['TX_0']+[k for k in keys if k!='TX_0']
        for key in keys:
            report['stage']=key;save()
            if not (ROOT/f'evidence/target-031-{key}-clone-rewritten.json').exists():call('uia',h,json.dumps({'rewrite_clone_fast':31,'object':key}))
            report['completed'].append(key);save();print(json.dumps({'saved':key,'count':len(report['completed'])}),flush=True)
        call('uia',h,json.dumps({'target_page_audit':31}));report['ok']=True;report['stage']='saved and directory verified';save()
    except Exception as e:report['error']=str(e);save();raise
    finally:lock.unlink(missing_ok=True)
if __name__=='__main__':run()
