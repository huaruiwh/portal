"""Complete rows fast path only for fully observed native-backed forms."""
import json,hashlib,ctypes
from pathlib import Path
from eb_native_messages import visible_handles,text,combo_text,msg
from eb_live_inventory import native_caption,native_class
ROOT=Path(__file__).resolve().parent.parent
DIR=ROOT/'evidence/source-row-profiles-v2'
U=ctypes.windll.user32
CLASSES=('Edit','RichEdit20W','RichEdit20A','ComboBox','Button','Static')
def identity(d):
 handles=visible_handles(d.handle,CLASSES)
 tabs=visible_handles(d.handle,('SysTabControl32',))
 labels=[(native_class(h),U.GetDlgCtrlID(h),native_caption(h))for h in handles if native_class(h)in ('Static','Button')]
 data={'version':2,'title':native_caption(d.handle),'tab':msg(tabs[0],0x130B)if len(tabs)==1 else None,'controls':[(native_class(h),U.GetDlgCtrlID(h),U.GetWindowLongW(h,-16))for h in handles],'labels':labels}
 key=hashlib.sha256(json.dumps(data,ensure_ascii=False,sort_keys=True).encode('utf8')).hexdigest()
 return handles,data,key
def fast(d):
 handles,ident,key=identity(d);path=DIR/(key+'.json')
 if not path.exists():return None
 data=json.loads(path.read_text(encoding='utf8'))
 if data['identity']!=json.loads(json.dumps(ident)):return None
 from pywinauto import Desktop
 native_set=set(handles);virtual={}
 for typ,expected in data.get('virtual',{}).items():
  refs=[c for c in d.descendants(control_type=typ,cache_enable=True) if c.is_visible() and int(c.element_info.handle or 0)not in native_set]
  actual=[{'type':typ,'name':c.element_info.name,'class':c.element_info.class_name}for c in refs]
  if actual!=expected:return None # Virtual structure changed: full observed read.
  virtual[typ]=refs
 result=[]
 for row in data['rows']:
  out={k:v for k,v in row.items()if k not in ('index','dynamic_name','virtual_index')}
  typ=row['type']
  if 'virtual_index'in row:
   c=virtual[typ][row['virtual_index']]
   if typ=='Edit':out['value']=c.get_value().rstrip('\r\n')
   elif typ=='ComboBox':out['value']=c.selected_text()
   elif typ=='CheckBox':out['value']=c.get_toggle_state()
   elif typ=='RadioButton':out['value']=int(c.is_selected())
  else:
   h=handles[row['index']]
   if not U.IsWindow(h)or not U.IsWindowVisible(h):raise ValueError('Source native field disappeared')
   if row.get('dynamic_name'):out['name']=native_caption(h)
   if typ=='Edit':out['value']=text(h).rstrip('\r\n')
   elif typ=='ComboBox':out['value']=combo_text(h)
   elif typ in ('CheckBox','RadioButton'):out['value']=msg(h,240)
  result.append(out)
 with (ROOT/'evidence/source-profile-use.jsonl').open('a',encoding='utf8')as f:f.write(json.dumps({'title':ident['title'],'tab':ident['tab'],'profile_hit':True,'rows':len(result)})+'\n')
 return result
def remember(d,observed):
 handles,ident,key=identity(d);index={h:i for i,h in enumerate(handles)};stored=[];virtual={}
 for row in observed:
  if 'read_error'in row:return
  h=row.get('_native_handle');typ=row['type']
  out={k:v for k,v in row.items()if k not in ('value','read_error','_native_handle')}
  native=h in index and not(typ=='ComboBox'and native_class(h)!='ComboBox')and not(typ=='Edit'and native_class(h)not in ('Edit','RichEdit20W','RichEdit20A'))
  if native:out.update(index=index[h],dynamic_name=typ in ('Text','Button')and row['name']==native_caption(h))
  else:
   rows=virtual.setdefault(typ,[]);out['virtual_index']=len(rows);rows.append({'type':typ,'name':row['name'],'class':row['class']})
  stored.append(out)
 DIR.mkdir(exist_ok=True);(DIR/(key+'.json')).write_text(json.dumps({'identity':ident,'rows':stored,'virtual':virtual,'basis':'complete observed UIA rows; native values and identity-checked targeted virtual reads'},ensure_ascii=False,indent=2),encoding='utf8')
