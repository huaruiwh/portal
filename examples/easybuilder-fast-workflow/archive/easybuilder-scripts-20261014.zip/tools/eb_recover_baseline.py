"""Reconstruct only project helper files from prior patch records, never execute logs."""
import json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
log=next(Path("C:/Users/wei'ke/.codex/sessions/2026/10/07").glob('*01a1115b*.jsonl'))
dest=ROOT/'backup/page29_script_baseline';dest.mkdir(exist_ok=True)
names={'eb_native_form.py','eb_object_ui.py','eb_build_bit_general.py','eb_extract.py','eb_flat_picture.py','eb_build_ms.py','eb_selector_picture.py','eb_address_type.py'}
states={};events=[]
for line in log.open(encoding='utf8'):
    obj=json.loads(line)
    if obj.get('timestamp','')>'2026-10-08T12:55:00.000Z':continue
    p=obj.get('payload',{})
    if p.get('name')!='exec':continue
    for match in re.finditer(r'tools\.apply_patch\(("(?:[^"\\]|\\.)*")\)',p.get('input','')):
        patch=json.loads(match[1]);sections=re.split(r'(?=\*\*\* (?:Add|Update|Delete) File: )',patch)
        for section in sections:
            lines=section.splitlines()
            if not lines or not re.match(r'\*\*\* (Add|Update) File:',lines[0]):continue
            action,path=lines[0][4:].split(' File: ',1);name=Path(path).name
            if name not in names:continue
            body=[]
            for value in lines[1:]:
                if value.startswith('*** '):break
                body.append(value)
            if action=='Add':
                states[name]='\n'.join(v[1:] for v in body if v.startswith('+'))+'\n'
                events.append({'time':obj['timestamp'],'file':name,'action':'add'})
            elif name in states:
                chunks=[];chunk=[]
                for v in body:
                    if v.startswith('@@'):
                        if chunk:chunks.append(chunk)
                        chunk=[]
                    else:chunk.append(v)
                if chunk:chunks.append(chunk)
                for chunk in chunks:
                    old='\n'.join(v[1:] for v in chunk if v.startswith((' ','-')))+'\n'
                    new='\n'.join(v[1:] for v in chunk if v.startswith((' ','+')))+'\n'
                    count=states[name].count(old)
                    if old.strip() and count==1:
                        states[name]=states[name].replace(old,new,1);status='applied'
                    elif new in states[name]:status='already_present'
                    else:status='unmatched'
                    events.append({'time':obj['timestamp'],'file':name,'action':status})
for name,content in states.items():(dest/name).write_text(content,encoding='utf8')
report={'cutoff_utc':'2026-10-08T12:55:00Z','files':sorted(states),'unmatched':[e for e in events if e['action']=='unmatched'],'events':events,'patch_records_only':True,'not_installed':True}
(ROOT/'evidence/page29-baseline-recovery.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'files':report['files'],'unmatched':len(report['unmatched'])}))
