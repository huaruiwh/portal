"""Summarize observed phase timings and the verified combined workflow."""
import json,re,statistics
from datetime import datetime
from eb_rebuild_page import ROOT
def read_lines(path):
    return [json.loads(s) for s in path.read_text(encoding='utf8').splitlines() if s]
phases=read_lines(ROOT/'evidence/uia-phase-timing.jsonl')
colors=read_lines(ROOT/'evidence/color-timing.jsonl')
stats={}
for name,data in [('open_picker',colors),('rgb',colors),('eb_object_ui.properties',phases),('eb_object_ui.save',phases),('eb_page26_shapes.native_rows',phases)]:
    values=[r['seconds'] for r in data if r['phase']==name and r['ok']]
    stats[name]={'samples':len(values),'median_seconds':round(statistics.median(values),4),'min_seconds':min(values),'max_seconds':max(values)}
combined=[r for r in phases if r['phase']=='eb_page26_shapes.run' and r.get('request',{}).get('page26_shapes')=='repair-all' and r['ok']]
verified=[]
for r in combined:
    q=r['request'];key=f"page{q['page']}-{q['kind']}{q['n']}"
    shape=json.loads((ROOT/f'evidence/{key}-shape-correction.json').read_text(encoding='utf8'))
    color=json.loads((ROOT/f'evidence/{key}-color-correction.json').read_text(encoding='utf8'))
    if all((shape.get('saved'),shape.get('general_unchanged'),shape.get('geometry_unchanged'),color.get('native_reopened_rgb_verified'),color.get('combined_shape_color'))):
        verified.append({'control':key,'target_combined_seconds':r['seconds'],'property_open_count':sum(x['pid']==r['pid'] and x['phase']=='eb_object_ui.properties' for x in phases)})
assert verified,'Combined workflow not yet actually verified'
report={'date':datetime.now().isoformat(timespec='seconds'),'statistics':stats,'combined_verified':verified,'runtime_verified':False}
(ROOT/'evidence/speed-diagnosis.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
section=f"""<!-- SPEED-DIAGNOSIS -->
### {report['date']} 后续按钮变慢的实测原因与修正

已加本地分步计时tools/eb_timing.py、evidence/uia-phase-timing.jsonl、evidence/color-timing.jsonl，无截图回传。实测统计原文：{json.dumps(stats,ensure_ascii=False)}。分步嵌套计时不能直接相加；保存函数时间只是发送保存及前景检查耗时，实际工程验证仍靠保存后重开。

主要可消除开销：原形状repair和target-colors分两次，各打开、保存、重开目标属性，合计4次属性打开、2次保存；单次属性打开实测9.2405及11.7647秒。RGB读回约0.1秒，原生字段读取并非主要瓶颈。图库选择也有软件等待开销，未凭猜测删除等待。新repair-all先读源两状态颜色，然后同一目标属性中写图库及图片/标签色，一次保存后重开核对一般参数、轮廓、图片族名/尺寸、全部启用的两状态颜色；目标属性打开减为2次、保存减为1次。已有shape报告但颜色未完的旧控件继续颜色专用路线，已验证控件全部跳过。

已实测通过的合并控件：{json.dumps(verified,ensure_ascii=False)}。这是目标修改步骤计时，不包含读取原件和排队，不能将其当整控件总时长或宣称固定提速百分比。继续使用Python tools/eb_fix_flow_appearances.py 45 47。

中断原因另有：45 TS_3保存重开时`ValueError: Observed More colors entry required`；45 TS_4形状报告成功后，worker的全桌面snapshot遇到无关瞬态窗口报`pywinauto.controls.hwndwrapper.InvalidWindowHandle: Handle 6686848 is not a vaild window handle`，导致成功动作被返回为失败、队列停止。已改eb_ui.py为原生EnumWindows先筛EasyBuilder进程，再包装匹配窗口，跳过已销毁句柄；颜色popup也原生筛pid/类名后缓存读取MenuItem。旧worker通过restart_local_worker重启，新worker PID18672，admin=true，无并发GUI。45 TS_3已重新实查通过，TS_4已有shape验证据后安全跳过，不重复新增。

验证：7个修改脚本AST语法检查通过；合并控件真实保存/重开RGB、一般参数和几何验证通过。遗留：偶发popup失效仍应按实际窗口恢复，不能盲重试；45、47剩余按钮、其余向量灯、新编译及整体运行验收以同文档实时进度为准。此次性能修改没有下载PLC/HMI或执行宏。
<!-- /SPEED-DIAGNOSIS -->"""
for rel in ('README.md','docs/MT8106iP重建-实现记录.md'):
    p=ROOT/rel;t=p.read_text(encoding='utf8');pat=r'<!-- SPEED-DIAGNOSIS -->.*?<!-- /SPEED-DIAGNOSIS -->'
    t=re.sub(pat,lambda _:section,t,flags=re.S) if re.search(pat,t,flags=re.S) else t+'\n'+section+'\n'
    p.write_text(t,encoding='utf8')
print(json.dumps(report,ensure_ascii=False))
