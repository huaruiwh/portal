"""Place the header background below labels using the observed Order menu."""
import json,time,ctypes,re
from eb_extract import ROOT
from eb_object_ui import target,object_item,menu,save
def run(handle,q):
    page,n=int(q['page']),int(q['order_sp'])
    kind=q.get('kind','SP')
    source_n=n
    if page==101:
        if kind!='SP' or n not in range(8):raise ValueError('Reviewed instruction vector required')
        verified=json.loads((ROOT/'evidence/page-101-vector-sample-reopened.json').read_text(encoding='utf8'))
        if not verified['ok'] or verified['source']!='SP_1' or verified['target']!='SP_0':raise ValueError('Verified pilot identity required')
        source_n={0:1,1:0,2:2,3:3,4:4,5:5,6:6,7:7}[n]
        if not (ROOT/f'evidence/target-101-SP{source_n}-built.json').exists():raise ValueError('Saved vector report required before ordering')
    elif page==10:
        if (kind,n)!=('SP',0) or not (ROOT/'evidence/target-010-SP0-built.json').exists():raise ValueError('Saved base vector required')
        inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
        names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==10)
        if not any('SP_0' in v and '(最下层)' in v for v in names):raise ValueError('Source lowest layer required')
    elif page==11:
        if (kind,n)!=('FK',0) or not (ROOT/'evidence/target-011-FK0-built.json').exists():raise ValueError('Saved manual navigation key required')
        inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
        names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==11)
        if not any('FK_0' in v and '(最下层)' in v for v in names):raise ValueError('Source manual lowest layer required')
    elif page==103:
        if (kind,n)!=('SP',0) or not (ROOT/'evidence/target-103-SP0-built.json').exists():raise ValueError('Saved background vector required')
        inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
        names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==103)
        if not any('SP_0' in v and '(最下层)' in v for v in names):raise ValueError('Source lowest layer required')
    elif page==201 and kind=='SP'and n in (0,1):
        inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
        names=next(p['observed_objects']for p in inventory['pages']if p['id']==201)
        if names[:2]!=['SP_0 (最下层)','SP_1']or not(ROOT/f'evidence/target-201-SP{n}-built.json').exists():raise ValueError('Original first two background vectors required')
    elif page>=26:
        if page in (48,49):
            from eb_template_guard import ALLOWED
            model=dict(zip(('SW','BL'),ALLOWED[page]))
        else:
            from eb_flow_model import counts
            model=counts(page)
        if kind not in model or n not in range(model[kind]):raise ValueError('Reviewed source layer object required')
        inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
        names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==page)
        if not any(re.search(r'(?:^|\])\s*'+re.escape(f'{kind}_{n}')+r'(?:\s|$)',v) and '(最下层)' in v for v in names):raise ValueError('Source lowest layer not verified')
    elif (page,n,kind) not in ((17,0,'SP'),(16,0,'GP')):raise ValueError('Unreviewed background ordering')
    root,w=target(handle,page);item=object_item(w,f'{kind}_{n}')
    if page==101:
        from eb_object_ui import properties
        from eb_native_form import tab,typed_children
        from eb_native_messages import msg
        from eb_extract import rows
        from eb_layout import geometry
        d,_=properties(root,w,f'SP_{n}','向量图的属性');tab(d,'轮廓')
        expected=geometry(json.loads((ROOT/f'evidence/source-object-properties/101_SP_{source_n}.json').read_text(encoding='utf8')))
        actual={v['name']:v['value'] for v in rows(d) if v['type']=='Edit' and v['name'] in expected}
        if actual!=expected:raise ValueError('Instruction layer object identity mismatch')
        cancel=[v for v in typed_children(d,'Button') if v.window_text()=='取消']
        if len(cancel)!=1:raise ValueError('Unique vector property cancel required')
        msg(cancel[0].handle,245);time.sleep(.1);item=object_item(w,f'SP_{n}')
    if page in (48,49):
        from eb_object_ui import properties
        from eb_extract import rows
        from eb_native_form import typed_children
        from eb_native_messages import msg
        d,_=properties(root,w,f'{kind}_{n}','多状态设置的属性')
        expected=json.loads((ROOT/f'evidence/source-object-properties/{page:03d}_{kind}_{n}.json').read_text(encoding='utf8'))
        source_addresses=[v['value'] for v in expected['tabs']['一般属性'] if v['type']=='Edit' and v['name']=='Static']
        actual_addresses=[v['value'] for v in rows(d) if v['type']=='Edit' and v['name']=='Static']
        if actual_addresses!=source_addresses:raise ValueError('Layer object identity mismatch')
        cancel=[v for v in typed_children(d,'Button') if v.window_text()=='取消']
        if len(cancel)!=1:raise ValueError('One layer property cancel required')
        msg(cancel[0].handle,245);time.sleep(.1)
        item=object_item(w,f'{kind}_{n}')
    root.set_focus();item.click_input(coords=(30,item.rectangle().height()//2));
    if ctypes.windll.user32.GetDpiForWindow(root.handle)==120 and (root.rectangle().width(),root.rectangle().height())==(1848,1281):
        root.click_input(coords=(232,52));time.sleep(.1)
        menu(root,(981,133),'移至底层')
    else:raise ValueError('Unreviewed ordering layout')
    time.sleep(.1)
    current=object_item(w,f'{kind}_{n}').window_text()
    if '(最下层)' not in current:raise ValueError('Vector lowest-layer marker not observed')
    save(root)
    path=ROOT/'evidence'/f'target-{page:03d}-{kind}{source_n}-built.json';report=json.loads(path.read_text(encoding='utf8'))
    report.update(target=current,z_order_review_pending=False,lowest_layer_verified=True)
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
