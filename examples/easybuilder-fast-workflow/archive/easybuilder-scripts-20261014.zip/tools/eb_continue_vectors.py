"""Build remaining reviewed instruction vectors serially, skipping saved reports."""
import json
from eb_rebuild_page import ROOT,call

def run():
    lock=ROOT/'tools/batch.lock'
    with lock.open('x'):pass
    path=ROOT/'evidence/page-101-vector-workflow.json'
    progress={'page':101,'completed':[],'ok':False}
    def persist():path.write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf8')
    try:
        call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
        found=[w for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
        if len(found)!=1:raise ValueError('Unique target required')
        h=found[0]['handle']
        call('uia',h,json.dumps({'open_target_page':101}))
        for n in (1,0,2,3,4,5,6,7):
            progress['stage']=f'SP_{n}';persist()
            if not (ROOT/f'evidence/target-101-SP{n}-built.json').exists():call('uia',h,json.dumps({'page':101,'build_sp':n}))
            progress['completed'].append(n);persist();print(json.dumps({'saved_source_vector':n}),flush=True)
        progress['ok']=True;persist()
    except Exception as e:
        progress['error']=str(e);persist();raise
    finally:lock.unlink(missing_ok=True)

if __name__=='__main__':run()
