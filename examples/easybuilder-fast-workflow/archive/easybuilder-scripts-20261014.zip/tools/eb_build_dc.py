"""Recreate page17 clock formats and layout; custom image appearance stays pending."""
import json
from eb_extract import ROOT,rows
from eb_object_ui import target,menu,dialog,placed_properties,save
from eb_native_form import tab,fields,confirm
from eb_layout import geometry
def run(handle,q):
    page,n=int(q['page']),int(q['build_dc'])
    if (page,n) not in ((10,0),(11,0),(17,0),(103,0)):raise ValueError('Unreviewed clock')
    source=json.loads((ROOT/'evidence'/'source-object-properties'/f'{page:03d}_DC_{n}.json').read_text(encoding='utf8'))
    for r in source['tabs']['安全']:
        if r['type']=='CheckBox' and r.get('value')!=0:raise ValueError('Clock visibility condition requires review')
    if page in (10,11):
        if (ROOT/f'evidence/target-{page:03d}-DC{n}-built.json').exists():raise ValueError('Saved clock exists; audit instead')
        audit=json.loads((ROOT/f'evidence/target-page{page}-audit.json').read_text(encoding='utf8'))
        if f'DC_{n}' not in audit['missing']:raise ValueError('Fresh missing-clock audit required')
    root,w=target(handle,page)
    if not q.get('resume'):
        root.set_focus();root.click_input(coords=(373,52) if page in (10,11,103) else (427,63));menu(root,(1416,145) if page in (10,11,103) else (1511,173),'日期/时间')
    d=dialog(root.process_id(),'新增 日期/时间');tab(d,'一般属性');general=fields(d,source['tabs']['一般属性'])
    tab(d,'图片')
    if page in (10,11,103):
        fields(d,source['tabs']['图片'])
        from eb_flat_picture import choose
        choose(d,root.process_id())
    else:fields(d,[{'type':'CheckBox','name':'使用图片','value':0},{'type':'CheckBox','name':'使用向量图','value':0}])
    if page in (10,11):
        from eb_color_picker import set_rgb,probe
        expected=source['colors']['颜色 :'];set_rgb(d,expected,'颜色 :')
        if probe(d,'颜色 :')!=expected:raise ValueError('Base clock picture RGB mismatch')
    pictures=rows(d)
    confirm(d);d,name=placed_properties(root,w,f'DC_{n}','日期/时间的属性')
    tab(d,'一般属性');readback=rows(d)
    def values(rs):return [(r['type'],r['name'],r['value'].split(' [')[0] if r['name']=='字体 :' and isinstance(r['value'],str) else r['value']) for r in rs if 'value' in r]
    if values(readback)!=values(source['tabs']['一般属性']):raise ValueError('Clock formats or flags mismatch')
    tab(d,'轮廓');shape=geometry(source);fields(d,[{'type':'Edit','name':k,'value':v} for k,v in shape.items()]);shape_readback=rows(d)
    confirm(d);save(root)
    report={'page':page,'source':source['object'],'target':name,'general':readback,'geometry':shape_readback,'picture':pictures,'saved_requested':True,'custom_background_review_pending':True}
    (ROOT/'evidence'/f'target-{page:03d}-DC{n}-built.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
