"""Copy verified NE0: same format, keypad, restrictions, colors, font and size."""
import json,time
from pywinauto.keyboard import send_keys
from eb_rebuild_page import ROOT
from eb_extract import rows
from eb_object_ui import target,properties,save
from eb_native_form import tab,fields,confirm,typed_children
from eb_native_messages import msg
from eb_layout import geometry

def run(handle,q):
 n=int(q['copy_page200_numeric'])
 if n not in range(1,25):raise ValueError('Reviewed remaining page200 numbers only')
 path=ROOT/f'evidence/target-200-NE{n}-built.json'
 if path.exists():raise ValueError('Saved numeric exists; no duplicate copy')
 source=json.loads((ROOT/f'evidence/source-object-properties/200_NE_{n}.json').read_text(encoding='utf8'))
 base=json.loads((ROOT/'evidence/source-object-properties/200_NE_0.json').read_text(encoding='utf8'))
 values=lambda rs:[(r['type'],r['name'],r['value']) for r in rs if 'value' in r]
 for name in ['格式','数值输入','安全','图片','字体']:
  if values(source['tabs'][name])!=values(base['tabs'][name]):raise ValueError('Template differs from original '+name)
 from eb_page_audit import run as audit
 def read_audit():
  try:audit(handle,{'target_page_audit':200})
  except ValueError as e:
   if 'Target object audit incomplete' not in str(e):raise
  return json.loads((ROOT/'evidence/target-page200-audit.json').read_text(encoding='utf8'))
 before=read_audit();key=f'NE_{n}'
 if key not in before['missing'] and not q.get('recover_existing'):raise ValueError('Existing numeric without report; inspect before paste')
 root,w=target(handle,200);title='数值的属性'
 phase=ROOT/f'evidence/target-200-NE{n}-copy-phase.json'
 if q.get('recover_existing'):
  if key in before['missing'] or not phase.exists():raise ValueError('Existing pasted numeric recovery proof required')
  template=json.loads((ROOT/'evidence/page200-numeric-copy-template.json').read_text(encoding='utf8'))
 else:
  d,_=properties(root,w,'NE_0',title)
  tp=ROOT/'evidence/page200-numeric-copy-template.json'
  if not tp.exists():
   captured={}
   for name in ['格式','数值输入','安全','字体','图片','轮廓']:
    tab(d,name);captured[name]=rows(d)
   tp.write_text(json.dumps({'template':'NE_0','tabs':captured,'source_picture_colors':base['colors'],'font_verified':True},ensure_ascii=False,indent=2),encoding='utf8')
  template=json.loads(tp.read_text(encoding='utf8'))
  cancel=[c for c in typed_children(d,'Button') if c.window_text()=='取消']
  if len(cancel)!=1:raise ValueError('One template cancel required')
  msg(cancel[0].handle,245);time.sleep(.1);send_keys('^c',pause=.03)
  root.set_focus();root.click_input(coords=(963,367));send_keys('^v',pause=.03);time.sleep(.15)
  root.click_input(coords=(963,367));send_keys('{ESC}',pause=.01)
  phase=ROOT/f'evidence/target-200-NE{n}-copy-phase.json'
  phase.write_text(json.dumps({'pasted':True,'saved':False,'template':'NE_0'}),encoding='utf8')
  after=read_audit()
  if after['target_count']!=before['target_count']+1 or key in after['missing'] or after['unexpected']:
   send_keys('^z',pause=.01);save(root);raise ValueError('Copy count guard rejected paste')
 d,name=properties(root,w,key,title);tab(d,'一般属性')
 address=next(r['value'] for r in source['tabs']['一般属性'] if r['type']=='Edit' and r['name']=='Static')
 fields(d,[{'type':'Edit','name':'Static','value':address}]);general=rows(d)
 if [r['value'] for r in general if r['type']=='Edit' and r['name']=='Static']!=[address]:raise ValueError('Copied numeric address mismatch')
 tab(d,'轮廓');shape=geometry(source)
 for r in template['tabs']['轮廓']:
  if r['type']=='Edit' and r['name'] in (' 宽度 :','高度 :'):shape[r['name']]=r['value']
 fields(d,[{'type':'Edit','name':k,'value':v} for k,v in shape.items() if k in ('X :',' Y :')])
 confirm(d);save(root)
 d,_=properties(root,w,key,title);captured={}
 for name in ['一般属性','格式','数值输入','安全','字体','轮廓']:
  tab(d,name);captured[name]=rows(d)
  if name in ['格式','数值输入','安全','字体'] and values(captured[name])!=values(template['tabs'][name]):raise ValueError('Copied numeric changed template '+name)
 actual={r['name']:r['value'] for r in captured['轮廓'] if r['type']=='Edit' and r['name'] in shape}
 if actual!=shape:raise ValueError('Copied numeric geometry mismatch')
 if [r['value'] for r in captured['一般属性'] if r['type']=='Edit' and r['name']=='Static']!=[address]:raise ValueError('Saved numeric address mismatch')
 cancel=[c for c in typed_children(d,'Button') if c.window_text()=='取消']
 msg(cancel[0].handle,245)
 report={'page':200,'source':source['object'],'target':name,'template':'NE_0','general':captured['一般属性'],'tabs':captured,'geometry':captured['轮廓'],'saved_requested':True,'saved_reopened_verified':True,'picture_color_method':'inherited verified NE_0','source_picture_colors':base['colors'],'only_address_and_position_changed':True,'runtime_verified':False}
 path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 phase.write_text(json.dumps({'pasted':True,'saved':True,'template':'NE_0'}),encoding='utf8')
