"""Synchronize exact cached appearance RGB on existing 103-page objects."""
import json,re
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_extract import ROOT,rows
from eb_object_ui import target,properties,save,dialog
from eb_native_form import tab,confirm
from eb_color_picker import probe,set_rgb
from eb_layout import geometry
def run(handle,q):
    key=q['sync_existing_appearance']
    if not re.fullmatch(r'(?:FK_[0-6]|TS_0|DC_0)',key):raise ValueError('Reviewed existing appearance only')
    s=json.loads((ROOT/f'evidence/source-object-properties/103_{key}.json').read_text(encoding='utf8'))
    expected=s['appearance_colors'];root,w=target(handle,103)
    if q.get('resume'):
        from pywinauto import Desktop
        from eb_color_picker import close
        colors=[c for c in Desktop(backend='win32').windows(process=root.process_id()) if c.window_text()=='Colors' and c.is_visible()]
        if len(colors)>1:raise ValueError('One pending color picker required')
        if colors:close(Desktop(backend='uia').window(handle=colors[0].handle).wrapper_object(),'Cancel')
        d=dialog(root.process_id(),s['dialog_title'])
    else:d,_=properties(root,w,key,s['dialog_title'])
    tab(d,'轮廓')
    actual={r['name']:r['value'] for r in rows(d) if r['type']=='Edit' and r['name'] in geometry(s)}
    if actual!=geometry(s):raise ValueError('Existing appearance object geometry identity mismatch')
    changes=[]
    for name,states in expected.items():
        tab(d,name)
        controls=[c for c in d.descendants(control_type='ComboBox') if c.window_text()=='状态 :' and c.is_visible() and c.element_info.class_name=='ComboBox']
        if len(controls)>1:raise ValueError('One appearance state control required')
        native=ComboBoxWrapper(controls[0].handle) if controls else None
        for state,rgb in states.items():
            if state!='common':
                if native is None:raise ValueError('Source states require target state selector')
                native.select(state)
            before=probe(d,'颜色 :')
            if before!=rgb:set_rgb(d,rgb,'颜色 :')
            after=probe(d,'颜色 :') if before!=rgb else before
            if after!=rgb:raise ValueError('Appearance RGB readback mismatch')
            changes.append({'tab':name,'state':state,'before':before,'after':after,'changed':before!=rgb})
    confirm(d);save(root)
    (ROOT/f'evidence/target-103-{key}-appearance.json').write_text(json.dumps({'object':key,'changes':changes,'saved_requested':True,'project_reopened_verified':False},ensure_ascii=False,indent=2),encoding='utf8')

def rectangle(handle,q):
    s=json.loads((ROOT/'evidence/source-object-properties/103_DW_0.json').read_text(encoding='utf8'))
    root,w=target(handle,103);d,_=properties(root,w,'DW_0','矩形元件属性');tab(d,'轮廓')
    actual={r['name']:r['value'] for r in rows(d) if r['type']=='Edit' and r['name'] in geometry(s)}
    if actual!=geometry(s):raise ValueError('Existing rectangle identity mismatch')
    tab(d,' 形状');changes=[]
    for i,name in enumerate(('fill','border')):
        rgb=s['rectangle_colors'][name];before=probe(d,'颜色 :',i)
        if before!=rgb:set_rgb(d,rgb,'颜色 :',i)
        after=probe(d,'颜色 :',i) if before!=rgb else before
        if after!=rgb:raise ValueError('Rectangle color readback mismatch')
        changes.append({'field':name,'before':before,'after':after,'changed':before!=rgb})
    confirm(d);save(root)
    (ROOT/'evidence/target-103-DW0-colors.json').write_text(json.dumps({'changes':changes,'saved_requested':True,'project_reopened_verified':False},ensure_ascii=False,indent=2),encoding='utf8')
