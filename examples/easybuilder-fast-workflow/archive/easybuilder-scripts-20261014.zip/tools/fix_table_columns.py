"""Restore the original table COLUMN boundaries on pages 210/212/218 (rows stay evenly divided).

The original tables divide rows evenly but use custom column widths: a wide label column plus two
equal value columns. This controller derives those boundaries from the ORIGINAL numeric boxes
(midpoint between adjacent value columns), maps them into the reviewed 890x469 frame, and asks the
worker to drag only the interior vertical lines. Nothing else is touched.

Usage:  python tools/fix_table_columns.py
"""
import json,os,re,sys,time,traceback,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'tools'))
from eb_rebuild_page import call

TABLES=[(210,'TB_0'),(210,'TB_1'),(212,'TB_0'),(218,'TB_0')]
TGT_TITLE='组装机_MT8106iP.emtp'
SRC_TITLE='组装机2台15工位取消.cmtp'
REVIEWED=(1848,1281)
BACKUP=ROOT/'backup/tools-old-name-20261011_220309'
DIR=ROOT/'evidence/scale-890x469'
WF=ROOT/'evidence/table-column-fix-workflow.json'
NAMES=('X :',' Y :',' 宽度 :','高度 :')

def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
def load(p):return json.loads(p.read_text(encoding='utf8'))

def patch_dispatch():
    f=ROOT/'tools/eb_uia.py'
    old=" if 'extract' in batch_request:"
    new=(" if batch_request.get('table_columns'):\n"
         "  from eb_table_columns import run\n"
         "  run(int(sys.argv[1]),batch_request)\n"
         "  sys.exit(0)\n"
         +old)
    b=f.read_bytes();bom=b[:3]==b'\xef\xbb\xbf'
    t=b.decode('utf-8-sig') if bom else b.decode('utf-8')
    if 'table_columns' in t:return 'already'
    n=t.count(old)
    if n!=1:raise ValueError('dispatch anchor count=%d; no edit'%n)
    BACKUP.mkdir(parents=True,exist_ok=True)
    dst=BACKUP/'eb_uia.py.before-table-columns-dispatch.bak'
    if not dst.exists():shutil.copy2(f,dst)
    o=t.replace(old,new)
    data=(b'\xef\xbb\xbf'+o.encode('utf-8')) if bom else o.encode('utf-8')
    tmp=f.with_suffix('.py.tmp');tmp.write_bytes(data);tmp.replace(f)
    if f.read_bytes()!=data:raise ValueError('dispatch patch readback mismatch')
    return 'edited'

def geometry(path):
    j=load(path);g={}
    for r in j.get('tabs',{}).get('轮廓',[]):
        if r.get('type')=='Edit' and r.get('name') in NAMES and 'value' in r:g[r['name']]=int(r['value'])
    return g

def derive(page,key,rec):
    before,after=rec['before'],rec['after']
    bx,bw=int(before['X :']),int(before[' 宽度 :'])
    ax,aw=int(after['X :']),int(after[' 宽度 :'])
    centers=[]
    for f in (ROOT/'evidence/source-object-properties').glob('%d_NE_*.json'%page):
        g=geometry(f)
        if not g or 'X :' not in g:continue
        cx=g['X :']+g.get(' 宽度 :',0)/2
        if bx<=cx<=bx+bw:centers.append((round(cx,1),f.stem))
    centers=sorted(set(c[0] for c in centers))
    if len(centers)<2:return None,{'reason':'fewer than two value columns observed','centers':centers}
    interior=[(centers[i]+centers[i+1])/2 for i in range(len(centers)-1)]
    mapx=lambda v:ax+(v-bx)*(aw/bw)
    wanted=[ax]+[round(mapx(v),1) for v in interior]+[ax+aw]
    return wanted,{'value_column_centers_original':centers,'interior_boundaries_original':interior,
                   'mapped_to_after_frame':wanted,'before':before,'after':after}

def windows():
    call('snapshot')
    for _ in range(30):
        try:return [w for w in load(ROOT/'evidence/windows.json') if w.get('title')]
        except Exception:time.sleep(.1)
    raise ValueError('windows.json unreadable')

def target_handle():
    ws=windows()
    m=[w for w in ws if TGT_TITLE in w['title'] and w.get('class')=='EasyBuilderPro']
    if len(m)!=1:raise ValueError('Unique target window required')
    t=m[0]
    if (t['rect'][2]-t['rect'][0],t['rect'][3]-t['rect'][1])!=REVIEWED:
        call('uia',t['handle'],json.dumps({'restore_target_window':True,'reviewed_size':True}))
        m=[w for w in windows() if TGT_TITLE in w['title'] and w.get('class')=='EasyBuilderPro']
        t=m[0]
    return t['handle']

def main():
    lock=ROOT/'tools/batch.lock'
    with lock.open('x',encoding='utf8') as fh:fh.write(json.dumps({'pid':os.getpid(),'task':'table-column-fix'},ensure_ascii=False))
    out=None
    try:
        out={'date':time.strftime('%Y-%m-%dT%H:%M:%S'),'dispatch':patch_dispatch(),'tables':{},'finished':False,
             'scope':'only the interior vertical lines of the 4 tables; rows and every other object untouched'}
        write(WF,out)
        print(json.dumps({'dispatch':out['dispatch']},ensure_ascii=False),flush=True)
        h=target_handle()
        def clear_leftovers(tag):
            for w in windows():
                if w.get('title') and 'EasyBuilder Pro V' not in w['title']:
                    print(json.dumps({'clearing_leftover':{tag:w.get('title')}},ensure_ascii=False),flush=True)
                    try:call('keys',w['handle'],'{ESC}')
                    except Exception as e:print(json.dumps({'clear_error':str(e)[-140:]},ensure_ascii=False),flush=True)
                    time.sleep(1)
        for page,key in TABLES:
            name='%d_%s'%(page,key);rec={'page':page,'key':key}
            try:
                rp=DIR/('%d_%s.json'%(page,key))
                if not rp.exists():raise ValueError('No scale record for %s'%name)
                srec=load(rp)
                wanted,info=derive(page,key,srec)
                rec['derivation']=info
                if wanted is None:
                    rec['result']='skipped: '+info.get('reason','')
                    out['tables'][name]=rec;write(WF,out)
                    print(json.dumps({'skip':{name:rec['result']},'centers':info.get('centers')},ensure_ascii=False),flush=True)
                    continue
                rec['wanted']=wanted
                print(json.dumps({'derived':{name:info}},ensure_ascii=False),flush=True)
                clear_leftovers(name)
                call('uia',h,json.dumps({'open_target_page':page}))
                call('uia',h,json.dumps({'table_columns':{'page':page,'key':key,'bounds':srec['after'],'wanted':wanted}}))
                ev=ROOT/'evidence'/('table-columns-%d-%s.json'%(page,key))
                e=load(ev) if ev.exists() else {}
                rec.update({'live_before':e.get('live_before'),'live_after':e.get('live_after'),'changes':e.get('changes'),
                            'spacing_after':e.get('spacing_after'),'counts_after':e.get('counts_after'),'verified':e.get('verified'),
                            'result':'columns restored and verified' if e.get('verified') else 'not verified'})
                out['tables'][name]=rec;write(WF,out)
                print(json.dumps({'applied':{name:{'verified':rec['verified'],'changes':len(e.get('changes') or []),'spacing_after':rec['spacing_after']}}},ensure_ascii=False),flush=True)
            except Exception as e:
                rec['error']=str(e)[-400:]
                out['tables'][name]=rec;write(WF,out)
                print(json.dumps({'table_error':{name:rec['error']}},ensure_ascii=False),flush=True)
        for w in windows():
            if w.get('title') and 'EasyBuilder Pro V' not in w['title']:
                try:call('keys',w['handle'],'{ESC}')
                except Exception:pass
                time.sleep(1)
        print(json.dumps({'stage':'compile'},ensure_ascii=False),flush=True)
        call('uia',h,json.dumps({'compile_target':True}))
        out['compile']=load(ROOT/'evidence/latest-project-compile.json')
        out['finished']=bool(out['compile'].get('ok'))
        write(WF,out)
        print(json.dumps({'finished':out['finished'],'messages':out['compile']['messages'],
                          'project_bytes':out['compile']['project_bytes'],'exob_bytes':out['compile']['exob_bytes']},ensure_ascii=False),flush=True)
    except Exception as e:
        out=(out or {});out['error']=traceback.format_exc();write(WF,out)
        print(json.dumps({'error':str(e)[:600]},ensure_ascii=False),flush=True)
        raise
    finally:
        lock.unlink(missing_ok=True)

if __name__=='__main__':main()
