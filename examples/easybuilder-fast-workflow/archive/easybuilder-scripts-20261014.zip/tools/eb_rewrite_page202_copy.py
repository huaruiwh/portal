"""Rewrite only copied page202 bindings/text; preserve the user-approved page200 layout."""
import json
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save
from eb_native_form import tab,fields,confirm,commit_text
from eb_extract import rows
from eb_page26_shapes import cancel

def run(handle,q):
 key=q['rewrite_page202_copy'];kind,num=key.split('_');n=int(num)
 if kind not in ('TS','BL','NE','SW','TX'):raise ValueError('Unreviewed copied type')
 mapped=json.loads((ROOT/'evidence/page202-semantic-copy-mapping.json').read_text(encoding='utf8'))['mapping'][key]
 path=ROOT/f'evidence/target-202-{key}-copy-rewritten.json'
 if path.exists() and not q.get('semantic_repair'):raise ValueError('Verified copied object already rewritten')
 source=json.loads((ROOT/f'evidence/source-object-properties/202_{key}.json').read_text(encoding='utf8'));base=json.loads((ROOT/f'evidence/source-object-properties/200_{key}.json').read_text(encoding='utf8'))
 sig=lambda rs:[(x['type'],x['name'],x['value']) for x in rs if 'value' in x]
 if '安全' in source['tabs'] and sig(source['tabs']['安全'])!=sig(base['tabs']['安全']):raise ValueError('Copied safety differs from original202; separate adaptation required')
 title={'TS':'位状态切换开关/位状态指示灯的属性','BL':'位状态指示灯/位状态切换开关的属性','SW':'多状态设置的属性','NE':'数值的属性','TX':'文字/批注的属性'}[kind]
 root,w=target(handle,202);d,_=properties(root,w,mapped,title);tab(d,'轮廓');geometry_before=rows(d);changed=False
 if kind=='TX':
  tab(d,'文字/批注');before=rows(d);want=next(x['value'] for x in source['tabs']['文字/批注'] if x['type']=='Edit' and x.get('class')=='RichEdit20W')
  current=next(x for x in before if x['type']=='Edit' and x.get('class')=='RichEdit20W')
  if current['value']!=want:commit_text(d,current['name'],want);changed=True
  expected={'caption':want}
 else:
  ordinary=lambda rs:[x for x in sig(rs) if not(x[0]=='Edit' and x[1]=='Static')]
  if ordinary(source['tabs']['一般属性'])!=ordinary(base['tabs']['一般属性']):raise ValueError('Copied device/mode differs')
  tab(d,'一般属性');before=rows(d);addresses=[r for r in source['tabs']['一般属性'] if r['type']=='Edit' and r['name']=='Static'];current=[r['value'] for r in before if r['type']=='Edit' and r['name']=='Static'];want=[r['value'] for r in addresses]
  if len(current)!=len(want):raise ValueError('Copied address field count differs')
  if current!=want:fields(d,addresses);changed=True
  expected={'addresses':want}
 if kind in ('TS','BL'):
  from pywinauto.controls.win32_controls import ComboBoxWrapper
  tab(d,'标签');choices=[c for c in d.descendants(control_type='ComboBox') if c.is_visible() and c.window_text()=='状态 :']
  if len(choices)!=1:raise ValueError('Unique cloned label state required')
  for state,rs in source['label_states'].items():
   ComboBoxWrapper(choices[0].handle).select(state);rsnow=rows(d);want=next(r['value'] for r in rs if r['type']=='Edit' and r['name']=='');current=next(r for r in rsnow if r['type']=='Edit' and r['name']=='')
   if current['value']!=want:commit_text(d,'',want);changed=True
 tab(d,'轮廓');geometry_before=rows(d)
 if changed:
  confirm(d);save(root);d,_=properties(root,w,mapped,title)
 if kind=='TX':
  tab(d,'文字/批注');after=rows(d)
  if not any(x.get('class')=='RichEdit20W' and x.get('value')==expected['caption'] for x in after):raise ValueError('Saved copied caption differs')
 else:
  tab(d,'一般属性');after=rows(d)
  if [x['value'] for x in after if x['type']=='Edit' and x['name']=='Static']!=expected['addresses']:raise ValueError('Saved copied addresses differ')
 tab(d,'轮廓');geometry_after=rows(d)
 if sig(geometry_before)!=sig(geometry_after):raise ValueError('Copied address/text change affected layout')
 safety=None
 if kind in ('TS','BL','SW'):
  tab(d,'安全');safety=rows(d)
  # Saved page200 safety was already verified; source202 equality checked above.
 cancel(d)
 report={'source':key,'target':mapped,'page':202,'template':200,'expected':expected,'changed':changed,'saved_reopened_verified':True,'geometry_unchanged':True,'geometry':geometry_after,'safety_reopened':safety,'source_safety_equal_to_template':True,'appearance_inherited_from_user_approved_200':True,'runtime_verified':False}
 path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')


