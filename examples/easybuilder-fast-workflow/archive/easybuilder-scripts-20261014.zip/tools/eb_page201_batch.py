"""Bounded two-button trial: exact verified template, per-item checkpoints, batch audits."""
import json,time
from eb_rebuild_page import ROOT
from eb_copy_200_style_object import read_audit
from eb_page201_buttons import run as build
from eb_page208 import write

def run(handle,q):
    if q.get('discard_unverified_gap_copy'):
        from eb_object_ui import target,properties,save
        from eb_page26_shapes import cancel
        from pywinauto.keyboard import send_keys
        p=ROOT/'evidence/target-201-TS14-copy-phase.json';v=json.loads(p.read_text(encoding='utf8'))
        if v['stage']!='pasted' or any((ROOT/f'evidence/target-201-TS{n}-built.json').exists()for n in (13,14)):raise ValueError('Only unverified gap copy allowed')
        a=read_audit(handle,201)
        if a['target_count']!=30 or 'TS_13'in a['missing']or 'TS_14'not in a['missing']:raise ValueError('Gap copy directory changed')
        root,w=target(handle,201);d,_=properties(root,w,'TS_13','位状态切换开关/位状态指示灯的属性');cancel(d);root.set_focus();send_keys('{DELETE}',pause=.01)
        time.sleep(.2);a=read_audit(handle,201)
        if a['target_count']!=29 or 'TS_13'not in a['missing']or a['unexpected']or a['address_name_mismatch']:raise ValueError('Gap cleanup failed')
        save(root);v.update(stage='removed-unverified-gap-copy',actual_key='TS_13');write(ROOT/'evidence/target-201-TS14-gap-history.json',v);p.unlink();return
    ids=q['page201_batch']
    if ids not in ([7,8],[9,10],[11,12],[13,14]):raise ValueError('Only reviewed bounded batches allowed')
    templates={7:'TS_1',8:'TS_1',9:'TS_2',10:'TS_3',11:'TS_5',12:'TS_5',14:'TS_5',13:'TS_6'}
    report=ROOT/('evidence/page201-two-button-batch.json'if ids==[7,8]else 'evidence/page201-batch-'+ '-'.join(map(str,ids))+'.json')
    started=time.perf_counter()
    before=read_audit(handle,201)
    permitted=[]
    for n in ids:
        p=ROOT/f'evidence/target-201-TS{n}-copy-phase.json'
        if p.exists() and json.loads(p.read_text(encoding='utf8')).get('stage')in ('pasted','saved-unverified'):permitted.append(f'TS_{n}')
    if before['unexpected'] or any(k not in permitted for k in before['address_name_mismatch']):raise ValueError('Batch initial directory mismatch')
    results=[]
    try:
        for n in ids:
            t=time.perf_counter()
            build(handle,{'page201_button':n,'batch_template':templates[n],'_batch_audit':before})
            results.append({'key':f'TS_{n}','seconds':time.perf_counter()-t})
    finally:
        write(report,{'items':results,'seconds':time.perf_counter()-started,'finished':False})
    after=read_audit(handle,201)
    added=sum(f'TS_{n}'in before['missing']for n in ids)
    if after['target_count']!=before['target_count']+added or any(f'TS_{n}'in after['missing']for n in ids) or after['unexpected'] or after['address_name_mismatch']:raise ValueError('Batch final directory mismatch')
    write(report,{'items':results,'seconds':time.perf_counter()-started,'finished':True,'before_count':before['target_count'],'after_count':after['target_count'],'remaining':len(after['missing'])})
