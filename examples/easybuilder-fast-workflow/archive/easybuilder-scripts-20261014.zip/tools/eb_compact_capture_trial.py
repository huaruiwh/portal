"""Read-only comparison: one UIA enumeration per requested type, native value reads."""
import json,time
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties
from eb_native_form import tab
from eb_page26_shapes import cancel
from eb_live_fields import capture
from eb_native_messages import text,combo_text,msg

def compact(d,wants):
    wants=list(dict.fromkeys(wants));found={}
    for typ in dict.fromkeys(t for t,n in wants):
        for c in d.descendants(control_type=typ,cache_enable=True):
            key=(typ,c.element_info.name)
            if key not in wants or not c.is_visible():continue
            h=c.element_info.handle;cls=c.element_info.class_name
            native=bool(h)and cls in {'Edit','RichEdit20W','RichEdit20A','ComboBox','Button'}
            if native:
                v=text(h).rstrip('\r\n')if typ=='Edit'else combo_text(h)if typ=='ComboBox'else msg(h,240)
            else:
                v=c.get_value().rstrip('\r\n')if typ=='Edit'else c.selected_text()if typ=='ComboBox'else c.get_toggle_state()if typ=='CheckBox'else int(c.is_selected())
            found.setdefault(key,[]).append({'type':typ,'name':key[1],'value':v})
    if any(k not in found for k in wants):raise ValueError('Compact capture missing required field')
    return [row for k in wants for row in found[k]]

def run(handle,q):
    root,w=target(handle,201);s=json.loads((ROOT/'evidence/source-object-properties/201_TS_8.json').read_text(encoding='utf8'))
    d,_=properties(root,w,'TS_8','位状态切换开关/位状态指示灯的属性');result=[]
    try:
        for name in ('一般属性','标签','轮廓'):
            tab(d,name)
            wants=[(r['type'],r['name'])for r in s['tabs'][name]if'value'in r]
            if name=='标签':wants=[('Edit',''),('ComboBox','字体 :'),('ComboBox','尺寸 :')]
            samples=[]
            for i in range(3):
                t=time.perf_counter();old=capture(d,wants);old_seconds=time.perf_counter()-t
                t=time.perf_counter();new=compact(d,wants);new_seconds=time.perf_counter()-t
                if new!=old:raise ValueError('Read-only capture differs on '+name)
                samples.append({'old_seconds':old_seconds,'compact_seconds':new_seconds})
            result.append({'tab':name,'equal':True,'samples':samples})
    finally:cancel(d)
    (ROOT/'evidence/compact-capture-trial.json').write_text(json.dumps({'changed':False,'saved':False,'results':result},ensure_ascii=False,indent=2),encoding='utf8')
