"""Serial cached page11 settings; one worker, per-object save and duplicate guard."""
import json
from eb_rebuild_page import ROOT,call
def run():
 lock=ROOT/'tools/batch.lock'
 with lock.open('x'):pass
 r={'ok':False,'completed':[]};p=ROOT/'evidence/base-settings-workflow.json'
 def persist():p.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
 try:
  call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
  h=next(w['handle'] for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title'])
  call('uia',h,json.dumps({'open_target_page':11}))
  for n in range(12):
   r['stage']={'page':11,'kind':'SW','n':n};persist()
   report=ROOT/f'evidence/target-011-SW{n}-built.json'
   if not report.exists():call('uia',h,json.dumps({'page':11,'build_sw':n}))
   r['completed'].append(n);persist();print('SW',n,'saved',flush=True)
  try:call('uia',h,json.dumps({'target_page_audit':11}))
  except RuntimeError as e:
   if 'Target object audit incomplete' not in str(e):raise
  r['ok']=True;persist()
 except Exception as e:r['error']=str(e);persist();raise
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':run()
