"""Recreate static S7 main-page bit objects, including separate read/write addresses."""
import json,time
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_extract import ROOT,rows
from eb_object_ui import target,dialog,placed_properties,save
from eb_native_form import tab,fields,confirm
from eb_layout import geometry


def run(handle,q):
    if q.get('repair_source_indicator'):
        from eb_repair_page16_indicator_style import run as repair
        return repair(handle,q)
    page=int(q['page']);kind=q['bit_kind'];n=int(q['build_bit_general'])
    from eb_flow_model import counts as flow_counts
    counts={16:{'TS':18,'BL':33}} if page==16 else ({103:{'TS':1}} if page==103 else {page:flow_counts(page)})
    if kind not in counts[page] or n not in range(counts[page][kind]):raise ValueError('Unreviewed bit object')
    source=json.loads((ROOT/'evidence'/'source-object-properties'/f'{page:03d}_{kind}_{n}.json').read_text(encoding='utf8'))
    source_vector=(page==16 and kind=='BL' and n>=5) or (page in (200,202) and kind=='BL')
    source_picture=page in (16,200,202) and kind=='TS'
    if source_picture and page==16 and n>=11:
        audit=json.loads((ROOT/'evidence/target-page16-audit.json').read_text(encoding='utf8'))
        if audit['source_count']!=101 or f'TS_{n}' not in audit['missing']:raise ValueError('Fresh missing switch proof required')
        if (ROOT/f'evidence/target-016-TS{n}-built.json').exists():raise ValueError('Saved switch exists; no duplicate creation')
    if source_vector and page==16:
        audit=json.loads((ROOT/'evidence/target-page16-audit.json').read_text(encoding='utf8'))
        if audit['source_count']!=101 or f'BL_{n}' not in audit['missing']:raise ValueError('Fresh complete-source missing indicator proof required')
        if (ROOT/f'evidence/target-016-BL{n}-built.json').exists():raise ValueError('Saved indicator exists; no duplicate creation')
        colors=source.get('state_colors',{})
        required_tabs=['图片']+(['标签'] if any(r['name']=='使用文字标签' and r.get('value')==1 for r in source['tabs']['标签']) else [])
        if any(set(colors.get(t,{}))!={'0','1'} for t in required_tabs):raise ValueError('Exact two-state source colors required')
    if page in (200,202) and kind=='BL' and source.get('vector_identity',{}).get('family')!='System Frame':raise ValueError('Page200 original lamp vector family requires review')
    if page in (200,202) and kind=='BL' and source['vector_identity']['index']!='0':raise ValueError('Page200 original lamp vector index requires review')
    general=source['tabs']['一般属性']
    if kind=='SW':
        expected={('Edit','设置常数 :'):'0',('ComboBox','设备 :'):'Local HMI',('Edit','Static'):('1' if page in (200,202) else '3'),('ComboBox',' Down'):'LW'}
        if any([r.get('value') for r in general if (r['type'],r['name'])==key]!=[value] for key,value in expected.items()):raise ValueError('Only reviewed LW3 close action supported')
    for row in general:
        if row['name']=='触发宏指令' and row.get('value')!=0:raise ValueError('Bit macro action requires review')
    for row in source['tabs']['安全']:
        if page not in (200,202) and row['name']=='使用寄存器状态/数值' and row.get('value')!=0:raise ValueError('Bit visibility requires review')
    root,w=target(handle,page)
    timing_start=time.monotonic();timings=[]
    def timing(stage):
        if source_vector:
            timings.append({'stage':stage,'elapsed_seconds':round(time.monotonic()-timing_start,3)})
            (ROOT/f'evidence/page16-BL{n}-timing.json').write_text(json.dumps(timings,ensure_ascii=False,indent=2),encoding='utf8')
    timing('begin')
    rgb_checks=[]
    def ensure_rgb(d,label,rgb,scope,state):
        from eb_color_picker import set_rgb,probe
        result=set_rgb(d,rgb,label)
        actual=result['after'] if result.get('already_equal') else probe(d,label)
        if actual!=rgb:raise ValueError('Indicator '+scope+' RGB mismatch')
        rgb_checks.append({'scope':scope,'state':state,'label':label,'requested':rgb,'native_readback':actual,'already_equal':bool(result.get('already_equal'))})
    if q.get('repair_source_appearance'):
        if not source_picture or n not in range(11):raise ValueError('Reviewed existing page16 switches only')
        from eb_object_ui import properties
        d,name=properties(root,w,f'TS_{n}','位状态切换开关/位状态指示灯的属性')
        tab(d,'一般属性');created=rows(d)
        expected=[r['value'] for r in general if r['type']=='Edit' and r['name']=='Static']
        if [r['value'] for r in created if r['type']=='Edit' and r['name']=='Static']!=expected:raise ValueError('Existing switch read/write address mismatch')
        tab(d,'图片');fields(d,[{'type':'CheckBox','name':'使用图片','value':1},{'type':'CheckBox','name':'调整对象尺寸为图片原尺寸','value':0},{'type':'CheckBox','name':'使用向量图','value':0}])
        family=next(r['name'] for r in source['tabs']['图片'] if r['type']=='Text' and r['name'] in ('Button - Standard','Selector_3_Position_Metal_Silver-Red'))
        if not any(r['type']=='Text' and r['name']==family for r in rows(d)):
            from eb_picture_family import choose
            choose(d,root.process_id(),family)
        pictures=rows(d);tab(d,'标签');labels={}
        use=next(r['value'] for r in source['tabs']['标签'] if r['type']=='CheckBox' and r['name']=='使用文字标签')
        fields(d,[{'type':'CheckBox','name':'使用文字标签','value':use}])
        if use:
            original=source.get('label_states') or {'0':source['tabs']['标签'],'1':source['tabs']['标签']}
            cs=[c for c in d.descendants(control_type='ComboBox') if c.element_info.name=='状态 :' and c.is_visible()]
            if len(cs)!=1:raise ValueError('One existing switch label selector required')
            for value in ('0','1'):
                ComboBoxWrapper(cs[0].handle).select(value);actual=rows(d)
                caption=next(r['value'] for r in original[value] if r['type']=='Edit' and r['name']=='')
                if next(r['value'] for r in actual if r['type']=='Edit' and r['name']=='')!=caption:raise ValueError('Existing switch caption mismatch '+value)
                fields(d,original[value],skip=(('ComboBox','状态 :'),('Edit','')))
                for label,rgb in source['state_colors']['标签'][value].items():ensure_rgb(d,label,rgb,'标签',value)
                labels[value]=rows(d)
        else:labels['disabled']=rows(d)
        tab(d,'安全');from eb_press_safety import apply
        apply(d,source);fields(d,source['tabs']['安全'],skip=(('CheckBox','最短按压时间'),('ComboBox',' Down')));safety=rows(d)
        tab(d,'轮廓');fields(d,[{'type':'Edit','name':key,'value':value} for key,value in geometry(source).items()]);shape_readback=rows(d)
        confirm(d);save(root)
        report={'page':page,'source':source['object'],'target':name,'general':created,'labels':labels,'safety':safety,'picture':pictures,'geometry':shape_readback,'saved_requested':True,'custom_picture_review_pending':False,'label_color_review_pending':False,'native_rgb_checks':rgb_checks,'repaired_existing_object':True,'offline_simulation_verified':False}
        (ROOT/f'evidence/target-016-TS{n}-appearance-repaired.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
        (ROOT/f'evidence/target-016-TS{n}-built.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');return
    if q.get('finish_existing'):
        title='多状态设置的属性' if kind=='SW' else ('位状态切换开关/位状态指示灯的属性' if kind=='TS' else '位状态指示灯/位状态切换开关的属性')
        if q.get('open_existing'):
            from eb_object_ui import properties
            d,_=properties(root,w,f'{kind}_{n}',title)
        else:d=dialog(root.process_id(),title)
        tab(d,'一般属性');created=rows(d)
        expected=[r['value'] for r in general if r['type']=='Edit' and r['name']=='Static']
        if [r['value'] for r in created if r['type']=='Edit' and r['name']=='Static']!=expected:raise ValueError('Existing bit address mismatch')
        tab(d,'图片');pictures=rows(d)
        if not any(r['name']=='Button - Flat' for r in pictures):raise ValueError('Existing bit picture mismatch')
        tab(d,'标签');labels={}
        states=[c for c in d.descendants(control_type='ComboBox',cache_enable=True) if c.element_info.name=='状态 :' and c.is_visible()]
        if source.get('label_states'):
            if len(states)!=1:raise ValueError('Existing label state selector required')
            for value in ('0','1'):
                ComboBoxWrapper(states[0].handle).select(value);labels[value]=rows(d)
                caption=next(r['value'] for r in source['label_states'][value] if r['type']=='Edit' and r['name']=='')
                if next(r['value'] for r in labels[value] if r['type']=='Edit' and r['name']=='')!=caption:raise ValueError('Existing caption mismatch '+value)
        tab(d,'安全');safety=rows(d)
        for r in source['tabs']['安全']:
            if r['type'] in ('CheckBox','RadioButton') and 'value' in r:
                values=[v.get('value') for v in safety if (v['type'],v['name'])==(r['type'],r['name'])]
                if values!=[r['value']]:raise ValueError('Existing safety mismatch '+r['name'])
        tab(d,'轮廓');shape=geometry(source)
        fields(d,[{'type':'Edit','name':key,'value':value} for key,value in shape.items()]);shape_readback=rows(d)
        confirm(d);save(root)
        report={'page':page,'source':source['object'],'target':f'{kind}_{n}','general':created,'labels':labels,'safety':safety,'picture':pictures,'geometry':shape_readback,'saved_requested':True,'custom_picture_review_pending':True,'label_color_review_pending':True,'offline_simulation_verified':False,'recovered_existing_object':True}
        (ROOT/'evidence'/f'target-{page:03d}-{kind}{n}-built.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
        from eb_saved_progress import record
        record(page,f'{kind}{n}')
        return
    creation_title='新增 多状态设置' if kind=='SW' else '新增 位状态指示灯/位状态切换开关'
    if not q.get('resume'):
        from eb_ribbon import create
        create(root,'SW' if kind=='SW' else 'BIT',creation_title)
    d=dialog(root.process_id(),creation_title)
    if not q.get('resume_labels'):
        tab(d,'一般属性')
        fields(d,[row for row in general if row['name'] not in ('设备 :',' Down','Static')])
        fields(d,[row for row in general if row['type']=='ComboBox' and row['name']=='设备 :'])
        fields(d,[row for row in general if row['type']=='ComboBox' and row['name']==' Down'])
        fields(d,[row for row in general if row['type']=='Edit' and row['name']=='Static'])
    timing('general_done')
    tab(d,'图片')
    if source_vector:
        fields(d,[r for r in source['tabs']['图片'] if r['type']=='CheckBox'])
        from eb_frame_vector import choose
        choose(d,root.process_id())
        tab(d,'图片')
        states=[c for c in d.descendants(control_type='ComboBox') if c.element_info.name=='状态 :' and c.is_visible()]
        if len(states)!=1:raise ValueError('One indicator picture state required: '+str([(c.element_info.name,c.is_visible(),c.element_info.handle) for c in d.descendants(control_type='ComboBox')]))
        from eb_color_picker import set_rgb,probe
        for value in ('0','1'):
            ComboBoxWrapper(states[0].handle).select(value)
            for label,rgb in source['state_colors']['图片'][value].items():
                ensure_rgb(d,label,rgb,'图片',value)
    else:
        if not q.get('resume_labels'):fields(d,[{'type':'CheckBox','name':'使用图片','value':1},{'type':'CheckBox','name':'调整对象尺寸为图片原尺寸','value':0},{'type':'CheckBox','name':'使用向量图','value':0}])
        if source_picture:
            family=next(r['name'] for r in source['tabs']['图片'] if r['type']=='Text' and r['name'] in ('Button - Standard','Selector_3_Position_Metal_Silver-Red'))
            if not any(r['type']=='Text' and r['name']==family for r in rows(d)):
                from eb_picture_family import choose
                choose(d,root.process_id(),family)
        elif not any(row['type']=='Text' and row['name']=='Button - Flat' for row in rows(d)):
            from eb_flat_picture import choose
            choose(d,root.process_id())
    pictures=rows(d);timing('picture_done')
    tab(d,'标签')
    use=next(row['value'] for row in source['tabs']['标签'] if row['type']=='CheckBox' and row['name']=='使用文字标签')
    fields(d,[{'type':'CheckBox','name':'使用文字标签','value':use}]);labels={}
    if use:
        original=source.get('label_states') or {'0':source['tabs']['标签'],'1':source['tabs']['标签']}
        state=[c for c in d.descendants(control_type='ComboBox',cache_enable=True) if c.element_info.name=='状态 :' and c.is_visible()]
        if len(state)!=1:raise ValueError('Two target bit label states required')
        texts=[]
        for value in ('0','1'):
            ComboBoxWrapper(state[0].element_info.handle).select(value)
            fields(d,original[value],skip=(('ComboBox','状态 :'),('Edit','')))
            texts.append(next(row['value'] for row in original[value] if row['type']=='Edit' and row['name']==''))
        from eb_label_commit import commit
        commit(d,texts)
        for value in ('0','1'):
            ComboBoxWrapper(state[0].element_info.handle).select(value)
            if source_vector or source_picture:
                from eb_color_picker import set_rgb,probe
                for label,rgb in source['state_colors']['标签'][value].items():
                    ensure_rgb(d,label,rgb,'标签',value)
            labels[value]=rows(d)
    else:labels['disabled']=rows(d)
    timing('labels_done')
    tab(d,'安全')
    from eb_press_safety import apply
    if page in (200,202) and kind=='TS' and any(r['name']=='使用寄存器状态/数值' and r.get('value')==1 for r in source['tabs']['安全']):
        from eb_page200_safety import apply as apply200
        apply200(d,source)
    elif page in (200,202):
        fields(d,source['tabs']['安全'])
    else:
        apply(d,source)
        fields(d,source['tabs']['安全'],skip=(('CheckBox','最短按压时间'),('ComboBox',' Down')))
    safety=rows(d);confirm(d);timing('safety_done')
    title='多状态设置的属性' if kind=='SW' else ('位状态切换开关/位状态指示灯的属性' if kind=='TS' else '位状态指示灯/位状态切换开关的属性')
    d,name=placed_properties(root,w,f'{kind}_{n}',title);timing('placed_properties')
    tab(d,'一般属性');created=rows(d)
    expected=[row['value'] for row in general if row['type']=='Edit' and row['name']=='Static']
    if [row['value'] for row in created if row['type']=='Edit' and row['name']=='Static']!=expected:raise ValueError('Bit read/write address mismatch')
    tab(d,'轮廓');shape=geometry(source)
    fields(d,[{'type':'Edit','name':key,'value':value} for key,value in shape.items()]);shape_readback=rows(d)
    confirm(d);save(root);timing('saved')
    report={'page':page,'source':source['object'],'target':name,'general':created,'labels':labels,'safety':safety,'picture':pictures,'geometry':shape_readback,
            'saved_requested':True,'custom_picture_review_pending':not(source_vector or source_picture),'label_color_review_pending':not(source_vector or source_picture),'source_state_colors':source.get('state_colors'),'native_rgb_checks':rgb_checks,'vector_shape_identity_review_pending':source_vector,'offline_simulation_verified':False}
    (ROOT/'evidence'/f'target-{page:03d}-{kind}{n}-built.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    from eb_saved_progress import record
    record(page,f'{kind}{n}')
