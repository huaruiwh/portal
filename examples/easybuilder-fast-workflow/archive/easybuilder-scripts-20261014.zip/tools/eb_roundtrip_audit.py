"""Compare properties freshly read after reopening the saved target project."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent

def run(page,objects,target_keys=None):
    checks=[]
    general_names={'Static','设置常数 :','设备 :','模式 :',' Down','启用','输出反向','设 ON','写入后','当按钮松开后发出指令'}
    geometry_names={'X :',' Y :',' 宽度 :','高度 :'}
    for key in objects:
        source=json.loads((ROOT/'evidence'/'source-object-properties'/f'{page:03d}_{key}.json').read_text(encoding='utf8'))
        target_key=(target_keys or {}).get(key,key)
        target=json.loads((ROOT/'evidence'/'target-object-properties'/f'{page:03d}_{target_key}.json').read_text(encoding='utf8'))
        if not target.get('read_only_target'):raise ValueError('Fresh explicit read-only target evidence required')
        def fields(data,tab,names):
            return [(c['type'],c['name'],c['value']) for c in data['tabs'][tab] if c['name'] in names and 'value' in c]
        def texts(data):
            return {state:[c['value'] for c in rows if c['type']=='Edit' and c['name']==''] for state,rows in data.get('label_states',{}).items()}
        source_text=texts(source);target_text=texts(target)
        disabled=any(c['type']=='CheckBox' and c['name']=='使用文字标签' and c.get('value')==0 for c in target['tabs']['标签'])
        text_ok=source_text==target_text or (disabled and all(not value for values in source_text.values() for value in values))
        from eb_layout import geometry as adapt_geometry
        expected_geometry=adapt_geometry(source)
        actual_geometry={c['name']:c['value'] for c in target['tabs']['轮廓'] if c['type']=='Edit' and c['name'] in geometry_names}
        safety_names={'最短按压时间',' Down'}
        safety_ok=page not in (11,17) or fields(source,'安全',safety_names)==fields(target,'安全',safety_names)
        if page in (11,48,49):
            safety_names={c['name'] for c in source['tabs']['安全'] if 'value' in c}
            safety_ok=fields(source,'安全',safety_names)==fields(target,'安全',safety_names)
        checks.append({'object':key,'target_object':target_key,'general_verified':fields(source,'一般属性',general_names)==fields(target,'一般属性',general_names),
                       'geometry_verified':expected_geometry==actual_geometry,
                       'safety_verified':safety_ok,
                       'text_verified':text_ok})
    report={'page':page,'checks':checks,'saved_reopened_verified':all(all(c[k] for k in ('general_verified','geometry_verified','text_verified','safety_verified')) for c in checks),'sample_only':True,'offline_simulation_verified':False}
    (ROOT/'evidence'/f'page-{page}-roundtrip-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    if not report['saved_reopened_verified']:raise ValueError('Reopened parameter mismatch; inspect roundtrip evidence')
    print(json.dumps({'page':page,'sample_objects':len(checks),'saved_reopened_verified':True},ensure_ascii=False))

if __name__=='__main__':run(int(sys.argv[1]),sys.argv[2:])
