"""Expand source single-caption PLC reset switch into both MT caption states."""
import json
from eb_extract import ROOT,rows
from eb_object_ui import target,object_item,dialog,save
from eb_native_form import fields,tab,confirm
from eb_label_commit import commit
from pywinauto.controls.win32_controls import ComboBoxWrapper
def run(handle,q):
    from eb_bit_switch_guard import validate
    page,n=int(q['page']),int(q['fix_ts_labels']);source=validate(page,n)
    root,w=target(handle,page);item=object_item(w,f'TS_{n}')
    if item.window_text()!=source['object']:raise ValueError('Existing switch tree address mismatch')
    root.set_focus();item.double_click_input(coords=(40,item.rectangle().height()//2))
    d=dialog(root.process_id(),'位状态切换开关/位状态指示灯的属性');tab(d,'标签')
    cs=[c for c in d.descendants(control_type='ComboBox') if c.window_text()=='状态 :' and c.is_visible()]
    if len(cs)!=1:raise ValueError('Expected MT caption state selector')
    state=ComboBoxWrapper(cs[0].element_info.handle)
    for value in ('0','1'):state.select(value);fields(d,source['tabs']['标签'])
    text=next(r['value'] for r in source['tabs']['标签'] if r['type']=='Edit' and r['name']=='')
    commit(d,[text,text]);labels={}
    for value in ('0','1'):state.select(value);labels[value]=rows(d)
    labels['single']=labels['0'];confirm(d);save(root)
    path=ROOT/'evidence'/f'target-{page:03d}-TS{n}-built.json'
    report=json.loads(path.read_text(encoding='utf8'));report['labels']=labels;report['source_single_caption_expanded']=True
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
