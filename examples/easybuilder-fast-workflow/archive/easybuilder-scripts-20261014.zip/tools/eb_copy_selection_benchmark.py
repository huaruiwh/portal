"""Compare native clipboard copies without pasting or changing the project."""
import json,time,hashlib
from pywinauto import mouse
from pywinauto.keyboard import send_keys
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,object_item
from eb_page26_shapes import cancel
from eb_copy_200_style_object import native_clipboard_data,restore_native_clipboard

def run(handle,q):
    root,w=target(handle,201)
    if not root.is_enabled():raise ValueError('Modal dialog present; no benchmark input sent')
    if q.get('inspect_copy_menu'):
        from pywinauto import Desktop
        item=object_item(w,'NE_0');box=item.rectangle()
        root.set_focus();mouse.click(button='right',coords=(box.left+min(40,box.width()-2),(box.top+box.bottom)//2));time.sleep(.2)
        result=[]
        try:
            observed=[{'handle':win.handle,'class':win.class_name(),'title':win.window_text(),'rect':str(win.rectangle())} for win in Desktop(backend='win32').windows(process=root.process_id()) if win.is_visible()]
            (ROOT/'evidence/copy-menu-windows.json').write_text(json.dumps(observed,ensure_ascii=False,indent=2),encoding='utf8')
            for win in Desktop(backend='win32').windows(process=root.process_id()):
                if win.is_visible() and (win.class_name().startswith('Qt5QWindowPopup') or win.class_name()=='#32768'):
                    popup=Desktop(backend='uia').window(handle=win.handle).wrapper_object()
                    result.extend({'name':c.element_info.name,'rect':str(c.rectangle())} for c in popup.descendants(control_type='MenuItem') if c.is_visible())
            (ROOT/'evidence/copy-context-menu.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
        finally:send_keys('{ESC}',pause=.01)
        return
    if q.get('benchmark_copy_cache'):
        from eb_native_copy import copy_control
        from eb_copy_200_style_object import native_clipboard_digest
        result={'page':201,'object':'NE_0','paste_sent':False,'changed':False,'measurements':[]}
        for name,reuse in [('fresh_copy',False),('same_template_cached_1',True),('same_template_cached_2',True)]:
            start=time.perf_counter();data=copy_control(root,w,'NE_0',reuse=reuse)
            result['measurements'].append({'route':name,'seconds':time.perf_counter()-start,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
        result['all_payloads_equal']=len({v['sha256'] for v in result['measurements']})==1
        if q.get('test_cache_invalidation'):
            import win32clipboard as c,ctypes
            prior_sequence=int(ctypes.windll.user32.GetClipboardSequenceNumber())
            c.OpenClipboard(root.handle)
            try:c.EmptyClipboard();c.SetClipboardText('copy-cache-invalidation-test',c.CF_UNICODETEXT)
            finally:c.CloseClipboard()
            changed_sequence=int(ctypes.windll.user32.GetClipboardSequenceNumber())
            start=time.perf_counter();data=copy_control(root,w,'NE_0',reuse=True)
            result['invalidation_test']={'clipboard_sequence_changed':changed_sequence!=prior_sequence,'seconds':time.perf_counter()-start,'native_bytes_after_recopy':len(data)}
        (ROOT/'evidence/copy-cache-benchmark.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8');return
    if q.get('inspect_ribbon'):
        from pywinauto import Desktop
        ribbons=[c for c in root.children() if c.class_name().startswith('EBRibbonBar:')]
        if len(ribbons)!=1:raise ValueError('Unique native ribbon required')
        if q.get('ribbon_project') or q.get('ribbon_tab'):
            cached=json.loads((ROOT/'evidence/copy-ribbon-local-ocr.json').read_text(encoding='utf-8-sig'))
            top=[v for v in cached['words'] if v['y']<30]
            first,second=('元','件') if q.get('ribbon_tab')=='objects' else ('工','程')
            found=[v for v in top if v['text']==first and (first=='元' or any(a['text']==second and 0<a['x']-v['x']<25 for a in top))]
            if len(found)!=1:raise ValueError('Unique observed project ribbon tab required')
            box=ribbons[0].rectangle();v=found[0]
            mouse.click(coords=(box.left+v['x']+v['width']//2,box.top+v['y']+v['height']//2));time.sleep(.2)
        uia=Desktop(backend='uia').window(handle=ribbons[0].handle).wrapper_object()
        result=[{'type':c.element_info.control_type,'name':c.element_info.name,'rect':str(c.rectangle())} for c in uia.descendants(cache_enable=True) if c.is_visible()]
        (ROOT/'evidence/copy-ribbon-probe.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
        from PIL import ImageGrab
        import subprocess
        box=ribbons[0].rectangle();img=ROOT/'evidence/copy-ribbon-local.png';out=ROOT/'evidence/copy-ribbon-local-ocr.json'
        ImageGrab.grab(bbox=(box.left,box.top,box.right,box.bottom)).save(img)
        code=(ROOT/'tools/Read-LocalImageText.ps1').read_text(encoding='utf8').replace('param([string]$ImagePath,[string]$OutputPath)',"$ImagePath='"+str(img).replace("'","''")+"';$OutputPath='"+str(out).replace("'","''")+"'")
        p=__import__('subprocess').run([r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe','-NoProfile','-Command',code],capture_output=True,text=True,timeout=30)
        if p.returncode:raise RuntimeError(p.stderr)
        return
    if q.get('save_cleaned_trial'):
        path=ROOT/'evidence/direct-copy-trial.json'
        result=json.loads(path.read_text(encoding='utf8'))
        if result.get('stage')!='trial-removed' or not result.get('copied_fields_equal'):raise ValueError('Trial cleanup not verified; save not sent')
        from eb_object_ui import save
        from eb_native_copy import copy_control
        begin=time.perf_counter();data=copy_control(root,w,'NE_0')
        result['integrated_copy_seconds']=time.perf_counter()-begin
        result['integrated_clipboard_bytes']=len(data)
        save(root);result['saved_after_cleanup']=True
        path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8');return
    if q.get('verify_trial'):
        return verify_trial(handle,root,w)
    if q.get('inspect_copy_focus'):
        result={'children':[{'handle':c.handle,'class':c.class_name(),'text':c.window_text(),'rect':str(c.rectangle())} for c in root.descendants() if c.is_visible() and c.class_name() not in ('Button','Edit','Static','ComboBox','ScrollBar')], 'copy_entries':[{'type':c.element_info.control_type,'name':c.element_info.name} for c in w.descendants(cache_enable=True) if any(v in c.element_info.name for v in ('复制','拷贝'))]}
        (ROOT/'evidence/copy-focus-probe.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8');return
    result={'page':201,'object':'NE_0','project_changed':False,'paste_sent':False,'measurements':[]}
    try:prior=native_clipboard_data()
    except ValueError:prior=None
    try:
        start=time.perf_counter()
        d,name=properties(root,w,'NE_0','数值的属性');cancel(d)
        root.set_focus();send_keys('^c',pause=.01);time.sleep(.15)
        baseline=native_clipboard_data()
        result['measurements'].append({'route':'properties_cancel_copy','seconds':time.perf_counter()-start,'bytes':len(baseline)})
        start=time.perf_counter();item=object_item(w,'NE_0');box=item.rectangle()
        from eb_directory import scope
        trees=[t for t in scope(w).descendants(control_type='Tree') if t.is_visible()]
        if len(trees)!=1:raise ValueError('Unique directory viewport required')
        viewport=trees[0].rectangle()
        if not (0<box.height()<60 and viewport.left<=box.left<box.right<=viewport.right and viewport.top<=box.top<box.bottom<=viewport.bottom):raise ValueError('Object row not safely visible')
        mouse.click(coords=(box.left+min(40,box.width()-2),(box.top+box.bottom)//2))
        root.set_focus()
        views=[c for c in root.descendants(class_name='AfxFrameOrView140u') if c.window_text().startswith('201 - ')]
        if len(views)!=1:raise ValueError('Unique live page201 canvas required')
        import ctypes
        u=ctypes.windll.user32
        current=ctypes.windll.kernel32.GetCurrentThreadId()
        thread=u.GetWindowThreadProcessId(views[0].handle,None)
        if not u.AttachThreadInput(current,thread,True):raise ValueError('Canvas focus attachment failed')
        try:u.SetFocus(views[0].handle)
        finally:u.AttachThreadInput(current,thread,False)
        # Remove the old EB format first: unchanged stale clipboard cannot count as a successful copy.
        import win32clipboard as c
        c.OpenClipboard()
        try:c.EmptyClipboard()
        finally:c.CloseClipboard()
        send_keys('^c',pause=.01);time.sleep(.15)
        direct=native_clipboard_data()
        result['measurements'].append({'route':'directory_single_click_copy','seconds':time.perf_counter()-start,'bytes':len(direct)})
        result.update(object_name=name,exact_native_payload_equal=direct==baseline,baseline_sha256=hashlib.sha256(baseline).hexdigest(),direct_sha256=hashlib.sha256(direct).hexdigest())
    except Exception as error:
        result['error']=str(error)
        raise
    finally:
        (ROOT/'evidence/copy-selection-benchmark.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
        if prior is not None:
            try:restore_native_clipboard(prior)
            except Exception as error:
                result['clipboard_restore_error']=str(error)
                (ROOT/'evidence/copy-selection-benchmark.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')

def verify_trial(handle,root,w):
    from eb_native_form import tab
    from eb_original_style_existing import form_rows
    from eb_copy_200_style_object import read_audit
    from eb_native_messages import msg
    path=ROOT/'evidence/direct-copy-trial.json'
    if path.exists():raise ValueError('Trial journal exists; inspect outcome before retry')
    state={'page':201,'stage':'before-copy','saved':False,'expected_existing_count':16}
    def persist():path.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf8')
    def capture(key):
        d,_=properties(root,w,key,'数值的属性')
        try:
            out={}
            for name in ('一般属性','格式','字体','安全','图片','数值输入'):
                tab(d,name)
                out[name]=[(r['type'],r['name'],r['value']) for r in form_rows(d) if 'value'in r]
            return out
        finally:cancel(d)
    before=read_audit(handle,201)
    if before['target_count']!=16 or before['unexpected']:raise ValueError('Expected sixteen saved controls only')
    expected=capture('NE_0')
    item=object_item(w,'NE_0');box=item.rectangle()
    from eb_directory import scope
    tree=[t for t in scope(w).descendants(control_type='Tree') if t.is_visible()]
    if len(tree)!=1:raise ValueError('Unique directory tree required')
    viewport=tree[0].rectangle()
    if not(viewport.top<=box.top<box.bottom<=viewport.bottom):raise ValueError('Selected row outside viewport')
    mouse.click(coords=(box.left+min(40,box.width()-2),(box.top+box.bottom)//2))
    views=[c for c in root.descendants(class_name='AfxFrameOrView140u') if c.window_text().startswith('201 - ')]
    if len(views)!=1:raise ValueError('Unique canvas required')
    import ctypes,win32clipboard as c
    u=ctypes.windll.user32;current=ctypes.windll.kernel32.GetCurrentThreadId();thread=u.GetWindowThreadProcessId(views[0].handle,None)
    if not u.AttachThreadInput(current,thread,True):raise ValueError('Canvas focus attachment failed')
    try:u.SetFocus(views[0].handle)
    finally:u.AttachThreadInput(current,thread,False)
    c.OpenClipboard()
    try:c.EmptyClipboard()
    finally:c.CloseClipboard()
    send_keys('^c',pause=.01);time.sleep(.15);data=native_clipboard_data()
    state.update(stage='paste-requested',clipboard_bytes=len(data));persist()
    root.click_input(coords=(963,367));send_keys('^v',pause=.01);time.sleep(.2);send_keys('{ESC}',pause=.01)
    after=read_audit(handle,201)
    if after['target_count']!=17 or after['unexpected']!=['NE_12']:
        state.update(stage='unknown-paste-outcome',audit=after);persist();raise ValueError('Unexpected paste count; trial retained for inspection')
    state.update(stage='pasted',trial_key='NE_12');persist()
    try:
        actual=capture('NE_12');state['copied_fields_equal']=actual==expected
        if actual!=expected:state['differing_tabs']=[k for k in expected if actual[k]!=expected[k]]
    finally:
        # Delete only the precisely identified trial object, never undo prior user work.
        d,_=properties(root,w,'NE_12','数值的属性');cancel(d);root.set_focus()
        state['stage']='delete-requested';persist();send_keys('{DELETE}',pause=.01);time.sleep(.2)
        cleaned=read_audit(handle,201)
        state.update(stage='trial-removed' if cleaned['target_count']==16 and not cleaned['unexpected'] else 'cleanup-needs-inspection',target_count=cleaned['target_count'],unexpected=cleaned['unexpected']);persist()
        if state['stage']!='trial-removed':raise ValueError('Trial cleanup incomplete; inspect target')
