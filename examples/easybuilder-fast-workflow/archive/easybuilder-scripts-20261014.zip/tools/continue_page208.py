"""Resume serial208 work; verified copies never rewritten or pasted twice."""
import sys,json,os,time
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
with lock.open('x',encoding='utf8') as f:f.write(json.dumps({'pid':os.getpid(),'page':208}))
p=ROOT/'evidence/page208-workflow.json'
d={'page':208,'template':204,'pid':os.getpid(),'status':'running','verified':[]}
def persist():p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
def ui(h,q):return call('uia',h,json.dumps(dict(q,build_bit_general=0),ensure_ascii=False))
try:
 call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
 def resolve(s):
  found=[w['handle'] for w in ws if w['class']=='EasyBuilderPro' and s in w['title']]
  if len(found)!=1:raise ValueError('One actual project required')
  return found[0]
 source=resolve('组装机2台15工位取消.cmtp');target=resolve('组装机_MT8106iP.emtp')
 phase=json.loads((ROOT/'evidence/page208-whole-page-copy.json').read_text(encoding='utf8'))
 if phase['stage']=='saved-compiled':
  project=ROOT/'output/组装机_MT8106iP.emtp';stat=project.stat()
  if phase.get('project_mtime_ns')==stat.st_mtime_ns and phase.get('project_bytes')==stat.st_size:
   print('208 already saved and compiled; no GUI action or repeated compilation',flush=True);sys.exit(0)
  raise ValueError('Project changed after208 completion; inspect affected fields instead of blindly repeating')
 if phase['stage']!='saved-bindings-pending':raise ValueError('Saved copy required; no automatic repeat paste')
 keys=['TX_0']+['TS_'+str(i) for i in range(22)]+['BL_'+str(i) for i in range(10)]
 for i in range(0,len(keys),4):
  chunk=keys[i:i+4];d['stage']='source captions';d['current']=chunk;persist()
  missing=[k for k in chunk if not (ROOT/f'evidence/page208-source-{k}.json').exists()]
  if missing:ui(source,{'page208':'source','keys':missing})
  for key in chunk:
   d['stage']='rewrite';d['current']=key;persist()
   report=ROOT/f'evidence/target-208-{key}-rewritten.json'
   if not report.exists() or not json.loads(report.read_text(encoding='utf8')).get('saved_reopened_verified'):
    ui(target,{'page208':'rewrite','key':key})
   d['verified'].append(key);persist();print(json.dumps({'verified':key,'count':len(d['verified'])}),flush=True)
 d['stage']='directory audit';persist()
 call('uia',target,json.dumps({'target_page_audit':208}))
 d['stage']='compile';persist()
 call('uia',target,json.dumps({'compile_target':True,'start_only':True}))
 call('uia',target,json.dumps({'compile_target':True,'capture_result':True}))
 d['status']='saved-compiled';d['stage']='done';persist()
 project=ROOT/'output/组装机_MT8106iP.emtp';stat=project.stat()
 writephase=dict(phase,stage='saved-compiled',project_mtime_ns=stat.st_mtime_ns,project_bytes=stat.st_size)
 (ROOT/'evidence/page208-whole-page-copy.json').write_text(json.dumps(writephase,ensure_ascii=False,indent=2),encoding='utf8')
 import shutil
 shutil.copy2(ROOT/'evidence/latest-project-compile.json',ROOT/'evidence/page208-project-compile.json')
except Exception as e:
 d.update(status='needs-recovery',error=str(e));persist();raise
finally:
 lock.unlink(missing_ok=True)
