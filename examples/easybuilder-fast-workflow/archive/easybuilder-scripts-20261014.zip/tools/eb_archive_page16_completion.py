"""Archive real page16 evidence and reproducible scripts in the same documents."""
import json,re
from datetime import datetime
from eb_rebuild_page import ROOT
from eb_sync_page16_checkpoint import sync

def run():
 sync()
 def read(name):return json.loads((ROOT/'evidence'/name).read_text(encoding='utf8'))
 a=read('target-page16-audit.json');c=read('latest-project-compile.json');v=read('page16-completion-checks.json');r=read('page16-final-reopened.json');old=read('page16-switch-appearance-workflow.json');lamps=read('page16-existing-indicator-workflow.json')
 if not all([a['tree_verified'],v['ok'],r['ok'],old['ok'],c['ok'],lamps['ok']]):raise ValueError('Successful current evidence required for completion archive')
 size=(ROOT/'output/组装机_MT8106iP.emtp').stat().st_size;exob=(ROOT/'output/组装机_MT8106iP.exob').stat().st_size
 if c['project_bytes']!=size or r['project_bytes']!=size or c['exob_bytes']!=exob:raise ValueError('Compile and reopened evidence must match current saved file sizes')
 date=datetime.now().isoformat(timespec='seconds');p=ROOT/'evidence/resume-checkpoint.json';d=read('resume-checkpoint.json')
 d.update(date=date,status='page16-editing-completed-runtime-pending',bytes=size,exob_bytes=exob,target_pid=r['reopened_pid'],target_handle=r['reopened_handle'],page16_objects=104,page16_source_objects=101,page16_missing_objects=0,page16_native_evidence_verified=True,page16_final_reopened=r,page16_compile_current=c,batch_running=False,next='16页补件及原有按钮修正已保存、0错误编译、正常重开11件原生抽查通过；不得重复新增101+3对象。后续继续外观细节（矢量身份/矩形线样式/字体实际显示）及离线/实机交互验收；没有PLC/HMI下载或PLC宏运行。')
 p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
 d['page16_existing_indicator_repair']=lamps;p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
 d['next']='16页101原对应件+3报警标题适配件已保存，原有11按钮及5指示灯已修正，编译0错误1已接受警告，13件重开抽查通过。后续外观细节和离线/实机交互未验收，不重复新增，不下载PLC/HMI、不执行PLC宏。'
 p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
 block=f'''<!-- PAGE16-FINAL-BEGIN -->
{date} 16页按原图补齐并适配MT8106iP：源101控件，原目标53控件，本轮补48个原对应件（TX20..30共11、BL5..32共28、TS11..17共7、AL0和DW4各1）。MT无cMT报警标题页，增加DW5/TX31/TX32共3普通组件，目标物理104件；完整目录missing=0、unexpected=0、address_name_mismatch=0。源目录仍为101，不以目标辅助件篡改源清单。
原有TS0..10共11件按源图库修正，TS4/TS15用Selector_3_Position_Metal_Silver-Red（95x109），其余TS用Button - Standard（143x64）。最短按压时间逐件取源安全Down，通常0.5秒、TS4/TS15为0.1秒；保留地址、行为、文字及两状态原生RGB读回。纵向位置/高度以600/768适配，X/宽度保持源布局且边界裁切；所有101源对应件保存报告的地址、尺寸边界和18个TS安全/文字/图库核对通过。报警整体417x185，标题24px、内容161px；源蓝字RGB0/0/255、标题底RGB192/208/224，内容背景RGB240/240/240，日期隐藏、网格关闭、消息显示37字符。16页RGB155/155/150、1024x600、底层10. 自动背景正常重开核对通过。
本轮真实编译信息：{json.dumps(c['messages'],ensure_ascii=False)}；警告详情：{json.dumps(c['warning_details'],ensure_ascii=False)}。GP0“设为原尺寸”警告已由用户接受，未更改其尺寸。EMTP {size}字节，EXOB {exob}字节。正常关闭旧PID {r['previous_pid']}并重新打开为PID {r['reopened_pid']}；{len(r['checks'])}件抽查TS4/TS10/TS15/TS17、BL0/BL4/BL32、TX30、DW4、AL0、DW5/TX31/TX32通过，源101/目标104目录重开后再次通过。证据：page16-completion-checks.json、page16-final-reopened.json、latest-project-compile.json。
BL0..4五个原有指示灯也由旧Flat样式恢复为源图片/向量勾选及原生两状态RGB，BL0保留原96x96 Standard位图与向量组合；BL4文字颜色也按源读回。源BL0同名颜色字段有两个，分别按occurrence=0/1采集和设置，避免覆盖遗漏。脚本`python tools/eb_repair_page16_existing_indicators.py`只修改已有控件，不新增。向量选择需暂时关闭位图、选Frame再恢复原图片/向量勾选，位图图库按原族名和尺寸原生确认。
额外核对与报错原文：`Page16 saved native parameter evidence mismatch` 曾指向NE3旧报告26px，实际只读属性为28px，已用真实读回更正报告，工程不需改写。BL4按比例请求12px并保存，重开固定为16px；按原8号字体保留该原生最小高度，eb_layout明确记录这个适配例外。一次只读采集完成后发生`InvalidWindowHandle: Handle 70230 is not a vaild window handle`（后台窗口枚举竞争），属性证据已生成，不重复控件动作。编译第一次读到了错误列表的GP0警告文本，产生`Compile did not report success with zero errors and warnings`；改为编译后明确激活“导出”页读取成功/错误计数，再查错误列表，不能以新EXOB文件 alone 判成功。`Exact target page required`和`Unique target filter required`发生于当前17页/窗口预览面板，不在错误页改写；先用`{{"op":"selecttab","type":"TabItem","name":"目录树","selector":true}}`恢复目录，再打开16并设精确16 :过滤审计。通用UIA op为selecttab/clickcontrol，非click；缺selector会报`UIA selector changed; inspect again`，错误op会报`Unsupported UIA operation`。
复现/恢复命令（Python路径见README已有运行环境）：
`python tools/eb_complete_page16_switches.py` 仅缺失TS11..17；已有保存报告不重复新增。
`python tools/eb_repair_page16_switch_appearance.py` 只修改已有TS0..10；不复制/新增。
`python tools/eb_verify_page16_completion.py` 文件证据核对，不操作GUI。
`python tools/eb_finish_page16.py` 编译、真实重开及11件只读抽查，仅在无batch.lock且上一阶段明确结束时运行；若已有未完成弹窗，先按实际窗口和worker/request/response恢复，不能盲目重新启动。
`python tools/eb_archive_page16_completion.py` 更新同一README、实现记录和断点，不操作GUI。
踩坑与修正：初始目录采集只读可见视口，误认53件已齐；改为滚动到稳定底部，完整源101件。新增后树停在底部，`Expected unique page header`，目录审计增加最多4次向上80滚轮恢复页头。目录行被裁切时双击会误触面板停靠，限制在真实树矩形内。`Color selector not unique` 因颜色控件横向包含于标签矩形，已按实际矩形/Y匹配；`Native property readback mismatch` 的Qt表格字段用commit_edits=True提交。图库第一屏group0是Green而非源银红；先激活图库并翻页，按精确文字和所在缩略图选择，父弹窗读回验证族名。新增探针没有放置为额外控件，最终104件无重复。
未完成项：矢量形状身份、矩形线宽/样式与字体实际显示的最终外观对照；离线/实机报警触发和交互验收。保存、编译及11件原生重开抽查不等同运行验收。本轮没有PLC/HMI下载、没有执行PLC宏，没有发布未完成工程。
<!-- PAGE16-FINAL-END -->'''
 block=block.replace('11件原生重开抽查','13件原生重开抽查').replace('11件正常重开抽查','13件正常重开抽查').replace('11件只读抽查','13件只读抽查').replace('新EXOB文件 alone 判成功','只有新EXOB文件就判成功')
 for p in (ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md'):
  s=p.read_text(encoding='utf8');begin='<!-- PAGE16-FINAL-BEGIN -->';end='<!-- PAGE16-FINAL-END -->'
  if begin in s:s=re.sub(re.escape(begin)+r'.*?'+re.escape(end),lambda _:block,s,flags=re.S)
  else:s+='\n\n'+block+'\n'
  # Replace the temporary live block to avoid stale "still pending" statements.
  live='<!-- PAGE16-LIVE-BEGIN -->\n'+date+f' 本轮16页补件与按钮修正阶段结束：101源对应件+3型号适配件=104件；EMTP {size}字节，缺失0。编译成功、{len(r["checks"])}件正常重开抽查通过；具体证据、脚本、报错与运行未验收项见同文档PAGE16-FINAL段。\n<!-- PAGE16-LIVE-END -->'
  s=re.sub(r'<!-- PAGE16-LIVE-BEGIN -->.*?<!-- PAGE16-LIVE-END -->',lambda _:live,s,flags=re.S);p.write_text(s,encoding='utf8')
 print(json.dumps({'page':16,'target_count':104,'bytes':size,'exob_bytes':exob,'documents_updated':True},ensure_ascii=False))
if __name__=='__main__':run()
