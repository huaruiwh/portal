"""Cache source properties serially with a resumable local progress file."""
import json,re,sys
from pathlib import Path
from eb_rebuild_page import call,ROOT
def run(page):
    lock=ROOT/'tools'/'batch.lock'
    with lock.open('x'):pass
    report={'page':page,'completed':[],'ok':False}
    path=ROOT/'evidence'/f'page-{page}-source-collection.json'
    def save():path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    try:
        call('snapshot');ws=json.loads((ROOT/'evidence'/'windows.json').read_text(encoding='utf8'))
        candidates=[w['handle'] for w in ws if w['class']=='EasyBuilderPro' and '组装机2台15工位取消.cmtp' in w['title']]
        if len(candidates)!=1:raise ValueError('Unique source required')
        h=candidates[0]
        inv=json.loads((ROOT/'evidence'/'source-pages-inventory.json').read_text(encoding='utf8'))
        names=next(p['observed_objects'] for p in inv['pages'] if p['id']==page)
        for name in names:
            key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)
            if not key:raise ValueError('Unknown source object name')
            report['stage']=key[1];save()
            if not (ROOT/'evidence'/'source-object-properties'/f'{page:03d}_{key[1]}.json').exists():
                call('uia',h,json.dumps({'extract':{'page':page,'object':name}},ensure_ascii=False))
            report['completed'].append(key[1]);save()
        report['ok']=True;save();print(json.dumps({'page':page,'cached':len(report['completed']),'ok':True}))
    except Exception as e:
        report['error']=str(e);save();print(json.dumps({'ok':False,'page':page,'stage':report.get('stage'),'error_file':str(path)}));raise
    finally:lock.unlink(missing_ok=True)
if __name__=='__main__':run(int(sys.argv[1]))
