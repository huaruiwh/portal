"""Short, readback-checked phases for the original MS builder."""
import json
from eb_extract import ROOT,rows
from eb_object_ui import dialog,placed_properties,save
from eb_native_form import tab,fields,confirm

def run_step(root,w,source,page,q):
    step=q['ms_step'];path=ROOT/f'evidence/target-{page:03d}-MS0-phases.json'
    progress=json.loads(path.read_text(encoding='utf8')) if path.exists() else {'page':page,'steps':[],'readbacks':{}}
    if step=='start':
        from eb_ribbon import create
        d=create(root,'MS','新增 多状态指示灯/多状态切换开关')
    elif step=='geometry_open':
        d,name=placed_properties(root,w,'MS_0','多状态切换开关/多状态指示灯的属性')
        progress['target']=name;tab(d,'轮廓')
    elif step.startswith('geometry_'):
        d=dialog(root.process_id(),'多状态切换开关/多状态指示灯的属性')
    else:d=dialog(root.process_id(),'新增 多状态指示灯/多状态切换开关')
    if step=='tab':
        tab(d,q['tab'])
        progress['native_map']={'dialog':d.handle,'tab':q['tab'],'controls':[{'type':c.element_info.control_type,'name':c.element_info.name,'handle':c.element_info.handle} for c in d.descendants(cache_enable=True) if c.element_info.handle]}
    elif step=='field':
        records=source['tabs'][q['tab']]
        row=records[int(q['index'])]
        if row['type'] not in ('Edit','ComboBox','CheckBox','RadioButton') or 'value' not in row:raise ValueError('Reviewed source field required')
        mapping=progress.get('native_map',{})
        if mapping.get('dialog')==d.handle and mapping.get('tab')==q['tab']:d._native_map=mapping['controls']
        result=fields(d,[row])
        progress['readbacks'][q['tab']+':'+str(q['index'])]=result
    elif step=='picture_choose':
        from eb_selector_picture import choose_existing
        choose_existing(d,root.process_id())
    elif step=='gallery':
        from eb_selector_picture import choose_gallery
        choose_gallery(root.process_id())
    elif step=='picture_verify':
        evidence=rows(d)
        if not any(r['name']=='Selector_3_Position_Green' for r in evidence):raise ValueError('Exact selector family required')
        progress['picture']=evidence
    elif step=='place':confirm(d)
    elif step=='geometry_field':
        row=next(r for r in source['tabs']['轮廓'] if r['type']=='Edit' and r['name']==q['name'])
        progress['readbacks']['geometry:'+q['name']]=fields(d,[row],commit_edits=True)
    elif step=='geometry_save':
        confirm(d);save(root)
        progress.update(source=source['object'],saved_requested=True,label_color_review_pending=True,offline_simulation_verified=False)
        (ROOT/f'evidence/target-{page:03d}-MS0-built.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf8')
    progress['steps'].append({'step':step,'tab':q.get('tab'),'index':q.get('index'),'name':q.get('name')})
    path.write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf8')
