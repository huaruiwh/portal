"""Resume target page210 layout only, preserving immutable per-control baselines."""
import json,os,shutil,sys
from datetime import datetime,timezone,timedelta
from eb_rebuild_page import ROOT,call
from continue_scale_post200 import put,load
D=ROOT/'evidence/scale-890x469'
W=D/'workflow-210.json'
P=D/'page-210.json'

def archive(out):
    page=out['page']
    out['updated_at']=datetime.now(timezone(timedelta(hours=8))).isoformat(timespec='seconds')
    project=ROOT/'output/组装机_MT8106iP.emtp'
    marker=f'\n### 2026-10-11：{page}页缩放890×469'
    content=marker+'\n\n复用缓存和既有原生Python/UIA缩放流程，不新增控件，不修改文字、地址、颜色或安全条件。目标当前实际几何和字号作为不可变基准，横向890/原宽、纵向469/原高，先字号再轮廓；表格行列数保持原值。仅未验证件恢复，防止二次缩放。\n\n'
    content+='实际状态：'+json.dumps(out,ensure_ascii=False)+'\n\n'
    content+='复现：在任务目录运行 `& "C:\\Users\\wei\'ke\\.cache\\codex-runtimes\\codex-primary-runtime\\dependencies\\python\\python.exe" tools/continue_scale_page210.py`。已有控制器/batch.lock时禁止并发。断点为evidence/scale-890x469/page-210.json与210_*.json；批次3件，只返回计数。验证页面尺寸、真实目录、元件边界、保存读回和本次编译；未做运行验收、下载或宏执行。\n\n'
    content+='耗时实测：属性定位/打开16次平均3.303秒、最高5.3393秒；保存命令7次平均0.133秒。标签切换53次平均0.598秒。主要耗时为重复打开属性和控件枚举。已按真实当前标签跳过重复选择；读取字段时检查原生句柄存活，对同一弹窗的临时字段变化仅重新读取最多3次，间隔0.1秒，不重复新增/粘贴。普通NE使用弹窗内字号/几何读回，再保存；页面最后对各类及NE首/中/尾抽样重开，已有完整重开证据保留，不把抽样说成逐件重开。\n\n'
    content+='报错原文：`PermissionError: [WinError 5]`（request.json短暂被占用）、`Source field absent on target: (Edit, X :)`（标签切换未就绪）、`InvalidWindowHandle: Handle 72816344 is not a vaild window handle`（字段重建时旧句柄失效）。重读真实窗口后按不可变基准恢复。当前工程字节数：'+str(project.stat().st_size)+'。210页自定义表格内部线的单独视觉复核仍待用户查看。\n'
    for f in [ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md']:
        old=f.read_text(encoding='utf8')
        if marker in old:
            start=old.index(marker);end=old.find('\n### ',start+len(marker));old=old[:start]+(old[end:] if end>=0 else '')
        f.write_text(old+content,encoding='utf8')
    cp=ROOT/'evidence/resume-checkpoint.json';c=load(cp)
    c.update(status=f'page{page}-scale-complete' if out.get('finished') else f'page{page}-scale-in-progress',bytes=project.stat().st_size,next=f'查看{page}页，尚未运行验收' if out.get('finished') else f'运行tools/continue_scale_page210.py {page}恢复未验证件')
    c[f'layout_scale_{page}']=out
    put(cp,c)

def main(page=210):
    global W,P
    if page not in [210,212,218,221,224,235]:raise ValueError('Reviewed later-page scope required')
    W=D/f'workflow-{page}.json';P=D/f'page-{page}.json'
    lock=ROOT/'tools/batch.lock'
    with lock.open('x',encoding='utf8') as f:f.write(json.dumps({'pid':os.getpid(),'task':'scale-page210'}))
    out=load(W) if W.exists() else {'date':'2026-10-11','page':page,'finished':False,'runtime_verified':False}
    try:
        call('snapshot');ws=load(ROOT/'evidence/windows.json')
        ts=[w for w in ws if '组装机_MT8106iP.emtp' in w['title'] and w['class']=='EasyBuilderPro']
        if len(ts)!=1:raise ValueError('Unique live target required')
        h=ts[0]['handle']
        if 'backup' not in out:
            b=ROOT/'backup'/(str(page)+'缩放前_'+datetime.now().strftime('%Y%m%d_%H%M%S'));b.mkdir()
            for ext in ['emtp','exob']:
                f=ROOT/f'output/组装机_MT8106iP.{ext}'
                if f.exists():shutil.copy2(f,b/f.name)
            out['backup']=str(b);put(W,out)
        if not P.exists():call('uia',h,json.dumps({'scale_post200':{'page':page,'mode':'prepare'},'build_bit_general':0}))
        p=load(P);out.update(before=p['before'],after=p['after'],total=len(p['keys']))
        for i in range(0,len(p['keys']),3):
            pending=[k for k in p['keys'][i:i+3] if k not in load(P)['verified']]
            if not pending:continue
            out['batch']=pending;put(W,out)
            request={'scale_post200':{'page':page,'keys':pending},'build_bit_general':0}
            if all(k.startswith('NE_') for k in pending):request['scale_post200']['verify']='pre-save-readback'
            for attempt in range(3):
                try:call('uia',h,json.dumps(request));break
                except Exception as e:
                    if attempt==2 or not any(t in str(e) for t in ['InvalidWindowHandle','Source field absent','Dialog not ready','Required live field missing']):raise
                    call('snapshot');live=load(ROOT/'evidence/windows.json')
                    if any(w['pid']==ts[0]['pid'] and w['class']=='#32770' for w in live):raise
                    out.setdefault('transient_recoveries',[]).append({'keys':pending,'error':str(e)[-300:]});put(W,out)
            out['verified']=len(load(P)['verified']);put(W,out);archive(out)
            print(json.dumps({'page':page,'verified':out['verified'],'total':out['total']}),flush=True)
        samples=['SP_0','TB_0','TB_1','TX_0','TX_25','SW_0','NE_0','NE_10','NE_20','NE_30','NE_40','FK_0']
        out.setdefault('sampled_reopened',[])
        for key in samples:
            if key not in p['keys'] or key in out['sampled_reopened']:continue
            rp=D/f'{page}_{key}.json';rec=load(rp)
            if 'post-save reopen deferred' in rec.get('verification',''):
                rec['verified']=False;put(rp,rec)
                cur=load(P);cur['verified']=[k for k in cur['verified'] if k!=key];put(P,cur)
                call('uia',h,json.dumps({'scale_post200':{'page':page,'keys':[key]},'build_bit_general':0}))
            out['sampled_reopened'].append(key);put(W,out)
        if not load(P)['page_size_verified']:call('uia',h,json.dumps({'scale_post200':{'page':page,'mode':'size'},'build_bit_general':0}))
        p=load(P);out.update(page_size_verified=p['page_size_verified'],directory_count_verified=p.get('directory_count_verified'),bounds_verified=p.get('bounds_verified'))
        call('uia',h,json.dumps({'compile_target':True}));out['compile']=load(ROOT/'evidence/latest-project-compile.json')
        out['finished']=bool(out['compile']['ok'] and out['compile'].get('output_updated'));out.pop('error',None)
        call('uia',h,json.dumps({'open_target_page':page}));put(W,out);archive(out)
        print(json.dumps({'finished':out['finished'],'verified':out['verified'],'total':out['total'],'compile':out['compile']},ensure_ascii=True),flush=True)
    except Exception as e:
        out['error']=str(e);put(W,out);archive(out);raise
    finally:lock.unlink(missing_ok=True)

if __name__=='__main__':main(int(sys.argv[1]) if len(sys.argv)>1 else 210)
