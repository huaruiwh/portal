"""Serial203 copied-control difference batches, each verified report resumable."""
import json,re,time
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
with lock.open('x',encoding='utf8')as f:f.write('203 rewrite batches')
rp=ROOT/'evidence/page203-rewrite-workflow.json';out={'page':203,'verified':[],'finished':False}
try:
 call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'));ts=[x for x in ws if '组装机_MT8106iP.emtp'in x['title']and x['class']=='EasyBuilderPro']
 if len(ts)!=1:raise ValueError('Unique target required')
 h=ts[0]['handle'];call('uia',h,json.dumps({'open_target_page':203}))
 inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));keys=[re.search(r'(?:^|\])\s*([A-Z]+_\d+)',n)[1]for n in next(x['observed_objects']for x in inv['pages']if x['id']==203)]
 if len(keys)!=52 or any(not(ROOT/f'evidence/source-object-properties/203_{k}.json').exists()for k in keys):raise ValueError('Full52 source cache required')
 for i in range(0,len(keys),3):
  batch=keys[i:i+3];out['current_batch']=batch;rp.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
  call('uia',h,json.dumps({'page203_rewrite':batch,'build_bit_general':0}))
  for k in batch:
   d=json.loads((ROOT/f'evidence/target-203-{k}-rewritten.json').read_text(encoding='utf8'))
   if not d['saved_reopened_verified']:raise ValueError('Unverified '+k)
  out['verified']+=batch;rp.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps({'verified':len(out['verified']),'total':52}),flush=True)
 call('uia',h,json.dumps({'target_page_audit':203}));out['directory_verified']=True
 call('uia',h,json.dumps({'compile_target':True}));out['compile']=json.loads((ROOT/'evidence/latest-project-compile.json').read_text(encoding='utf8'));out['finished']=True;out['runtime_verified']=False;rp.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
except Exception as e:
 out['error']=str(e);rp.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');raise
finally:lock.unlink(missing_ok=True)
