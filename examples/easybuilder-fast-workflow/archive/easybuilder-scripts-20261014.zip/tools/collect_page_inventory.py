"""Collect observed source page names/hooks; never equate viewport to full project."""
import json,re
from pathlib import Path
root=Path(__file__).resolve().parent.parent
pages={}
for name in ['source-main-current-uia.json','source-pages-scroll-uia.json','source-window10-expanded-uia.json']:
    rows=json.loads((root/'evidence'/name).read_text(encoding='utf-8-sig'))
    current=None
    for row in rows:
        if row['type']!='TreeItem':continue
        match=re.match(r'^(\d+)(?:\s*:\s*(.*))?$',row['name'])
        if match:
            current=int(match[1])
            pages.setdefault(current,{'id':current,'observed_name':row['name'],
                'close_macros':[int(v) for v in re.findall(r'关闭\s*\((\d+)\)',row['name'])],
                'observed_objects':[]})
        elif current is not None and row['name'] not in pages[current]['observed_objects']:
            pages[current]['observed_objects'].append(row['name'])
report={'complete_project_inventory':False,'observed_page_count':len(pages),
    'pages_with_observed_close_macros':sum(bool(p['close_macros']) for p in pages.values()),
    'pages':sorted(pages.values(),key=lambda p:p['id'])}
(root/'evidence'/'source-pages-inventory.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'observed_page_count':len(pages),'pages_with_observed_close_macros':report['pages_with_observed_close_macros'],
    'window10_observed_objects':len(pages[10]['observed_objects']),'complete_project_inventory':False},ensure_ascii=False))
