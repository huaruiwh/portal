"""Serial instruction text stage with cached-source guards and saved reports."""
import json
from eb_rebuild_page import ROOT,call

def run():
    lock=ROOT/'tools/batch.lock'
    with lock.open('x'):pass
    progress={'page':101,'completed':[],'text_stage_only':True,'ok':False}
    path=ROOT/'evidence/page-101-text-workflow.json'
    def persist():path.write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf8')
    try:
        call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
        found=[w for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
        if len(found)!=1:raise ValueError('Unique target required')
        h=found[0]['handle']
        def ui(q):return call('uia',h,json.dumps(q,ensure_ascii=False))
        ui({'open_target_page':101})
        if not (ROOT/'evidence/target-page-101-size.json').exists():ui({'target_page_size':101})
        if not (ROOT/'evidence/target-page-101-color.json').exists():ui({'page_settings':101,'apply_source_background':True,'apply_source_border':True})
        for n in range(7):
            progress['stage']=f'TX_{n}';persist()
            if not (ROOT/f'evidence/target-101-TX{n}-built.json').exists():ui({'page':101,'build_tx':n})
            progress['completed'].append(f'TX_{n}');persist()
            print(json.dumps({'saved':f'101 TX{n}'}),flush=True)
        progress['ok']=True;persist()
    except Exception as e:
        progress['error']=str(e);persist();raise
    finally:lock.unlink(missing_ok=True)

if __name__=='__main__':run()
