"""File-only final verification and documentation of the completed391 layout task."""
import json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
DIR=ROOT/'evidence/scale-pages26-47-height391'
def read(p):return json.loads(p.read_text(encoding='utf8'))
def write(p,a):p.write_text(json.dumps(a,ensure_ascii=False,indent=2),encoding='utf8')
def main():
 wp=DIR/'workflow.json';workflow=read(wp);pages=[];count=0;squares=0;states=0;sizes=set();baseline_pages=[]
 for page in workflow['scope']:
  pp=DIR/f'page-{page}.json'
  if not pp.exists():
   assert workflow['pages'][str(page)].get('undefined_empty_page');continue
  p=read(pp);assert p['page_size_verified']and p['bounds_verified']and p['directory_count_verified'];assert p['after']['高度 :']=='391'and p['after']['宽度 :']==p['before']['宽度 :'];assert set(p['accepted'])==set(p['keys'])
  audit=read(ROOT/f'evidence/target-page{page}-audit.json');assert audit['tree_verified']
  if 'objects_before'in p:
   assert sorted(audit['objects'])==sorted(p['objects_before']);baseline_pages.append(page);p['literal_verification_basis']='immutable actual target directory before layout change'
  else:
   assert page==26;p['literal_verification_basis']='original source directory matches final target; first prototype has no immutable literal snapshot, geometry baseline is preserved'
  for key in p['keys']:
   file=DIR/f'{page}_{key}.json';rec=read(file);assert rec['accepted']and rec['property_session_verified'];g=rec['after']
   assert int(g['X :'])>=0 and int(g[' Y :'])>=0 and int(g['X :'])+int(g.get(' 宽度 :',0))<=int(p['after']['宽度 :'])and int(g[' Y :'])+int(g.get('高度 :',0))<=391
   if rec['before'].get(' 宽度 :')==rec['before'].get('高度 :'):assert g.get(' 宽度 :')==g.get('高度 :');squares+=1
   for scope in rec['fonts_after'].values():
    for v in scope.values():sizes.add(int(v['size']));states+=1;assert str(v['font']).split(' [')[0]=='微软正黑体 Light'
   rec.update(saved=True,completed_date='2026-10-14');write(file,rec)
  for key in p['representative_reopened']:assert read(DIR/f'{page}_{key}.json')['saved_reopened_verified']
  p['layout_verified']=True;write(pp,p);count+=len(p['keys']);pages.append({'page':page,'controls':len(p['keys']),'before':p['before'],'after':p['after'],'representatives':p['representative_reopened']})
 compile=read(ROOT/'evidence/latest-project-compile.json');assert compile['ok']and compile['output_updated'];write(DIR/'final-compile.json',compile)
 report={'date':'2026-10-14','started_date':'2026-10-13','pages':pages,'page_count':len(pages),'controls':count,'height':391,'uniform_scale':True,'square_bounds_equal_count':squares,'font_state_count':states,'font_sizes':sorted(sizes),'literal_baseline_pages':baseline_pages,'source_directory_match_pages':[p['page']for p in pages],'skipped_undefined':[int(k)for k,v in workflow['pages'].items()if v.get('undefined_empty_page')],'backup':workflow['backup'],'compile':compile,'project_sha256':hashlib.sha256((ROOT/'output/组装机_MT8106iP.emtp').read_bytes()).hexdigest(),'runtime_verified':False}
 write(DIR/'final-report.json',report);workflow.update(finished=True,completed_date='2026-10-14',compile=compile,controls=count,page_count=len(pages),runtime_verified=False);workflow.pop('error',None);write(wp,workflow)
 text='\n\n## 2026-10-14 26～47页高度391适配完成\n\n实际完成'+str(len(pages))+'个已定义页面、'+str(count)+'控件；46为未定义空页，真实目录不能定位定义窗口，已记录且未新增。各页800×500→800×391，比例0.782等比缩放整体位置和宽高，水平居中，保留图形比例；'+str(squares)+'个原宽高相等的控件新宽高仍相等，圆形不单轴拉伸。字体微软正黑体Light，'+str(states)+'个启用字体状态，实际字号集合'+str(sorted(sizes))+'；先字号再轮廓，必要时只取消图片原尺寸自动尺寸，不替换图库或颜色。\n\n每件同会话读回，每3件保存；21页高度保存重开、各类代表共'+str(sum(len(p['representatives'])for p in pages))+'件重开、目录与边界通过。saved_reopened_verified仅标实际代表重开的件，不冒称全422逐件重开。21页最终目录与原件相符；其中27～45及47共20页还与本任务不可变目标目录基准一致。26为第一试跑，目录字面基准未保留，不能补造；其原几何基准完整、最终目录与原件相符。\n\n工程output/组装机_MT8106iP.emtp保存'+str(compile['project_bytes'])+'字节，新exob '+str(compile['exob_bytes'])+'字节。真实新编译0错误1警告，output_updated=true；唯一原有警告：1. [窗口 16] GP_0 : 选择 "设为原尺寸" 以加快画面显示速度.。最终停26供查看。未执行任何PLC/HMI宏、未下载、未做运行验收，其他旧页待办保留。\n\n编译入口曾报ValueError: Target only，实际窗口标题/进程正确；保存期间消息式window_text读取暂时失败。改为GetWindowTextW读真实标题并保留严格目标文件名校验，仅重试新编译成功，未重做缩放。末尾归档曾报KeyError: objects_before，定位仅第一试跑26缺目录基准；改为明确区分20页原目标比较与21页原件比较，未伪造丢失证据。MS初始化、目录激活、缩进修复、同进程缓存及批次保存详见前文。\n\n证据evidence/scale-pages26-47-height391/final-report.json、final-compile.json、workflow.json和逐件原/后数据；备份见workflow.backup。脚本tools/eb_scale_pages26_47.py、tools/continue_scale_pages26_47.py、tools/finalize_scale_pages26_47.py；恢复python tools/continue_scale_pages26_47.py，先核锁和实际worker。完成页/件跳过，不二次缩放；文件归档复核python tools/finalize_scale_pages26_47.py；方法快照python tools/archive_fast_workflow.py 2026-10-14。\n'
 for f in [ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md']:
  s=f.read_text(encoding='utf8')
  for page in range(38,48):s=s.replace('2026-10-13 高度391适配：页'+str(page)+'，','2026-10-14 高度391适配：页'+str(page)+'，')
  if '## 2026-10-14 26～47页高度391适配完成'not in s:f.write_text(s+text,encoding='utf8')
 cp=ROOT/'evidence/resume-checkpoint.json';data=read(cp);data.update(date='2026-10-14',active_task='pages26..47 height391 complete',phase='saved audited compiled',height391_complete=True,page_count=len(pages),controls=count,undefined_pages=report['skipped_undefined'],bytes=compile['project_bytes'],compile='0 errors,1 accepted GP_0 warning',final_report='evidence/scale-pages26-47-height391/final-report.json');write(cp,data)
 repo=ROOT.parent/'portal'
 for f in [repo/'examples/easybuilder-fast-workflow/README.md',repo/'docs/EasyBuilder快速重建-实现记录.md']:
  s=f.read_text(encoding='utf8')
  if '## 2026-10-14 26～47页高度391适配完成'not in s:f.write_text(s+text,encoding='utf8')
 print(json.dumps({'pages':len(pages),'controls':count,'square_bounds':squares,'font_states':states,'font_sizes':sorted(sizes),'bytes':compile['project_bytes'],'exob_bytes':compile['exob_bytes']}))
if __name__=='__main__':main()
