import json
from eb_object_ui import target,properties,save
from eb_native_form import tab,fields,confirm
from eb_extract import ROOT,rows
from eb_layout import geometry

def run(handle,q):
 key=q['fit_page10_fk']
 if key not in ['FK_'+str(i) for i in range(6)]:raise ValueError('Reviewed FK only')
 si={0:0,1:1,2:2,3:3,4:5,5:4}[int(key[3:])]
 src=json.loads((ROOT/f'evidence/source-object-properties/010_FK_{si}.json').read_text(encoding='utf8'))
 old=json.loads((ROOT/f'evidence/target-object-properties/010_{key}.json').read_text(encoding='utf8'))
 shape_tab=next(k for k,v in old['tabs'].items() if any(x['name']=='X :' for x in v))
 expected=geometry(src)
 # Preserve adapted widths; remove adjacent button overlap with a 2px gap.
 widthkey=next(k for k in expected if k not in ('X :',' Y :') and int(expected[k])==140)
 oldvals={x['name']:x.get('value') for x in old['tabs'][shape_tab] if x['type']=='Edit'}
 x=int(expected['X :']);nx={52:186,186:321,321:455,455:590,590:724}.get(x)
 expected[widthkey]=str(min(int(oldvals[widthkey]),nx-x-2)) if nx else oldvals[widthkey]
 root,w=target(handle,10)
 title=json.loads((ROOT/'evidence/source-object-properties/010_FK_0.json').read_text(encoding='utf8')).get('dialog_title')
 if not title:
  from eb_native_messages import text
  title='\u529f\u80fd\u952e\u7684\u5c5e\u6027'.encode().decode('unicode_escape')
 d,name=properties(root,w,key,title)
 tab(d,shape_tab);fields(d,[{'type':'Edit','name':k,'value':v} for k,v in expected.items()])
 actual={x['name']:x.get('value') for x in rows(d) if x['type']=='Edit' and x['name'] in expected}
 if actual!=expected:raise ValueError('FK geometry readback mismatch')
 confirm(d);save(root)
 (ROOT/f'evidence/page10-{key}-fit.json').write_text(json.dumps({'key':key,'source_key':f'FK_{si}','expected':expected,'readback':actual,'saved_requested':True,'reopened_verified':False},ensure_ascii=False,indent=2),encoding='utf8')
