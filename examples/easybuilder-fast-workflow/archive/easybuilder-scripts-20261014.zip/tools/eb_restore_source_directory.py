"""Dock the uniquely observed floating source directory, without touching the project."""
import json,uuid,time
from eb_rebuild_page import ROOT,call
if (ROOT/'tools/batch.lock').exists():raise ValueError('Active controller; do not operate GUI concurrently')
call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
s=[w for w in ws if w['class']=='EasyBuilderPro' and '组装机2台15工位取消.cmtp' in w['title']]
if len(s)!=1:raise ValueError('One source project required')
a=[w for w in ws if w['pid']==s[0]['pid'] and w['title']=='目录树' and 'MiniFrame' in w['class']]
if len(a)!=1:raise ValueError('Unique observed floating source directory required')
rid=str(uuid.uuid4());q={'id':rid,'action':'click','handle':a[0]['handle'],'coords':[110,12],'double':True,'wait':0}
p=ROOT/'tools/request.tmp';p.write_text(json.dumps(q),encoding='utf8');p.replace(ROOT/'tools/request.json')
for i in range(100):
 r=json.loads((ROOT/'evidence/response.json').read_text(encoding='utf8'))
 if r.get('id')==rid:
  if not r.get('ok'):raise ValueError(r)
  print('source-directory-docked');break
 time.sleep(.1)
else:raise ValueError('Dock response missing')
