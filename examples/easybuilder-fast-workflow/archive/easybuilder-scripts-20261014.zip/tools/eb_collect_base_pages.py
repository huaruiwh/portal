"""Serial read-only source cache for unfinished base pages10/11."""
import json,re
from eb_rebuild_page import ROOT,call

def run():
 lock=ROOT/'tools/batch.lock'
 with lock.open('x'):pass
 report={'pages':[10,11],'completed':[],'ok':False,'source_modified':False}
 path=ROOT/'evidence/base-pages-source-cache-progress.json'
 def persist():path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 try:
  call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
  h=next(w['handle'] for w in ws if w['class']=='EasyBuilderPro' and '组装机2台15工位取消.cmtp' in w['title'])
  inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
  for page in (10,11):
   call('uia',h,json.dumps({'page_settings':page,'color_probe':True}))
   names=next(p['observed_objects'] for p in inv['pages'] if p['id']==page)
   for name in names:
    key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)[1]
    report['stage']={'page':page,'object':key};persist()
    cached=ROOT/f'evidence/source-object-properties/{page:03d}_{key}.json'
    if not cached.exists():
     extract={'page':page,'object':name}
     kind=key.split('_')[0]
     color_specs={'SP':(['图案颜色 :','颜色 :'],'图片'),'AB':(['外框颜色 :','背景颜色 :'],'报警'),'DC':(['颜色 :'],'图片'),'TX':(['颜色 :'],'文字/批注'),'DW':(['颜色 :'],' 形状')}
     if kind in color_specs:extract.update(colors=color_specs[kind][0],color_tab=color_specs[kind][1])
     call('uia',h,json.dumps({'extract':extract},ensure_ascii=False))
    report['completed'].append({'page':page,'object':key});persist()
    print(str(page)+' '+key+' cached',flush=True)
  report['ok']=True;persist()
 except Exception as e:report['error']=str(e);persist();raise
 finally:lock.unlink(missing_ok=True)
if __name__=='__main__':run()
