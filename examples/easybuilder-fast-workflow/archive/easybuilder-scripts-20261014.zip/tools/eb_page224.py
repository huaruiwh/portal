import json,time
from eb_rebuild_page import ROOT
from eb_page203_rewrite import plan,TITLES
from eb_object_ui import target,properties,save
from eb_native_form import tab,fields,confirm,commit_text,typed_children
from eb_page26_shapes import cancel
from eb_live_fields import capture
from eb_original_style_existing import verify_fields
from pywinauto.controls.win32_controls import ComboBoxWrapper

def run(h,q):
 if q.get('page224_clone'):
  from eb_clone221_to224 import run as clone
  return clone(h,{'page224':'clone'})
 root,w=target(h,224)
 for key in q['page224_controls']:
  rp=ROOT/f'evidence/target-224-{key}-rewritten.json'
  if rp.exists()and json.loads(rp.read_text(encoding='utf8')).get('binding_fields_verified'):continue
  s=json.loads((ROOT/f'evidence/source-object-properties/224_{key}.json').read_text(encoding='utf8'));b=json.loads((ROOT/f'evidence/source-object-properties/221_{key}.json').read_text(encoding='utf8'))
  edits,unknown=plan(s,b)
  for u in list(unknown):
   if u['scope']in ('一般属性','项目选单','源数据')and u['identity']in [('ComboBox','设备 :'),('ComboBox',' Down')]:
    edits.append({'scope':u['scope'],'state':None,'rows':[r for r in s['tabs'][u['scope']]if (r['type'],r['name'])==u['identity']]});unknown.remove(u)
  inherited_differences=unknown # User requested text/address only: retain221 nonbinding settings and record differences.
  forced=[]
  for scope in ('一般属性','项目选单','源数据'):
   for ident in [('ComboBox','设备 :'),('ComboBox',' Down'),('Edit','Static')]:
    rows=[r for r in s['tabs'].get(scope,[])if (r['type'],r['name'])==ident]
    if not rows:continue
    edits=[e for e in edits if not(e['scope']==scope and any((r['type'],r['name'])==ident for r in e['rows']))]
    forced.append({'scope':scope,'state':None,'rows':rows})
  edits=forced+edits
  edits.sort(key=lambda e:0 if any(r['name']=='设备 :'for r in e['rows'])else 1 if any(r['name']==' Down'for r in e['rows'])else 2)
  d,_=properties(root,w,key,TITLES[key.split('_')[0]])
  try:
   from eb_font_policy import apply as font_policy
   font_policy(d,s)
   for e in edits:
    tab(d,e['scope'])
    if e['state']is not None:
     cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :'];ComboBoxWrapper(cs[0].handle).select(e['state']);time.sleep(.2)
    if e['scope']in ('文字/批注','标签'):commit_text(d,e['rows'][0]['name'],e['rows'][0]['value'])
    else:fields(d,e['rows'],commit_edits=True)
   # Keep the saved221 layout; clipboard placement must not move controls.
   g=json.loads((ROOT/f'evidence/target-221-{key}-built.json').read_text(encoding='utf8'))['geometry']
   tab(d,'轮廓');fields(d,[{'type':'Edit','name':n,'value':v}for n,v in g.items()],commit_edits=True)
   confirm(d);d=None;save(root)
  finally:
   if d is not None:cancel(d)
  d,_=properties(root,w,key,TITLES[key.split('_')[0]])
  try:
   for e in edits:
    tab(d,e['scope'])
    if e['state']is not None:
     cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :'];ComboBoxWrapper(cs[0].handle).select(e['state']);time.sleep(.2)
    verify_fields(capture(d,[(r['type'],r['name'])for r in e['rows']]),e['rows'])
   from eb_font_policy import apply as font_policy
   font_policy(d,s,verify_only=True)
   tab(d,'轮廓');verify_fields(capture(d,[('Edit',n)for n in g]),[{'type':'Edit','name':n,'value':v}for n,v in g.items()])
  finally:cancel(d)
  rp.write_text(json.dumps({'page':224,'key':key,'template_page':221,'geometry':g,'edits':edits,'inherited_nonbinding_differences':inherited_differences,'binding_fields_verified':True,'saved_reopened_verified':True,'original_text_preserved':True,'runtime_verified':False},ensure_ascii=False,indent=2),encoding='utf8')
