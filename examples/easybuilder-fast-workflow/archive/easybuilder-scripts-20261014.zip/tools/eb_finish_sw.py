"""Verify and finish an already placed SW object without creating a duplicate."""
import json,time,re
from pathlib import Path
from pywinauto import Desktop
from pywinauto.controls.win32_controls import EditWrapper,ComboBoxWrapper,ButtonWrapper
from pywinauto.keyboard import send_keys
ROOT=Path(__file__).resolve().parent.parent
def run(handle,request):
    begin=time.monotonic();page=int(request['page']);n=int(request['finish_sw'])
    from eb_template_guard import validate_object
    validate_object(page,'SW',n)
    src=json.loads((ROOT/'evidence'/'source-object-properties'/f'{page:03d}_SW_{n}.json').read_text(encoding='utf8'))
    g=src['tabs']['一般属性'];constant=next(c['value'] for c in g if c['type']=='Edit' and c['name']=='设置常数 :')
    addresses=[c['value'] for c in g if c['type']=='Edit' and c['name']=='Static']
    from eb_layout import geometry as adapt_geometry
    geometry=adapt_geometry(src)
    main=Desktop(backend='win32').window(handle=handle).wrapper_object();pid=main.process_id()
    if '组装机_MT8106iP.emtp' not in main.window_text() or f'[{page} - ' not in main.window_text():raise ValueError('Expected target page')
    w=Desktop(backend='uia').window(handle=handle).wrapper_object()
    trees=[c for c in w.descendants(control_type='Tree') if c.is_visible()]
    if len(trees)!=1:raise ValueError('Unique directory required')
    tree=trees[0]
    def find():return [c for c in tree.descendants(control_type='TreeItem') if c.window_text().startswith(f'SW_{n} ')]
    objects=find()
    if not objects:
        headers=[c for c in tree.descendants(control_type='TreeItem') if re.match(r'^'+str(page)+r'\s*:',c.window_text())]
        if len(headers)!=1:raise ValueError('Unique page header required')
        try:headers[0].expand()
        except Exception:
            from pywinauto import mouse
            r=headers[0].rectangle();main.set_focus();mouse.click(coords=(r.left-14,(r.top+r.bottom)//2));time.sleep(.1)
        objects=find()
    if len(objects)!=1:raise ValueError('Existing object required; refusing to recreate')
    name=objects[0].window_text()
    if re.sub(r'\s*\(最下层\)$','',name)!=re.sub(r'\s*\(最下层\)$','',src['object']):raise ValueError('Tree address mismatch')
    main.set_focus();objects[0].double_click_input(coords=(40,objects[0].rectangle().height()//2))
    ds=[]
    for _ in range(20):
        ds=[d for d in Desktop(backend='win32').windows() if d.process_id()==pid and d.window_text()=='多状态设置的属性' and d.is_visible()]
        if len(ds)==1:break
        time.sleep(.1)
    if len(ds)!=1:raise ValueError('Properties not ready')
    native=ds[0];controls=native.descendants()
    def byid(i):return sorted([c for c in controls if c.control_id()==i and c.is_visible()],key=lambda c:c.rectangle().top)
    actual={'constant':EditWrapper(byid(1156)[0].handle).window_text(),'addresses':[EditWrapper(c.handle).window_text() for c in byid(2510)],'devices':[ComboBoxWrapper(c.handle).selected_text() for c in byid(1646)],'notification':ButtonWrapper(byid(1856)[0].handle).get_check_state(),'on':ButtonWrapper(byid(1887)[0].handle).get_check_state(),'after_write':ButtonWrapper(byid(1864)[0].handle).get_check_state()}
    if actual['constant']!=constant or actual['addresses']!=addresses or actual['devices']!=['Local HMI','Local HMI'] or any(actual[k]!=1 for k in ('notification','on','after_write')):raise ValueError('General readback mismatch: '+str(actual))
    d=Desktop(backend='uia').window(handle=native.handle).wrapper_object()
    from eb_press_safety import apply as apply_safety
    apply_safety(d,src)
    labels={}
    if any(c.get('value','').strip() for state in src.get('label_states',{}).values() for c in state if c['type']=='Edit' and c['name']==''):
        from eb_extract import rows
        label_tabs=[c for c in d.descendants(control_type='TabItem') if c.window_text()=='标签']
        if len(label_tabs)!=1:raise ValueError('Unique label tab required')
        label_tabs[0].select()
        state_controls=[c for c in d.descendants(control_type='ComboBox') if c.window_text()=='状态 :' and c.is_visible()]
        if len(state_controls)!=1:raise ValueError('Unique label state control required')
        for state in ('0','1'):
            ComboBoxWrapper(state_controls[0].element_info.handle).select(state);labels[state]=rows(d)
            source_text=next(c['value'] for c in src['label_states'][state] if c['type']=='Edit' and c['name']=='')
            actual_text=next(c['value'] for c in labels[state] if c['type']=='Edit' and c['name']=='')
            if actual_text!=source_text:raise ValueError('Existing labelled button text mismatch')
    tabs=[c for c in d.descendants(control_type='TabItem') if c.window_text()=='轮廓']
    if len(tabs)!=1:raise ValueError('Geometry tab required')
    tabs[0].select();fields=d.descendants(control_type='Edit');actual_geometry={}
    for key,value in geometry.items():
        cs=[c for c in fields if c.window_text()==key and c.is_visible()]
        if len(cs)!=1:raise ValueError('Unique geometry field required')
        e=EditWrapper(cs[0].handle);e.set_edit_text(value);actual_geometry[key]=e.window_text()
        if actual_geometry[key]!=value:raise ValueError('Geometry mismatch')
    ok=[c for c in native.descendants() if c.control_id()==1 and c.class_name()=='Button' and c.is_visible()]
    if len(ok)!=1:raise ValueError('Unique native OK required')
    ButtonWrapper(ok[0].handle).send_message_timeout(0x00F5,timeout=2);main.set_focus();send_keys('^s',pause=.01)
    (ROOT/'evidence'/f'target-{page:03d}-SW{n}-built.json').write_text(json.dumps({'page':page,'source':src['object'],'target':name,'general':actual,'geometry':actual_geometry,'labels':labels,'elapsed_seconds':round(time.monotonic()-begin,3),'saved_requested':True,'appearance_review_pending':True},ensure_ascii=False,indent=2),encoding='utf8')
