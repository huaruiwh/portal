"""Build the first three original201 buttons from saved templates, then cached copies."""
import json,re,time
from pywinauto.controls.win32_controls import ComboBoxWrapper
from pywinauto.keyboard import send_keys
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save
from eb_open_page import run as open_page
from eb_native_copy import copy_control
from eb_copy_200_style_object import read_audit,native_clipboard_data,restore_native_clipboard
from eb_native_form import tab,fields,confirm,typed_children
from eb_original_style_existing import form_rows,verify_fields
from eb_page26_shapes import cancel
from eb_layout import geometry
from eb_page208 import shape,write
from eb_timing import timed

TITLE='位状态切换开关/位状态指示灯的属性'

@timed
def quick_capture(d,name,wants):
    from eb_native_id_fields import read
    from eb_live_fields import capture
    schema=json.loads((ROOT/'evidence/button-native-field-schema.json').read_text(encoding='utf8'))[name]
    native=read(d,schema)
    keys={(r['type'],r['name'])for r in native}
    missing=[v for v in dict.fromkeys(wants)if v not in keys]
    rows=native+capture(d,missing) if missing else native
    return [r for r in rows if (r['type'],r['name'])in wants]

@timed
def quick_edit(d,name,rows,commit_edits=False):
    from eb_native_id_fields import write_edits
    if name=='一般属性':
        first=[r for r in rows if r['type']=='ComboBox'and r['name']in ('设备 :',' Down')]
        if first:fields(d,first)
        rows=[r for r in rows if r not in first]
    schema=json.loads((ROOT/'evidence/button-native-field-schema.json').read_text(encoding='utf8'))[name]
    rest=write_edits(d,schema,rows,commit_edits=commit_edits,native_messages=not commit_edits)
    if rest:fields(d,rest,commit_edits=commit_edits)
def sig(rs):return [(r['type'],r['name'],r['value'])for r in rs if'value'in r]
def run(handle,q):
    n=int(q['page201_button'])
    if n not in range(15):raise ValueError('Only original201 TS0..14 supported')
    started=time.perf_counter();key=f'TS_{n}'
    stage_seconds={};last=started
    def stamp(name):
        nonlocal last
        now=time.perf_counter();stage_seconds[name]=now-last;last=now
    if q.get('discard_pending_preview'):
        if n!=2:raise ValueError('Only unverified preview TS_2 cleanup allowed')
        phase=ROOT/'evidence/target-201-TS2-copy-phase.json'
        state=json.loads(phase.read_text(encoding='utf8'))
        if state.get('stage')!='pasted' or (ROOT/'evidence/target-201-TS2-built.json').exists():raise ValueError('Saved or unknown object; cleanup refused')
        root,w=target(handle,201)
        if not root.is_enabled():raise ValueError('Modal dialog present; cleanup refused')
        before=read_audit(handle,201)
        if before['target_count']!=19 or 'TS_2'in before['missing']:raise ValueError('Expected unverified19th control only')
        d,_=properties(root,w,'TS_2',TITLE);cancel(d);root.set_focus();send_keys('{DELETE}',pause=.01);time.sleep(.2)
        after=read_audit(handle,201)
        if after['target_count']!=18 or 'TS_2'not in after['missing']or after['unexpected']:raise ValueError('Cleanup count mismatch')
        save(root);state.update(stage='removed-unverified-preview',reason='Original1second/Cpermission safety adapter not yet verified');write(phase,state)
        write(ROOT/'evidence/page201-buttons-preview-workflow.json',{'page':201,'verified':['TS_0','TS_1'],'status':'saved-preview-awaiting-user','remaining':34,'pending':'TS_2 original1second/C permission adapter'})
        return
    if q.get('inspect_open_safety')or q.get('inspect_open_general'):
        from eb_object_ui import dialog
        from pywinauto import Desktop
        root,w=target(handle,201)
        popups=[win for win in Desktop(backend='win32').windows(process=root.process_id())if win.is_visible()and win.class_name().startswith('Qt5QWindowPopup')]
        if popups:send_keys('{ESC}',pause=.01)
        d=dialog(root.process_id(),TITLE)
        write(ROOT/('evidence/page201-button-general-pending.json'if q.get('inspect_open_general')else 'evidence/page201-button-safety-current.json'),__import__('eb_extract').rows(d))
        cancel(d);return
    if q.get('inspect_current'):
        root,w=target(handle,201);d,_=properties(root,w,key,TITLE)
        try:
            tab(d,'安全' if q.get('inspect_safety')else '一般属性')
            write(ROOT/f'evidence/page201-{key}-general-current.json',__import__('eb_extract').rows(d))
            if q.get('probe_duration'):
                cs=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name==' Down'and c.is_visible()]
                if len(cs)!=1:raise ValueError('Unique duration combo required')
                box=cs[0].rectangle();cs[0].click_input(coords=(box.width()-12,box.height()//2));time.sleep(.1)
                from eb_popup_local_ocr import observe
                _,ocr=observe(root.process_id());write(ROOT/'evidence/page201-duration-options.json',ocr)
                send_keys('{ESC}',pause=.01)
        finally:cancel(d)
        return
    report=ROOT/f'evidence/target-201-TS{n}-built.json';phase=ROOT/f'evidence/target-201-TS{n}-copy-phase.json'
    if report.exists() and json.loads(report.read_text(encoding='utf8')).get('saved_reopened_verified'):return
    s=json.loads((ROOT/f'evidence/source-object-properties/201_{key}.json').read_text(encoding='utf8'))
    base=json.loads((ROOT/'evidence/source-object-properties/201_TS_0.json').read_text(encoding='utf8'))
    picture_changed=s.get('picture_identity')!=base.get('picture_identity')
    colors_changed=s.get('state_colors')!=base.get('state_colors')
    if not q.get('batch_template') and ((colors_changed and n!=6)or (picture_changed and (n<4 or s['picture_identity']['family']!=base['picture_identity']['family']))):raise ValueError('Button appearance differs; first-template adaptation needed')
    security_changed=sig(s['tabs']['安全'])!=sig(base['tabs']['安全'])
    template_key='TS_0'
    if n>=4:
        matches=[]
        for candidate in range(n):
            rp=ROOT/f'evidence/target-201-TS{candidate}-built.json'
            sp=ROOT/f'evidence/source-object-properties/201_TS_{candidate}.json'
            if not rp.exists()or not sp.exists()or not json.loads(rp.read_text(encoding='utf8')).get('saved_reopened_verified'):continue
            cached=json.loads(sp.read_text(encoding='utf8'))
            if sig(cached['tabs']['安全'])==sig(s['tabs']['安全'])and cached.get('state_colors')==s.get('state_colors'):
                def address_type(v):return [(r['name'],r['value'])for r in v['tabs']['一般属性']if r['type']=='ComboBox'and r['name']in ('设备 :',' Down')]
                matches.append((cached.get('picture_identity')==s.get('picture_identity'),address_type(cached)==address_type(s),candidate,cached))
        if matches:
            _,_,candidate,cached=max(matches,key=lambda v:v[:3])
            template_key=f'TS_{candidate}';security_changed=False
            picture_changed=cached.get('picture_identity')!=s.get('picture_identity')
    if q.get('batch_template'):
        template_key=q['batch_template']
        candidate=json.loads((ROOT/f'evidence/source-object-properties/201_{template_key}.json').read_text(encoding='utf8'))
        proof=json.loads((ROOT/f'evidence/target-201-{template_key.replace("_","")}-built.json').read_text(encoding='utf8'))
        if not proof.get('saved_reopened_verified') or candidate.get('picture_identity')!=s.get('picture_identity') or candidate.get('state_colors')!=s.get('state_colors') or sig(candidate['tabs']['安全'])!=sig(s['tabs']['安全']):raise ValueError('Batch template must exactly match verified appearance and safety')
        security_changed=False;picture_changed=False;colors_changed=False
    if any(r['name']=='触发宏指令' and r.get('value')!=0 for r in s['tabs']['一般属性']):raise ValueError('Macro forbidden')
    if n and not json.loads((ROOT/'evidence/target-201-TS0-built.json').read_text(encoding='utf8')).get('saved_reopened_verified'):raise ValueError('First201 button must be verified')
    open_page(handle,{'open_target_page':201});root,w=target(handle,201)
    if phase.exists() and q.get('retry_removed'):
        prior=json.loads(phase.read_text(encoding='utf8'))
        a=read_audit(handle,201)
        if prior.get('stage')!='removed-unverified-preview' or key not in a['missing'] or a['target_count']!=18 or a['unexpected']:
            raise ValueError('Removed-preview recovery requires exact saved18-object directory')
        write(ROOT/'evidence/target-201-TS2-removed-phase-history.json',prior)
        phase.unlink()
    if phase.exists():
        state=json.loads(phase.read_text(encoding='utf8'))
        if state.get('stage') not in ('pasted','saved-unverified'):raise ValueError('Unknown paste stage; inspect instead of repasting')
    else:
        a=q.get('_batch_audit') or read_audit(handle,201)
        if key not in a['missing']:raise ValueError('Button already present; no duplicate paste')
        basepage=200 if n==0 else 201
        open_page(handle,{'open_target_page':basepage});root,w=target(handle,basepage)
        begin=time.perf_counter();data=copy_control(root,w,template_key);copy_seconds=time.perf_counter()-begin
        open_page(handle,{'open_target_page':201});root,w=target(handle,201)
        try:equal=native_clipboard_data()==data
        except ValueError:equal=False
        if not equal:restore_native_clipboard(data)
        state={'stage':'paste-requested','key':key,'template':f'{basepage}/{template_key}','copy_seconds':copy_seconds,'first_attempt_started_epoch':time.time()-(time.perf_counter()-started)};write(phase,state)
        root.click_input(coords=(963,367));send_keys('^v',pause=.01);time.sleep(.2);send_keys('{ESC}',pause=.01)
        if not q.get('_batch_audit'):
            a=read_audit(handle,201)
            if a['target_count']!=17+n or key in a['missing']:raise ValueError('Unexpected copy count; inspect trial journal')
        else:
            # Exact new key is resolved by properties immediately below; no count assumption.
            properties_root,properties_window=target(handle,201)
            root,w=properties_root,properties_window
        state['stage']='pasted';write(phase,state)
    recovering_saved=state.get('stage')=='saved-unverified'
    d,_=properties(root,w,key,TITLE)
    stamp('prepare_copy_paste_open')
    general_write_rows=s['tabs']['一般属性'];template_report=None;template_source=None
    if n>=6:
        template_report=json.loads((ROOT/f'evidence/target-201-{template_key.replace("_","")}-built.json').read_text(encoding='utf8'))
        template_source=json.loads((ROOT/f'evidence/source-object-properties/201_{template_key}.json').read_text(encoding='utf8'))
        known={(r['type'],r['name'],str(r['value']))for r in template_report['general']if'value'in r}
        general_write_rows=[r for r in general_write_rows if'value'in r and (r['type'],r['name'],str(r['value']))not in known]
    tab(d,'一般属性');quick_edit(d,'一般属性',general_write_rows,commit_edits=True)
    stamp('general_write')
    if (n==0 and not recovering_saved) or security_changed:
        tab(d,'安全')
        if n>=6 and template_source is not None:
            inherited={(r['type'],r['name'],str(r['value']))for r in template_source['tabs']['安全']if'value'in r}
            changed=[r for r in s['tabs']['安全']if'value'in r and (r['type'],r['name'],str(r['value']))not in inherited]
            fields(d,changed,skip=(('ComboBox',' Down'),))
        else:
            fields(d,[r for r in s['tabs']['安全']if r['name']=='使用寄存器状态/数值'])
            fields(d,[r for r in s['tabs']['安全']if r['name']=='用户限制 Down'])
            fields(d,s['tabs']['安全'],skip=(('ComboBox',' Down'),))
        durations=[r['value']for r in s['tabs']['安全']if r['type']=='ComboBox'and r['name']==' Down']
        combos=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name==' Down'and c.is_visible()]
        if len(durations)>1 or (durations and len(combos)!=1):raise ValueError('Unique minimum press duration required')
        from eb_live_fields import capture
        current=capture(d,[('ComboBox',' Down')])[0]['value']if durations else None
        if durations and current!=durations[0]:
            if durations[0]not in ('0.1','1'):raise ValueError('Unreviewed minimum press duration')
            combos[0].expand()
            options=[c for c in combos[0].descendants(control_type='ListItem')if c.element_info.name==durations[0]and c.is_visible()]
            if len(options)!=1:raise ValueError('Unique visible duration option required')
            options[0].click_input()
            if capture(d,[('ComboBox',' Down')])[0]['value']!=durations[0]:raise ValueError('Fresh minimum press readback mismatch')
    stamp('safety_write')
    if (n==0 and not recovering_saved)or picture_changed:
        tab(d,'图片');fields(d,[r for r in s['tabs']['图片']if r['type']=='CheckBox'])
        from eb_picture_family import choose
        choose(d,root.process_id(),'Button - Flat',standard_index=s['picture_identity']['index'],readback_fn=form_rows)
    labels={};tab(d,'标签')
    label_flags=[r for r in s['tabs']['标签']if r['type']=='CheckBox']
    if template_source is None or sig(label_flags)!=sig([r for r in template_source['tabs']['标签']if r['type']=='CheckBox']):fields(d,label_flags)
    from eb_label_commit import commit
    texts=[next(r['value']for r in s['label_states'][value]if r['type']=='Edit' and r['name']=='')for value in ('0','1')]
    if n==0 and not recovering_saved:
        cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']
        if len(cs)!=1:raise ValueError('Unique button state required')
        for value in ('0','1'):
            ComboBoxWrapper(cs[0].handle).select(value)
            font=[]
            for r in s['label_states'][value]:
                if 'value'not in r or r['type']not in ('ComboBox','CheckBox') or r['name']=='状态 :':continue
                row=dict(r)
                if row['name']=='字体 :':row['value']='微软正黑体 Light'
                if row['name']=='尺寸 :':row['value']='13'
                font.append(row)
            fields(d,font)
    commit(d,texts)
    changed_colors=[]
    if colors_changed:
        from eb_color_picker import set_rgb
        prior=template_source['state_colors']if template_source else base['state_colors']
        for name,states in s['state_colors'].items():
            for value,colors in states.items():
                changed_colors.extend((name,value,label,rgb)for label,rgb in colors.items()if prior.get(name,{}).get(value,{}).get(label)!=rgb)
        for name,value,label,rgb in changed_colors:
            tab(d,name);stateboxes=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']
            if len(stateboxes)!=1:raise ValueError('Unique color state required')
            ComboBoxWrapper(stateboxes[0].handle).select(value);set_rgb(d,rgb,label)
    if n==0 and not recovering_saved:
        from eb_color_picker import set_rgb,probe
        for name in ('图片','标签'):
            tab(d,name);states=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']
            for value in ('0','1'):
                ComboBoxWrapper(states[0].handle).select(value)
                for label,rgb in s['state_colors'][name][value].items():
                    set_rgb(d,rgb,label)
                    if probe(d,label)!=rgb:raise ValueError('Button color write mismatch')
    stamp('appearance_labels_write')
    tab(d,'轮廓');bounds=geometry(s);quick_edit(d,'轮廓',[{'type':'Edit','name':k,'value':v}for k,v in bounds.items()])
    confirm(d);save(root);state['stage']='saved-unverified';write(phase,state)
    stamp('geometry_confirm_save')
    d,_=properties(root,w,key,TITLE)
    try:
        tab(d,'一般属性')
        from eb_live_fields import capture
        general=quick_capture(d,'一般属性',[(r['type'],r['name']) for r in s['tabs']['一般属性']if'value'in r]);verify_fields(general,[r for r in s['tabs']['一般属性']if'value'in r])
        tab(d,'标签');cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']
        for value,want in zip(('0','1'),texts):
            ComboBoxWrapper(cs[0].handle).select(value);rs=quick_capture(d,'标签',[('Edit',''),('ComboBox','字体 :'),('ComboBox','尺寸 :')])
            verify_fields(rs,[{'type':'Edit','name':'','value':want},{'type':'ComboBox','name':'字体 :','value':'微软正黑体 Light'},{'type':'ComboBox','name':'尺寸 :','value':'13'}]);labels[value]=want
        if n==0 or security_changed:
            tab(d,'安全');verify_fields(capture(d,[(r['type'],r['name']) for r in s['tabs']['安全']if'value'in r]),[r for r in s['tabs']['安全']if'value'in r])
        if n==0 or picture_changed:
            tab(d,'图片');rs=form_rows(d)
            if not any(r['type']=='Text'and r['name']=='Button - Flat'for r in rs):raise ValueError('Button family mismatch')
            from eb_color_picker import probe
            for name in ('图片','标签'):
                tab(d,name);states=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']
                for value in ('0','1'):
                    ComboBoxWrapper(states[0].handle).select(value)
                    for label,rgb in s['state_colors'][name][value].items():
                        if probe(d,label)!=rgb:raise ValueError('Saved button color mismatch')
        if changed_colors:
            from eb_color_picker import probe
            for name,value,label,rgb in changed_colors:
                tab(d,name);states=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']
                if len(states)!=1:raise ValueError('Unique saved color state required')
                ComboBoxWrapper(states[0].handle).select(value)
                if probe(d,label)!=rgb:raise ValueError('Saved changed color mismatch')
        tab(d,'轮廓');actual={r['name']:r['value']for r in quick_capture(d,'轮廓',[('Edit',v)for v in bounds])}
        if actual!=bounds:raise ValueError('Saved button bounds mismatch')
    finally:cancel(d)
    stamp('reopen_verify_cancel')
    write(report,{'page':201,'key':key,'template':state['template'],'saved_reopened_verified':True,'labels':labels,'shape':actual,'general':general,'picture_identity':s['picture_identity'],'state_colors':s['state_colors'],'safety_verified_or_inherited':True,'font':'微软正黑体 Light','font_size':13,'copy_seconds':state.get('copy_seconds'),'elapsed_seconds':time.perf_counter()-started,'runtime_verified':False,'field_read_method':'learned-native-identity-plus-Qt-fallback'})
    state['stage']='verified';write(phase,state)
    completed=json.loads(report.read_text(encoding='utf8'));completed.update(stage_seconds=stage_seconds,safety_template_exact_match=not security_changed,first_attempt_started_epoch=state.get('first_attempt_started_epoch'),finished_epoch=time.time());write(report,completed)
    if n>=6:
        completed.update(general_write_mode='verified-template-delta',general_written_keys=[(r['type'],r['name'])for r in general_write_rows],general_verified_after_save='all original general fields');write(report,completed)
