"""Collect complete page202 source directory across visible tree viewports."""
import json,re,time
from pywinauto import Desktop,mouse
from pywinauto.keyboard import send_keys
from eb_extract import ROOT

def run(handle,q):
 page=int(q.get("inventory_page202_full",202));
 if page not in (201,202,203,204,205,206,208,210,212,213,214,215,216,217,218,219,220,221,209,222,223,224,225,226,228,229,230,231,232,235,236,237,302,313):raise ValueError("Unapproved source page")
 w=Desktop(backend='uia').window(handle=handle).wrapper_object();root=Desktop(backend='win32').window(handle=handle).wrapper_object()
 if not root.window_text().endswith('.cmtp - [202 - '+chr(20027)+chr(30028)+chr(38754)+']') and '.cmtp' not in root.window_text():raise ValueError('Source only')
 root.set_focus();time.sleep(.15)
 tabs=[c for c in w.descendants(control_type='TabItem') if c.window_text()=='目录树' and c.is_visible()]
 if len(tabs)==1:root.set_focus();tabs[0].click_input();time.sleep(.2)
 from eb_directory import scope
 dock=scope(w);wr=w.rectangle();ed=[c for c in dock.descendants(control_type='Edit')if c.is_visible()]
 if len(ed)!=1:raise ValueError('One source filter required')
 root.set_focus();ed[0].click_input();send_keys('^a'+str(page)+' :',with_spaces=True,pause=.01);time.sleep(.1)
 trees=[c for c in dock.descendants(control_type='Tree') if c.is_visible()]
 if len(trees)!=1:raise ValueError('One source tree required')
 tree=trees[0];rect=tree.rectangle();mouse.scroll(coords=((rect.left+rect.right)//2,(rect.top+rect.bottom)//2),wheel_dist=80);time.sleep(.15)
 def nodes():return tree.descendants(control_type='TreeItem')
 ns=nodes();headers=[c for c in ns if re.match(r'^'+str(page)+r'\s*:',c.window_text())]
 if len(headers)!=1:raise ValueError('Source202 header required')
 if f'[{page} - ' not in root.window_text():headers[0].double_click_input(coords=(40,headers[0].rectangle().height()//2));time.sleep(.2)
 try:
  if headers[0].get_expand_state()==0:headers[0].expand();time.sleep(.1)
 except Exception:pass
 if len(nodes())==1:
  headers[0].click_input(coords=(40,headers[0].rectangle().height()//2));send_keys('{RIGHT}',pause=.03);time.sleep(.2)
 current=None;objects=[];seen=set();boundary=False;stable=False;last=None;views=[]
 for i in range(40):
  names=[c.window_text() for c in nodes()];views.append(names)
  for name in names:
   m=re.match(r'^(\d+)(?:\s*:|$)',name)
   if m:
    n=int(m[1])
    if current==page and n!=page:boundary=True;break
    current=n
   elif current==page and name and name not in seen:
    if not re.search(r'(?:^|\])\s*[A-Z]+_\d+(?:\s|$)',name):raise ValueError('Unexpected source item '+name)
    seen.add(name);objects.append(name)
  if boundary:break
  sig=tuple(names)
  if sig==last:stable=True;break
  last=sig;mouse.scroll(coords=((rect.left+rect.right)//2,(rect.top+rect.bottom)//2),wheel_dist=-8);time.sleep(.12)
 if not boundary and not stable:raise ValueError('Source202 directory did not reach boundary')
 if not objects:raise ValueError('Empty source inventory')
 p=ROOT/'evidence/source-pages-inventory.json';data=json.loads(p.read_text(encoding='utf8'));record=next((x for x in data['pages'] if x['id']==page),None)
 if record is None:
  record={'id':page,'observed_name':headers[0].window_text(),'observed_objects':[]};data['pages'].append(record)
 old=record['observed_objects'];record.update(observed_objects=objects,inventory_filter_verified=True,complete_viewports_verified=True)
 (ROOT/f'evidence/page{page}-full-source-inventory.json').write_text(json.dumps({'old_count':len(old),'new_count':len(objects),'added':[x for x in objects if x not in old],'viewports':len(views),'boundary_reached':boundary,'stable_bottom':stable,'source_modified':False,'objects':objects},ensure_ascii=False,indent=2),encoding='utf8')
 p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')

