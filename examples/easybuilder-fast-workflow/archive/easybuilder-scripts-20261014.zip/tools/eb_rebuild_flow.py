"""Resume page26's reviewed bit/close/text objects, retaining local evidence."""
import json,re,sys
from eb_rebuild_page import ROOT,call

def run(page=26):
    from eb_flow_model import counts
    model=counts(page)
    lock=ROOT/'tools/batch.lock'
    with lock.open('x'):pass
    path=ROOT/f'evidence/page-{page}-workflow.json'
    progress={'page':page,'completed':[],'ok':False}
    def persist():path.write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf8')
    try:
        call('snapshot');windows=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
        def find(title):
            choices=[w['handle'] for w in windows if w['class']=='EasyBuilderPro' and title in w['title']]
            if len(choices)!=1:raise ValueError('One exact project required')
            return choices[0]
        source=find('组装机2台15工位取消.cmtp');target=find('组装机_MT8106iP.emtp')
        def ui(handle,q):call('uia',handle,json.dumps(q,ensure_ascii=False))
        ui(target,{'open_target_page':page})
        inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
        names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==page)
        for kind,count in ((kind,model[kind]) for kind in ('TS','BL','SW','TX')):
            for n in range(count):
                key=f'{kind}_{n}';progress['stage']=key;persist()
                if not (ROOT/f'evidence/target-{page:03d}-{kind}{n}-built.json').exists():
                    if kind=='TX':
                        cached=ROOT/f'evidence/source-object-properties/{page:03d}_{key}.json'
                        if 'colors' not in json.loads(cached.read_text(encoding='utf8')):
                            name=next(v for v in names if re.search(r'(?:^|\])\s*'+key+r'(?:\s|$)',v))
                            ui(source,{'extract':{'page':page,'object':name,'only_color':True,'colors':['颜色 :'],'color_tab':'文字/批注'}})
                        ui(target,{'page':page,'build_tx':n})
                    else:ui(target,{'page':page,'build_bit_general':n,'bit_kind':kind})
                progress['completed'].append(key);persist();print(json.dumps({'saved':key,'count':len(progress['completed'])}),flush=True)
        if (ROOT/f'evidence/target-{page:03d}-MS0-built.json').exists():progress['completed'].append('MS_0')
        ui(target,{'target_page_audit':page})
        progress['ok']=True;progress['stage']='saved and directory audited';persist()
    except Exception as e:progress['error']=str(e);persist();raise
    finally:lock.unlink(missing_ok=True)

if __name__=='__main__':run(int(sys.argv[1]) if len(sys.argv)>1 else 26)
