"""Collect complete page16 source directory across visible tree viewports."""
import json,re,time
from pywinauto import Desktop,mouse
from pywinauto.keyboard import send_keys
from eb_extract import ROOT

def run(handle,q):
 page=16;w=Desktop(backend='uia').window(handle=handle).wrapper_object();root=Desktop(backend='win32').window(handle=handle).wrapper_object()
 if not root.window_text().endswith('.cmtp - [16 - '+chr(20027)+chr(30028)+chr(38754)+']') and '.cmtp' not in root.window_text():raise ValueError('Source only')
 from eb_directory import scope
 dock=scope(w);wr=w.rectangle();ed=[c for c in dock.descendants(control_type='Edit') if wr.left<=c.rectangle().left and c.rectangle().right<wr.left+500 and wr.top+190<c.rectangle().top<wr.top+270]
 if len(ed)!=1:raise ValueError('One source filter required')
 root.set_focus();ed[0].click_input();send_keys('^a16 :',with_spaces=True,pause=.01);time.sleep(.1)
 trees=[c for c in dock.descendants(control_type='Tree') if c.is_visible()]
 if len(trees)!=1:raise ValueError('One source tree required')
 tree=trees[0];rect=tree.rectangle();mouse.scroll(coords=((rect.left+rect.right)//2,(rect.top+rect.bottom)//2),wheel_dist=80);time.sleep(.15)
 def nodes():return tree.descendants(control_type='TreeItem')
 ns=nodes();headers=[c for c in ns if re.match(r'^16\s*:',c.window_text())]
 if len(headers)!=1:raise ValueError('Source16 header required')
 try:
  if headers[0].get_expand_state()==0:headers[0].expand();time.sleep(.1)
 except Exception:pass
 current=None;objects=[];seen=set();boundary=False;stable=False;last=None;views=[]
 for i in range(40):
  names=[c.window_text() for c in nodes()];views.append(names)
  for name in names:
   m=re.match(r'^(\d+)(?:\s*:|$)',name)
   if m:
    n=int(m[1])
    if current==16 and n!=16:boundary=True;break
    current=n
   elif current==16 and name and name not in seen:
    if not re.search(r'(?:^|\])\s*[A-Z]+_\d+(?:\s|$)',name):raise ValueError('Unexpected source item '+name)
    seen.add(name);objects.append(name)
  if boundary:break
  sig=tuple(names)
  if sig==last:stable=True;break
  last=sig;mouse.scroll(coords=((rect.left+rect.right)//2,(rect.top+rect.bottom)//2),wheel_dist=-8);time.sleep(.12)
 if not boundary and not stable:raise ValueError('Source16 directory did not reach boundary')
 if len(objects)<53:raise ValueError('Full source inventory cannot shrink')
 p=ROOT/'evidence/source-pages-inventory.json';data=json.loads(p.read_text(encoding='utf8'));record=next(x for x in data['pages'] if x['id']==16);old=record['observed_objects'];record.update(observed_objects=objects,inventory_filter_verified=True,complete_viewports_verified=True)
 (ROOT/'evidence/page16-full-source-inventory.json').write_text(json.dumps({'old_count':len(old),'new_count':len(objects),'added':[x for x in objects if x not in old],'viewports':len(views),'boundary_reached':boundary,'stable_bottom':stable,'source_modified':False,'objects':objects},ensure_ascii=False,indent=2),encoding='utf8')
 p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
