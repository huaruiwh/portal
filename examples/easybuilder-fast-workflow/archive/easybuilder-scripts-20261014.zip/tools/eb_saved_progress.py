"""Write documentation immediately after a confirmed object save."""
import json
from datetime import datetime,timezone,timedelta
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
def record(page,key):
    e=ROOT/'evidence';path=e/'resume-checkpoint.json'
    cp=json.loads(path.read_text(encoding='utf-8-sig'))
    reports=sorted(p.name for p in e.glob(f'target-{page:03d}-*-built.json'))
    inventory=json.loads((e/'source-pages-inventory.json').read_text(encoding='utf8'))
    total=len(next(p['observed_objects'] for p in inventory['pages'] if p['id']==page))
    size=(ROOT/'output/组装机_MT8106iP.emtp').stat().st_size
    stamp=datetime.now(timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M:%S')
    cp.update(date=stamp[:10],bytes=size,batch_running=True,next=f'{page}页{key}已保存，剩余对象按built报告跳过；先核对活动控制器避免并发GUI')
    cp[f'page{page}_saved_object_reports']=reports
    path.write_text(json.dumps(cp,ensure_ascii=False,indent=2),encoding='utf8')
    marker=f'{page}:{key}'
    documented=cp.get('documented_saved_objects',[])
    if marker not in documented:
        note=f'\n{stamp}：第{page}页{key}完成原控件流程并确认保存。当前built报告{len(reports)}/{total}，EMTP {size} bytes。证据evidence/target-{page:03d}-{key}-built.json；字段读回见该报告。仅控件保存通过，整页编译与重开验收以独立报告为准。恢复先看实际弹窗及目录，禁止重复新增。\n'
        for p in (ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md'):
            with p.open('a',encoding='utf8') as f:f.write(note)
        cp['documented_saved_objects']=documented+[marker]
        path.write_text(json.dumps(cp,ensure_ascii=False,indent=2),encoding='utf8')
