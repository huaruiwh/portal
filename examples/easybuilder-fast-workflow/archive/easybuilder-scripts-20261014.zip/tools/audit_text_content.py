"""Compare literal captions locally; never infer a fresh GUI check from cache."""
import json,re
from datetime import datetime
from eb_rebuild_page import ROOT
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def normalized(value):return str(value).replace('\r\n','\n').replace('\r','\n').rstrip('\n')
def captions(rows):
    return [normalized(c['value']) for c in rows if c.get('type')=='Edit' and c.get('name') in ('','内容') and 'value' in c]
checks=[];pending=[]
for p in sorted((ROOT/'evidence/source-object-properties').glob('*.json')):
    m=re.fullmatch(r'(\d+)_(TX|TS|BL|SW|MS)_(\d+)\.json',p.name)
    if not m:continue
    page,kind,n=int(m[1]),m[2],int(m[3]);s=read(p)
    target=ROOT/f'evidence/target-{page:03d}-{kind}{n}-built.json'
    reopened=ROOT/f'evidence/target-object-properties/{page:03d}_{kind}_{n}.json'
    text_live=ROOT/f'evidence/target-text-readbacks/{page:03d}_{kind}_{n}.json'
    tabs=s.get('tabs',{})
    if kind!='TX':
        possible=[captions(v) for v in s.get('label_states',{}).values()]+[captions(tabs.get('标签',[]))]
        if not any(any(v) for v in possible):continue
    candidates=[v for v in (target,reopened,text_live) if v.exists()]
    if not candidates:pending.append({'page':page,'object':f'{kind}_{n}','reason':'no target literal readback'});continue
    t=read(max(candidates,key=lambda v:v.stat().st_mtime_ns))
    if 'tabs' in t:
        t={'text':t['tabs'].get('文字/批注',[]),'labels':t.get('label_states',{'single':t['tabs'].get('标签',[])})}
    if kind=='TX':
        expected=captions(tabs.get('文字/批注',[]));actual=captions(t.get('text',[]))
        checks.append({'page':page,'object':f'TX_{n}','state':'text','expected':expected,'actual':actual,'ok':bool(expected) and expected==actual})
        continue
    label_tab=tabs.get('标签',[])
    enabled=next((c['value'] for c in label_tab if c.get('name')=='使用文字标签' and 'value' in c),None)
    if enabled==0:continue
    source_states=s.get('label_states',{})
    target_states=t.get('labels')
    if not isinstance(target_states,dict):pending.append({'page':page,'object':f'{kind}_{n}','reason':'no caption-state readback'});continue
    states=[v for v in source_states if str(v).isdigit()] or ['0','1']
    for state in states:
        expected=captions(source_states.get(state,source_states.get('single',label_tab)))
        if not expected or not any(expected):continue
        actual=captions(target_states.get(state,target_states.get('single',[])))
        if not actual:
            pending.append({'page':page,'object':f'{kind}_{n}','state':state,'reason':'no literal caption in cached target report'})
            continue
        state_rows=target_states.get(state,target_states.get('single',[]))
        target_enabled=next((c['value'] for c in state_rows if c.get('name')=='使用文字标签' and 'value' in c),None)
        enabled_ok=enabled is None or target_enabled is None or enabled==target_enabled
        checks.append({'page':page,'object':f'{kind}_{n}','state':state,'expected':expected,'actual':actual,'enabled_verified':enabled_ok,'readback_file':str(max(candidates,key=lambda v:v.stat().st_mtime_ns).relative_to(ROOT)),'ok':expected==actual and enabled_ok})
live=[]
ui=ROOT/'evidence/uia.json'
if ui.exists():
    rows=read(ui)
    contents=[c for c in rows if c.get('type')=='Edit' and c.get('name')=='内容' and 'value' in c]
    if len(contents)==1:
        value=normalized(contents[0]['value'])
        matches=[c for c in checks if c['page']==47 and c['object']=='TX_0']
        if len(matches)==1:live=[{'page':47,'object':'TX_0','actual':value,'expected':matches[0]['expected'],'ok':[value]==matches[0]['expected'],'scope':'currently open title text buffer only; other properties untouched'}]
report={'date':datetime.now().isoformat(timespec='seconds'),'cached_checks':len(checks),'cached_passed':sum(c['ok'] for c in checks),'mismatches':[c for c in checks if not c['ok']],'pending':pending,'checks':checks,'live_checks':live,'cached_evidence_only':True,'render_clipping_verified':False,'runtime_verified':False}
(ROOT/'evidence/text-content-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in report.items() if k!='checks'},ensure_ascii=False))
