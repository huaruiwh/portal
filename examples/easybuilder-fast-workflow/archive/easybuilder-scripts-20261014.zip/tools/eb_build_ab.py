"""Recreate reviewed page17 alarm bar; explicitly retain model differences."""
import json
from eb_extract import ROOT, rows
from eb_object_ui import target, dialog, placed_properties, save
from eb_native_form import tab, fields, confirm
from eb_color_picker import set_rgb, probe
from eb_layout import geometry


def alarm_fields(source):
    selected=[]
    for row in source['tabs']['报警']:
        if row['type']=='ComboBox' and row['name']=='显示 Down':
            if row.get('value')=='跑马灯':continue
            if row.get('value')!='速度 4':raise ValueError('Unreviewed alarm speed')
            selected.append(row)
        elif row['name'] in ('显示的类别范围','透明') and 'value' in row:
            selected.append(row)
    return selected


def run(handle,q):
    page,n=int(q['page']),int(q['build_ab'])
    if (page,n) not in ((10,0),(11,0),(17,0),(103,0)):raise ValueError('Only reviewed alarm bars')
    source=json.loads((ROOT/'evidence'/'source-object-properties'/f'{page:03d}_AB_0.json').read_text(encoding='utf8'))
    if set(source.get('colors',{}))!={'外框颜色 :','背景颜色 :'}:raise ValueError('Exact alarm colors required')
    if page in (10,11):
        if (ROOT/f'evidence/target-{page:03d}-AB0-built.json').exists():raise ValueError('Saved alarm bar exists; audit instead')
        audit=json.loads((ROOT/f'evidence/target-page{page}-audit.json').read_text(encoding='utf8'))
        if 'AB_0' not in audit['missing']:raise ValueError('Fresh missing-alarm audit required')
        if not any(r['name']=='Row 1, Column 1' and r.get('value')==0 for r in source['tabs']['排序']):raise ValueError('Base alarm visible four-digit date requires review')
    root,w=target(handle,page)
    if not q.get('resume'):
        if page in (10,11,103):
            from eb_alarm_entry import run as prepare
            prepare(handle,{'page':page,'alarm_entry':'AB'})
        else:
            from eb_prepare_complex import run as prepare
            prepare(handle,{'page':page,'prepare_complex':'AB'})
    d=dialog(root.process_id(),'新增 报警条')
    captured={}
    tab(d,'报警');fields(d,alarm_fields(source))
    fields(d,[{'type':'CheckBox','name':'文字平滑移动 (可能会提高 CPU 使用率)','value':0}])
    for label,value in source['colors'].items():
        set_rgb(d,value,label)
        if probe(d,label)!=value:raise ValueError('Alarm color readback mismatch')
    captured['报警']=rows(d)
    for name in ('排序','安全','图片'):
        tab(d,name)
        skip=(('ComboBox','日期 :'),) if name=='排序' else ()
        if name=='排序' and not any(r['name']=='Row 1, Column 1' and r.get('value')==0 for r in source['tabs'][name]):
            raise ValueError('Unsupported four-digit date format cannot be skipped when visible')
        fields(d,source['tabs'][name],skip=skip);captured[name]=rows(d)
    tab(d,'字体')
    fields(d,source['tabs']['字体'],skip=(('ComboBox','字体 :'),('Edit','字体 :'),('CheckBox','字体将取自 [语言 & 字体] 的设置')))
    captured['字体']=rows(d)
    confirm(d)
    d,name=placed_properties(root,w,'AB_0','报警条的属性')
    tab(d,'轮廓');shape=geometry(source)
    fields(d,[{'type':'Edit','name':key,'value':value} for key,value in shape.items()])
    shape_readback=rows(d);confirm(d);save(root)
    report={'page':page,'source':source['object'],'target':name,'tabs':captured,
            'colors':source['colors'],'geometry':shape_readback,'saved_requested':True,
            'model_differences':['目标报警条未提供多行显示及模式选择','源日期显示关闭；目标不支持MM/DD/YYYY，保留MM/DD/YY且日期关闭','目标使用系统语言字体，字形一致性待验证','目标未提供源启用选项，行为待离线验证'],
            'vector_shape_identity_review_pending':True,'alarm_event_table_pending':True,
            'offline_simulation_verified':False}
    (ROOT/'evidence'/f'target-{page:03d}-AB0-built.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
