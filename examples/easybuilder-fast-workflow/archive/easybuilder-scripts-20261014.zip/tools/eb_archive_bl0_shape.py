"""Archive the approved square variant and current compilation evidence."""
import json
from datetime import datetime
from eb_rebuild_page import ROOT

def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8-sig'))
def write(p,v):(ROOT/p).write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8')
src=read('evidence/source-object-properties/016_BL_0.json')
dst=read('evidence/target-object-properties/016_BL_0.json')
report=read('evidence/page16-BL0-shape-correction.json')
comp=read('evidence/latest-project-compile.json')
def vals(rs,names):return [(r['type'],r['name'],r['value']) for r in rs if r['name'] in names and 'value' in r]
if vals(src['tabs']['一般属性'],{'设备 :','Static',' Down'})!=vals(dst['tabs']['一般属性'],{'设备 :','Static',' Down'}):raise ValueError('BL0 address mismatch')
shape={r['name']:r['value'] for r in dst['tabs']['轮廓'] if r['type']=='Edit'}
if any(shape[k]!=v for k,v in {'X :':'224',' Y :':'174',' 宽度 :':'136','高度 :':'47'}.items()):raise ValueError('BL0 target geometry mismatch')
if not comp['ok']:raise ValueError('Current compilation failed')
now=datetime.now().isoformat(timespec='seconds')
report.update(date=now,user_approved=True,address_verified=True,geometry_verified=True,compile=comp,source_gallery_group='1',source_vector_gallery_group='0',cause='Identical family and dimensions did not distinguish round group0 from square group1.')
write('evidence/page16-BL0-shape-correction.json',report)
# The read-only inspection refreshed source rows without probing colors.
# Retain the prior native RGB evidence, explicitly identified as cached.
old=read('evidence/target-016-BL0-appearance-repaired.json')
if 'state_colors' not in src and 'source_state_colors' in old:
 src['state_colors']=old['source_state_colors'];src['state_colors_provenance']='prior native source readback retained from target-016-BL0-appearance-repaired.json';write('evidence/source-object-properties/016_BL_0.json',src)
for p in ('evidence/target-016-BL0-built.json','evidence/target-016-BL0-appearance-repaired.json'):
 r=read(p);r.update(bitmap_variant='System Button - Standard / 1',bitmap_shape='square metal frame',shape_user_approved=True,shape_correction_report='evidence/page16-BL0-shape-correction.json');write(p,r)
cp=read('evidence/resume-checkpoint.json');cp.update(date=now,bytes=comp['project_bytes'],exob_bytes=comp['exob_bytes'],page16_bl0_shape=report,page16_compile_current=comp);write('evidence/resume-checkpoint.json',cp)
text=f'''\n\n### {now} 16页BL_0形状修正（用户确认）

- 问题：原件是矩形金属边框，目标是圆形图片拉伸成椭圆。源图库实际选中 System Button - Standard / 1，目标错误为 / 0；两者名称 Button - Standard 和尺寸96x96完全相同。源向量图库为 System Frame / 0，先前怀疑向量不是本次形状问题的原因。
- 解决：仅将已有BL_0图片改为图库1，保存后重开属性检查，用户回复“对了”。修正 eb_repair_page16_indicator_style.py，禁止按同名同尺寸首个匹配选择圆形0。地址M21.3读回一致，目标X224/Y174/宽136/高47保持；未新增部件。
- 当前真实编译：{comp['messages']}；警告原文：{comp['warning_details']}。EMTP {comp['project_bytes']}字节，EXOB {comp['exob_bytes']}字节；未进行运行交互验收。
- 脚本：tools/eb_bl0_shape.py，tools/eb_archive_bl0_shape.py。修复入口为串行worker uia请求 {{"bl0_shape":"select-square"}}，仅在已检查的目标图片图库打开且原件1号形状身份已核实时执行；禁止对源工程保存。完整结果 evidence/page16-BL0-shape-correction.json。
- 调试错误原文：Dialog not ready（keep_open需放在extract内部）；Unique enabled gallery required（同时启用图片和向量时有2个图库按钮，按实际上下位置区分）；TypeError: 'RECT' object is not iterable（元数据不再直接list转换RECT）。均已恢复弹窗并完成保存。局部图像仅用于本机确认同名图案，不作为常规流程。
- 下一步：其它外观和运行交互仍待验收；不要重跑新增流程。源颜色缓存明确沿用此前原生读回，未将本轮未探测颜色伪称新验证。
'''
for p in ('README.md','docs/MT8106iP重建-实现记录.md'):
 with (ROOT/p).open('a',encoding='utf8') as f:f.write(text)
print('Archived BL0 square variant; current compile ok.')
