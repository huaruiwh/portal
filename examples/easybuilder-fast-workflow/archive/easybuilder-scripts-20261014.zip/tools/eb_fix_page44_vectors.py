import json,os,re
from datetime import datetime
from eb_rebuild_page import ROOT,call
report={'date':datetime.now().isoformat(timespec='seconds'),'page':44,'requested':['BL_3','BL_4','BL_5','BL_6'],'completed':[],'ok':False,'controller_pid':os.getpid()}
path=ROOT/'evidence/page44-vector-workflow.json'
lock=ROOT/'tools/batch.lock'
read=lambda p:json.loads((ROOT/p).read_text(encoding='utf-8-sig'))
def persist():
 report['date']=datetime.now().isoformat(timespec='seconds');path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 cp=read('evidence/resume-checkpoint.json');cp.update(date=report['date'],page44_vectors=report,batch_running=not report['ok'] and 'error' not in report,controller_pid=os.getpid() if not report['ok'] and 'error' not in report else None,next='继续44页BL3-BL6向量workflow；图片剩余44、45、47；只跳过saved和reopened_rgb_verified均通过报告。')
 (ROOT/'evidence/resume-checkpoint.json').write_text(json.dumps(cp,ensure_ascii=False,indent=2),encoding='utf8')
 section=f"<!-- PAGE44-VECTOR-LIVE -->\n### {report['date']} 44页BL3—BL6原图向量修正\n\n- 请求4个控件，当前完成{report['completed']}；阶段{report.get('stage')}，ok={report['ok']}，错误={report.get('error','无')}。\n- 复用eb_flow_vector.py：源原件只读，实际向量族名、选中编号、每状态内部/外框RGB分别采集；目标禁图片、启用原向量，保存重开核对标志和两状态RGB，地址/尺寸/文字保持。BL3实查System Frame0，状态0内部97/176/254、状态1内部255/0/66，外框均0/0/255；其它各取自身原色。\n- 图库不支持选择状态UIA接口，脚本仅本地临时截图识别唯一数字Group顶部黄色选中背景，无法唯一确定就停止；不回传截图，不盲按默认编号。颜色按内部/外框CheckBox定位，避免空颜色标签。\n- 当前入口Python tools/eb_fix_page44_vectors.py；batch.lock独占，每控件实际报告evidence/page44-BL_<n>-vector-correction.json；整体运行和编译不据保存结果推断。\n<!-- /PAGE44-VECTOR-LIVE -->"
 for rel in ('README.md','docs/MT8106iP重建-实现记录.md'):
  p=ROOT/rel;t=p.read_text(encoding='utf8');pat=r'<!-- PAGE44-VECTOR-LIVE -->.*?<!-- /PAGE44-VECTOR-LIVE -->';t=re.sub(pat,lambda _:section,t,flags=re.S) if re.search(pat,t,flags=re.S) else t+'\n'+section+'\n';p.write_text(t,encoding='utf8')
with lock.open('x',encoding='utf8') as f:json.dump({'pid':os.getpid(),'task':'page44 vector originals'},f)
try:
 persist();call('snapshot');ws=read('evidence/windows.json')
 def resolve(title):
  v=[w['handle'] for w in ws if w['class']=='EasyBuilderPro' and title in w['title']]
  if len(v)!=1:raise ValueError('One project required '+title)
  return v[0]
 sh=resolve('组装机2台15工位取消.cmtp');th=resolve('组装机_MT8106iP.emtp')
 ui=lambda h,q:call('uia',h,json.dumps(q,ensure_ascii=False))
 ui(th,{'open_target_page':44})
 for n in (3,4,5,6):
  key=f'BL_{n}';report['stage']=key;persist();proof=ROOT/f'evidence/page44-{key}-vector-correction.json'
  if not proof.exists() or not read(str(proof.relative_to(ROOT))).get('reopened_rgb_verified'):
   src=read(f'evidence/source-object-properties/044_{key}.json')
   ui(sh,{'extract':{'page':44,'object':src['object'],'keep_open':True}})
   ui(sh,{'flow_vector':'source-inspect','page':44,'n':n,'build_bit_general':n})
   ui(th,{'flow_vector':'target-repair','page':44,'n':n,'build_bit_general':n})
  report['completed'].append(key);persist();print(key+' original vector/RGB saved and reopened',flush=True)
 report['ok']=True;report['stage']='four requested vectors verified; other pages pending';persist()
except Exception as e:report['error']=str(e);persist();raise
finally:lock.unlink(missing_ok=True)
from eb_fix_flow_appearances import run
run([44,45,47])
