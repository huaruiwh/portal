"""Page210-only 890x580 -> 890x469 layout adaptation.

User scope (2026-10-11): 只对210. Pages 200-208 are never re-processed, and no shared
README / 实现记录 / resume-checkpoint archive is rewritten. All state lives in
evidence/scale-890x469/page-210-workflow.json plus the per-object records under the same folder.

Run:  python tools/scale_page210.py
"""
import json,os,sys,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'tools'))
from eb_rebuild_page import call

PAGE=210
TGT_TITLE='组装机_MT8106iP.emtp'
REVIEWED=(1848,1281)
DIR=ROOT/'evidence/scale-890x469'
WF=DIR/'page-210-workflow.json'

def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
def load(p):return json.loads(p.read_text(encoding='utf8'))

def windows():
    call('snapshot')
    for _ in range(30):
        try:return [w for w in load(ROOT/'evidence/windows.json') if w.get('title')]
        except Exception:time.sleep(.1)
    raise ValueError('windows.json unreadable')

def size_of(w):return (w['rect'][2]-w['rect'][0],w['rect'][3]-w['rect'][1])

def target_handle():
    ws=windows()
    m=[w for w in ws if TGT_TITLE in w['title'] and w.get('class')=='EasyBuilderPro']
    if len(m)!=1:raise ValueError('Unique target window required (found %d)'%len(m))
    t=m[0]
    if size_of(t)!=REVIEWED:
        call('uia',t['handle'],json.dumps({'restore_target_window':True,'reviewed_size':True}))
        ws=windows();m=[w for w in ws if TGT_TITLE in w['title'] and w.get('class')=='EasyBuilderPro']
        t=m[0]
        if size_of(t)!=REVIEWED:raise ValueError('Reviewed target size required: %s'%(size_of(t),))
    return t['handle']

def main():
    lock=ROOT/'tools/batch.lock'
    with lock.open('x',encoding='utf8') as fh:fh.write(json.dumps({'pid':os.getpid(),'task':'scale210only'},ensure_ascii=False))
    out=None
    try:
        out=load(WF) if WF.exists() else {'date':time.strftime('%Y-%m-%d'),'scope':[PAGE],'finished':False,'pages':{}}
        out['scope']=[PAGE]
        out['other_pages_untouched']=[200,201,202,203,204,205,208]
        out['shared_archive_rewritten']=False
        h=target_handle()
        pp=DIR/'page-210.json'
        if not pp.exists():
            print(json.dumps({'stage':'prepare'},ensure_ascii=False),flush=True)
            call('uia',h,json.dumps({'scale_post200':{'page':PAGE,'mode':'prepare'},'build_bit_general':0}))
        p=load(pp)
        out['pages']['210']={'before':p['before'],'after':p['after'],'total':len(p['keys'])}
        write(WF,out)
        print(json.dumps({'before':p['before'],'after':p['after'],'objects':len(p['keys'])},ensure_ascii=False),flush=True)
        for i in range(0,len(p['keys']),3):
            p=load(pp)
            pending=[k for k in p['keys'][i:i+3] if k not in p['verified']]
            if not pending:continue
            for attempt in range(1,4):
                try:
                    call('uia',h,json.dumps({'scale_post200':{'page':PAGE,'keys':pending,'verify':'pre-save-readback'},'build_bit_general':0}));break
                except Exception as e:
                    if attempt==3:raise
                    print(json.dumps({'retry':pending,'attempt':attempt,'error':str(e)[-200:]},ensure_ascii=False),flush=True)
                    time.sleep(3)
            p=load(pp)
            out['pages']['210'].update({'verified':len(p['verified']),'page_size_verified':p['page_size_verified']});write(WF,out)
            print(json.dumps({'verified':len(p['verified']),'total':len(p['keys']),'mode':'fast-pre-save-readback'},ensure_ascii=False),flush=True)
        # Sampled full verification: reopen representative kinds and re-verify saved geometry and fonts.
        p=load(pp)
        sample=[k for k in ('SP_0','TB_1','TX_25','SW_0','NE_0','NE_10','NE_20','NE_30','NE_40','FK_0') if k in p['keys']]
        print(json.dumps({'stage':'sampled-verification','keys':sample},ensure_ascii=False),flush=True)
        done=[]
        for i in range(0,len(sample),3):
            batch=sample[i:i+3]
            for k in batch:
                rp=DIR/('210_%s.json'%k)
                if rp.exists():
                    rec=load(rp);rec['verified']=False;write(rp,rec)
            p=load(pp);p['verified']=[k for k in p['verified'] if k not in batch];write(pp,p)
            for attempt in range(1,4):
                try:
                    call('uia',h,json.dumps({'scale_post200':{'page':PAGE,'keys':batch},'build_bit_general':0}));break
                except Exception as e:
                    if attempt==3:raise
                    print(json.dumps({'retry_verify':batch,'attempt':attempt,'error':str(e)[-200:]},ensure_ascii=False),flush=True)
                    time.sleep(3)
            p=load(pp);done+=[k for k in batch if k in p['verified']]
            out['sampled_verified']=done;write(WF,out)
            print(json.dumps({'sampled_verified':len(done),'of':len(sample),'mode':'full-reopen'},ensure_ascii=False),flush=True)
        p=load(pp)
        if not p['page_size_verified']:
            print(json.dumps({'stage':'page-size'},ensure_ascii=False),flush=True)
            call('uia',h,json.dumps({'scale_post200':{'page':PAGE,'mode':'size'},'build_bit_general':0}))
            p=load(pp)
        out['pages']['210'].update({'verified':len(p['verified']),'page_size_verified':p.get('page_size_verified'),
                                    'bounds_verified':p.get('bounds_verified'),'directory_count_verified':p.get('directory_count_verified')})
        write(WF,out)
        print(json.dumps({'stage':'compile'},ensure_ascii=False),flush=True)
        call('uia',h,json.dumps({'compile_target':True}))
        out['compile']=load(ROOT/'evidence/latest-project-compile.json')
        out['finished']=bool(p.get('page_size_verified') and out['compile'].get('ok'))
        out['runtime_verified']=False
        write(WF,out)
        print(json.dumps({'finished':out['finished'],'messages':out['compile']['messages'],
                          'project_bytes':out['compile']['project_bytes'],'exob_bytes':out['compile']['exob_bytes']},ensure_ascii=False),flush=True)
    except Exception as e:
        out=out or {};out['error']=traceback.format_exc();write(WF,out)
        print(json.dumps({'error':str(e)[:600]},ensure_ascii=False),flush=True)
        raise
    finally:
        lock.unlink(missing_ok=True)

if __name__=='__main__':
    import shutil
    def patch_fast_geo():
        """Measured: rows() costs ~3.45s/call (293s of 797s logged). geo() needs only 4 Edit fields."""
        f=ROOT/'tools/eb_scale_post200.py'
        old=" tab(d,'轮廓');rs=rows(d)"
        new=(" tab(d,'轮廓')\n"
             " try:rs=capture(d,[('Edit',n)for n in NAMES])\n"
             " except ValueError:rs=rows(d)")
        b=f.read_bytes();bom=b[:3]==b'\xef\xbb\xbf'
        text=b.decode('utf-8-sig') if bom else b.decode('utf-8')
        if new in text:return 'already'
        n=text.count(old)
        if n!=1:raise ValueError('geo anchor count=%d; no edit made'%n)
        dst=ROOT/'backup/tools-old-name-20261011_220309/eb_scale_post200.py.before-fast-geo.bak'
        dst.parent.mkdir(parents=True,exist_ok=True)
        if not dst.exists():shutil.copy2(f,dst)
        out=text.replace(old,new)
        data=(b'\xef\xbb\xbf'+out.encode('utf-8')) if bom else out.encode('utf-8')
        tmp=f.with_suffix('.py.tmp');tmp.write_bytes(data);tmp.replace(f)
        if f.read_bytes()!=data:raise ValueError('eb_scale_post200 edit readback mismatch')
        return 'edited'
    def patch_fast_verify():
        """Fast mode: keep in-dialog readback (geometry + fonts), skip the per-object post-save reopen."""
        f=ROOT/'tools/eb_scale_post200.py'
        b=f.read_bytes();bom=b[:3]==b'\xef\xbb\xbf'
        t=b.decode('utf-8-sig') if bom else b.decode('utf-8')
        def line_with(text,frag):
            hits=[l for l in text.split('\n') if frag in l]
            if len(hits)!=1:raise ValueError('anchor %r count=%d; no edit'%(frag,len(hits)))
            return hits[0]
        def indent_of(line):return line[:len(line)-len(line.lstrip())]
        out=t
        if 'Scaled font size differs before save' not in out:
            line=line_with(out,"record['fonts_after']=fonts(d,scopes,")
            out=out.replace(line,line+'\n'+indent_of(line)
                +"if q['scale_post200'].get('verify')=='pre-save-readback' and fonts(d,scopes)!=record['fonts_after']:raise ValueError('Scaled font size differs before save: '+key)",1)
        if 'post-save reopen deferred to sampled verification' not in out:
            line=line_with(out,'for attempt in range(4):')
            ind=indent_of(line)
            block=(ind+"if q['scale_post200'].get('verify')=='pre-save-readback':\n"
                   +ind+" record['verified']=True;record['stage']='verified';record['verification']='pre-save readback in the open property dialog; post-save reopen deferred to sampled verification';put(rp,record)\n"
                   +ind+" if key not in p['verified']:p['verified'].append(key)\n"
                   +ind+" put(pp,p);continue")
            out=out.replace(line,block+'\n'+line,1)
        if out==t:return 'already'
        dst=ROOT/'backup/tools-old-name-20261011_220309/eb_scale_post200.py.before-fast-verify.bak'
        dst.parent.mkdir(parents=True,exist_ok=True)
        if not dst.exists():shutil.copy2(f,dst)
        data=(b'\xef\xbb\xbf'+out.encode('utf-8')) if bom else out.encode('utf-8')
        tmp=f.with_suffix('.py.tmp');tmp.write_bytes(data);tmp.replace(f)
        if f.read_bytes()!=data:raise ValueError('eb_scale_post200 fast-verify readback mismatch')
        return 'edited'
    print(json.dumps({'fast_geo':patch_fast_geo()},ensure_ascii=False),flush=True)
    print(json.dumps({'fast_verify':patch_fast_verify()},ensure_ascii=False),flush=True)
    main()
