"""Finish page200 same-format numerics from verified NE0, serially."""
import os,json,traceback
from eb_rebuild_page import ROOT,call
def main():
 lock=ROOT/'tools/batch.lock'
 with lock.open('x',encoding='utf8') as f:json.dump({'pid':os.getpid(),'task':'page200 numeric copies'},f)
 p=ROOT/'evidence/page200-numeric-workflow.json';d={'completed':['NE_0'],'status':'running','total':25}
 try:
  for n in range(1,25):
   d['stage']=f'NE_{n}';p.write_text(json.dumps(d,indent=2),encoding='utf8')
   report=ROOT/f'evidence/target-200-NE{n}-built.json'
   if not report.exists():call('uia',10488686,json.dumps({'copy_page200_numeric':n}))
   if not json.loads(report.read_text(encoding='utf8')).get('saved_reopened_verified'):raise ValueError('Incomplete numeric copy needs review')
   d['completed'].append(f'NE_{n}');p.write_text(json.dumps(d,indent=2),encoding='utf8')
   print(json.dumps({'saved_verified':f'NE_{n}','completed':len(d['completed'])}),flush=True)
  d['status']='25-numerics-saved-reopened'
 except Exception:d['status']='needs-review';d['error']=traceback.format_exc();print(d['error'],flush=True)
 finally:
  p.write_text(json.dumps(d,indent=2),encoding='utf8');lock.unlink(missing_ok=True)
  entry=f"\n2026-10-11：数值复制脚本 tools/build_page200_numerics.py，本轮状态{d['status']}，保存重开进度{len(d['completed'])}/25。详细断点evidence/page200-numeric-workflow.json；保留同一模板格式、键盘、安全、字体、尺寸和配色，仅改原地址并按原位置排列。\n"
  if d.get('error'):entry+='报错原文：\n```\n'+d['error']+'```\n'
  for doc in [ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md']:
   with doc.open('a',encoding='utf8') as f:f.write(entry)
  print(json.dumps({'status':d['status'],'completed':len(d['completed'])}),flush=True)
if __name__=='__main__':main()
