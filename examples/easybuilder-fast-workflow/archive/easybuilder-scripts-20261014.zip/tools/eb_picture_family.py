"""Choose source built-in picture families by exact observed gallery names."""
import time,json
from pywinauto import Desktop
from eb_object_ui import dialog
from eb_extract import ROOT,rows
from eb_native_form import tab
from eb_uia_inventory import descendants as cached_descendants

def popupitem(pid,name):
 for _ in range(20):
  cs=[]
  for win in Desktop(backend='win32').windows(process=pid):
   if win.process_id()==pid and win.is_visible() and win.class_name().startswith('Qt5QWindowPopup'):
    u=Desktop(backend='uia').window(handle=win.handle).wrapper_object();cs.extend(c for c in u.descendants(control_type='MenuItem') if c.is_visible() and c.element_info.name==name)
  if len(cs)==1:
   try:cs[0].select()
   except AttributeError:cs[0].click_input()
   time.sleep(.25);return
  time.sleep(.1)
 raise ValueError('One observed gallery menu entry required '+name)

def choose(d,pid,family,opened_menu=False,standard_index='3',readback_fn=rows):
 existing=[v for v in Desktop(backend='win32').windows(process=pid) if v.process_id()==pid and v.is_visible() and v.window_text()=='图片管理']
 if not existing:
  from eb_native_form import typed_children
  bs=[c for c in typed_children(d,'Button') if c.element_info.name=='图库...' and c.is_visible() and c.is_enabled()]
  if len(bs)!=1:raise ValueError('One enabled image gallery button required')
  bs[0].click_input()
 g=dialog(pid,'图片管理')
 Desktop(backend='win32').window(handle=g.handle).set_focus()
 category_matches=False
 if not opened_menu:
  ms=[c for c in cached_descendants(g) if c.element_info.control_type=='MenuItem' and c.is_visible() and c.element_info.name and c.rectangle().top<g.rectangle().top+150]
  if len(ms)!=1:raise ValueError('One picture category control required')
  desired={'Button - Standard':'System Button - Standard','Button - Flat':'System Button - Flat','Switch - Flat':'System Switch - Flat','Lamp - Flat':'System Lamp - Flat'}.get(family)
  category_matches=bool(desired and ms[0].element_info.name==desired)
  if not category_matches:ms[0].click_input();time.sleep(.1)
 if category_matches:index=standard_index
 elif family=='Button - Standard':popupitem(pid,'System Button');popupitem(pid,'Standard');index=standard_index
 elif family=='Button - Flat':popupitem(pid,'System Button');popupitem(pid,'Flat');index=standard_index
 elif family=='Switch - Flat':popupitem(pid,'System Switch');popupitem(pid,'Flat');index=standard_index
 elif family=='Lamp - Flat':popupitem(pid,'System Lamp');popupitem(pid,'Flat');index=standard_index
 elif family=='Selector_3_Position_Metal_Silver-Red':
  popupitem(pid,'选择开关');index=None
  for attempt in range(8):
   texts=[c for c in g.descendants(control_type='Text') if c.is_visible() and c.element_info.name==family]
   if len(texts)==1:
    tr=texts[0].rectangle()
    gs=[c for c in cached_descendants(g,'Group') if c.is_visible() and c.element_info.name.isdigit() and c.rectangle().left<=tr.left and c.rectangle().right>=tr.right and c.rectangle().top<=tr.top and c.rectangle().bottom>=tr.bottom]
    if len(gs)!=1:raise ValueError('One original-selector thumbnail required')
    index=gs[0].element_info.name;break
   cs=[c for c in cached_descendants(g,'Button') if c.is_visible() and c.element_info.name=='向下翻页']
   if len(cs)!=1:raise ValueError('One gallery page-down required')
   cs[0].click_input();time.sleep(.15)
  if index is None:raise ValueError('Original selector family absent from library')
 else:raise ValueError('Unreviewed original picture family')
 from pywinauto.keyboard import send_keys
 for _ in range(3):
  popups=[v for v in Desktop(backend='win32').windows(process=pid) if v.is_visible() and v.class_name().startswith('Qt5QWindowPopup')]
  if not popups:break
  send_keys('{ESC}');time.sleep(.1)
 g=dialog(pid,'图片管理')
 Desktop(backend='win32').window(handle=g.handle).set_focus();time.sleep(.2)
 observed=cached_descendants(g)
 groups=[c for c in observed if c.element_info.control_type=='Group' and c.is_visible() and c.element_info.name==index]
 if len(groups)!=1:raise ValueError('One source-family gallery thumbnail required '+index)
 r=groups[0].rectangle()
 from pywinauto import mouse
 mouse.click(coords=(r.left+60,r.top+70));time.sleep(.5)
 cs=[c for c in observed if c.element_info.control_type=='Button' and c.is_visible() and c.element_info.name=='确定']
 if len(cs)!=1:raise ValueError('One gallery confirmation required')
 if cs[0].element_info.handle:
  from eb_native_messages import msg
  try:msg(cs[0].element_info.handle,245)
  except TimeoutError:
   import ctypes
   for _ in range(20):
    if not ctypes.windll.user32.IsWindow(g.handle):break
    time.sleep(.1)
   else:raise
   # The original click already closed this exact gallery; do not click again.
 else:
  r=cs[0].rectangle();mouse.click(coords=((r.left+r.right)//2,(r.top+r.bottom)//2))
 tab(d,'图片');actual=readback_fn(d)
 if not any(r['type']=='Text' and r['name']==family for r in actual):
  (ROOT/'evidence/page16-picture-family-mismatch.json').write_text(json.dumps({'expected':family,'rows':actual},ensure_ascii=False,indent=2),encoding='utf8')
  raise ValueError('Original picture family readback mismatch '+family)
 return actual

def run(handle,q):
 native=Desktop(backend='win32').window(handle=handle).wrapper_object()
 pid=native.process_id();d=dialog(pid,'新增 位状态指示灯/位状态切换开关')
 if q['source_picture_family']=='probe-gallery-row':
  g=dialog(pid,'图片管理')
  Desktop(backend='win32').window(handle=g.handle).set_focus()
  if q.get('button'):
   cs=[c for c in cached_descendants(g,'Button') if c.is_visible() and c.element_info.name==q['button']]
   if len(cs)!=1:raise ValueError('One observed gallery navigation button required')
   cs[0].click_input();time.sleep(.15)
  if q.get('scroll'):
   from pywinauto import mouse
   cs=[c for c in cached_descendants(g,'Group') if c.is_visible() and c.element_info.name=='3']
   if len(cs)!=1:raise ValueError('One observed gallery group required')
   r=cs[0].rectangle();mouse.scroll(coords=((r.left+r.right)//2,(r.top+r.bottom)//2),wheel_dist=int(q['scroll']));time.sleep(.2)
  groups=[{'name':c.element_info.name,'rect':[c.rectangle().left,c.rectangle().top,c.rectangle().right,c.rectangle().bottom]} for c in g.descendants() if c.is_visible() and c.element_info.control_type in ('Group','ScrollBar')]
  (ROOT/'evidence/page16-current-gallery-probe.json').write_text(json.dumps({'rows':rows(g),'groups':groups},ensure_ascii=False,indent=2),encoding='utf8');return
 if q['source_picture_family']=='probe-observed-item':
  popupitem(pid,q['menu_item']);entries=[]
  for win in Desktop(backend='win32').windows(process=pid):
   if win.process_id()==pid and win.is_visible() and win.class_name().startswith('Qt5QWindowPopup'):
    u=Desktop(backend='uia').window(handle=win.handle).wrapper_object();entries.extend(c.element_info.name for c in u.descendants(control_type='MenuItem') if c.is_visible())
  g=dialog(pid,'图片管理')
  (ROOT/'evidence/page16-current-gallery-probe.json').write_text(json.dumps({'entries':entries,'rows':rows(g)},ensure_ascii=False,indent=2),encoding='utf8');return
 if q['source_picture_family']=='probe-control-panel':
  popupitem(pid,'System Control Panel');entries=[]
  for win in Desktop(backend='win32').windows(process=pid):
   if win.process_id()==pid and win.is_visible() and win.class_name().startswith('Qt5QWindowPopup'):
    u=Desktop(backend='uia').window(handle=win.handle).wrapper_object();entries.extend(c.element_info.name for c in u.descendants(control_type='MenuItem') if c.is_visible())
  (ROOT/'evidence/page16-control-panel-library-menu.json').write_text(json.dumps(entries,ensure_ascii=False),encoding='utf8');return
 if q['source_picture_family']=='probe-switch':
  bs=[c for c in cached_descendants(d,'Button') if c.element_info.name=='图库...' and c.is_visible() and c.is_enabled()]
  if len(bs)!=1:raise ValueError('One active picture gallery required')
  bs[0].click_input();g=dialog(pid,'图片管理')
  ms=[c for c in cached_descendants(g,'MenuItem') if c.is_visible() and c.element_info.name and c.rectangle().top<g.rectangle().top+150]
  if len(ms)!=1:raise ValueError('One active category required')
  ms[0].click_input();popupitem(pid,'System Switch')
  entries=[]
  for win in Desktop(backend='win32').windows(process=pid):
   if win.process_id()==pid and win.is_visible() and win.class_name().startswith('Qt5QWindowPopup'):
    u=Desktop(backend='uia').window(handle=win.handle).wrapper_object();entries.extend(c.element_info.name for c in u.descendants(control_type='MenuItem') if c.is_visible())
  (ROOT/'evidence/page16-switch-library-menu.json').write_text(json.dumps(entries,ensure_ascii=False),encoding='utf8')
  return
 actual=choose(d,pid,q['source_picture_family'],bool(q.get('opened_menu')))
 (ROOT/'evidence/page16-original-picture-pilot.json').write_text(json.dumps({'family':q['source_picture_family'],'rows':actual,'created_object':False},ensure_ascii=False,indent=2),encoding='utf8')
