"""Read-only background regression; preserve the existing 43-page evidence."""
import json
from datetime import datetime
from eb_rebuild_page import ROOT, call

def run():
    lock = ROOT / 'tools/batch.lock'
    with lock.open('x'): pass
    path = ROOT / 'evidence/final-background-sample.json'
    report = {'date': datetime.now().isoformat(), 'pages': [26,100,101,102,103],
              'completed': [], 'ok': False, 'readonly': True}
    def persist(): path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    try:
        call('snapshot')
        ws = json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
        candidates = [w for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
        if len(candidates)!=1: raise ValueError('Unique target required')
        w=candidates[0]; report['target_pid']=w['pid']; persist()
        for page in report['pages']:
            report['stage']=page; persist()
            call('uia',w['handle'],json.dumps({'page_settings':page,'target_readonly':True,'color_probe':True}))
            src=json.loads((ROOT/f'evidence/source-pages-settings/{page:03d}.json').read_text(encoding='utf8'))
            dst=json.loads((ROOT/f'evidence/target-pages-settings/{page:03d}.json').read_text(encoding='utf8'))
            if src['background_rgb']!=dst['background_rgb']: raise ValueError(f'Background mismatch: {page}')
            report['completed'].append({'page':page,'rgb':dst['background_rgb']}); persist()
            print(f"verified {page}: {dst['background_rgb']}",flush=True)
        call('uia',w['handle'],json.dumps({'open_target_page':16}))
        report['ok']=True; report['stage']='completed'; persist()
    except Exception as exc:
        report['error']=str(exc); persist(); raise
    finally: lock.unlink(missing_ok=True)

if __name__=='__main__': run()
