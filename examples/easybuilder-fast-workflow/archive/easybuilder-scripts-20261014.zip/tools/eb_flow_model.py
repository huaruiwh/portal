"""Validate the cached inventory before reusing the reviewed flow-page templates."""
import json,re
from collections import Counter
from eb_rebuild_page import ROOT

def counts(page):
    if page not in (*range(26,46),47,200,201,202,203,204,205,206,208,210,212,213,214,215,216,217,218,219,220,221,209,222,223,224,225,226,228,229,230,231,232,235,236,237,302,313):raise ValueError('Outside flow-page inventory')
    inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
    names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==page)
    keys=[re.search(r'(?:^|\])\s*([A-Z]+)_(\d+)',v) for v in names]
    if not all(keys):raise ValueError('Unknown source object name')
    result=Counter(k[1] for k in keys)
    if page in (209,222):
        expected={209: {'SP': 3, 'TX': 22, 'DW': 3, 'ND': 6, 'OL': 3, 'TS': 25, 'NE': 23, 'SW': 1, 'FK': 1}, 222: {'SP': 3, 'TX': 21, 'DW': 3, 'ND': 6, 'OL': 3, 'TS': 24, 'NE': 21, 'SW': 1, 'FK': 1}}[page]
        if dict(result)!=expected:raise ValueError('209/222 observed source count changed')
        return dict(result)
    if page in (223,224):
        if dict(result)!={224: {'SP': 2, 'TX': 13, 'SW': 1, 'TB': 1, 'NE': 18, 'TS': 9, 'BL': 8, 'DW': 1, 'FK': 1}, 223: {'SP': 2, 'DW': 2, 'TX': 12, 'ND': 4, 'TS': 14, 'NE': 10, 'SW': 1, 'OL': 2, 'FK': 1}}[page]:raise ValueError('223/224 complete source inventory changed')
        return dict(result)
    if page==313:
        if dict(result)!={'SP': 1, 'SW': 1, 'TX': 7, 'DW': 1, 'ND': 2, 'OL': 1, 'TS': 8, 'NE': 7, 'FK': 1}:raise ValueError('313 complete source inventory changed')
        return dict(result)
    if page==302:
        if dict(result)!={'SP': 7, 'TS': 5, 'TX': 13, 'SW': 1, 'BL': 16, 'DW': 5, 'TB': 2, 'NE': 4, 'FK': 1}:raise ValueError('302 complete source inventory changed')
        return dict(result)
    if page==237:
        if dict(result)!={'SP': 2, 'SW': 1, 'TX': 15, 'ND': 4, 'OL': 2, 'TS': 17, 'NE': 16, 'DW': 2, 'FK': 1}:raise ValueError('237 complete source inventory changed')
        return dict(result)
    if page==236:
        if dict(result)!={'SP': 2, 'TX': 15, 'ND': 4, 'OL': 2, 'TS': 17, 'NE': 16, 'DW': 2, 'SW': 1, 'FK': 1}:raise ValueError('236 complete source inventory changed')
        return dict(result)
    if page==235:
        if dict(result)!={'SP': 2, 'TS': 2, 'BL': 6, 'TB': 1, 'TX': 6, 'DW': 1, 'NE': 4, 'FK': 1, 'SW': 1}:raise ValueError('235 complete source inventory changed')
        return dict(result)
    if page==232:
        if dict(result)!={'SP': 4, 'TS': 2, 'TX': 10, 'DW': 2, 'SW': 1, 'BL': 12, 'TB': 2, 'NE': 4, 'FK': 1}:raise ValueError('232 complete source inventory changed')
        return dict(result)
    if page==231:
        if dict(result)!={'SP': 3, 'TX': 13, 'TS': 10, 'DW': 2, 'SW': 1, 'TB': 1, 'NE': 11, 'ND': 2, 'OL': 1, 'BL': 16, 'FK': 1}:raise ValueError('231 complete source inventory changed')
        return dict(result)
    if page==230:
        if dict(result)!={'SP': 3, 'TX': 16, 'TS': 13, 'DW': 2, 'SW': 1, 'TB': 1, 'NE': 17, 'ND': 2, 'OL': 1, 'BL': 16, 'FK': 1}:raise ValueError('230 complete source inventory changed')
        return dict(result)
    if page==229:
        if dict(result)!={'SP': 3, 'TS': 16, 'TX': 19, 'DW': 2, 'SW': 1, 'BL': 16, 'TB': 1, 'NE': 23, 'ND': 2, 'OL': 1, 'FK': 1}:raise ValueError('229 complete source inventory changed')
        return dict(result)
    if page in (226,228):
        if dict(result)!={226: {'SP': 2, 'DW': 2, 'SW': 1, 'TX': 12, 'ND': 4, 'TS': 14, 'NE': 10, 'OL': 2, 'FK': 1}, 228: {'SP': 3, 'TX': 35, 'TS': 18, 'DW': 4, 'SW': 1, 'TB': 2, 'NE': 38, 'ND': 2, 'OL': 1, 'BL': 18, 'FK': 1}}[page]:raise ValueError('226/228 complete source inventory changed')
        return dict(result)
    if page==225:
        if dict(result)!={'SP': 3, 'SW': 1, 'TX': 21, 'DW': 3, 'ND': 6, 'OL': 3, 'TS': 24, 'NE': 21, 'FK': 1}:raise ValueError('225 complete source inventory changed')
        return dict(result)
    if page==220:
        if dict(result)!={'SP':4,'DW':3,'TX':13,'SW':1,'TS':10,'BL':6,'TB':1,'NE':9,'ND':2,'OL':1,'FK':1}:raise ValueError('220 source inventory changed')
        return dict(result)
    if page==219:
        if dict(result)!={'SP':3,'TX':19,'ND':6,'TS':21,'NE':16,'DW':3,'OL':2,'SW':1,'FK':1}:raise ValueError('219 source inventory changed')
        return dict(result)
    if page==217:
        if dict(result)!={'SP':2,'TS':1,'BL':6,'TX':5,'DW':1,'SW':1,'TB':1,'NE':2,'FK':1}:raise ValueError('217 source inventory changed')
        return dict(result)
    if page==216:
        if dict(result)!={'SP':2,'BL':4,'TX':7,'DW':2,'SW':1,'ND':2,'OL':1,'TS':7,'NE':5,'FK':1}:raise ValueError('216 source inventory changed')
        return dict(result)
    if page in (214,215):
        if dict(result)!={'SP':2,'TX':12,'ND':4,'TS':14,'NE':10,'DW':2,'SW':1,'OL':2,'FK':1}:raise ValueError('214 source inventory changed')
        return dict(result)
    if page==213:
        if dict(result)!={'SP':2,'BL':8,'TX':7,'DW':2,'SW':1,'TS':8,'ND':2,'OL':1,'NE':5,'FK':1}:raise ValueError('213 source inventory changed')
        return dict(result)
    if page==205:
        if dict(result)!={'SP':3,'TX':22,'DW':3,'ND':6,'OL':3,'TS':25,'NE':23,'SW':1,'FK':1}:raise ValueError('205 reviewed87 count changed')
        return dict(result)
    if page in (201,203):
        if dict(result)!={'SP':2,'TX':13,'TS':15,'ND':4,'OL':2,'NE':12,'DW':2,'SW':1,'FK':1}:raise ValueError('201 reviewed52 count changed')
        return dict(result)
    if page==208:
        if dict(result)!={'SP':1,'TX':1,'TS':22,'BL':10,'DW':1,'SW':1}:raise ValueError('Page208 count differs from reviewed204 template')
        return dict(result)
    if page in (204,206,210,212,213,214,215,216,217,218,219,220,221,209,222,223,224,225,226,228,229,230,231,232,235,236,237,302,313):
        expected=json.loads((ROOT/'evidence/eight-page-source-review.json').read_text(encoding='utf8'))['counts'][str(page)]
        if dict(result)!=expected:raise ValueError('Reviewed source count changed')
        return dict(result)
    if page in (200,202):
        if dict(result)!={'SP':2,'TX':17,'TS':12,'BL':14,'DW':1,'SW':1,'TB':1,'NE':25,'FK':1}:raise ValueError('Page200 observed inventory changed')
        for kind,count in result.items():
            if sorted(int(k[2]) for k in keys if k[1]==kind)!=list(range(count)):raise ValueError('Page200 noncontiguous source keys')
        return dict(result)
    if set(result)!={'TS','BL','MS','SW','TX'} or result['MS']!=1 or result['SW']!=1 or result['BL']!=7 or result['TS'] not in (6,7,8) or result['TX'] not in (3,5):raise ValueError('New flow-page family requires review')
    for kind,count in result.items():
        if sorted(int(k[2]) for k in keys if k[1]==kind)!=list(range(count)):raise ValueError('Noncontiguous source keys')
    return dict(result)
