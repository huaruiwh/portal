"""Single-control native203 templates for the different-layout237 page."""
import json,time,re
from pathlib import Path
from pywinauto.keyboard import send_keys
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save
from eb_native_form import tab,fields,confirm,commit_text,typed_children
from eb_page26_shapes import cancel
from eb_layout import geometry
from eb_live_fields import capture
from eb_original_style_existing import verify_fields
from eb_copy_200_style_object import native_clipboard_data,restore_native_clipboard,read_audit
from eb_open_page import run as open_page
from eb_page203_rewrite import plan,TITLES

def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')

from eb_timing import timed

@timed
def template(source):
 key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',source['object'])[1]
 base=json.loads((ROOT/f'evidence/source-object-properties/236_{key}.json').read_text(encoding='utf8'))
 planned,unknown=plan(source,base);edits=[]
 for item in planned:
  if item['scope'] in ('文字/批注','标签'):
   rows=[r for r in item['rows'] if r['type']=='Edit' and (str(r.get('class','')).startswith('RichEdit')or r['name'] in ('','内容'))]
   if rows:edits.append(dict(item,rows=rows))
 for scope in ('一般属性','项目选单','源数据'):
  rows=[r for r in source['tabs'].get(scope,[]) if (r['type'],r['name']) in (('ComboBox','设备 :'),('ComboBox',' Down'),('Edit','Static')) and 'value'in r]
  if rows:edits.insert(0,{'scope':scope,'state':None,'rows':rows})
 return key,base,edits,236

@timed
def verify_saved(handle,key):
 from collections import defaultdict
 from pywinauto import Desktop
 rp=ROOT/f'evidence/target-237-{key}-built.json';phase=ROOT/f'evidence/target-237-{key}-copy-phase.json'
 if not rp.exists()or not phase.exists():return False
 report=json.loads(rp.read_text(encoding='utf8'));state=json.loads(phase.read_text(encoding='utf8'))
 if state.get('stage')=='session-verified-saved' and report.get('property_session_verified') and report.get('saved'):return True
 if state.get('stage')!='saved-unverified':return False
 root,w=target(handle,237);ds=[v for v in Desktop(backend='win32').windows()if v.process_id()==root.process_id()and v.is_visible()and v.window_text()==TITLES[key.split('_')[0]]]
 if len(ds)>1:raise ValueError('Ambiguous saved-control dialog')
 d=Desktop(backend='uia').window(handle=ds[0].handle).wrapper_object()if ds else properties(root,w,key,TITLES[key.split('_')[0]])[0]
 try:
  groups=defaultdict(list)
  for e in report['edits']:groups[(e['scope'],e['state'])].extend(e['rows'])
  for (scope,st),rs in groups.items():
   tab(d,scope)
   if st is not None:
    cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :'];ComboBoxWrapper(cs[0].handle).select(st);time.sleep(.1)
   observed=capture(d,list(dict.fromkeys((r['type'],r['name'])for r in rs)))
   try:verify_fields(observed,rs)
   except ValueError:
    write(ROOT/f'evidence/page237-{key}-readback-difference.json',{'scope':scope,'state':st,'expected':rs,'actual':observed});raise
  if key.startswith(('NE_','ND_')):
   source=json.loads((ROOT/f'evidence/source-object-properties/237_{key}.json').read_text(encoding='utf8'))
   tab(d,'格式');rs=[r for r in source['tabs']['格式']if 'value'in r and r['type']in ('Edit','ComboBox','CheckBox','RadioButton')]
   observed=capture(d,list(dict.fromkeys((r['type'],r['name'])for r in rs)))
   try:verify_fields(observed,rs)
   except ValueError:
    write(ROOT/f'evidence/page237-{key}-readback-difference.json',{'scope':scope,'state':st,'expected':rs,'actual':observed});raise
   tab(d,'字体');time.sleep(.1);preview=[r for r in source['tabs']['字体']if r['type']=='Edit'and r['name']=='内容']
   if preview:verify_fields(capture(d,[('Edit','内容')]),preview)
   from eb_font_policy import apply as apply_font_policy
   report['standard_font_verified']=apply_font_policy(d,source,verify_only=True)
  if key.startswith('OL_'):
   source=json.loads((ROOT/f'evidence/source-object-properties/237_{key}.json').read_text(encoding='utf8'))
   from eb_font_policy import apply as apply_font_policy
   report['standard_font_verified']=apply_font_policy(d,source,verify_only=True)
  tab(d,'轮廓');g=report['geometry'];verify_fields(capture(d,[('Edit',n)for n in g]),[{'type':'Edit','name':n,'value':v}for n,v in g.items()])
 finally:cancel(d)
 report.update(saved_reopened_verified=True,original_text_preserved=True,verification_recovered_without_rewrite=True);write(rp,report);state['stage']='verified';write(phase,state);return True

def place_deferred(handle,key):
 # Latest user: no validation/retry for unavailable types. Whole236 layout
 # is inherited from the saved, count-checked whole-page copy, not re-opened.
 copy=json.loads((ROOT/'evidence/page237-whole-page-copy.json').read_text(encoding='utf8'))
 phase=json.loads((ROOT/f'evidence/target-237-{key}-copy-phase.json').read_text(encoding='utf8'))
 if copy.get('stage')!='saved-bindings-pending' or copy.get('count')!=60 or not phase.get('whole_page_copy'):raise ValueError('Verified whole-copy provenance required for skipped type')
 proof_path=ROOT/f'evidence/target-236-{key}-built.json'
 if not proof_path.exists():proof_path=ROOT/f'evidence/target-236-{key}-deferred-layout.json'
 g=json.loads(proof_path.read_text(encoding='utf8'))['geometry']
 root,w=target(handle,237)
 from pywinauto import Desktop
 ds=[v for v in Desktop(backend='win32').windows() if v.process_id()==root.process_id() and v.is_visible() and v.window_text()==TITLES[key.split('_')[0]]]
 if len(ds)>1:raise ValueError('Ambiguous scripted skipped-type property dialog')
 if ds:cancel(Desktop(backend='uia').window(handle=ds[0].handle).wrapper_object())
 write(ROOT/f'evidence/target-237-{key}-deferred-layout.json',{'key':key,'geometry':g,'reference_page':236,'layout_inherited_from_saved_whole_copy':True,'layout_saved_reopened_verified':False,'binding_verified':False,'type_pending':True,'type_validation_skipped_by_user':True,'font_and_style_inherited_from236':True})



def run(handle,q):
 if q.get('page237_clone'):
  from eb_clone236_to237 import run as clone
  return clone(handle,{'page237':'clone'})
 if q.get('repair_saved_labels'):
  key=q['repair_saved_labels'];source=json.loads((ROOT/f'evidence/source-object-properties/237_{key}.json').read_text(encoding='utf8'));root,w=target(handle,237);d,_=properties(root,w,key,TITLES[key.split('_')[0]])
  try:
   from eb_font_policy import apply as apply_font_policy
   apply_font_policy(d,source);tab(d,'标签')
   cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']
   for st,rs in source['label_states'].items():
    ComboBoxWrapper(cs[0].handle).select(st);time.sleep(.2)
    commit_text(d,'',next(r['value']for r in rs if r['type']=='Edit'and r['name']==''))
   report=json.loads((ROOT/f'evidence/target-237-{key}-built.json').read_text(encoding='utf8'));g=report['geometry'];tab(d,'轮廓');fields(d,[{'type':'Edit','name':n,'value':v}for n,v in g.items()],commit_edits=True);confirm(d);d=None;save(root)
  finally:
   if d is not None:cancel(d)
  return
 if q.get('place_deferred_type'):return place_deferred(handle,q['place_deferred_type'])
 if q.get('numeric_probe'):
  key=q['numeric_probe'];root,w=target(handle,237);d,_=properties(root,w,key,TITLES['NE'])
  try:
   tab(d,'格式');fmt=capture(d,[('ComboBox','资料格式 :'),('Edit','小数点以上位数 :'),('Edit','小数点以下位数 :'),('Edit','设备上限 :'),('Edit','输入上限 :')])
   tab(d,'字体');preview=capture(d,[('Edit','内容')])
   write(ROOT/'evidence/page237-numeric-probe.json',{'format':fmt,'preview':preview})
  finally:cancel(d)
  return
 if q.get('page237_safety_probe'):
  root,w=target(handle,237);d,_=properties(root,w,'TS_17',TITLES['TS'])
  try:
   tab(d,'安全');cs=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name==' Down'and c.is_visible()]
   out=[]
   for c in cs:
    children=[]
    for v in c.descendants():
     e=v.element_info;item={'type':e.control_type,'name':e.name,'class':e.class_name,'handle':e.handle,'rect':str(v.rectangle())}
     if e.control_type=='Edit':item['value']=v.get_value()
     children.append(item)
    out.append({'value':c.selected_text(),'rect':str(c.rectangle()),'children':children})
   write(ROOT/'evidence/page237-safety-probe.json',out)
  finally:cancel(d)
  return
 if q.get('page237_count_probe'):
  from pywinauto import Desktop,mouse
  from eb_color_picker import native_window_handles
  root,w=target(handle,237);d,_=properties(root,w,'OL_2',TITLES['OL'])
  try:
   tab(d,'源数据');cs=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name=='预设 Down'and c.is_visible()]
   if len(cs)!=1:raise ValueError('Unique count probe')
   c=cs[0];r=c.rectangle();out={'class':c.element_info.class_name,'handle':c.handle,'value':c.selected_text(),'rect':[r.left,r.top,r.right,r.bottom]}
   mouse.click(coords=(r.right-10,(r.top+r.bottom)//2));time.sleep(.2)
   out['items']=[{'name':v.element_info.name,'type':v.element_info.control_type,'rect':str(v.rectangle()),'visible':v.is_visible()}for v in c.descendants()if v.element_info.control_type=='ListItem'][:12]
   out['windows']=[{'title':v.window_text(),'class':v.class_name(),'rect':str(v.rectangle())}for h in native_window_handles(d.process_id())for v in [Desktop(backend='win32').window(handle=h).wrapper_object()]]
   write(ROOT/'evidence/page237-count-probe.json',out)
  finally:
   import ctypes
   if ctypes.windll.user32.IsWindowVisible(d.handle):cancel(d)
  return
 keys=q['page237_controls']
 keys=[key for key in keys if not verify_saved(handle,key)]
 if not keys:return
 if all((ROOT/f'evidence/target-237-{key}-built.json').exists()and json.loads((ROOT/f'evidence/target-237-{key}-built.json').read_text(encoding='utf8')).get('saved_reopened_verified')for key in keys):return
 if not keys or len(keys)>4:raise ValueError('Reviewed237 batch up to4')
 inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));observed=[re.search(r'(?:^|\])\s*([A-Z]+_\d+)',s)[1]for s in next(x['observed_objects']for x in inv['pages']if x['id']==237)]
 if not set(keys)<=set(observed)or len(observed)!=60:raise ValueError('Unobserved237 key')
 # A timed-out scripted property dialog disables the directory. Cancel only
 # the exact pasted-control dialog; source fields are reapplied after audit.
 from pywinauto import Desktop
 for key in keys:
  phase=ROOT/f'evidence/target-237-{key}-copy-phase.json'
  if not phase.exists()or json.loads(phase.read_text(encoding='utf8')).get('stage')!='pasted':continue
  root=Desktop(backend='win32').window(handle=handle).wrapper_object()
  ds=[v for v in Desktop(backend='win32').windows()if v.process_id()==root.process_id()and v.is_visible()and v.window_text()==TITLES[key.split('_')[0]]]
  if len(ds)>1:raise ValueError('Ambiguous237 scripted property dialog before audit')
  if len(ds)==1:cancel(Desktop(backend='uia').window(handle=ds[0].handle).wrapper_object())
 open_page(handle,{'open_target_page':237})
 # One initial audit per batch, not per individual object.
 ledger_path=ROOT/'evidence/page237-serial-directory-ledger.json'
 ledger=json.loads(ledger_path.read_text(encoding='utf8'))if ledger_path.exists()else {}
 safe_ledger=ledger.get('handle')==handle and ledger.get('page')==237
 # Recovery always checks the real entire directory before trusting a paste.
 for requested_key in keys:
  request_phase=ROOT/f'evidence/target-237-{requested_key}-copy-phase.json'
  if request_phase.exists() and not json.loads(request_phase.read_text(encoding='utf8')).get('whole_page_copy'):safe_ledger=False
 if safe_ledger:
  for prior_key in ledger.get('keys',[]):
   proof_path=ROOT/f'evidence/target-237-{prior_key}-built.json'
   proof=json.loads(proof_path.read_text(encoding='utf8'))if proof_path.exists()else {}
   layout_path=ROOT/f'evidence/target-237-{prior_key}-deferred-layout.json'
   layout=json.loads(layout_path.read_text(encoding='utf8'))if layout_path.exists()else {}
   copied_phase=ROOT/f'evidence/target-237-{prior_key}-copy-phase.json'
   copied=json.loads(copied_phase.read_text(encoding='utf8'))if copied_phase.exists()else{}
   if not(proof.get('saved_reopened_verified')or(proof.get('property_session_verified')and proof.get('saved'))or layout.get('layout_saved_reopened_verified')or (copied.get('whole_page_copy') and copied.get('stage')=='pasted')):safe_ledger=False;break
 if safe_ledger:
  actualkeys=set(ledger['keys'])
 else:
  actual=read_audit(handle,237);actualkeys={re.search(r'(?:^|\])\s*([A-Z]+_\d+)',n)[1]for n in actual['objects']}
  if actual['unexpected']:raise ValueError('Unexpected237 objects')
 for key in keys:
  rp=ROOT/f'evidence/target-237-{key}-built.json';phase=ROOT/f'evidence/target-237-{key}-copy-phase.json'
  if rp.exists()and json.loads(rp.read_text(encoding='utf8')).get('saved_reopened_verified'):continue
  source=json.loads((ROOT/f'evidence/source-object-properties/237_{key}.json').read_text(encoding='utf8'));basekey,b,edits,template_page=template(source);kind,n=key.split('_');n=int(n)
  if phase.exists():template_page=json.loads(phase.read_text(encoding='utf8')).get('template_page',template_page)
  geometry_proof=ROOT/f'evidence/target-236-{key}-built.json'
  if not geometry_proof.exists():geometry_proof=ROOT/f'evidence/target-236-{key}-deferred-layout.json'
  geometry_data=json.loads(geometry_proof.read_text(encoding='utf8'))
  g=geometry_data['geometry']
  if phase.exists():
   state=json.loads(phase.read_text(encoding='utf8'))
   if state['stage']not in ('pasted','saved-unverified')or key not in actualkeys:raise ValueError('Unknown237 paste phase; inspect, do not repeat: '+key)
   if state['template']!=basekey:raise ValueError('237 recovery template differs')
  else:
   if key in actualkeys:raise ValueError('Existing237 without report; no paste')
   samekind={int(k.split('_')[1])for k in actualkeys if k.startswith(kind+'_')}
   if samekind!=set(range(n)):raise ValueError('Sequential237 destination numbering required '+key)
   cp=ROOT/f'evidence/native{template_page}-template-for237-{basekey}-{handle}.bin'
   if cp.exists():data=cp.read_bytes()
   else:
    # Reuse exact 228/template clipboard from previously verified destination
    # controls. Never substitute another template's safety/behavior identity.
    reused=None
    for oldpage in (236,235,232,231,230,229):
     candidate=ROOT/f'evidence/native{template_page}-template-for{oldpage}-{basekey}-{handle}.bin'
     if not candidate.exists():continue
     proven=False
     for proof_path in (ROOT/'evidence').glob(f'target-{oldpage}-*-built.json'):
      proof=json.loads(proof_path.read_text(encoding='utf8'))
      if (proof.get('saved_reopened_verified') or (proof.get('property_session_verified') and proof.get('saved'))) and proof.get('template_page')==template_page and proof.get('template')==basekey:proven=True;break
     if proven:reused=candidate;break
    if reused is not None:
     data=reused.read_bytes();cp.write_bytes(data)
     write(ROOT/f'evidence/page237-{key}-clipboard-reuse.json',{'template_page':template_page,'template':basekey,'reused_from':str(reused),'verified_prior_destination':True,'template_page_opened':False})
    else:
     open_page(handle,{'open_target_page':template_page});root,w=target(handle,template_page);d,_=properties(root,w,basekey,TITLES[kind]);cancel(d);root.set_focus();send_keys('^c',pause=.04);time.sleep(.15);data=native_clipboard_data();cp.write_bytes(data)
   open_page(handle,{'open_target_page':237});root,w=target(handle,237);placement_started=time.monotonic();restore_native_clipboard(data);root.click_input(coords=(963,367))
   write(phase,{'page':237,'key':key,'template_page':template_page,'template':basekey,'stage':'paste-requested'})
   root.set_focus();send_keys('^v',pause=.04);time.sleep(.8);root.click_input(coords=(963,367));time.sleep(.3);send_keys('{ESC}',pause=.02)
   # Resolve exact new property identity; do not perform another full-page scan.
   write(phase,{'page':237,'key':key,'template_page':template_page,'template':basekey,'stage':'pasted'})
   write(ROOT/f'evidence/page237-{key}-placement-time.json',{'key':key,'placement_seconds':round(time.monotonic()-placement_started,3),'measurement':'cached clipboard restore through paste/place/ESC; actual object identity checked next','identity_verified':False})
  root,w=target(handle,237)
  from pywinauto import Desktop
  existing=[v for v in Desktop(backend='win32').windows()if v.process_id()==root.process_id()and v.is_visible()and v.window_text()==TITLES[kind]]
  if len(existing)>1:raise ValueError('Ambiguous237 property recovery dialog')
  d=Desktop(backend='uia').window(handle=existing[0].handle).wrapper_object()if existing else properties(root,w,key,TITLES[kind])[0]
  placement_report=ROOT/f'evidence/page237-{key}-placement-time.json'
  if placement_report.exists():
   placed=json.loads(placement_report.read_text(encoding='utf8'));placed['identity_verified']=True;write(placement_report,placed)
  try:
   from eb_font_policy import apply as apply_font_policy
   template_report=ROOT/f'evidence/target-{template_page}-{basekey}-built.json'
   template_proof=json.loads(template_report.read_text(encoding='utf8'))if template_report.exists()else {}
   inherited=template_proof.get('standard_font_verified',{})
   font=json.loads((ROOT/'tools/font-policy.json').read_text(encoding='utf8'))['font']
   font_values=[str(value).split(' [')[0]for states in inherited.values()for value in states.values()]
   if (template_proof.get('saved_reopened_verified') or (template_proof.get('property_session_verified')and template_proof.get('saved')))and font_values and all(v==font for v in font_values):
    standard_fonts=inherited # Approved native template already has policy font.
   else:standard_fonts=apply_font_policy(d,source)
   # Consolidate binding scopes so each is entered only once.
   grouped=[];positions={}
   for item in edits:
    if item['scope'] in ('一般属性','项目选单','源数据') and item['state'] is None:
     scope_key=item['scope']
     if scope_key not in positions:positions[scope_key]=len(grouped);grouped.append(dict(item,rows=[]))
     for row in item['rows']:
      if row not in grouped[positions[scope_key]]['rows']:grouped[positions[scope_key]]['rows'].append(row)
    else:grouped.append(item)
   edits=grouped
   for e in edits:
    tab(d,e['scope'])
    if e['state']is not None:
     cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']
     if len(cs)!=1:raise ValueError('Unique237 label state required')
     ComboBoxWrapper(cs[0].handle).select(e['state']);time.sleep(.2)
    rs=e['rows'];verification_rows=e['rows']
    if (template_proof.get('saved_reopened_verified') or (template_proof.get('property_session_verified')and template_proof.get('saved'))) and e['scope'] in ('一般属性','项目选单','源数据'):
     # Omit only unchanged binding writes from the verified clipboard template.
     # The original full e.rows remains in report and saved readback below.
     same=[]
     for row in rs:
      ident=(row['type'],row['name'])
      base=[v for v in b['tabs'].get(e['scope'],[]) if (v['type'],v['name'])==ident and 'value'in v]
      if ident in (('ComboBox','设备 :'),('ComboBox',' Down')) and len(base)==1 and base[0]['value']==row.get('value'):same.append(row)
     rs=[row for row in rs if row not in same]
     verification_rows=[row for row in e['rows'] if row not in same]
     if same:e['inherited_binding_from_verified_template']=same
     if not rs:continue
    if e['scope']in ('文字/批注','标签'):commit_text(d,rs[0]['name'],rs[0]['value'])
    elif (e['scope']=='源数据'and rs[0]['name']=='预设 Down')or(e['scope']=='安全'and rs[0]['type']=='ComboBox'and rs[0]['name']==' Down'):
     cs=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name==rs[0]['name']and c.is_visible()]
     if len(cs)!=1:raise ValueError('Unique237 option item count required')
     c=cs[0];want=str(rs[0]['value'])
     if c.selected_text()!=want:
      from pywinauto import mouse,Desktop
      from eb_color_picker import native_window_handles
      r=c.rectangle();mouse.click(coords=(r.right-10,(r.top+r.bottom)//2));time.sleep(.2)
      items=[];pops=[]
      for _ in range(20):
       pops=native_window_handles(d.process_id(),class_prefix='Qt5QWindowPopup')
       fresh=[v for v in d.descendants(control_type='ComboBox')if v.element_info.name==rs[0]['name']and v.is_visible()]
       items=[v for v in fresh[0].descendants(control_type='ListItem')if v.element_info.name==want]if len(fresh)==1 else []
       if len(items)==len(pops)==1:break
       time.sleep(.05)
      if len(items)!=1 or len(pops)!=1:raise ValueError('Unique237 physical count popup/item required')
      item=items[0];ir=item.rectangle();pr=Desktop(backend='win32').window(handle=pops[0]).rectangle()
      write(ROOT/f'evidence/page237-combo-selection-{key}.json',{'scope':e['scope'],'name':rs[0]['name'],'wanted':want,'before':c.selected_text(),'item_rect':[ir.left,ir.top,ir.right,ir.bottom],'popup_rect':[pr.left,pr.top,pr.right,pr.bottom],'reported_visible':item.is_visible()})
      if not(pr.left<=ir.left<ir.right<=pr.right and pr.top<=ir.top<ir.bottom<=pr.bottom):raise ValueError('237 count item outside observed popup')
      mouse.click(coords=((ir.left+ir.right)//2,(ir.top+ir.bottom)//2));time.sleep(.2);send_keys('{TAB}',pause=.01)
     if c.selected_text()!=want:raise ValueError('237 option count readback failed')
    else:
     binding_only=e['scope'] in ('一般属性','项目选单','源数据') and all((r['type'],r['name']) in (('ComboBox','设备 :'),('ComboBox',' Down'),('Edit','Static'))for r in rs)
     fields(d,rs,commit_edits=not binding_only)
    if verification_rows:verify_fields(capture(d,[(row['type'],row['name']) for row in verification_rows]),verification_rows)
   tab(d,'轮廓');fields(d,[{'type':'Edit','name':k,'value':v}for k,v in sorted(g.items(),key=lambda pair:pair[0] in ('X :',' Y :'))],commit_edits=False)
   tab(d,'轮廓');actualg={r['name']:r['value']for r in capture(d,[('Edit',k)for k in g])}
   if actualg!=g:raise ValueError('237 saved geometry differs '+key)
   if kind in ('NE','ND'):
    tab(d,'格式')
    fmt=[r for r in source['tabs']['格式'] if 'value' in r and r['type'] in ('Edit','ComboBox','CheckBox','RadioButton')]
    verify_fields(capture(d,list(dict.fromkeys((r['type'],r['name'])for r in fmt))),fmt)
   from eb_font_policy import apply as apply_font_policy
   standard_fonts=apply_font_policy(d,source,verify_only=True)
   if kind in ('NE','ND'):
    tab(d,'字体')
    preview=[r for r in source['tabs']['字体']if r['type']=='Edit'and r['name']=='内容']
    if preview:
     time.sleep(.1);verify_fields(capture(d,[('Edit','内容')]),preview)
   confirm(d);d=None;save(root)
  finally:
   if d is not None:cancel(d)
  report={'page':237,'key':key,'template_page':template_page,'template':basekey,'geometry':g,'edits':edits,'source_safety_equal_to_template':source['tabs'].get('安全')==b['tabs'].get('安全'),'inherited_nonbinding_differences':{'planned':plan(source,b)[0],'unknown':plan(source,b)[1]},'user_scope':'whole236 copy; captions and bindings only','reviewed_safety_changes':[e for e in edits if e['scope']=='安全'],'font_style_from228':True,'standard_font_verified':standard_fonts,'property_session_verified':True,'saved':True,'saved_reopened_verified':False,'original_text_preserved':True,'runtime_verified':False}
  write(rp,report);state=json.loads(phase.read_text(encoding='utf8'));state['stage']='session-verified-saved';write(phase,state);actualkeys.add(key)
  write(ledger_path,{'page':237,'handle':handle,'keys':sorted(actualkeys),'last_verified_key':key,'mode':'serial increment after actual identity and all fields verified; recovery performs full audit'})
