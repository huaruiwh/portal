"""Serial fresh read-only review of pages after page16; no duplicate creation."""
import json,re,sys
from datetime import datetime
from eb_rebuild_page import ROOT,call
from eb_layout import geometry

def run(pages):
 lock=ROOT/'tools/batch.lock'
 with lock.open('x'):pass
 report={'date':datetime.now().isoformat(),'pages':pages,'completed':[],'checks':[],'ok':False,'readonly':True,'runtime_verified':False}
 path=ROOT/'evidence/following-pages-review.json'
 def persist():path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
 def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8-sig'))
 def values(rows,names):return [(r['type'],r['name'],r['value']) for r in rows if r['name'] in names and 'value' in r]
 try:
  call('snapshot');ws=read('evidence/windows.json')
  targets=[w for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
  if len(targets)!=1:raise ValueError('Unique target required')
  w=targets[0];report['target_pid']=w['pid'];persist()
  call('uia',w['handle'],json.dumps({'op':'selecttab','type':'TabItem','name':'目录树','selector':True},ensure_ascii=False))
  inv=read('evidence/source-pages-inventory.json')
  for page in pages:
   call('uia',w['handle'],json.dumps({'open_target_page':page}))
   call('uia',w['handle'],json.dumps({'target_page_audit':page}))
   names=next(p['observed_objects'] for p in inv['pages'] if p['id']==page)
   for name in names:
    if (ROOT/'tools/review-pause.flag').exists():
     report['stage']='paused at object boundary for page26 correction';persist();return
    key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)[1]
    report['stage']=f'{page}:{key}';persist()
    call('uia',w['handle'],json.dumps({'extract':{'page':page,'object':name,'target_readonly':True}},ensure_ascii=False))
    s=read(f'evidence/source-object-properties/{page:03d}_{key}.json');t=read(f'evidence/target-object-properties/{page:03d}_{key}.json')
    c={'page':page,'object':key}
    expected=geometry(s);actual={r['name']:r['value'] for r in t['tabs']['轮廓'] if r['type']=='Edit' and r['name'] in expected}
    c['geometry_verified']=expected==actual
    if '一般属性' in s['tabs']:
     fields={'设备 :','Static',' Down','设置常数 :','输出反向','设 ON','写入后'}
     c['general_verified']=values(s['tabs']['一般属性'],fields)==values(t['tabs']['一般属性'],fields)
    if key.startswith(('BL_','TS_','SW_')):
     c['picture_flags_verified']=values(s['tabs']['图片'],{'使用图片','使用向量图','调整对象尺寸为图片原尺寸'})==values(t['tabs']['图片'],{'使用图片','使用向量图','调整对象尺寸为图片原尺寸'})
     st=[r['name'] for r in s['tabs']['图片'] if r['type']=='Text' and (r['name'].startswith('Button - ') or re.fullmatch(r'\d+x\d+',r['name']))]
     tt=[r['name'] for r in t['tabs']['图片'] if r['type']=='Text']
     c['picture_metadata_verified']=all(x in tt for x in st)
     c['specific_picture_shape_verified']=False
    report['checks'].append(c);persist()
    print(f"{page}:{key} reviewed",flush=True)
   report['completed'].append(page);persist()
  report['ok']=all(v for c in report['checks'] for k,v in c.items() if k.endswith('_verified') and k!='specific_picture_shape_verified')
  report['stage']='read-only review completed';persist()
 except Exception as e:report['error']=str(e);persist();raise
 finally:lock.unlink(missing_ok=True)

if __name__=='__main__':run([int(p) for p in sys.argv[1:]])
