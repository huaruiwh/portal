"""Read missing 103-page colors serially, source dialogs always cancelled."""
import json,re
from eb_rebuild_page import ROOT,call
def run():
    call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
    matches=[w for w in ws if '组装机2台15工位取消.cmtp' in w['title'] and w['class']=='EasyBuilderPro']
    if len(matches)!=1:raise ValueError('One source required')
    inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
    names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==103)
    for kind,labels,color_tab in [('SP',['图案颜色 :','颜色 :'],'图片'),('AB',['外框颜色 :','背景颜色 :'],'报警'),('DW',['颜色 :'],' 形状')]:
        name=next(s for s in names if re.search(r'(?:^|\])\s*'+kind+r'_0(?:\s|$)',s))
        call('uia',matches[0]['handle'],json.dumps({'extract':{'page':103,'object':name,'only_color':True,'colors':labels,'color_tab':color_tab}},ensure_ascii=False))
        print(kind+' color cached',flush=True)
if __name__=='__main__':run()
