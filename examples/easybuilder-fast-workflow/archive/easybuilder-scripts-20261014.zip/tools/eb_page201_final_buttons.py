import json,time
from eb_rebuild_page import ROOT
from eb_object_ui import target,dialog,properties,save
from eb_ribbon import create
from eb_native_form import tab,fields,confirm,typed_children,commit_text
from eb_page26_shapes import cancel
from eb_picture_family import choose
from eb_original_style_existing import form_rows,verify_fields
from eb_live_fields import capture
from eb_color_picker import set_rgb,probe
from eb_layout import geometry
from eb_page208 import write
from eb_copy_200_style_object import read_audit
from pywinauto.controls.win32_controls import ComboBoxWrapper
from pywinauto.keyboard import send_keys

def run(handle,q):
    if q.get('inspect_login'):
        from eb_extract import rows
        root,w=target(handle,201);d=dialog(root.process_id(),'新增 功能键');tab(d,'一般属性');write(ROOT/'evidence/page201-login-pending.json',rows(d));return
    if q.get('inspect_destination_items'):
        root,w=target(handle,201);d=dialog(root.process_id(),'新增 功能键');boxes=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name==' Down'and c.is_visible()]
        observed=[{'type':v.element_info.control_type,'name':v.element_info.name,'visible':v.is_visible()}for v in boxes[0].descendants()]
        write(ROOT/'evidence/page201-login-destination-items.json',observed);return
    root,w=target(handle,201)
    if not root.is_enabled():
        pending=ROOT/'evidence/target-201-FK0-phase.json'
        if not pending.exists()or json.loads(pending.read_text(encoding='utf8'))['stage']!='new-modal':raise ValueError('Unknown modal; no batch started')
        dialog(root.process_id(),'新增 功能键');a=json.loads((ROOT/'evidence/target-page201-audit.json').read_text(encoding='utf8'))
    else:a=read_audit(handle,201)
    for kind in ('SW','FK'):
        key=kind+'_0';rp=ROOT/f'evidence/target-201-{kind}0-built.json';pp=ROOT/f'evidence/target-201-{kind}0-phase.json'
        if rp.exists()and json.loads(rp.read_text(encoding='utf8')).get('saved_reopened_verified'):continue
        s=json.loads((ROOT/f'evidence/source-object-properties/201_{key}.json').read_text(encoding='utf8'));root,w=target(handle,201);title='多状态设置'if kind=='SW'else '功能键';g=geometry(s)
        if not rp.exists():
            if pp.exists():
                phase=json.loads(pp.read_text(encoding='utf8'))
                if phase['stage']!='new-modal':raise ValueError('Unknown button phase; inspect')
                d=dialog(root.process_id(),'新增 '+title)
            else:
                if key not in a['missing']:raise ValueError('Existing button; no duplicate')
                d=create(root,kind,'新增 '+title);write(pp,{'stage':'new-modal'})
            tab(d,'一般属性')
            if kind=='SW':
                initial=[r for r in s['tabs']['一般属性']if r['type']=='ComboBox'and r['name']in ('设备 :',' Down')];fields(d,initial);fields(d,[r for r in s['tabs']['一般属性']if r not in initial],commit_edits=True)
            else:
                fields(d,[{'type':'RadioButton','name':'','value':1},{'type':'ComboBox','name':'','value':'弹出窗口'}])
                boxes=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name==' Down'and c.is_visible()]
                if len(boxes)!=1:raise ValueError('Unique login destination required')
                value=next(r['value']for r in s['tabs']['一般属性']if r['type']=='ComboBox'and r['name']==' Down')
                if boxes[0].selected_text().strip()!=value.strip():
                    from pywinauto import Desktop,mouse
                    Desktop(backend='win32').window(handle=d.handle).set_focus()
                    box=boxes[0].rectangle();boxes[0].click_input(coords=(box.width()-12,box.height()//2));time.sleep(.1);items=[]
                    previous=None;stable=0
                    for _ in range(40):
                        choices=boxes[0].descendants(control_type='ListItem');items=[c for c in choices if c.element_info.name==value]
                        if len(items)==1:break
                        signature=tuple(c.element_info.name for c in choices);stable=stable+1 if signature==previous else 0;previous=signature
                        if stable>=3:break
                        ps=[v for v in Desktop(backend='win32').windows(process=root.process_id())if v.is_visible()and v.class_name().startswith('Qt5QWindowPopup')]
                        if len(ps)!=1:raise ValueError('Unique destination popup required')
                        rect=ps[0].rectangle()
                        if rect.width()<100 or rect.height()<50:raise ValueError('Destination popup bounds invalid')
                        mouse.scroll(coords=((rect.left+rect.right)//2,(rect.top+rect.bottom)//2),wheel_dist=-5);time.sleep(.1)
                    if len(items)!=1:raise ValueError('Unique observed70 destination item required')
                    rect=items[0].rectangle();popup=ps[0]if 'ps'in locals()and ps else None
                    if popup is None:
                        current=[v for v in Desktop(backend='win32').windows(process=root.process_id())if v.is_visible()and v.class_name().startswith('Qt5QWindowPopup')]
                        popup=current[0]if len(current)==1 else None
                    container=popup.rectangle()if popup else None
                    if container and rect.width()>0 and container.left<=rect.left<rect.right<=container.right and container.top<=rect.top<rect.bottom<=container.bottom:
                        mouse.click(coords=((rect.left+rect.right)//2,(rect.top+rect.bottom)//2))
                    else:
                        from eb_popup_local_ocr import observe
                        popup,ocr=observe(root.process_id());ids=[v for v in ocr['words']if v['text'].rstrip('.')=='70'and v['x']<50]
                        if len(ids)!=1:raise ValueError('Observed popup70 row required')
                        row=ids[0];popup.click_input(coords=(80,round(row['y']+row['height']/2)))
                    for _ in range(10):
                        if boxes[0].selected_text().strip()==value.strip():break
                        time.sleep(.1)
                if boxes[0].selected_text().strip()!=value.strip():raise ValueError('Login destination differs')
                fields(d,[r for r in s['tabs']['一般属性']if r['name']in ('当父窗口被关闭时结束弹出窗口','当按钮松开后发出指令','启用')])
            tab(d,'安全');fields(d,s['tabs']['安全'])
            tab(d,'图片');fields(d,s['tabs']['图片'],skip=(('CheckBox','调整对象尺寸为图片原尺寸'),));choose(d,root.process_id(),'Button - Flat',standard_index=s['picture_identity']['index'],readback_fn=form_rows)
            tab(d,'标签');fields(d,[r for r in s['tabs']['标签']if r['type']=='CheckBox'])
            boxes=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']
            for state in ('0','1'):
                ComboBoxWrapper(boxes[0].handle).select(state)
                adapted=[dict(r,value='微软正黑体 Light')if r['name']=='字体 :'else dict(r,value='12')if r['name']=='尺寸 :'else r for r in s['label_states'][state]if r['type']in ('ComboBox','CheckBox')and r['name']!='状态 :']
                fields(d,adapted)
            from eb_label_commit import commit
            texts=[next(r['value']for r in s['label_states'][state]if r['type']=='Edit'and r['name']=='')for state in ('0','1')];commit(d,texts)
            for scope,states in s['state_colors'].items():
                tab(d,scope);box=next(c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :')
                for state,colors in states.items():
                    ComboBoxWrapper(box.handle).select(state)
                    for label,rgb in colors.items():set_rgb(d,rgb,label)
            confirm(d);write(pp,{'stage':'placement-requested'});root.set_focus();root.click_input(coords=(963,367));send_keys('{ESC}',pause=.01)
            d,_=properties(root,w,key,title+'的属性');tab(d,'轮廓');fields(d,[{'type':'Edit','name':k,'value':v}for k,v in g.items()]);confirm(d);save(root);write(rp,{'saved_requested':True,'saved_reopened_verified':False});write(pp,{'stage':'saved-unverified'})
        d,_=properties(root,w,key,title+'的属性')
        try:
            tab(d,'一般属性')
            if kind=='SW':
                expected=[r for r in s['tabs']['一般属性']if'value'in r];verify_fields(capture(d,[(r['type'],r['name'])for r in expected]),expected)
            else:
                actual=capture(d,[('ComboBox',''),('ComboBox',' Down'),('CheckBox','当父窗口被关闭时结束弹出窗口')]);verify_fields(actual,[{'type':'ComboBox','name':'','value':'弹出窗口'},{'type':'ComboBox','name':' Down','value':'70. Login & Logout'},{'type':'CheckBox','name':'当父窗口被关闭时结束弹出窗口','value':1}])
            tab(d,'安全');expected=[r for r in s['tabs']['安全']if'value'in r];verify_fields(capture(d,[(r['type'],r['name'])for r in expected]),expected)
            for scope,states in s['state_colors'].items():
                tab(d,scope);box=next(c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :')
                for state,colors in states.items():
                    ComboBoxWrapper(box.handle).select(state)
                    for label,rgb in colors.items():
                        if probe(d,label)!=rgb:raise ValueError('Saved button RGB differs')
                    if scope=='标签':
                        want=next(r['value']for r in s['label_states'][state]if r['type']=='Edit'and r['name']=='');verify_fields(capture(d,[('Edit',''),('ComboBox','字体 :'),('ComboBox','尺寸 :')]),[{'type':'Edit','name':'','value':want},{'type':'ComboBox','name':'字体 :','value':'微软正黑体 Light'},{'type':'ComboBox','name':'尺寸 :','value':'12'}])
            tab(d,'轮廓');verify_fields(capture(d,[('Edit',k)for k in g]),[{'type':'Edit','name':k,'value':v}for k,v in g.items()])
        finally:cancel(d)
        write(rp,{'page':201,'key':key,'saved_reopened_verified':True,'font':'微软正黑体 Light','font_size':12,'picture_identity':s['picture_identity'],'colors':s['state_colors'],'geometry':g,'macro_executed':False,'runtime_verified':False,'model_adaptation':'MT popup uses existing70 Login & Logout; cMT display-close-button field absent, popup window behavior requires runtime review'if kind=='FK'else 'Original image-native-size option omitted; original geometry retained'});write(pp,{'stage':'verified'})
    a=read_audit(handle,201);write(ROOT/'evidence/page201-final-buttons.json',{'finished':True,'count':a['target_count'],'remaining':len(a['missing'])})
