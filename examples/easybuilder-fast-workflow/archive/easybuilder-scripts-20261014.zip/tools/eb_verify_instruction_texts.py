"""Compile, normally reopen, and read back the instruction text stage."""
import json,re,time
from eb_rebuild_page import ROOT,call
from eb_layout import geometry
from eb_roundtrip_main import selected

def run():
    def target():
        call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
        found=[w for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
        if len(found)!=1:raise ValueError('Unique target required')
        return found[0]
    w=target()
    def ui(q):return call('uia',w['handle'],json.dumps(q,ensure_ascii=False))
    ui({'compile_target':True,'start_only':True});time.sleep(2)
    ui({'compile_target':True,'capture_result':True,'expected_pid':w['pid']})
    old=w['pid'];call('keys',w['handle'],'%{F4}');call('launch',value=str(ROOT/'output/组装机_MT8106iP.emtp'))
    for _ in range(20):
        try:
            w=target()
            if w['pid']!=old:break
        except ValueError:pass
        time.sleep(.5)
    else:raise ValueError('New target process required')
    ui({'restore_target_window':True,'reviewed_size':True});ui({'open_target_page':101})
    ui({'page_settings':101,'target_readonly':True,'color_probe':True})
    settings=json.loads((ROOT/'evidence/target-pages-settings/101.json').read_text(encoding='utf8'))
    shape={c['name']:c['value'] for c in settings['controls'] if c['type']=='Edit' and c['name'] in ('宽度 :','高度 :')}
    inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
    names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==101)
    checks=[]
    for n in range(7):
        key=f'TX_{n}';name=next(v for v in names if re.search(r'(?:^|\])\s*'+key+r'(?:\s|$)',v))
        ui({'extract':{'page':101,'object':name,'target_readonly':True,'colors':['颜色 :'],'color_tab':'文字/批注'}})
        source=json.loads((ROOT/f'evidence/source-object-properties/101_{key}.json').read_text(encoding='utf8'))
        saved=json.loads((ROOT/f'evidence/target-object-properties/101_{key}.json').read_text(encoding='utf8'))
        actual={c['name']:c['value'] for c in saved['tabs']['轮廓'] if c['type']=='Edit' and c['name'] in geometry(source)}
        def values(rows):return [(c['type'],c['name'],c['value']) for c in rows if 'value'in c]
        checks.append({'object':key,'geometry_verified':geometry(source)==actual,'text_verified':selected(source['tabs']['文字/批注'],{'内容'})==selected(saved['tabs']['文字/批注'],{'内容'}),'color_verified':source['colors']==saved['colors'],'safety_verified':values(source['tabs']['安全'])==values(saved['tabs']['安全'])})
    report={'page':101,'previous_pid':old,'reopened_pid':w['pid'],'checks':checks,'dimensions_verified':shape=={'宽度 :':'1024','高度 :':'600'},'background_rgb':settings['background_rgb'],'text_stage_only':True,'remaining_vectors':8,'offline_simulation_verified':False}
    source_settings=json.loads((ROOT/'evidence/source-pages-settings/101.json').read_text(encoding='utf8'))
    report['ok']=report['dimensions_verified'] and 'background_color_occurrence' in source_settings and settings['background_color_label']=='背景颜色 :' and settings['background_rgb']==source_settings['background_rgb'] and all(v for c in checks for k,v in c.items() if k.endswith('_verified'))
    (ROOT/'evidence/page-101-text-roundtrip.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    if not report['ok']:raise ValueError('Instruction text roundtrip mismatch')
    print(json.dumps({'page':101,'text_verified':7,'remaining_vectors':8,'pid':w['pid']},ensure_ascii=False),flush=True)

if __name__=='__main__':run()
