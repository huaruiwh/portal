"""Audit cached source/target layer references without GUI changes."""
import json
from eb_rebuild_page import ROOT
names=[chr(24213)+chr(23618)+' :',chr(20013)+chr(23618)+' :',chr(39030)+chr(23618)+' :']
checks=[]
for p in sorted((ROOT/'evidence/source-pages-settings').glob('*.json')):
 t=ROOT/'evidence/target-pages-settings'/p.name
 if not t.exists():continue
 a=json.loads(p.read_text(encoding='utf8'));b=json.loads(t.read_text(encoding='utf8'))
 get=lambda d:{x['name']:x.get('value') for x in d['controls'] if x['type']=='ComboBox' and x['name'] in names}
 x=get(a);y=get(b);checks.append({'page':int(p.stem),'source':x,'target':y,'ok':x==y and len(x)==3})
report={'cached_only':True,'checks':checks,'page_count':len(checks),'mismatches':[x['page'] for x in checks if not x['ok']],'runtime_verified':False}
(ROOT/'evidence/underlay-cached-mismatch-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'pages':len(checks),'mismatches':report['mismatches']}))
