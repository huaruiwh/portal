"""Archive complete production timings and source-research limits, not microbenchmarks alone."""
import json,pathlib,py_compile
ROOT=pathlib.Path(__file__).resolve().parents[1]
def load(name):return json.loads((ROOT/'evidence'/name).read_text(encoding='utf-8-sig'))
a=load('target-page201-audit.json');r4=load('target-201-TS4-built.json');r5=load('target-201-TS5-built.json');r6=load('target-201-TS6-built.json')
bench=load('geometry-write-three-route-comparison.json');trial=load('native-message-save-roundtrip.json')
assert a['target_count']==23 and len(a['missing'])==29 and not a['unexpected']and not a['address_name_mismatch']
assert all(load(f'target-201-TS{n}-built.json')['saved_reopened_verified']for n in range(7))
assert trial['temporary_reopened_verified']and trial['original_reopened_verified']
size=(ROOT/'output/组装机_MT8106iP.emtp').stat().st_size
for name in ('eb_native_id_fields.py','eb_page201_buttons.py','eb_fast_fields_benchmark.py'):
    py_compile.compile(str(ROOT/'tools'/name),doraise=True)
summary=f'''

### 2026-10-11：以整件速度为准——模板匹配、差异写入与GitHub调查

用户要求继续找最优方法，强调整体速度、争取几秒，允许查GitHub。本阶段新增并保存201/TS_3“学习”、TS_4、TS_5、TS_6“停止”，TS_0至TS_6共7按钮均已保存重开核对。目录实际23/52件、缺29、额外0、地址/名称差异0；工程{size}字节，停201页；无新编译/运行验收，不下载或执行PLC/HMI宏。TS_6地址DB8Bit-754.1，原最短按压关闭，权限无；图片状态0 RGB237/0/47、状态1 RGB128/221/255，标签两态黑色、微软雅黑正黑体实际字体为微软正黑体 Light13号，原位置/尺寸按源适配。依据各built报告，不把未保存弹窗当成果。

当前已测最快完整建件为TS_5：从复制到保存、重开核对及取消属性，控制器耗时{r5['controller_wall_seconds']:.9f}秒，使用已验证201/TS_4模板；读取原件参数{r5['source_extraction_seconds']:.9f}秒，源读取加控制器{r5['source_plus_controller_seconds']:.9f}秒。相比TS_4首次图库适配{r4['controller_wall_seconds']:.9f}秒，实践上减少了图库/颜色重复操作；两件不是同一对象对照试验，不宣称所有按钮固定加速倍数，更没有达到几秒。证据target-201-TS4/TS5-built.json。

TS_4阶段耗时（秒）：{json.dumps(r4['stage_seconds'],ensure_ascii=False)}。
TS_5阶段耗时（秒）：{json.dumps(r5['stage_seconds'],ensure_ascii=False)}。
说明：TS_4原图库Flat3，而点动模板Flat1；不能套错图。首次图库适配及重开外观核对约93秒，远大于尺寸编辑。模板选择现从已verified前件中先匹配安全和颜色，再优先图形身份与设备/地址类型；源参数来自只读缓存，模板变化仍按原件适配。

最新差异写入生产实测TS_6：一般属性只写Edit/Static地址，general_write={r6['stage_seconds']['general_write']:.9f}秒；旧TS_5该阶段{r5['stage_seconds']['general_write']:.9f}秒。保存后仍核对全部原一般属性，安全只写与已验证模板不同项，颜色只适配状态0发生变化的一项并保存后读回；未改状态1或标签颜色。恢复调用完整耗时{r6['controller_resume_wall_seconds']:.9f}秒，包含第一次输入错误及排查/恢复的自然经过时间{r6['including_recovery_elapsed_seconds']:.9f}秒，不能把恢复调用当首次完整创建速度。证据target-201-TS6-built.json/general_written_keys、page201-button-general-pending.json。

问题与修复：
- TS_3首次粘贴后开属性报`Dialog not ready: 位状态切换开关/位状态指示灯的属性`；snapshot确认无残留弹窗，按pasted阶段恢复现有对象，未再次贴。恢复run71.6422239秒不含首失败，不能用于完整建件排名。
- TS_4/TS_6初次遇到`Button appearance differs; first-template adaptation needed`，均在粘贴前停止。先读实际图库与两态颜色再扩展适配；TS_6红色状态禁止假装蓝色模板已经合格。
- TS_6快速输入报`Learned native edit readback mismatch`，读取真实未确认属性证实已经是754.1；原因是输入提交晚于即时读回。原生字段新增20次×0.03秒条件等待，仅未达到期待值时等待，失败后包含期望/实值，不固定睡长时间；取消未保存弹窗后从pasted阶段恢复。不能用纯WM_SETTEXT替代业务提交。
- 本机主Python直接import pywinauto报`ModuleNotFoundError: No module named 'pywinauto'`，该库实际在tools/python-libs供管理员worker使用；检查当地源码EditWrapper.set_edit_text确认采用EM_SETSEL/EM_REPLACESEL，保持worker路径，不盲安装或更新生产环境。

原生消息路线：已学习class/GetDlgCtrlID/完整父链定位每个新弹窗的实际HWND；使用有1500ms上限的EM_SETSEL/EM_REPLACESEL，不猜ID，不改工程二进制。地址保留键盘提交和新值等待；尺寸采用经实测的原生消息。三轮同窗交替实测均由原生消息胜出，最新中位秒数{json.dumps(bench['median_seconds'])}。只算尺寸写入，不当作整件倍数。TS_3位置X临时加1真实保存并重开核对，再恢复原值保存重开核对，两次通过；测试最后原值恢复，证据native-message-save-roundtrip.json。原生ID先过滤再核对完整父链、去掉无用wrapper构造没有实质额外收益；不因更小局部数字宣称整体再加速。

GitHub调查（2026-10-11，以下为已打开的仓库README/源文档内容判断，不是已安装功能）：
- https://github.com/writeq/easybuilder-pro-agent ：EasyBuilder操作知识/Qt界面经验库，提供复制已调好外观对象的策略；未提供原生EMTP按钮/工程生成代码。它关于UIA不可用的环境结论与本机已成功读回的混合Win32/UIA不一致，不能照搬为本机限制。仅参考资料，未安装该外部skill、未执行其设备写入建议。
- https://github.com/IliTheButterfly/EasyBuilderMacroGenerator ：Python生成EasyBuilder宏、动态绘图及标签CSV合并工具，不是MT8106iP原生按钮工程生成器。本任务保留原生控件且禁止执行控制宏，未用宏替换界面。
- https://github.com/guziks/sm2csv ：SoMachine标签CSV转换，解决地址标签导入，不生成本次原生按钮。
- https://github.com/AReds4/HMItoNiryoNed ：有cmtp/emtp示例工程，不是重建/转换接口。
本轮未找到并验证可在几秒内直接生成这一原生EMTP界面的开源接口；不能从搜索未命中推断全网不存在。官方EasyConverter命令行只处理日志等数据转换，不能据此称为界面工程生成API。没有下载、安装或执行无关仓库，也没有发布未完成工程。

复现与恢复：管理员worker串行、batch.lock独占、单整件300秒；控制器call('uia',10488686,json.dumps({{'page201_button':6,'build_bit_general':0}},ensure_ascii=False))，已verified会跳过。新模块支持0..6；后续TS_7未读取/创建，不能盲循环。基准请求fast_fields_benchmark/geometry_write_comparison/three_routes只临时改TS_1 X并恢复取消；geometry_save_roundtrip用TS_3保存+1及恢复，恢复日志必须finished且两核对true。所有已完成对象禁止重复粘贴。各count、耗时和字节来自真实报告，不用旧编译代替本轮验收。

当前优选组合：源参数缓存→按原外观、安全、地址类型选择已验证模板→同批次原生剪贴板复用→只写变化字段→每件一次保存后核对必要修改/地址/安全→整批目录审计。减少图库和颜色窗口往返比继续微调单个Edit更有收益。下一步要接近几秒应优先测同模板连续批次、批次级目录审计和属性窗口直接入口，仍须真实整件计时；目前常规窗口创建/定位、完整地址核对与颜色弹窗是实际剩余成本，尚未达到几秒。当前最快完整成功样本44.229814秒，其它样本含新样式及恢复，不能选择性忽略失败计时。
'''
summary=summary.replace('微软雅黑正黑体实际字体为','字体为')
for p in (ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md'):
    if '### 2026-10-11：以整件速度为准——模板匹配、差异写入与GitHub调查'not in p.read_text(encoding='utf8'):
        with p.open('a',encoding='utf8')as f:f.write(summary)
cp=ROOT/'evidence/resume-checkpoint.json';d=json.loads(cp.read_text(encoding='utf-8-sig'))
d.update(status='page201-seven-buttons-saved-speed-research',page201_objects=23,page201_remaining_objects=29,project_bytes=size,target_project_bytes=size,batch_running=False,field_speed_production_integrated=True,whole_control_fastest_measured_seconds=r5['controller_wall_seconds'],whole_control_fastest_report='evidence/target-201-TS5-built.json',seconds_level_goal_achieved=False,current_stage='TS_0..TS_6 saved and reopened verified; end-to-end optimization documented',next_action='No duplicates TS_0..6. TS_7 not cached/built; inspect original first. Measure same-template continuous batch and safe batch-level directory audit. Preserve original style and changed safety/color verification.')
cp.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
(ROOT/'evidence/page201-buttons-preview-workflow.json').write_text(json.dumps({'page':201,'verified':[f'TS_{n}'for n in range(7)],'status':'saved-speed-research','remaining':29,'fastest_complete_seconds':r5['controller_wall_seconds'],'seconds_level_goal_achieved':False},ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'objects':23,'remaining':29,'bytes':size,'fastest_complete_seconds':r5['controller_wall_seconds'],'seconds_level_goal_achieved':False,'docs_updated':2},ensure_ascii=False))
