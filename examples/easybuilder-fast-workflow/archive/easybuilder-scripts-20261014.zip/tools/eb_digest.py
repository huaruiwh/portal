"""Print compact evidence summaries; never modify the full local evidence."""
import argparse
import json
from pathlib import Path


def digest(path):
    data = json.loads(path.read_text(encoding='utf-8-sig'))
    out = {'file': path.name}
    if not isinstance(data, dict):
        out.update(type=type(data).__name__, count=len(data))
        return out
    for key in ('ok', 'page', 'kind', 'whole_page_complete',
                'wholepage', 'project_reopened_verified'):
        if key in data:
            out[key] = data[key]
    for key in ('pages', 'completed', 'pending', 'objects', 'errors'):
        if key in data and isinstance(data[key], (list, dict)):
            out[key + '_count'] = len(data[key])
    # Preserve an explicit failure indicator; full text stays in the named file.
    for key in ('error', 'exception'):
        if data.get(key):
            out[key] = str(data[key])[:240]
    return out


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('files', nargs='+', type=Path)
    args = parser.parse_args()
    for file in args.files:
        try:
            result = digest(file)
        except Exception as exc:
            result = {'file': file.name, 'ok': False, 'error': str(exc)[:240]}
        print(json.dumps(result, ensure_ascii=False, separators=(',', ':')))
