"""Repair existing page26 switch bitmap variants, preserving all other fields."""
import json,time
from pywinauto import Desktop
from eb_extract import ROOT,rows
from eb_object_ui import dialog,target,properties,save
from eb_native_form import tab,confirm
from eb_native_messages import msg
from eb_timing import timed

@timed
def native_rows(d):
 """Read visible native form controls without recursive UIA FindAll."""
 from eb_native_messages import text,combo_text
 out=[]
 for n in Desktop(backend='win32').window(handle=d.handle).wrapper_object().descendants():
  if n.class_name() not in ('Edit','ComboBox','Button','Static') or not n.is_visible():continue
  c=Desktop(backend='uia').window(handle=n.handle).wrapper_object();e=c.element_info
  if e.control_type not in ('Edit','ComboBox','CheckBox','RadioButton','Text','Button'):continue
  r={'type':e.control_type,'name':e.name,'class':e.class_name}
  if e.control_type=='Edit':r['value']=text(n.handle).rstrip('\r\n')
  elif e.control_type=='ComboBox':r['value']=combo_text(n.handle)
  elif e.control_type in ('CheckBox','RadioButton'):r['value']=msg(n.handle,240)
  out.append(r)
 return out

def cancel(d):
 import ctypes
 if not ctypes.windll.user32.IsWindow(d.handle) or not ctypes.windll.user32.IsWindowVisible(d.handle):return
 native=Desktop(backend='win32').window(handle=d.handle).wrapper_object()
 bs=[c for c in native.descendants(class_name='Button') if c.is_visible() and c.is_enabled() and c.window_text()=='取消']
 if len(bs)!=1:raise ValueError('Unique cancel required')
 msg(bs[0].handle,245)
 import ctypes,time
 for _ in range(10):
  if not ctypes.windll.user32.IsWindow(d.handle) or not ctypes.windll.user32.IsWindowVisible(d.handle):return
  time.sleep(.05)
 # Some active native settings dialogs ignore the short BM_CLICK.
 if bs[0].is_visible() and bs[0].is_enabled():bs[0].click_input()
 for _ in range(20):
  if not ctypes.windll.user32.IsWindow(d.handle) or not ctypes.windll.user32.IsWindowVisible(d.handle):return
  time.sleep(.05)
 raise ValueError('Cancel did not close the observed property dialog')

@timed
def run(handle,q):
 import faulthandler
 trace=(ROOT/'evidence/page26-shape-slow-stack.txt').open('w',encoding='utf8')
 faulthandler.dump_traceback_later(25,repeat=True,file=trace)
 root=Desktop(backend='win32').window(handle=handle).wrapper_object();pid=root.process_id();mode=q['page26_shapes']
 if mode=='pause-save':
  import ctypes
  from types import SimpleNamespace
  from eb_color_picker import close
  u=ctypes.windll.user32;closed=[]
  def handles(title):
   found=[];cb=ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p)
   @cb
   def visit(h,_):
    p=ctypes.c_ulong();u.GetWindowThreadProcessId(h,ctypes.byref(p))
    t=ctypes.create_unicode_buffer(1024);u.GetWindowTextW(h,t,1024)
    if p.value==pid and u.IsWindowVisible(h) and t.value==title:found.append(int(h))
    return True
   u.EnumWindows(visit,0);return found
  for title in ('Colors','图片管理','位状态指示灯/位状态切换开关的属性','位状态切换开关/位状态指示灯的属性'):
   hs=handles(title)
   if len(hs)>1:raise ValueError('Pause cleanup requires unique modal '+title)
   if hs:
    d=SimpleNamespace(handle=hs[0])
    if title=='Colors':close(d,'Cancel')
    else:cancel(d)
    closed.append(title)
  for _ in range(20):
   if root.is_enabled():break
   time.sleep(.1)
  else:raise ValueError('Unknown modal remains; pause save not sent')
  save(root);time.sleep(1)
  (ROOT/'evidence/pause-save-result.json').write_text(json.dumps({'closed_without_committing_partial_fields':closed,'target_saved':True,'root_enabled':root.is_enabled(),'runtime_verified':False},ensure_ascii=False,indent=2),encoding='utf8');return
 if mode=='finish-open-lamp':
  from eb_uia_inventory import descendants as cached
  from pywinauto import mouse
  g=dialog(pid,'图片管理');Desktop(backend='win32').window(handle=g.handle).set_focus()
  observed=cached(g);groups=[c for c in observed if c.element_info.control_type=='Group' and c.element_info.name=='3' and c.is_visible()]
  if len(groups)!=1:raise ValueError('One observed lamp index3 required')
  r=groups[0].rectangle();mouse.click(coords=(r.left+60,r.top+70));time.sleep(.5)
  g.capture_as_image().save(str(ROOT/'evidence/lamp-selected-gallery-local.png'))
  cancel(g);return
 if mode=='open-lamp-gallery':
  from eb_native_form import typed_children
  d=dialog(pid,'位状态指示灯/位状态切换开关的属性');tab(d,'图片')
  bs=[c for c in typed_children(d,'Button') if c.element_info.name=='图库...' and c.is_visible() and c.is_enabled()]
  if len(bs)!=1:raise ValueError('One enabled lamp gallery required')
  bs[0].click_input();return
 if mode=='current-lamp-picture':
  d=dialog(pid,'位状态指示灯/位状态切换开关的属性');tab(d,'图片')
  (ROOT/'evidence/current-lamp-picture.json').write_text(json.dumps(native_rows(d),ensure_ascii=False,indent=2),encoding='utf8');return
 if mode=='cancel-lamp':cancel(dialog(pid,'位状态指示灯/位状态切换开关的属性'));return
 if mode=='gallery-inspect':
  from eb_uia_inventory import descendants as cached
  entries=[]
  for v in Desktop(backend='win32').windows(process=pid):
   if v.is_visible() and (v.window_text()=='图片管理' or v.class_name().startswith('Qt5QWindowPopup')):
    u=Desktop(backend='uia').window(handle=v.handle).wrapper_object()
    entries.append({'handle':v.handle,'title':v.window_text(),'class':v.class_name(),'rows':[{'type':c.element_info.control_type,'name':c.element_info.name,'rect':[c.rectangle().left,c.rectangle().top,c.rectangle().right,c.rectangle().bottom]} for c in cached(u) if c.is_visible() and c.element_info.control_type in ('MenuItem','Group','Button','Text')]})
  (ROOT/'evidence/lamp-menu-inspect.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2),encoding='utf8');return
 if mode=='cancel-lamp-gallery':
  g=dialog(pid,'图片管理');Desktop(backend='win32').window(handle=g.handle).set_focus()
  from pywinauto.keyboard import send_keys
  send_keys('{ESC}');time.sleep(.1)
  existing=[v for v in Desktop(backend='win32').windows(process=pid) if v.is_visible() and v.window_text()=='图片管理']
  if existing:cancel(dialog(pid,'图片管理'))
  cancel(dialog(pid,'位状态指示灯/位状态切换开关的属性'));return
 if mode=='directory-debug':
  w=Desktop(backend='uia').window(handle=handle).wrapper_object();entries=[]
  for c in w.descendants(cache_enable=True):
   if c.element_info.control_type not in ('Edit','Tree','TreeItem') or not c.is_visible():continue
   r=c.rectangle();v={'type':c.element_info.control_type,'name':c.element_info.name,'handle':c.element_info.handle,'class':c.element_info.class_name,'rect':[r.left,r.top,r.right,r.bottom]}
   if c.element_info.control_type=='Edit':v['value']=c.get_value()
   entries.append(v)
  (ROOT/'evidence/page26-directory-debug.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2),encoding='utf8');return
 if mode=='cancel-alarm':cancel(dialog(pid,'报警条的属性'));return
 if mode=='cancel-switch':cancel(dialog(pid,'位状态切换开关/位状态指示灯的属性'));return
 if mode=='recover-colors':
  from eb_color_picker import close
  close(dialog(pid,'Colors'),'Cancel')
  cancel(dialog(pid,'位状态切换开关/位状态指示灯的属性'));return
 n=int(q.get('n',0));page=int(q.get('page',26));kind=q.get('kind','TS')
 if kind not in ('TS','BL'):raise ValueError('Reviewed TS/BL kinds only')
 title='位状态切换开关/位状态指示灯的属性' if kind=='TS' else '位状态指示灯/位状态切换开关的属性'
 if page not in (*range(26,46),47):raise ValueError('Reviewed flow pages only')
 if mode in ('source-colors','target-colors'):
  from eb_color_picker import probe,set_rgb
  from eb_native_form import typed_children
  from pywinauto.controls.win32_controls import ComboBoxWrapper
  if mode=='source-colors':
   if '组装机2台15工位取消.cmtp' not in root.window_text():raise ValueError('Source-only color read')
   d=dialog(pid,title)
  else:
   root,w=target(handle,page);d,_=properties(root,w,f'{kind}_{n}',title)
   tab(d,'一般属性');actual=native_rows(d)
   source=json.loads((ROOT/f'evidence/source-object-properties/{page:03d}_{kind}_{n}.json').read_text(encoding='utf8'))
   addresses=lambda rs:[r['value'] for r in rs if r['type']=='Edit' and r['name']=='Static']
   if addresses(actual)!=addresses(source['tabs']['一般属性']):raise ValueError('Target source-address guard failed')
  tab(d,'标签');label_used=any(r['name']=='使用文字标签' and r.get('value')==1 for r in native_rows(d))
  scopes=['图片']+(['标签'] if label_used else [])
  path=ROOT/f'evidence/page{page}-{kind}{n}-source-colors.json'
  original=json.loads(path.read_text(encoding='utf8')) if mode=='target-colors' else None
  if original is not None and set(original['colors'])!=set(scopes):raise ValueError('Original/target label-enable mismatch; review before changing colors')
  colors={}
  for scope in scopes:
   tab(d,scope);cs=[c for c in typed_children(d,'ComboBox') if c.element_info.name=='状态 :']
   if len(cs)!=1:raise ValueError('One native state selector required')
   colors[scope]={}
   for state in ('0','1'):
    ComboBoxWrapper(cs[0].handle).select(state)
    if mode=='source-colors':colors[scope][state]=probe(d,'颜色 :')
    else:
     wanted=original['colors'][scope][state];r=set_rgb(d,wanted,'颜色 :');actual=r['after']
     if actual!=wanted:raise ValueError('Source color native write/read mismatch')
     colors[scope][state]=actual
  if mode=='source-colors':
   path.write_text(json.dumps({'page':page,'object':f'{kind}_{n}','colors':colors,'source_modified':False},ensure_ascii=False,indent=2),encoding='utf8');cancel(d);return
  confirm(d);save(root)
  d,_=properties(root,w,f'{kind}_{n}',title)
  for scope in scopes:
   tab(d,scope);cs=[c for c in typed_children(d,'ComboBox') if c.element_info.name=='状态 :']
   for state in ('0','1'):
    ComboBoxWrapper(cs[0].handle).select(state)
    if probe(d,'颜色 :')!=colors[scope][state]:raise ValueError('Saved two-state source RGB mismatch')
  cancel(d)
  (ROOT/f'evidence/page{page}-{kind}{n}-color-correction.json').write_text(json.dumps({'page':page,'object':f'{kind}_{n}','colors':colors,'saved':True,'native_reopened_rgb_verified':True,'runtime_verified':False},ensure_ascii=False,indent=2),encoding='utf8');return
 if mode=='source-gallery':
  d=dialog(pid,title);tab(d,'图片')
  bs=[c for c in d.descendants(control_type='Button',cache_enable=True) if c.is_visible() and c.is_enabled() and c.element_info.name=='图库...']
  if len(bs)!=1:raise ValueError('One enabled source bitmap gallery required')
  bs[0].click_input();g=dialog(pid,'图片管理');Desktop(backend='win32').window(handle=g.handle).set_focus();time.sleep(.5)
  g.capture_as_image().save(str(ROOT/f'evidence/page{page}-{kind}{n}-source-gallery-local.png'))
  cancel(g);cancel(d);return
 if mode in ('repair','repair-all'):
  source_path=ROOT/f'evidence/source-object-properties/{page:03d}_{kind}_{n}.json'
  if not source_path.exists():raise ValueError('Observed source switch required')
  source=json.loads(source_path.read_text(encoding='utf8'))
  root,w=target(handle,page);d,name=properties(root,w,f'{kind}_{n}',title)
  tab(d,'一般属性');before=native_rows(d);tab(d,'轮廓');shape_before=native_rows(d);tab(d,'图片')
  from eb_picture_family import choose
  metadata=[r['name'] for r in source['tabs']['图片'] if r['type']=='Text']
  if 'Button - Standard' in metadata and '143x64' in metadata:family='Button - Standard';index='3';expected='143x64'
  elif 'Switch - Flat' in metadata and '70x29' in metadata:family='Switch - Flat';index='5';expected='70x29'
  elif 'Lamp - Flat' in metadata and '143x64' in metadata:
   pilot=ROOT/'evidence/page26-lamp-gallery-approved.json'
   if not pilot.exists():raise ValueError('Original lamp gallery identity not reviewed')
   family='Lamp - Flat';index=json.loads(pilot.read_text(encoding='utf8'))['index'];expected='143x64'
  else:raise ValueError('Source bitmap variant requires a new original-gallery review')
  choose(d,pid,family,standard_index=index,readback_fn=native_rows)
  picture=native_rows(d)
  if not all(any(r['type']=='Text' and r['name']==v for r in picture) for v in (family,expected)):
   (ROOT/f'evidence/page{page}-{kind}{n}-picture-mismatch.json').write_text(json.dumps(picture,ensure_ascii=False,indent=2),encoding='utf8')
   cancel(d);raise ValueError('Pre-save bitmap family/size mismatch; target not saved')
  combined_colors=None
  if mode=='repair-all':
   from eb_color_picker import set_rgb,probe
   from eb_native_form import typed_children
   from pywinauto.controls.win32_controls import ComboBoxWrapper
   original=json.loads((ROOT/f'evidence/page{page}-{kind}{n}-source-colors.json').read_text(encoding='utf8'))
   tab(d,'标签');label_used=any(r['name']=='使用文字标签' and r.get('value')==1 for r in native_rows(d))
   scopes=['图片']+(['标签'] if label_used else [])
   if set(original['colors'])!=set(scopes):raise ValueError('Original/target label-enable mismatch')
   combined_colors=original['colors']
   for scope in scopes:
    tab(d,scope);cs=[c for c in typed_children(d,'ComboBox') if c.element_info.name=='状态 :']
    if len(cs)!=1:raise ValueError('One native state selector required')
    for state in ('0','1'):
     ComboBoxWrapper(cs[0].handle).select(state)
     want=combined_colors[scope][state]
     if set_rgb(d,want,'颜色 :')['after']!=want:raise ValueError('Combined RGB write/read mismatch')
  confirm(d);save(root)
  d,_=properties(root,w,f'{kind}_{n}',title);tab(d,'一般属性');after=native_rows(d)
  vals=lambda rs:[(r['type'],r['name'],r['value']) for r in rs if 'value' in r]
  if vals(before)!=vals(after):raise ValueError('Switch general parameters changed')
  tab(d,'图片');actual=native_rows(d)
  if not all(any(r['type']=='Text' and r['name']==v for r in actual) for v in (family,expected)):raise ValueError('Bitmap readback mismatch')
  tab(d,'轮廓');shape_after=native_rows(d)
  if vals(shape_before)!=vals(shape_after):raise ValueError('Existing geometry changed')
  if combined_colors is not None:
   for scope in scopes:
    tab(d,scope);cs=[c for c in typed_children(d,'ComboBox') if c.element_info.name=='状态 :']
    if len(cs)!=1:raise ValueError('One reopened state selector required')
    for state in ('0','1'):
     ComboBoxWrapper(cs[0].handle).select(state)
     if probe(d,'颜色 :')!=combined_colors[scope][state]:raise ValueError('Combined saved RGB mismatch')
  r={'page':page,'object':f'{kind}_{n}','family':family,'gallery_index':index,'picture':actual,'general_unchanged':True,'geometry_unchanged':True,'color_fields_written':combined_colors is not None,'saved':True,'runtime_verified':False}
  (ROOT/f'evidence/page{page}-{kind}{n}-shape-correction.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
  cancel(d)
  if combined_colors is not None:
   (ROOT/f'evidence/page{page}-{kind}{n}-color-correction.json').write_text(json.dumps({'page':page,'object':f'{kind}_{n}','colors':combined_colors,'saved':True,'native_reopened_rgb_verified':True,'combined_shape_color':True,'runtime_verified':False},ensure_ascii=False,indent=2),encoding='utf8')
