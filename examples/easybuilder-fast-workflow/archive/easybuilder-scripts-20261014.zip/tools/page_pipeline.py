"""Generic source-page rebuild pipeline for the reviewed 8-page family (204/206/210/212/218/221/224/235).

Usage:  python tools/page_pipeline.py 212

Phases: cache original properties (read-only, resumable) -> collect page settings -> create blank
target page at the original size -> build every control from verified 200 templates with per-object
save+reopen verification -> target directory audit -> real compile.

User-authorized appearance scope: structure/address/text/format/geometry first; colors/fonts/galleries
stay deferred (see tools/original-style-deferred.json). The original project is never edited.
"""
import json,re,sys,os,time,traceback,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'tools'))
from eb_rebuild_page import call

PAGES=(204,206,210,212,218,221,224,235)
SRC_TITLE='组装机2台15工位取消.cmtp'
TGT_TITLE='组装机_MT8106iP.emtp'
REVIEWED=(1848,1281)
BACKUP=ROOT/'backup/tools-old-name-20261011_220309'
DEFERRED=ROOT/'tools/original-style-deferred.json'
PAGE=int(sys.argv[1]) if len(sys.argv)>1 else 212
WF=ROOT/('evidence/page%d-build-workflow.json'%PAGE)

def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
def load(p):return json.loads(p.read_text(encoding='utf8'))

def patch(path,old,new,expect=1,tag='edit'):
    f=ROOT/path
    b=f.read_bytes();bom=b[:3]==b'\xef\xbb\xbf'
    text=b.decode('utf-8-sig') if bom else b.decode('utf-8')
    if new in text:return tag+':already'
    n=text.count(old)
    if n!=expect:raise ValueError('%s anchor count=%d expected %d; no edit'%(tag,n,expect))
    BACKUP.mkdir(parents=True,exist_ok=True)
    dst=BACKUP/(f.name+'.before-%s.bak'%tag)
    if not dst.exists():shutil.copy2(f,dst)
    out=text.replace(old,new)
    data=(b'\xef\xbb\xbf'+out.encode('utf-8')) if bom else out.encode('utf-8')
    tmp=f.with_suffix(f.suffix+'.tmp');tmp.write_bytes(data);tmp.replace(f)
    if f.read_bytes()!=data:raise ValueError('%s readback mismatch'%tag)
    return tag+':edited'

def authorize_deferred_appearance():
    """The reviewed copy path is gated on the original-appearance requirement; this page is authorized."""
    if DEFERRED.exists():
        d=load(DEFERRED)
        if PAGE not in d.get('pages',[]):d['pages']=sorted(set(list(d.get('pages',[]))+[PAGE]));write(DEFERRED,d)
    else:
        write(DEFERRED,{'date':'2026-10-11','pages':[PAGE],'reason':'用户选择：先结构与地址，外观差异后续统一处理',
            'scope':'结构/地址/文字/格式/几何按原件；颜色/字体/图库/表格细节暂继承已验证200模板并登记为待统一适配',
            'original_style_required_file':'tools/original-style-required.json'})
    gate_old="(ROOT/'tools/original-style-required.json').exists() and not q.get('local_original_template') and not "
    gate_new="(ROOT/'tools/original-style-required.json').exists() and not q.get('local_original_template') and not q.get('deferred_original_appearance') and not "
    return {'gate':patch('tools/eb_copy_200_style_object.py',gate_old,gate_new,tag='pipeline-gate')}

def windows():
    call('snapshot')
    for _ in range(30):
        try:return [w for w in load(ROOT/'evidence/windows.json') if w.get('title')]
        except Exception:time.sleep(.1)
    raise ValueError('windows.json unreadable')

def size_of(w):return (w['rect'][2]-w['rect'][0],w['rect'][3]-w['rect'][1])

def find(ws,title):
    m=[w for w in ws if title in w['title']]
    if len(m)!=1:raise ValueError('Exactly one window required: %s (found %d)'%(title,len(m)))
    return m[0]

def calibrate(w):
    if size_of(w)!=REVIEWED:
        call('uia',w['handle'],json.dumps({'restore_target_window':True,'reviewed_size':True}))
    return w['handle']

def main():
    if PAGE not in PAGES:raise ValueError('Reviewed 8-page family only: %s'%str(PAGES))
    lock=ROOT/'tools/batch.lock'
    with lock.open('x',encoding='utf8') as fh:fh.write(json.dumps({'pid':os.getpid(),'task':'pipeline%d'%PAGE},ensure_ascii=False))
    out=None
    try:
        out={'page':PAGE,'date':time.strftime('%Y-%m-%dT%H:%M:%S'),'cached':[],'built':[],'finished':False,'runtime_verified':False}
        out['authorization']=authorize_deferred_appearance();write(WF,out)
        print(json.dumps({'authorization':out['authorization'],'page':PAGE},ensure_ascii=False),flush=True)
        inv=load(ROOT/'evidence/source-pages-inventory.json')
        rec=next(p for p in inv['pages'] if p['id']==PAGE)
        names=rec['observed_objects']
        keys=[re.search(r'(?:^|\])\s*([A-Z]+_\d+)',n)[1] for n in names]
        if len(keys)!=len(set(keys)):raise ValueError('Duplicate source keys')
        order=sorted(keys,key=lambda k:(k.split('_')[0],int(k.split('_')[1])))
        out['total']=len(order);out['keys']=order;write(WF,out)
        print(json.dumps({'objects':len(order),'kinds':sorted(set(k.split('_')[0] for k in order))},ensure_ascii=False),flush=True)
        ws=windows();src=find(ws,SRC_TITLE);tgt=find(ws,TGT_TITLE)
        h=calibrate(tgt)
        src=find(windows(),SRC_TITLE)
        print(json.dumps({'source':src['handle'],'target':h,'src_size':size_of(src),'tgt_size':REVIEWED},ensure_ascii=False),flush=True)
        # Phase 1: read-only source property cache
        for name in names:
            key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)[1]
            path=ROOT/'evidence/source-object-properties'/('%d_%s.json'%(PAGE,key))
            if not path.exists():
                call('uia',src['handle'],json.dumps({'extract':{'page':PAGE,'object':name,'basic_only':True}},ensure_ascii=False))
            if not path.exists():raise ValueError('Extract produced no cache for %s'%name)
            out['cached'].append(key)
        write(WF,out)
        print(json.dumps({'cached':len(out['cached'])},ensure_ascii=False),flush=True)
        # Phase 2: page settings
        sp=ROOT/'evidence/source-pages-settings'/('%03d.json'%PAGE)
        if not sp.exists():
            call('uia',src['handle'],json.dumps({'page_settings':PAGE,'color_probe':True}))
            if not sp.exists():raise ValueError('Page settings cache missing')
        s=load(sp)
        vals={c['name']:c['value'] for c in s['controls'] if c['type']=='Edit' and c['name'] in ('窗口名称 :','窗口编号 :','宽度 :','高度 :')}
        out['page_settings']=vals;out['background_rgb']=s.get('background_rgb');write(WF,out)
        print(json.dumps({'page_settings':vals,'background':s.get('background_rgb')},ensure_ascii=False),flush=True)
        # Phase 3: blank target page
        created=ROOT/'evidence'/('target-page-%d-created.json'%PAGE)
        for attempt in range(1,4):
            if created.exists():break
            q={'create_target_page':PAGE}
            if any(w.get('title')=='窗口设置' for w in windows()):q['resume']=True
            print(json.dumps({'stage':'create-page','attempt':attempt,'resume':bool(q.get('resume'))},ensure_ascii=False),flush=True)
            try:
                call('uia',h,json.dumps(q))
            except Exception as e:
                if attempt==3:raise
                print(json.dumps({'create_retry':str(e)[-200:]},ensure_ascii=False),flush=True)
                time.sleep(3)
        if not created.exists():raise ValueError('Page creation evidence missing')
        print(json.dumps({'stage':'page-created'},ensure_ascii=False),flush=True)
        # Phase 4: controls from verified 200 templates, save+reopen verified per object
        for key in order:
            kind,n=key.split('_');n=int(n)
            report=ROOT/'evidence'/('target-%d-%s%d-built.json'%(PAGE,kind,n))
            if report.exists() and load(report).get('saved_reopened_verified'):
                out['built'].append(key);write(WF,out);continue
            phase=ROOT/'evidence'/('target-%d-%s-copy-phase.json'%(PAGE,key))
            q={'page':PAGE,'copy_200_style_object':key,'build_bit_general':0}
            if phase.exists():
                stage=load(phase).get('stage')
                if stage in ('pasted','saved-unverified'):q['recover_existing']=True
                elif stage=='paste_requested':raise ValueError('Unknown paste outcome; inspect journal: '+key)
            out['current']=key;write(WF,out)
            for attempt in range(1,4):
                try:
                    call('uia',h,json.dumps(q,ensure_ascii=False));break
                except Exception as e:
                    if attempt==3:raise
                    print(json.dumps({'retry':key,'attempt':attempt,'error':str(e)[-200:]},ensure_ascii=False),flush=True)
                    time.sleep(3)
                    if phase.exists():
                        stage=load(phase).get('stage')
                        if stage in ('pasted','saved-unverified'):q['recover_existing']=True
                        elif stage=='paste_requested':raise ValueError('Unknown paste outcome; inspect journal: '+key)
            if not report.exists():raise ValueError('No saved report after build: '+key)
            if not load(report).get('saved_reopened_verified'):raise ValueError('Unverified build: '+key)
            out['built'].append(key);write(WF,out)
            print(json.dumps({'built':len(out['built']),'total':len(order),'key':key},ensure_ascii=False),flush=True)
        # Phase 5: directory audit
        try:
            call('uia',h,json.dumps({'target_page_audit':PAGE}));out['audit_ok']=True
        except Exception as e:
            out['audit_ok']=False;out['audit_error']=str(e)[:400]
        af=ROOT/'evidence'/('target-page%d-audit.json'%PAGE)
        if af.exists():
            a=load(af)
            out['audit']={'source_count':a.get('source_count'),'target_count':a.get('target_count'),'missing':a.get('missing'),
                          'unexpected':a.get('unexpected'),'address_name_mismatch':a.get('address_name_mismatch'),'tree_verified':a.get('tree_verified')}
        write(WF,out)
        print(json.dumps({'audit':out.get('audit')},ensure_ascii=False),flush=True)
        # Phase 6: real compile
        call('uia',h,json.dumps({'compile_target':True}))
        out['compile']=load(ROOT/'evidence/latest-project-compile.json')
        out['finished']=bool(out.get('audit_ok') and out['compile'].get('ok'))
        write(WF,out)
        print(json.dumps({'finished':out['finished'],'messages':out['compile']['messages'],
                          'project_bytes':out['compile']['project_bytes'],'exob_bytes':out['compile']['exob_bytes']},ensure_ascii=False),flush=True)
    except Exception as e:
        out=out or {};out['error']=traceback.format_exc();write(WF,out)
        print(json.dumps({'error':str(e)[:700]},ensure_ascii=False),flush=True)
        raise
    finally:
        lock.unlink(missing_ok=True)

if __name__=='__main__':main()
