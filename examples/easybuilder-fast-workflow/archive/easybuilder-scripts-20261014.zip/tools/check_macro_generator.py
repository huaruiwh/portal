"""Offline source-generation check; does not connect to HMI or PLC."""
import io,sys,json
from pathlib import Path
root=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(root/'research'/'EasyBuilderMacroGenerator'/'src'))
from eb_macro_gen.syntax import Macro,vbool
from eb_macro_gen.objects import Tag,DataType
macro=Macro('offline_generator_check','Offline check only')
value=vbool('mode_value',True)
tag=Tag('mode','Local HMI','LB,9000',DataType.Bit)
with macro:
 macro.write(tag.write(value))
out=io.StringIO();macro.display(out)
code=out.getvalue()
assert 'macro_command main()' in code
assert 'SetData(mode_value, "Local HMI", LB,9000, 1)' in code
(root/'evidence'/'github-generator-check.txt').write_text(code,encoding='utf8')
metadata='''macro_definition_begin
    "id": "200"
    "name": "offline_generator_check"
    "startup": "false"
    "periodic": [ "false" ]
    "interlock": [ "false" ]
macro_definition_end

'''
(root/'output'/'试验'/'200_offline_generator_check.ebm').write_text(metadata+code,encoding='utf8')
print(json.dumps({'generated':True,'characters':len(code),'easybuilder_compiled':False}))
