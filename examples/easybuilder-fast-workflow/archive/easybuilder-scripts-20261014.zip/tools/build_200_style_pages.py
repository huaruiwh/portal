"""Serial, resumable reconstruction of the eight user-authorized pneumatic pages."""
import os,sys,json,re,traceback,shutil
from datetime import datetime
from eb_rebuild_page import ROOT,call

PAGES=(204,206,210,212,218,221,224,235)
def ui(h,q):return call('uia',h,json.dumps(q,ensure_ascii=False))

def main():
    requested=[int(x) for x in sys.argv[1:]] or list(PAGES)
    if any(p not in PAGES for p in requested):raise ValueError('Unapproved page')
    lock=ROOT/'tools/batch.lock'
    with lock.open('x',encoding='utf8') as f:json.dump({'pid':os.getpid(),'task':'eight-page-200-style','pages':requested},f)
    workflow=ROOT/'evidence/eight-page-build-workflow.json'
    d=json.loads(workflow.read_text(encoding='utf8')) if workflow.exists() else {'completed':[]}
    d.pop('error',None)
    d.update(date=datetime.now().isoformat(timespec='seconds'),pid=os.getpid(),status='running')
    def checkpoint():
        workflow.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
        cp=ROOT/'evidence/resume-checkpoint.json';c=json.loads(cp.read_text(encoding='utf8'))
        c.update(status='eight-page-'+d['status'],active_page=d.get('page'),batch_running=d['status']=='running',next='Read eight-page-build-workflow.json and batch.lock. Never duplicate pasted objects; inspect copy-phase before recovery.',requested_pages=list(PAGES),current_stage=d.get('stage'))
        cp.write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding='utf8')
    try:
        backup=ROOT/'backup/八页重建前_20261011.emtp'
        if not backup.exists():shutil.copy2(ROOT/'output/组装机_MT8106iP.emtp',backup)
        ui(133522,{'selector':True,'op':'selecttab','type':'TabItem','name':'目录树','summary':True})
        ui(10488686,{'selector':True,'op':'selecttab','type':'TabItem','name':'目录树','summary':True})
        for page in requested:
            if page in d['completed']:continue
            d['page']=page;d['stage']='source-settings';checkpoint()
            if not (ROOT/f'evidence/source-pages-settings/{page:03d}.json').exists():ui(133522,{'page_settings':page,'color_probe':True})
            iv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
            names=next(r['observed_objects'] for r in iv['pages'] if r['id']==page)
            from eb_flow_model import counts
            counts(page)
            for name in names:
                key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)[1]
                d['stage']='cache '+key;checkpoint()
                if not (ROOT/f'evidence/source-object-properties/{page:03d}_{key}.json').exists():ui(133522,{'extract':{'page':page,'object':name,'basic_only':True}})
            d['stage']='create target page';checkpoint()
            if not (ROOT/f'evidence/target-page-{page:03d}-created.json').exists():ui(10488686,{'prepare_200_style_page':page,'build_bit_general':0,'trace_slow':True})
            for name in names:
                key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)[1];kind,n=key.split('_')
                d['stage']='copy and verify '+key;checkpoint()
                report=ROOT/f'evidence/target-{page:03d}-{kind}{n}-built.json'
                if report.exists():
                    if not json.loads(report.read_text(encoding='utf8')).get('saved_reopened_verified'):raise ValueError('Saved report not verified; inspect '+key)
                    continue
                ui(10488686,{'page':page,'copy_200_style_object':key,'build_bit_general':0})
                print(json.dumps({'page':page,'saved_verified':key}),flush=True)
            d['stage']='directory audit';checkpoint();ui(10488686,{'target_page_audit':page})
            d['completed'].append(page);checkpoint()
        d['status']='pages-saved-final-review-pending';d['stage']='Review table line positions/z-order/font fit and obtain new actual compilation before completion'
    except Exception:
        d['status']='needs-review';d['error']=traceback.format_exc();print(d['error'],flush=True)
    finally:
        checkpoint();lock.unlink(missing_ok=True)
        print(json.dumps({'status':d['status'],'completed_pages':d['completed'],'page':d.get('page'),'stage':d.get('stage')},ensure_ascii=False),flush=True)

if __name__=='__main__':main()
