"""Recreate page12 bit lamps using a verified built-in Flat picture preset."""
import json,time
from pathlib import Path
from pywinauto import Desktop
from pywinauto.controls.win32_controls import EditWrapper,ComboBoxWrapper,ButtonWrapper
from pywinauto.keyboard import send_keys
from eb_extract import rows
ROOT=Path(__file__).resolve().parent.parent

def run(handle,request):
    start=time.monotonic();n=int(request['build_bl']);page=int(request.get('page',12));kind=request.get('kind','BL')
    from eb_template_guard import validate_object
    if kind=='TS':
        from eb_bit_switch_guard import validate
        source=validate(page,n)
    elif kind=='BL':
        validate_object(page,'BL',n)
        source=json.loads((ROOT/'evidence'/'source-object-properties'/f'{page:03d}_BL_{n}.json').read_text(encoding='utf8'))
    else:raise ValueError('Unsupported bit object type')
    general=source['tabs']['一般属性']
    address=next(c['value'] for c in general if c['type']=='Edit' and c['name']=='Static')
    from eb_layout import geometry as adapt_geometry
    geometry=adapt_geometry(source)
    native_root=Desktop(backend='win32').window(handle=handle).wrapper_object()
    pid=native_root.process_id()
    w=Desktop(backend='uia').window(handle=handle).wrapper_object()
    if '组装机_MT8106iP.emtp' not in native_root.window_text() or f'[{page} - ' not in native_root.window_text():raise ValueError('Expected target page')
    r=native_root.rectangle()
    if (r.width(),r.height()) not in ((2218,1537),(1848,1281)):raise ValueError('Ribbon/layout changed')
    profile={(447,63):(427,63),(736,111):(532,138),(373,111):(378,103),(1156,440):(963,367)}
    def point(x,y):return profile[(x,y)] if r.width()==1848 else (x,y)
    if not request.get('resume') and any(c.window_text().startswith(f'{kind}_{n} ') for c in w.descendants(control_type='TreeItem')):raise ValueError('Object already exists')
    def dialog(title):
        for _ in range(20):
            matches=[d for d in Desktop(backend='win32').windows() if d.process_id()==pid and d.window_text()==title and d.is_visible()]
            if len(matches)==1:return Desktop(backend='uia').window(handle=matches[0].handle).wrapper_object()
            time.sleep(.1)
        raise ValueError('Dialog not ready: '+title)
    def c(d,typ,name,index=None):
        matches=[v for v in d.descendants(control_type=typ) if v.window_text()==name and v.is_visible()]
        if index is None:
            if len(matches)!=1:raise ValueError('Unique selector required: '+name)
            return matches[0]
        return matches[index]
    def edit(d,name,value):
        obj=c(d,'Edit',name);native=EditWrapper(obj.handle);native.set_edit_text(value)
        if native.window_text().rstrip('\r\n')!=value.rstrip('\r\n'):raise ValueError('Edit readback failed: '+name)
    def combo(d,name,value):
        obj=c(d,'ComboBox',name);native=ComboBoxWrapper(obj.handle);native.select(value)
        if native.selected_text()!=value:raise ValueError('Combo readback failed: '+name)
    def checkbox(d,name,value):
        obj=c(d,'CheckBox',name)
        native=ButtonWrapper(obj.handle)
        if native.get_check_state()!=value:native.click()
        time.sleep(.05)
        if native.get_check_state()!=value:raise ValueError('Checkbox readback failed: '+name)
    if not request.get('resume'):
        if page in (11,48,49):
            from eb_ribbon import create
            create(native_root,'BIT','新增 位状态指示灯/位状态切换开关')
        else:native_root.set_focus();native_root.click_input(coords=point(447,63));time.sleep(.1);native_root.click_input(coords=point(373,111))
    d=dialog('新增 位状态指示灯/位状态切换开关')
    c(d,'TabItem','一般属性').select()
    lamp=c(d,'RadioButton','位状态切换开关' if kind=='TS' else '位状态指示灯');ButtonWrapper(lamp.handle).send_message_timeout(0x00F5,timeout=2)
    if ButtonWrapper(lamp.handle).get_check_state()!=1:raise ValueError('Lamp mode verification failed')
    combo(d,'设备 :',next(v['value'] for v in general if v['type']=='ComboBox' and v['name']=='设备 :'))
    if kind=='TS':
        checkbox(d,'读取/写入使用不同的地址',0);checkbox(d,'触发宏指令',0);combo(d,'操作模式 :','复归型')
        actual=c(d,'ComboBox',' Down')
        if actual.selected_text()!='M':
            from eb_address_type import choose as choose_type
            choose_type(actual,'M',pid)
    edit(d,'Static',address)
    checkbox(d,'输出反向',0)
    general_readback=rows(d)
    if [v.get('value') for v in general_readback if v['type']=='ComboBox' and v['name']==' Down']!=(['M'] if kind=='TS' else ['LB']):raise ValueError('Bit address type mismatch')
    c(d,'TabItem','图片').select();checkbox(d,'使用图片',1);checkbox(d,'调整对象尺寸为图片原尺寸',0)
    pictures=rows(d)
    if not any(v['name']=='Button - Flat' and v['type']=='Text' for v in pictures):
        from eb_flat_picture import choose
        choose(d,pid);pictures=rows(d)
    c(d,'TabItem','标签').select()
    use_label=next(v['value'] for v in source['tabs']['标签'] if v['name']=='使用文字标签' and v['type']=='CheckBox')
    checkbox(d,'使用文字标签',use_label)
    labels={}
    if use_label:
        if kind=='TS' and not source.get('label_states'):
            from eb_native_form import fields
            text=next(v['value'] for v in source['tabs']['标签'] if v['type']=='Edit' and v['name']=='')
            states=[v for v in d.descendants(control_type='ComboBox') if v.window_text()=='状态 :' and v.is_visible()]
            if len(states)==1:
                for state in ('0','1'):
                    ComboBoxWrapper(states[0].element_info.handle).select(state);fields(d,source['tabs']['标签'])
                from eb_label_commit import commit
                commit(d,[text,text])
                for state in ('0','1'):
                    ComboBoxWrapper(states[0].element_info.handle).select(state);labels[state]=rows(d)
                labels['single']=labels['0']
            else:
                fields(d,source['tabs']['标签'])
                from eb_native_form import commit_text
                commit_text(d,'',text);labels['single']=rows(d)
        else:
            for state in ('0','1'):
                text=next(v['value'] for v in source['label_states'][state] if v['type']=='Edit' and v['name']=='')
                combo(d,'状态 :',state);combo(d,'字体 :','微软正黑体 Light');combo(d,'尺寸 :',next(v['value'] for v in source['label_states'][state] if v['type']=='ComboBox' and v['name']=='尺寸 :'));edit(d,'',text)
                labels[state]=rows(d)
            texts=[next(v['value'] for v in source['label_states'][state] if v['type']=='Edit' and v['name']=='') for state in ('0','1')]
            from eb_label_commit import commit
            commit(d,texts)
    from eb_press_safety import apply as apply_safety
    apply_safety(d,source)
    c(d,'Button','确定').click_input();time.sleep(.15)
    native_root.set_focus();native_root.click_input(coords=point(1156,440));send_keys('{ESC}',pause=.01);time.sleep(.15)
    matches=[v for v in w.descendants(control_type='TreeItem') if v.window_text().startswith(f'{kind}_{n} ')]
    if len(matches)!=1:raise ValueError('New lamp not uniquely present')
    name=matches[0].window_text();matches[0].double_click_input(coords=(40,matches[0].rectangle().height()//2))
    d=dialog('位状态切换开关/位状态指示灯的属性' if kind=='TS' else '位状态指示灯/位状态切换开关的属性');readback=rows(d)
    if next(v['value'] for v in readback if v['type']=='Edit' and v['name']=='Static')!=address:raise ValueError('Created lamp address mismatch')
    c(d,'TabItem','轮廓').select()
    for key,value in geometry.items():edit(d,key,value)
    shape=rows(d);c(d,'Button','确定').click_input();native_root.set_focus();send_keys('^s',pause=.01)
    report={'page':page,'source':source['object'],'target':name,'general':readback,'picture':pictures,'labels':labels,'geometry':shape,'elapsed_seconds':round(time.monotonic()-start,3),'saved_requested':True,'picture_color_review_pending':True}
    (ROOT/'evidence'/f'target-{page:03d}-{kind}{n}-built.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
