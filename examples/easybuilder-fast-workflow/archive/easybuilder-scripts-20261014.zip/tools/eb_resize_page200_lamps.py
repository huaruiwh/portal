"""User adjustment: BL2/BL3 width and height equal the actual target BL10."""
import json
from eb_rebuild_page import ROOT
from eb_extract import rows
from eb_object_ui import target,properties,save
from eb_native_form import tab,fields,confirm,typed_children
from eb_native_messages import msg

def run(handle,q):
 root,w=target(handle,200);title='位状态指示灯/位状态切换开关的属性'
 def shape(d):
  tab(d,'轮廓')
  return {r['name']:r['value'] for r in rows(d) if r['type']=='Edit' and 'value' in r and r['name'] in ('X :',' Y :',' 宽度 :','高度 :')}
 def cancel(d):
  bs=[b for b in typed_children(d,'Button') if b.window_text()=='取消']
  if len(bs)!=1:raise ValueError('Unique read-only cancel required')
  msg(bs[0].handle,245)
 d,_=properties(root,w,'BL_10',title);template=shape(d);cancel(d)
 dimensions={k:template[k] for k in (' 宽度 :','高度 :')}
 if len(dimensions)!=2:raise ValueError('Observed width/height fields required')
 items=[]
 keys=['BL_3'] if q.get('only_1_rear') else (['BL_11'] if q.get('only_2_rear') else ['BL_2','BL_3'])
 for key in keys:
  d,_=properties(root,w,key,title);before=shape(d)
  fields(d,[{'type':'Edit','name':k,'value':v} for k,v in dimensions.items()]);after=shape(d)
  if any(after[k]!=v for k,v in dimensions.items()):raise ValueError('Lamp dimensions mismatch')
  if any(after[k]!=v for k,v in before.items() if k not in dimensions):raise ValueError('Unexpected position change')
  confirm(d);save(root)
  d,_=properties(root,w,key,title);reopened=shape(d);cancel(d)
  if reopened!=after:raise ValueError('Saved lamp geometry mismatch')
  items.append({'key':key,'before':before,'after':after,'reopened':reopened})
 path=ROOT/'evidence/page200-lamp-size-user-adjustment.json'
 if (q.get('only_2_rear') or q.get('only_1_rear')) and path.exists():
  previous=json.loads(path.read_text(encoding='utf8'))
  items=[item for item in previous['items'] if item['key'] not in keys]+items
 path.write_text(json.dumps({'template':'BL_10 / 2前位','dimensions':dimensions,'items':items,'verified':True},ensure_ascii=False,indent=2),encoding='utf8')
