"""Local phase timings; no screenshots or extra provider queries."""
import json,time,os
from pathlib import Path
from functools import wraps
LOG=Path(__file__).resolve().parent.parent/'evidence/uia-phase-timing.jsonl'
def timed(fn):
    @wraps(fn)
    def measured(*args,**kwargs):
        start=time.perf_counter();ok=False
        try:
            result=fn(*args,**kwargs);ok=True;return result
        finally:
            row={'time':time.time(),'pid':os.getpid(),'phase':fn.__module__+'.'+fn.__name__,'seconds':round(time.perf_counter()-start,4),'ok':ok}
            if fn.__name__=='run' and len(args)>1 and isinstance(args[1],dict):
                row['request']={k:args[1][k] for k in ('page26_shapes','page','kind','n') if k in args[1]}
            with LOG.open('a',encoding='utf8') as f:
                f.write(json.dumps(row)+'\n')
    return measured
