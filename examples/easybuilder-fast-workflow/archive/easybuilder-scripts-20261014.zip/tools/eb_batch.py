"""One UIA connection per batch; exact selectors, readback, stop on failure."""
import json, time
from pathlib import Path
from pywinauto import Desktop
from pywinauto.controls.win32_controls import EditWrapper, ComboBoxWrapper

ROOT = Path(__file__).resolve().parent.parent

def run(handle, request):
    root = Desktop(backend='uia').window(handle=handle).wrapper_object()
    titles = [w.window_text() for w in Desktop(backend='win32').windows(visible_only=False)
              if w.process_id() == root.process_id() and w.class_name() == 'EasyBuilderPro']
    if len(titles) != 1 or '组装机_MT8106iP.emtp' not in titles[0]:
        raise ValueError('Batch requires one target reconstruction project')
    results = []
    start = time.monotonic()
    try:
        for step in request['batch']:
            op = step['op']
            if step.get('root'):
                control = root
            else:
                matches = [c for c in root.descendants(control_type=step['type'])
                           if c.element_info.name == step['name'] and c.is_visible()]
                if 'occurrence' not in step and len(matches) != 1:
                    raise ValueError(f'Expected unique selector: {step["type"]}/{step["name"]}: {len(matches)}')
                control = matches[step.get('occurrence', 0)]
            def read():
                if control.element_info.control_type == 'Edit':
                    return control.get_value().rstrip('\r\n')
                if control.element_info.control_type == 'ComboBox':
                    return control.selected_text()
                return control.window_text()
            if op == 'setvalue':
                if control.element_info.control_type != 'Edit':
                    raise ValueError('setvalue requires Edit')
                root.set_focus()
                if control.element_info.class_name in ('Edit', 'RichEdit20W') and control.element_info.handle:
                    EditWrapper(control.element_info.handle).set_edit_text(step['value'])
                else:
                    control.click_input()
                    control.set_edit_text(step['value'])
                if read() != step['value']:
                    raise ValueError('Batch value readback mismatch')
            elif op == 'selectitem':
                if control.element_info.class_name != 'ComboBox':
                    raise ValueError('Batch selectitem requires native ComboBox')
                ComboBoxWrapper(control.element_info.handle).select(step['value'])
                if read() != step['value']:
                    raise ValueError('Batch selection readback mismatch')
            elif op == 'assert':
                if read() != step['value']:
                    raise ValueError(f'Assertion mismatch: {read()!r}')
            elif op == 'invoke':
                if control.element_info.control_type != 'Button':
                    raise ValueError('Batch invoke requires Button')
                control.invoke()
            elif op != 'read':
                raise ValueError(f'Unsupported batch operation: {op}')
            results.append({'step': len(results), 'op': op,
                            'value': None if op == 'invoke' else read()})
        report = {'ok': True, 'steps_completed': len(results), 'results': results}
    except Exception as error:
        report = {'ok': False, 'steps_completed': len(results), 'results': results,
                  'error': f'{type(error).__name__}: {error}'}
    report['elapsed_seconds'] = round(time.monotonic() - start, 3)
    (ROOT/'evidence'/'batch-result.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    (ROOT/'evidence'/'uia.json').write_text(json.dumps(results, ensure_ascii=False), encoding='utf8')
    if not report['ok']:
        raise RuntimeError(report['error'])
