"""Finish a placed and currently-open reviewed PLC switch; never recreate it."""
import json
from pywinauto import Desktop
from pywinauto.keyboard import send_keys
from eb_extract import rows,ROOT
from eb_native_form import tab,fields,confirm
from eb_layout import geometry
def run(handle,q):
    page,n=int(q['page']),int(q['finish_bit'])
    from eb_bit_switch_guard import validate
    source=validate(page,n)
    root=Desktop(backend='win32').window(handle=handle).wrapper_object()
    if '组装机_MT8106iP.emtp' not in root.window_text() or f'[{page} - ' not in root.window_text():raise ValueError('Target page only')
    ds=[d for d in Desktop(backend='win32').windows() if d.process_id()==root.process_id() and d.window_text()=='位状态切换开关/位状态指示灯的属性' and d.is_visible()]
    if len(ds)!=1:raise ValueError('Existing switch properties required')
    d=Desktop(backend='uia').window(handle=ds[0].handle).wrapper_object()
    tab(d,'一般属性');general=rows(d)
    names={'设备 :','Static',' Down','操作模式 :','输出反向','读取/写入使用不同的地址','触发宏指令','位状态切换开关'}
    def selected(rs):return [(r['type'],r['name'],r['value']) for r in rs if r['name'] in names and 'value' in r]
    if selected(general)!=selected(source['tabs']['一般属性']):raise ValueError('Placed switch general mismatch')
    tab(d,'标签');labels=rows(d)
    def text(rs):return [r['value'] for r in rs if r['type']=='Edit' and r['name']=='']
    if text(labels)!=text(source['tabs']['标签']):raise ValueError('Placed switch text mismatch')
    tab(d,'轮廓');shape=geometry(source)
    fields(d,[{'type':'Edit','name':k,'value':v} for k,v in shape.items()]);actual=rows(d)
    confirm(d);root.set_focus();send_keys('^s',pause=.01)
    report={'page':page,'source':source['object'],'target':f'TS_{n} (M-26.0)','general':general,'labels':{'single':labels},'geometry':actual,'saved_requested':True,'source_picture':'picture51','replacement_picture':'Button - Flat','appearance_review_pending':True,'functional_simulation_verified':False}
    (ROOT/'evidence'/f'target-{page:03d}-TS{n}-built.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
