import json
from pywinauto import Desktop
from eb_color_picker import rgb,close
from eb_native_messages import msg
from eb_extract import ROOT

def run(handle,q):
 root=Desktop(backend='win32').window(handle=handle).wrapper_object()
 colors=[w for w in Desktop(backend='win32').windows() if w.process_id()==root.process_id() and w.window_text()=='Colors' and w.is_visible()]
 if len(colors)!=1:raise ValueError('One pending Colors required')
 d=Desktop(backend='uia').window(handle=colors[0].handle).wrapper_object()
 tabs=[c for c in d.descendants(control_type='TabItem') if c.window_text()=='Custom']
 if len(tabs)==1:tabs[0].select()
 value=rgb(d);close(d,'Cancel')
 p=ROOT/'evidence/header-10-SP_0-color-recovery.json';p.write_text(json.dumps({'pending_picker_rgb':value,'project_modified':False,'complete_color_check':False},ensure_ascii=False,indent=2),encoding='utf8')
 props=[w for w in Desktop(backend='win32').windows() if w.process_id()==root.process_id() and w.class_name()=='#32770' and w.is_visible()]
 if len(props)!=1:raise ValueError('One pending vector property required')
 d=Desktop(backend='uia').window(handle=props[0].handle).wrapper_object()
 cs=[c for c in d.descendants(control_type='Button') if c.window_text()==chr(21462)+chr(28040) and c.is_visible()]
 if len(cs)!=1:raise ValueError('One cancel required')
 msg(cs[0].handle,245)
