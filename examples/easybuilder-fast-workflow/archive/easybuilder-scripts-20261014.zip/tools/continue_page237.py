import json,os,re,traceback
from pathlib import Path
from eb_rebuild_page import ROOT,call
r=ROOT;p=r/'evidence/page237-build-workflow.json';lock=r/'tools/batch.lock'
if lock.exists():raise RuntimeError('Controller already running')
lock.write_text(json.dumps({'pid':os.getpid(),'task':'build237'}),encoding='utf8')
previous=json.loads(p.read_text(encoding='utf8'))if p.exists()else {}
def accepted(proof):return bool(proof.get('saved_reopened_verified') or (proof.get('property_session_verified') and proof.get('saved')))

d={'page':237,'built':[],'finished':False,'reference':228, 'native_control_reference':228,'target_height':469,'deferred_types':previous.get('deferred_types',[]),'deferred_edits':previous.get('deferred_edits',[])}
def record():
 p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
 marker='\n### 2026-10-13：237页参考228重建进度'
 text=marker+'\n'+json.dumps(d,ensure_ascii=False)+'\n脚本 tools/continue_page237.py，目标890×469，源参数缓存复用，单件完整控件60秒。仅通过同弹窗参数读回并保存、或保存重开的控件计入built，整页每类代表重开；颜色图库仍需原件复核，不执行任何源关闭宏、不下载。\n'
 for f in ['README.md','docs/MT8106iP重建-实现记录.md']:
  path=r/f;t=path.read_text(encoding='utf8');idx=t.find(marker)
  if idx>=0:
   end=t.find('\n### ',idx+len(marker));t=t[:idx]+(t[end:]if end>=0 else '')
  path.write_text(t+text,encoding='utf8')
try:
 height=json.loads((r/'evidence/scale-890x469/page-237-initial-height.json').read_text(encoding='utf8'))
 if not height['saved_reopened_verified']:raise ValueError('Height not verified')
 call('snapshot');ws=json.loads((r/'evidence/windows.json').read_text(encoding='utf8'));h=next(w['handle']for w in ws if '组装机_MT8106iP.emtp'in w['title'])
 inv=json.loads((r/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(x['observed_objects']for x in inv['pages']if x['id']==237)
 keys=sorted([re.search(r'(?:^|\])\s*([A-Z]+_\d+)',n)[1]for n in names],key=lambda k:(k.split('_')[0],int(k.split('_')[1])))
 # Reuse known unavailable types from236 only when the device/type source
 # rows match; user requested no repeated type validation.
 prior236=json.loads((r/'evidence/page236-build-workflow.json').read_text(encoding='utf8'))
 for entry in prior236.get('deferred_types',[]):
  key=entry['key'];a=json.loads((r/f'evidence/source-object-properties/236_{key}.json').read_text(encoding='utf8'));b=json.loads((r/f'evidence/source-object-properties/237_{key}.json').read_text(encoding='utf8'))
  identity=lambda obj:[(scope,row['type'],row['name'],row.get('value'))for scope,rows in obj['tabs'].items()for row in rows if scope in ('一般属性','项目选单','源数据') and (row['type'],row['name']) in (('ComboBox','设备 :'),('ComboBox',' Down'))]
  if identity(a)==identity(b) and not any(x['key']==key for x in d['deferred_types']):d['deferred_types'].append(dict(entry,reason='Known unavailable from236; matching device/type; user skips validation',user_authorized_skip=True))
 d['total']=len(keys);record()
 for offset in range(0,len(keys),1):
  batch=keys[offset:offset+1];pending=[]
  if any(x['key']==batch[0]for x in d['deferred_edits']):continue
  if any(x['key']==batch[0]for x in d['deferred_types']):
   if not(r/f'evidence/target-237-{batch[0]}-deferred-layout.json').exists():call('uia',h,json.dumps({'page237_controls':[],'place_deferred_type':batch[0],'build_bit_general':0}))
   continue
  for key in batch:
   report=r/f'evidence/target-237-{key}-built.json'
   if not report.exists()or not accepted(json.loads(report.read_text(encoding='utf8'))):pending.append(key)
  if pending:
   d['current_batch']=pending;record()
   try:call('uia',h,json.dumps({'page237_controls':pending,'build_bit_general':0}))
   except RuntimeError as error:
    msg=str(error)
    if 'Source combo choice unavailable: 资料格式 :'in msg or ('Unique observed address type item required:'in msg and re.search(r'item required: (?:DB[A-Za-z]*|VD|VW|VB|[MIQ](?:B|W|D)?)(?:[^A-Za-z]|$)',msg)):
     d['deferred_types'].append({'key':pending[0],'reason':msg,'verified':False,'user_authorized_skip':True});record()
     call('uia',h,json.dumps({'page237_controls':[],'place_deferred_type':pending[0],'build_bit_general':0}));continue
    if len(pending)==1 and "Original appearance readback differs" in msg and "Edit" in msg:
     key=pending[0];phase=r/f'evidence/target-237-{key}-copy-phase.json'
     if phase.exists()and json.loads(phase.read_text(encoding='utf8')).get('stage')=='saved-unverified':
      try:call('uia',h,json.dumps({'page237_controls':pending,'build_bit_general':0}))
      except RuntimeError:
       diff=r/f'evidence/page237-{key}-readback-difference.json'
       if not diff.exists()or json.loads(diff.read_text(encoding='utf8')).get('scope')!='标签':raise
       d.setdefault('label_recoveries',[]).append({'key':key,'action':'one original-label repair on saved control; no paste'});record()
       call('uia',h,json.dumps({'page237_controls':[],'repair_saved_labels':key,'build_bit_general':0}))
       call('uia',h,json.dumps({'page237_controls':pending,'build_bit_general':0}))
      proof=json.loads((r/f'evidence/target-237-{key}-built.json').read_text(encoding='utf8'))
      if not accepted(proof):raise ValueError('Label repair unverified '+key)
      d['built'].append(key);record();continue
    if len(pending)==1 and ('Live field dialog closed before capture'in msg or 'InvalidWindowHandle'in msg or 'Dialog not ready:'in msg):
     key=pending[0];journal=r/f'evidence/target-237-{key}-copy-phase.json'
     if journal.exists()and json.loads(journal.read_text(encoding='utf8')).get('stage')=='saved-unverified':
      d.setdefault('window_recoveries',[]).append({'key':key,'action':'one fresh saved-control readback; no rewrite/paste'});record()
      call('uia',h,json.dumps({'page237_controls':pending,'build_bit_general':0}))
      proof=json.loads((r/f'evidence/target-237-{key}-built.json').read_text(encoding='utf8'))
      if not accepted(proof):raise ValueError('Fresh-window recovery unverified '+key)
      d['built'].append(key);record();continue
    if len(pending)!=1 or not ('timed out after 60 seconds'in str(error)or('Original appearance readback differs'in str(error)and '内容'in str(error))):raise
    journal=r/f'evidence/target-237-{pending[0]}-copy-phase.json'
    if not journal.exists()or json.loads(journal.read_text(encoding='utf8')).get('stage')!='saved-unverified':raise
    d.setdefault('timeout_recoveries',[]).append({'key':pending[0],'action':'verify saved existing control; no rewrite/paste'});record()
    call('uia',h,json.dumps({'page237_controls':pending,'build_bit_general':0}))
  for key in batch:
   proof=json.loads((r/f'evidence/target-237-{key}-built.json').read_text(encoding='utf8'))
   if key.startswith('OL_') and not accepted(proof):
    call('uia',h,json.dumps({'page237_controls':[key],'build_bit_general':0}))
    proof=json.loads((r/f'evidence/target-237-{key}-built.json').read_text(encoding='utf8'))
   if not accepted(proof):raise ValueError('Unverified control '+key)
   d['built'].append(key)
  record()
 if d['deferred_types']or d['deferred_edits']:
  d['queue_processed']=True;d['finished']=False;d['pending_type_count']=len(d['deferred_types']);d['pending_edit_count']=len(d['deferred_edits']);record()
 else:
  # End-of-page representative reopen, one per control kind.
  samples={}
  for key in keys:samples.setdefault(key.split('_')[0],key)
  for key in samples.values():
   rp=r/f'evidence/target-237-{key}-built.json';proof=json.loads(rp.read_text(encoding='utf8'))
   if proof.get('saved_reopened_verified'):continue
   phase=r/f'evidence/target-237-{key}-copy-phase.json';state=json.loads(phase.read_text(encoding='utf8'));state['stage']='saved-unverified';phase.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf8')
   call('uia',h,json.dumps({'page237_controls':[key],'build_bit_general':0}))
  d['verification_mode']='all fields before save; one representative per kind reopened'
  call('uia',h,json.dumps({'target_page_audit':237}));call('uia',h,json.dumps({'compile_target':True,'entry_via_local_ocr':True}))
  d['finished']=True;record()
except Exception as e:
 d['error']=str(e);record();raise
finally:lock.unlink(missing_ok=True)
