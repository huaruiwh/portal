import json,hashlib,zipfile
from pathlib import Path
from datetime import datetime
ROOT=Path(__file__).resolve().parent.parent
stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
date=datetime.now().isoformat(timespec='seconds')
read=lambda p:json.loads((ROOT/p).read_text(encoding='utf-8-sig'))
assert not (ROOT/'tools/batch.lock').exists()
assert read('tools/request.json')['id']==read('evidence/response.json')['id']
assert read('evidence/response.json')['ok']
assert read('evidence/pause-save-result.json')['target_saved']
def good(name,key):
 p=ROOT/'evidence'/name
 return p.exists() and bool(json.loads(p.read_text(encoding='utf-8-sig')).get(key))
shapes=[f'26:{kind}_{n}' for kind,ns in [('TS',range(7)),('BL',range(3))] for n in ns if good(f'page26-{kind}{n}-shape-correction.json','saved')]
colors=[f'26:{kind}_{n}' for kind,ns in [('TS',range(7)),('BL',range(3))] for n in ns if good(f'page26-{kind}{n}-color-correction.json','native_reopened_rgb_verified')]
output=ROOT/'output/组装机_MT8106iP.emtp'
sha=hashlib.sha256(output.read_bytes()).hexdigest();size=output.stat().st_size
folder=ROOT/'archives';folder.mkdir(exist_ok=True)
archive=folder/f'暂停归档_{stamp}.zip'
cp=read('evidence/resume-checkpoint.json')
cp.update(date=date,status='paused-by-user',paused=True,batch_running=False,controller_pid=None,automation_status='PAUSED',last_saved_output=str(output),last_saved_bytes=size,last_saved_sha256=sha,verified_page26_shapes=shapes,verified_page26_colors=colors,archive_path=str(archive),next='用户明确继续后，先修复BL2颜色弹窗枚举InvalidWindowHandle；核对worker/request/response和无残留弹窗，清除tools/work-paused.json后恢复串行队列。向量84件及新编译/最终交互验收待。')
(ROOT/'evidence/resume-checkpoint.json').write_text(json.dumps(cp,ensure_ascii=False,indent=2),encoding='utf8')
text=f'''
### {date} 用户暂停并归档

- 用户要求“暂停，归档，晚些时间再工作”。控制器3004已经因BL2颜色窗口枚举异常退出，batch.lock已释放；请求响应同ID。自动跟进automation已通过应用工具设为PAUSED；tools/work-paused.json阻止队列误启动。常驻worker保留待命，不发送新建设请求。
- 已取消Colors及目标控件未保存属性，并保存工程，pause-save-result.json记录实际退出窗口。26页形状完成{len(shapes)}个：{shapes}；原色保存重开通过{len(colors)}个：{colors}。BL2颜色没有完成报告，不计完成，下一次从此处处理，不新增已有控件。
- 工程：{output}；实际{size}字节，SHA256 `{sha}`。本阶段尚未新编译，旧EXOB不能视为本轮运行成果。
- 最新失败原文：`pywinauto.controls.hwndwrapper.InvalidWindowHandle: Handle 38143236 is not a vaild window handle`；发生在eb_color_picker.open_picker无process过滤的Desktop.windows全窗口枚举。下一次先按目标PID限定/原生枚举Colors窗口，保留唯一弹窗和短超时读回；暂停期间不继续修改。
- 归档：{archive}，包括保存的EMTP、tools顶层Python/PowerShell/命令脚本与协议文件、同README/实现记录、全部evidence JSON断点及验证报告；不打包Python第三方运行库、旧EXOB或大量截图。电脑关机后可按原README启动管理员worker，不能重放旧request；worker启动按现有request ID初始化。
- 恢复：用户明确继续后先读README、同记录、resume-checkpoint.json、worker-ready.json、request/response、work-paused.json及workflow；确认没有活动控制器和未完成请求。处理上述BL2异常，再清除暂停标志，运行 `Python tools/eb_fix_flow_appearances.py`；已有saved与native_reopened_rgb_verified报告跳过，不复制地址、不重复新增。按需在应用恢复automation，暂停期间保持PAUSED。
- 遗留：BL2原色、其余流程页、84个向量灯、新编译及最终交互验收。保持103用户TS0模板，原件只读，禁止PLC/HMI下载或执行宏。
'''
for rel in ('README.md','docs/MT8106iP重建-实现记录.md'):
 p=ROOT/rel;p.write_text(p.read_text(encoding='utf8')+'\n'+text,encoding='utf8')
files=[output,ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md']
files+=list((ROOT/'evidence').rglob('*.json'))
files += [p for p in (ROOT/'tools').iterdir() if p.is_file() and p.suffix.lower() in ('.py','.ps1','.bat','.cmd','.json')]
files=sorted(set(files))
manifest={'date':date,'archive':str(archive),'output_bytes':size,'output_sha256':sha,'file_count':len(files)+1,'files':[str(p.relative_to(ROOT)) for p in files],'automation_status':'PAUSED','verified_shapes':shapes,'verified_colors':colors}
m=ROOT/'evidence/pause-archive-manifest.json';m.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
files=[p for p in files if p!=m]+[m]
manifest['file_count']=len(files);m.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,str(p.relative_to(ROOT)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(files)
 result={'archive':str(archive),'archive_bytes':archive.stat().st_size,'file_count':len(files),'zip_crc_verified':True,'output_bytes':size,'output_sha256':sha,'shapes':len(shapes),'colors':len(colors),'automation_status':'PAUSED'}
(ROOT/'evidence/pause-archive-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
for rel in ('README.md','docs/MT8106iP重建-实现记录.md'):
 p=ROOT/rel;p.write_text(p.read_text(encoding='utf8')+f"\n归档验真：ZIP {result['archive_bytes']}字节，{result['file_count']}个文件，testzip CRC全部通过；当前工程哈希见上。\n",encoding='utf8')
print(json.dumps(result,ensure_ascii=False))
