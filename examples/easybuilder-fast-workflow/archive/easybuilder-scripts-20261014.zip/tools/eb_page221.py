"""Single-control native203 templates for the different-layout221 page."""
import json,time,re
from pathlib import Path
from pywinauto.keyboard import send_keys
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_rebuild_page import ROOT
from eb_object_ui import target,properties,save
from eb_native_form import tab,fields,confirm,commit_text,typed_children
from eb_page26_shapes import cancel
from eb_layout import geometry
from eb_live_fields import capture
from eb_original_style_existing import verify_fields
from eb_copy_200_style_object import native_clipboard_data,restore_native_clipboard,read_audit
from eb_open_page import run as open_page
from eb_page203_rewrite import plan,TITLES

def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')

from eb_timing import timed

@timed
def template(source):
 kind=re.search(r'(?:^|\])\s*([A-Z]+)_\d+',source['object'])[1];candidates=[]
 source_key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',source['object'])[1]
 journal=ROOT/f'evidence/target-221-{source_key}-copy-phase.json'
 prior=json.loads(journal.read_text(encoding='utf8'))if journal.exists()else {}
 template_page=prior.get('template_page',218)
 template_pages=[template_page] if prior else [218]
 paths=[p for page in template_pages for p in sorted((ROOT/'evidence/source-object-properties').glob(f'{page}_{kind}_*.json'))]
 for p in paths:
  if prior.get('stage')in ('pasted','saved-unverified')and p.stem.split('_',1)[1]!=prior['template']:continue
  b=json.loads(p.read_text(encoding='utf8'));edits,unknown=plan(source,b)
  binding=[u for u in unknown if u['scope']in ('一般属性','项目选单','源数据')and u['identity']in [('ComboBox',' Down'),('ComboBox','设备 :')]]
  unknown=[u for u in unknown if u not in binding]
  reviewed=[]
  sourcekey=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',source['object'])[1]
  for u in list(unknown):
   ident=u['identity'];scope=u['scope']
   if kind in ('NE','ND') and scope=='字体' and ident==('Edit','内容'):
    unknown.remove(u);continue # Derived format preview is verified after applying the format.
   allowed=(kind=='TB' and scope=='一般属性' and ident[0]in ('Edit','ComboBox'))or(kind=='TS' and scope=='安全' and ident==('ComboBox','用户限制 Down') and len(u['after'])==1 and u['after'][0]in ('类别 : A','类别 : B','类别 : C','无'))or(kind in ('NE','ND') and scope=='格式' and ident[0] in ('Edit','ComboBox'))or(kind=='OL'and scope=='状态设置'and ident[0]=='Edit'and re.fullmatch(r'Row \d+, Column [123]',ident[1]))or(kind=='OL'and scope=='源数据'and ident==('ComboBox','预设 Down')and len(u['after'])==1 and str(u['after'][0]).isdigit())or(sourcekey in ('TS_17','TS_18')and scope=='安全'and ident==('ComboBox',' Down')and u['before']==['1']and u['after']==['0.1'])or(sourcekey=='SW_0'and scope=='图片'and ident==('CheckBox','调整对象尺寸为图片原尺寸')and u['after']==[0])
   if kind=='BL' and scope=='一般属性' and ident==('CheckBox','若当前状态无相对应的图片时, 不显示图片') and u['after'] in ([0],[1]):allowed=True
   if sourcekey=='TS_8' and scope=='安全' and ((ident==('CheckBox','使用寄存器状态/数值') and u['before']==[1] and u['after']==[0]) or (ident==('ComboBox',' Down') and u['before']==['I','0.1','关闭时不执行任何操作','ON','位'] and u['after']==['0.1'])):allowed=True
   if allowed:
    reviewed.append({'scope':scope,'state':None,'rows':[r for r in source['tabs'][scope]if (r['type'],r['name'])==ident]});unknown.remove(u)
  if unknown:continue
  # Increase item count before editing the generated option table cells.
  edits=sorted(reviewed,key=lambda e:0 if e['scope']=='源数据' or (e['scope']=='安全' and any(r['name']=='使用寄存器状态/数值' for r in e['rows'])) else 1)+edits
  for u in binding:edits.insert(0,{'scope':u['scope'],'state':None,'rows':[r for r in source['tabs'][u['scope']]if (r['type'],r['name'])==u['identity']]})
  def order(e):
   if e['scope']not in ('一般属性','项目选单','源数据'):return 3
   identities={(r['type'],r['name'])for r in e['rows']}
   return 0 if ('ComboBox','设备 :')in identities else 1 if ('ComboBox',' Down')in identities else 2
  forced=[]
  for scope in ('一般属性','项目选单','源数据'):
   for ident in [('ComboBox','设备 :'),('ComboBox',' Down'),('Edit','Static')]:
    rows=[r for r in source['tabs'].get(scope,[])if (r['type'],r['name'])==ident]
    if not rows:continue
    edits=[e for e in edits if not(e['scope']==scope and any((r['type'],r['name'])==ident for r in e['rows']))]
    forced.append({'scope':scope,'state':None,'rows':rows})
  edits=forced+edits
  edits.sort(key=order)
  candidates.append((len(binding),len(edits),int(p.stem.rsplit('_',1)[1]),p,b,edits))
 if not candidates:raise ValueError('No reviewed template with matching original221 safety/behavior: '+source['object'])
 _,_,_,p,b,edits=min(candidates,key=lambda x:x[:3]);return p.stem.split('_',1)[1],b,edits,int(p.stem.split('_',1)[0])

@timed
def verify_saved(handle,key):
 from collections import defaultdict
 from pywinauto import Desktop
 rp=ROOT/f'evidence/target-221-{key}-built.json';phase=ROOT/f'evidence/target-221-{key}-copy-phase.json'
 if not rp.exists()or not phase.exists():return False
 report=json.loads(rp.read_text(encoding='utf8'));state=json.loads(phase.read_text(encoding='utf8'))
 if state.get('stage')!='saved-unverified':return False
 root,w=target(handle,221);ds=[v for v in Desktop(backend='win32').windows()if v.process_id()==root.process_id()and v.is_visible()and v.window_text()==TITLES[key.split('_')[0]]]
 if len(ds)>1:raise ValueError('Ambiguous saved-control dialog')
 d=Desktop(backend='uia').window(handle=ds[0].handle).wrapper_object()if ds else properties(root,w,key,TITLES[key.split('_')[0]])[0]
 try:
  groups=defaultdict(list)
  for e in report['edits']:groups[(e['scope'],e['state'])].extend(e['rows'])
  for (scope,st),rs in groups.items():
   tab(d,scope)
   if st is not None:
    cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :'];ComboBoxWrapper(cs[0].handle).select(st);time.sleep(.1)
   observed=capture(d,list(dict.fromkeys((r['type'],r['name'])for r in rs)))
   try:verify_fields(observed,rs)
   except ValueError:
    write(ROOT/f'evidence/page221-{key}-readback-difference.json',{'scope':scope,'state':st,'expected':rs,'actual':observed});raise
  if key.startswith(('NE_','ND_')):
   source=json.loads((ROOT/f'evidence/source-object-properties/221_{key}.json').read_text(encoding='utf8'))
   tab(d,'格式');rs=[r for r in source['tabs']['格式']if 'value'in r and r['type']in ('Edit','ComboBox','CheckBox','RadioButton')]
   observed=capture(d,list(dict.fromkeys((r['type'],r['name'])for r in rs)))
   try:verify_fields(observed,rs)
   except ValueError:
    write(ROOT/f'evidence/page221-{key}-readback-difference.json',{'scope':scope,'state':st,'expected':rs,'actual':observed});raise
   tab(d,'字体');time.sleep(.1);preview=[r for r in source['tabs']['字体']if r['type']=='Edit'and r['name']=='内容']
   if preview:verify_fields(capture(d,[('Edit','内容')]),preview)
   from eb_font_policy import apply as apply_font_policy
   report['standard_font_verified']=apply_font_policy(d,source,verify_only=True)
  tab(d,'轮廓');g=report['geometry'];verify_fields(capture(d,[('Edit',n)for n in g]),[{'type':'Edit','name':n,'value':v}for n,v in g.items()])
 finally:cancel(d)
 report.update(saved_reopened_verified=True,original_text_preserved=True,verification_recovered_without_rewrite=True);write(rp,report);state['stage']='verified';write(phase,state);return True

def place_deferred(handle,key):
 source=json.loads((ROOT/f'evidence/source-object-properties/221_{key}.json').read_text(encoding='utf8'));g=geometry(source)
 settings=json.loads((ROOT/'evidence/source-pages-settings/221.json').read_text(encoding='utf8'));height=int(next(r['value']for r in settings['controls']if r['type']=='Edit'and r['name']=='高度 :'));ratio=469/height
 g[' Y :']=str(round(int(g[' Y :'])*ratio))
 if '高度 :'in g:g['高度 :']=str(max(30 if key.startswith(('NE_','ND_'))else 1,round(int(g['高度 :'])*ratio)))
 root,w=target(handle,221);d,_=properties(root,w,key,TITLES[key.split('_')[0]])
 try:
  from eb_font_policy import apply as font_policy
  font_policy(d,source)
  tab(d,'轮廓');fields(d,[{'type':'Edit','name':n,'value':v}for n,v in g.items()],commit_edits=True);confirm(d);d=None;save(root)
 finally:
  if d is not None:cancel(d)
 d,_=properties(root,w,key,TITLES[key.split('_')[0]])
 try:
  tab(d,'轮廓');verify_fields(capture(d,[('Edit',n)for n in g]),[{'type':'Edit','name':n,'value':v}for n,v in g.items()])
 finally:cancel(d)
 write(ROOT/f'evidence/target-221-{key}-deferred-layout.json',{'key':key,'geometry':g,'layout_saved_reopened_verified':True,'binding_verified':False,'type_pending':True})


def run(handle,q):
 if q.get('repair_saved_labels'):
  key=q['repair_saved_labels'];source=json.loads((ROOT/f'evidence/source-object-properties/221_{key}.json').read_text(encoding='utf8'));root,w=target(handle,221);d,_=properties(root,w,key,TITLES[key.split('_')[0]])
  try:
   from eb_font_policy import apply as apply_font_policy
   apply_font_policy(d,source);tab(d,'标签')
   cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']
   for st,rs in source['label_states'].items():
    ComboBoxWrapper(cs[0].handle).select(st);time.sleep(.2)
    commit_text(d,'',next(r['value']for r in rs if r['type']=='Edit'and r['name']==''))
   report=json.loads((ROOT/f'evidence/target-221-{key}-built.json').read_text(encoding='utf8'));g=report['geometry'];tab(d,'轮廓');fields(d,[{'type':'Edit','name':n,'value':v}for n,v in g.items()],commit_edits=True);confirm(d);d=None;save(root)
  finally:
   if d is not None:cancel(d)
  return
 if q.get('place_deferred_type'):return place_deferred(handle,q['place_deferred_type'])
 if q.get('numeric_probe'):
  key=q['numeric_probe'];root,w=target(handle,221);d,_=properties(root,w,key,TITLES['NE'])
  try:
   tab(d,'格式');fmt=capture(d,[('ComboBox','资料格式 :'),('Edit','小数点以上位数 :'),('Edit','小数点以下位数 :'),('Edit','设备上限 :'),('Edit','输入上限 :')])
   tab(d,'字体');preview=capture(d,[('Edit','内容')])
   write(ROOT/'evidence/page221-numeric-probe.json',{'format':fmt,'preview':preview})
  finally:cancel(d)
  return
 if q.get('page221_safety_probe'):
  root,w=target(handle,221);d,_=properties(root,w,'TS_17',TITLES['TS'])
  try:
   tab(d,'安全');cs=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name==' Down'and c.is_visible()]
   out=[]
   for c in cs:
    children=[]
    for v in c.descendants():
     e=v.element_info;item={'type':e.control_type,'name':e.name,'class':e.class_name,'handle':e.handle,'rect':str(v.rectangle())}
     if e.control_type=='Edit':item['value']=v.get_value()
     children.append(item)
    out.append({'value':c.selected_text(),'rect':str(c.rectangle()),'children':children})
   write(ROOT/'evidence/page221-safety-probe.json',out)
  finally:cancel(d)
  return
 if q.get('page221_count_probe'):
  from pywinauto import Desktop,mouse
  from eb_color_picker import native_window_handles
  root,w=target(handle,221);d,_=properties(root,w,'OL_2',TITLES['OL'])
  try:
   tab(d,'源数据');cs=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name=='预设 Down'and c.is_visible()]
   if len(cs)!=1:raise ValueError('Unique count probe')
   c=cs[0];r=c.rectangle();out={'class':c.element_info.class_name,'handle':c.handle,'value':c.selected_text(),'rect':[r.left,r.top,r.right,r.bottom]}
   mouse.click(coords=(r.right-10,(r.top+r.bottom)//2));time.sleep(.2)
   out['items']=[{'name':v.element_info.name,'type':v.element_info.control_type,'rect':str(v.rectangle()),'visible':v.is_visible()}for v in c.descendants()if v.element_info.control_type=='ListItem'][:12]
   out['windows']=[{'title':v.window_text(),'class':v.class_name(),'rect':str(v.rectangle())}for h in native_window_handles(d.process_id())for v in [Desktop(backend='win32').window(handle=h).wrapper_object()]]
   write(ROOT/'evidence/page221-count-probe.json',out)
  finally:
   import ctypes
   if ctypes.windll.user32.IsWindowVisible(d.handle):cancel(d)
  return
 keys=q['page221_controls']
 keys=[key for key in keys if not verify_saved(handle,key)]
 if not keys:return
 if all((ROOT/f'evidence/target-221-{key}-built.json').exists()and json.loads((ROOT/f'evidence/target-221-{key}-built.json').read_text(encoding='utf8')).get('saved_reopened_verified')for key in keys):return
 if not keys or len(keys)>4:raise ValueError('Reviewed221 batch up to4')
 inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));observed=[re.search(r'(?:^|\])\s*([A-Z]+_\d+)',s)[1]for s in next(x['observed_objects']for x in inv['pages']if x['id']==221)]
 if not set(keys)<=set(observed)or len(observed)!=54:raise ValueError('Unobserved221 key')
 open_page(handle,{'open_target_page':221})
 # One initial audit per batch, not per individual object.
 actual=read_audit(handle,221);actualkeys={re.search(r'(?:^|\])\s*([A-Z]+_\d+)',n)[1]for n in actual['objects']}
 if actual['unexpected']:raise ValueError('Unexpected221 objects')
 for key in keys:
  rp=ROOT/f'evidence/target-221-{key}-built.json';phase=ROOT/f'evidence/target-221-{key}-copy-phase.json'
  if rp.exists()and json.loads(rp.read_text(encoding='utf8')).get('saved_reopened_verified'):continue
  source=json.loads((ROOT/f'evidence/source-object-properties/221_{key}.json').read_text(encoding='utf8'));basekey,b,edits,template_page=template(source);kind,n=key.split('_');n=int(n)
  if phase.exists():template_page=json.loads(phase.read_text(encoding='utf8')).get('template_page',template_page)
  g=geometry(source)
  settings=json.loads((ROOT/'evidence/source-pages-settings/221.json').read_text(encoding='utf8'))
  original_height=int(next(r['value']for r in settings['controls']if r['type']=='Edit'and r['name']=='高度 :'))
  ratio=469/original_height
  g[' Y :']=str(round(int(g[' Y :'])*ratio))
  if '高度 :'in g:g['高度 :']=str(max(30 if kind in ('NE','ND')else 1,round(int(g['高度 :'])*ratio)))
  if phase.exists():
   state=json.loads(phase.read_text(encoding='utf8'))
   if state['stage']not in ('pasted','saved-unverified')or key not in actualkeys:raise ValueError('Unknown221 paste phase; inspect, do not repeat: '+key)
   if state['template']!=basekey:raise ValueError('221 recovery template differs')
  else:
   if key in actualkeys:raise ValueError('Existing221 without report; no paste')
   samekind={int(k.split('_')[1])for k in actualkeys if k.startswith(kind+'_')}
   if samekind!=set(range(n)):raise ValueError('Sequential221 destination numbering required '+key)
   cp=ROOT/f'evidence/native{template_page}-template-for221-{basekey}-{handle}.bin'
   if cp.exists():data=cp.read_bytes()
   else:
    open_page(handle,{'open_target_page':template_page});root,w=target(handle,template_page);d,_=properties(root,w,basekey,TITLES[kind]);cancel(d);root.set_focus();send_keys('^c',pause=.04);time.sleep(.15);data=native_clipboard_data();cp.write_bytes(data)
   open_page(handle,{'open_target_page':221});root,w=target(handle,221);restore_native_clipboard(data);root.click_input(coords=(963,367))
   write(phase,{'page':221,'key':key,'template_page':template_page,'template':basekey,'stage':'paste-requested'})
   send_keys('^v',pause=.04);time.sleep(.2);root.click_input(coords=(963,367));send_keys('{ESC}',pause=.02)
   # Resolve exact new property identity; do not perform another full-page scan.
   write(phase,{'page':221,'key':key,'template_page':template_page,'template':basekey,'stage':'pasted'})
  root,w=target(handle,221);d,_=properties(root,w,key,TITLES[kind])
  try:
   from eb_font_policy import apply as apply_font_policy
   standard_fonts=apply_font_policy(d,source)
   for e in edits:
    tab(d,e['scope'])
    if e['state']is not None:
     cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']
     if len(cs)!=1:raise ValueError('Unique221 label state required')
     ComboBoxWrapper(cs[0].handle).select(e['state']);time.sleep(.2)
    rs=e['rows']
    if e['scope']in ('文字/批注','标签'):commit_text(d,rs[0]['name'],rs[0]['value'])
    elif (e['scope']=='源数据'and rs[0]['name']=='预设 Down')or(e['scope']=='安全'and rs[0]['type']=='ComboBox'and rs[0]['name']==' Down'):
     cs=[c for c in d.descendants(control_type='ComboBox')if c.element_info.name==rs[0]['name']and c.is_visible()]
     if len(cs)!=1:raise ValueError('Unique221 option item count required')
     c=cs[0];want=str(rs[0]['value'])
     if c.selected_text()!=want:
      from pywinauto import mouse,Desktop
      from eb_color_picker import native_window_handles
      r=c.rectangle();mouse.click(coords=(r.right-10,(r.top+r.bottom)//2));time.sleep(.2)
      items=[];pops=[]
      for _ in range(20):
       pops=native_window_handles(d.process_id(),class_prefix='Qt5QWindowPopup')
       fresh=[v for v in d.descendants(control_type='ComboBox')if v.element_info.name==rs[0]['name']and v.is_visible()]
       items=[v for v in fresh[0].descendants(control_type='ListItem')if v.element_info.name==want]if len(fresh)==1 else []
       if len(items)==len(pops)==1:break
       time.sleep(.05)
      if len(items)!=1 or len(pops)!=1:raise ValueError('Unique221 physical count popup/item required')
      item=items[0];ir=item.rectangle();pr=Desktop(backend='win32').window(handle=pops[0]).rectangle()
      write(ROOT/f'evidence/page221-combo-selection-{key}.json',{'scope':e['scope'],'name':rs[0]['name'],'wanted':want,'before':c.selected_text(),'item_rect':[ir.left,ir.top,ir.right,ir.bottom],'popup_rect':[pr.left,pr.top,pr.right,pr.bottom],'reported_visible':item.is_visible()})
      if not(pr.left<=ir.left<ir.right<=pr.right and pr.top<=ir.top<ir.bottom<=pr.bottom):raise ValueError('221 count item outside observed popup')
      mouse.click(coords=((ir.left+ir.right)//2,(ir.top+ir.bottom)//2));time.sleep(.2);send_keys('{TAB}',pause=.01)
     if c.selected_text()!=want:raise ValueError('221 option count readback failed')
    else:fields(d,rs,commit_edits=True)
   tab(d,'轮廓');fields(d,[{'type':'Edit','name':k,'value':v}for k,v in g.items()],commit_edits=True);confirm(d);d=None;save(root)
  finally:
   if d is not None:cancel(d)
  report={'page':221,'key':key,'template_page':template_page,'template':basekey,'geometry':g,'edits':edits,'source_safety_equal_to_template':not any(e['scope']=='安全'for e in edits),'reviewed_safety_changes':[e for e in edits if e['scope']=='安全'],'font_style_from218':True,'saved_reopened_verified':False,'runtime_verified':False}
  write(rp,report);state=json.loads(phase.read_text(encoding='utf8'));state['stage']='saved-unverified';write(phase,state)
  d,_=properties(root,w,key,TITLES[kind])
  try:
   for e in edits:
    tab(d,e['scope'])
    if e['state']is not None:
     cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :'];ComboBoxWrapper(cs[0].handle).select(e['state']);time.sleep(.2)
    verify_fields(capture(d,[(r['type'],r['name'])for r in e['rows']]),e['rows'])
   tab(d,'轮廓');actualg={r['name']:r['value']for r in capture(d,[('Edit',k)for k in g])}
   if actualg!=g:raise ValueError('221 saved geometry differs '+key)
   from eb_font_policy import apply as apply_font_policy
   report['standard_font_verified']=apply_font_policy(d,source,verify_only=True)
   if kind in ('NE','ND'):
    tab(d,'字体')
    preview=[r for r in source['tabs']['字体']if r['type']=='Edit'and r['name']=='内容']
    if preview:
     time.sleep(.1);verify_fields(capture(d,[('Edit','内容')]),preview)
  finally:cancel(d)
  report.update(saved_reopened_verified=True,original_text_preserved=True);write(rp,report);state['stage']='verified';write(phase,state);actualkeys.add(key)
