import json,time
from pywinauto import Desktop
from pywinauto.keyboard import send_keys
from eb_extract import ROOT,rows
from eb_object_ui import target
from eb_native_form import typed_children
from eb_native_messages import msg

def run(handle,q):
 root,w=target(handle,103);root.set_focus();send_keys('{ESC}',pause=.01);root.click_input(coords=(1103,1153),double=True);time.sleep(.2)
 ds=[d for d in Desktop(backend='win32').windows() if d.process_id()==root.process_id() and d.is_visible() and d.class_name()=='#32770']
 result=[]
 for nd in ds:
  d=Desktop(backend='uia').window(handle=nd.handle).wrapper_object();result.append({'title':nd.window_text(),'controls':rows(d)})
  cancel=[b for b in typed_children(d,'Button') if b.window_text()=='取消']
  if len(cancel)==1:msg(cancel[0].handle,245)
 (ROOT/'evidence/canvas-reset-coordinate-probe.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
