import os,json,traceback
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
with lock.open('x',encoding='utf8') as f:json.dump({'pid':os.getpid(),'task':'202 semantic binding repair'},f)
p=ROOT/'evidence/page202-semantic-repair-workflow.json';r={'completed':[],'status':'running'}
try:
 for key in json.loads((ROOT/'evidence/page202-semantic-repair-queue.json').read_text(encoding='utf8')):
  r['stage']=key;p.write_text(json.dumps(r),encoding='utf8');call('uia',10488686,json.dumps({'rewrite_page202_copy':key,'semantic_repair':True,'build_bit_general':0}));r['completed'].append(key);p.write_text(json.dumps(r),encoding='utf8');print(json.dumps({'verified':key,'count':len(r['completed'])}),flush=True)
 r['status']='completed'
except Exception:r['status']='needs-review';r['error']=traceback.format_exc();print(r['error'],flush=True)
finally:p.write_text(json.dumps(r,indent=2),encoding='utf8');lock.unlink(missing_ok=True)
