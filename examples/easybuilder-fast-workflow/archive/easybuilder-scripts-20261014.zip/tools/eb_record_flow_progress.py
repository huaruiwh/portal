"""Record actual saved flow-page results in the existing documentation."""
import json
from datetime import datetime,timezone,timedelta
from eb_rebuild_page import ROOT

def record(page):
    audit=json.loads((ROOT/f'evidence/page-{page}-roundtrip-audit.json').read_text(encoding='utf8'))
    if not audit['ok']:raise ValueError('Verified roundtrip required for documentation')
    inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
    count=len(next(p['observed_objects'] for p in inventory['pages'] if p['id']==page))
    emtp=(ROOT/'output/组装机_MT8106iP.emtp').stat().st_size
    exob=(ROOT/'output/组装机_MT8106iP.exob').stat().st_size
    compile=json.loads((ROOT/'evidence/latest-project-compile.json').read_text(encoding='utf8'))
    day=datetime.now(timezone(timedelta(hours=8))).date().isoformat()
    note=f'\n{day} 连续批处理：第{page}页{count}/{count}目录核对及保存完成，重开7对象抽查、页面参数和底色通过。EMTP{emtp}字节，EXOB{exob}字节；编译消息：{compile["messages"]}。重开PID{audit["reopened_pid"]}。仍需最终外观、交互与离线仿真验收。\n'
    with (ROOT/'README.md').open('a',encoding='utf8') as f:f.write(note)
    with (ROOT/'docs/MT8106iP重建-实现记录.md').open('a',encoding='utf8') as f:f.write(note)
    p=ROOT/'evidence/resume-checkpoint.json';checkpoint=json.loads(p.read_text(encoding='utf8'))
    checkpoint.update(status='active',bytes=emtp,exob_bytes=exob,target_pid=audit['reopened_pid'],last_verified_flow_page=page,next=f'继续第{page+1}页及后续界面')
    p.write_text(json.dumps(checkpoint,ensure_ascii=False,indent=2),encoding='utf8')
