"""Rebuild only reviewed page200 objects, serially; never download or run macros."""
import json,re,os,traceback
from datetime import datetime
from eb_rebuild_page import ROOT,call
P=ROOT/'evidence/page-200-build-workflow.json'
def ui(h,q):return call('uia',h,json.dumps(q,ensure_ascii=False))
def main():
 lock=ROOT/'tools/batch.lock'
 with lock.open('x',encoding='utf8') as f:json.dump({'pid':os.getpid(),'task':'build page200'},f)
 d={'date':datetime.now().isoformat(timespec='seconds'),'status':'building','completed':[],'pid':os.getpid(),'total':74}
 try:
  from eb_flow_model import counts
  counts(200)
  inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(x['observed_objects'] for x in inv['pages'] if x['id']==200)
  ui(10488686,{'open_target_page':200});ui(10488686,{'adjust_fonts':True,'directory_probe':True,'directory_filter':'6-内体1气动','ensure_page_directory':True})
  for name in names:
   key=re.search(r'(?:^|\])\s*([A-Z]{2}_\d+)',name)[1];kind,number=key.split('_');n=int(number);d['stage']=key;P.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
   rp=ROOT/f'evidence/target-200-{kind}{n}-built.json'
   source_path=ROOT/f'evidence/source-object-properties/200_{key}.json'
   source=json.loads(source_path.read_text(encoding='utf8'))
   need_colors=(kind in ('SP','TX','NE','SW') and not source.get('colors')) or (kind in ('TS','BL') and not source.get('state_colors')) or (kind=='DW' and not source.get('rectangle_colors'))
   if not rp.exists() and (need_colors or kind in ('SP','BL','NE') and not source.get('vector_identity')):
    ui(133522,{'extract':{'page':200,'object':name}})
    source=json.loads(source_path.read_text(encoding='utf8'))
   if not rp.exists():
    if kind=='TX':q={'build_tx':n}
    elif kind=='SP':q={'build_sp':n}
    elif kind in ('TS','BL','SW'):q={'build_bit_general':n,'bit_kind':kind}
    elif kind=='NE':q={'build_numeric':n,'numeric_kind':kind}
    elif kind=='DW':q={'build_rectangle':n}
    elif kind=='FK':q={'build_fk':n}
    elif kind=='TB':q={'build_page200_table':True,'build_bit_general':0}
    else:raise ValueError('Unreviewed source object '+key)
    q['page']=200;ui(10488686,q)
   built=json.loads(rp.read_text(encoding='utf8'))
   inherited_font_verified=built.get('template')=='NE_0' and built.get('saved_reopened_verified',False)
   if not inherited_font_verified and any(any(r['type']=='ComboBox' and r['name']=='字体 :' and 'value' in r for r in rs) for rs in source['tabs'].values()):
    fontpath=ROOT/f'evidence/font-adjustments/200_{key}.json'
    font=json.loads(fontpath.read_text(encoding='utf8')) if fontpath.exists() else {}
    if not font.get('verified'):
     request={'adjust_fonts':True,'page':200,'key':key,'build_bit_general':0}
     if kind=='TX' and n>0:request['size_override']=12
     if not font.get('save_requested'):ui(10488686,dict(request,phase='edit'))
     ui(10488686,dict(request,phase='verify'))
   from eb_saved_progress import record
   record(200,f'{kind}{n}')
   d['completed'].append(key);P.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
  d['status']='saved-object-build-complete'
 except Exception:d['status']='needs-review';d['error']=traceback.format_exc();print(d['error'],flush=True)
 finally:
  P.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8');lock.unlink(missing_ok=True);print(json.dumps({'status':d['status'],'completed':len(d['completed']),'stage':d.get('stage')},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
