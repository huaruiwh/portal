"""Finalize instruction layers, compile and reopen all 15 controls."""
import json,re,time
from eb_rebuild_page import ROOT,call
from eb_layout import geometry
from eb_roundtrip_main import selected

def run(audit_only=False):
    lock=ROOT/'tools/batch.lock'
    with lock.open('x'):pass
    progress={'page':101,'ok':False,'checks':[]}
    path=ROOT/'evidence/page-101-final-roundtrip.json'
    def persist():path.write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf8')
    try:
        def target():
            call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
            found=[w for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
            if len(found)!=1:raise ValueError('Unique target required')
            return found[0]
        w=target()
        def ui(q):return call('uia',w['handle'],json.dumps(q,ensure_ascii=False))
        if not audit_only:
            ui({'open_target_page':101})
            mapping={1:0,0:1,2:2,3:3,4:4,5:5,6:6,7:7}
            # All vectors below text; the accepted green pilot stays globally lowest.
            for n in (7,6,5,4,3,2,0,1):
                progress['stage']=f'layer source SP{n}';persist()
                ui({'page':101,'order_sp':mapping[n],'kind':'SP'})
            progress['stage']='compile';persist()
            ui({'compile_target':True,'start_only':True});time.sleep(2)
            ui({'compile_target':True,'capture_result':True,'expected_pid':w['pid']})
            old=w['pid'];call('keys',w['handle'],'%{F4}');call('launch',value=str(ROOT/'output/组装机_MT8106iP.emtp'))
            for _ in range(20):
                try:
                    w=target()
                    if w['pid']!=old:break
                except ValueError:pass
                time.sleep(.5)
            else:raise ValueError('New process required')
            progress['reopened_pid']=w['pid']
            ui({'restore_target_window':True,'reviewed_size':True});ui({'open_target_page':101})
            ui({'page_settings':101,'target_readonly':True,'color_probe':True})
            settings=json.loads((ROOT/'evidence/target-pages-settings/101.json').read_text(encoding='utf8'))
            progress['dimensions_verified']={c['name']:c['value'] for c in settings['controls'] if c['type']=='Edit' and c['name'] in ('宽度 :','高度 :')}=={'宽度 :':'1024','高度 :':'600'}
            source_settings=json.loads((ROOT/'evidence/source-pages-settings/101.json').read_text(encoding='utf8'))
            if 'background_color_occurrence' not in source_settings:raise ValueError('Fresh source background identity required')
            progress['background_verified']=settings['background_color_label']=='背景颜色 :' and settings['background_rgb']==source_settings['background_rgb']
        else:
            previous=json.loads(path.read_text(encoding='utf8'))
            if previous['reopened_pid']!=w['pid']:raise ValueError('Same freshly read target process required')
            progress.update(reopened_pid=w['pid'],dimensions_verified=previous['dimensions_verified'],background_verified=previous['background_verified'])
        inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
        names=next(p['observed_objects'] for p in inv['pages'] if p['id']==101)
        keys=[re.search(r'(?:^|\])\s*([A-Z]+_\d+)',n)[1] for n in names]
        if not audit_only:
            for name,key in zip(names,keys):
                progress['stage']='read '+key;persist()
                ui({'extract':{'page':101,'object':name,'target_readonly':True,'colors':['图案颜色 :','颜色 :'] if key.startswith('SP') else ['颜色 :'],'color_tab':'图片' if key.startswith('SP') else '文字/批注'}})
        else:
            compiled=(ROOT/'evidence/latest-project-compile.json').stat().st_mtime
            for key in keys:
                cache=ROOT/f'evidence/target-object-properties/101_{key}.json'
                if cache.stat().st_mtime<compiled or not json.loads(cache.read_text(encoding='utf8')).get('read_only_target'):raise ValueError('Fresh reopened cache required')
        src={k:json.loads((ROOT/f'evidence/source-object-properties/101_{k}.json').read_text(encoding='utf8')) for k in keys}
        dst={k:json.loads((ROOT/f'evidence/target-object-properties/101_{k}.json').read_text(encoding='utf8')) for k in keys}
        actual_mapping={}
        def values(rows):return [(c['type'],c['name'],c['value']) for c in rows if 'value'in c]
        for k,s in src.items():
            candidates=[dk for dk,d in dst.items() if dk.split('_')[0]==k.split('_')[0] and geometry(s)==geometry(d)]
            if len(candidates)!=1:raise ValueError('Unique reopened geometry identity required')
            dk=candidates[0];actual_mapping[k]=dk;d=dst[dk]
            c={'source':k,'target':dk,'geometry_verified':True,'colors_verified':s['colors']==d['colors'],'safety_verified':values(s['tabs']['安全'])==values(d['tabs']['安全'])}
            if k.startswith('SP'):c['fill_border_verified']=values(s['tabs']['图片'])==values(d['tabs']['图片'])
            else:c['text_verified']=selected(s['tabs']['文字/批注'],{'内容'})==selected(d['tabs']['文字/批注'],{'内容'})
            progress['checks'].append(c)
        if len(set(actual_mapping.values()))!=15:raise ValueError('One-to-one mapping required')
        ui({'target_page_audit':101})
        directory=json.loads((ROOT/'evidence/target-page101-audit.json').read_text(encoding='utf8'))
        ordered=[re.search(r'(?:^|\])\s*([A-Z]+_\d+)',n)[1] for n in directory['objects']]
        progress['mapping']=actual_mapping
        progress['layers_verified']=ordered[:8]==[actual_mapping[f'SP_{n}'] for n in (1,0,2,3,4,5,6,7)] and '(最下层)' in directory['objects'][0]
        progress['directory_verified']=directory['tree_verified'] and directory['target_count']==15
        progress['offline_simulation_verified']=False
        progress['ok']=all(progress[k] for k in ('dimensions_verified','background_verified','layers_verified','directory_verified')) and all(v for c in progress['checks'] for k,v in c.items() if k.endswith('_verified'))
        persist()
        if not progress['ok']:raise ValueError('Instruction full-page mismatch')
        print(json.dumps({'page':101,'objects':15,'reopened_pid':w['pid'],'ok':True}),flush=True)
    except Exception as e:
        progress['error']=str(e);persist();raise
    finally:lock.unlink(missing_ok=True)

if __name__=='__main__':
    import sys
    run('--audit-only' in sys.argv)
