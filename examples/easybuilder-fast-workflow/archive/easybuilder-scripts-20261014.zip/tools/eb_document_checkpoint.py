"""Append actual phase readbacks and refresh a resumable checkpoint."""
import json
from datetime import datetime
from eb_rebuild_page import ROOT
e=ROOT/'evidence';p=e/'target-032-MS0-phases.json'
phase=json.loads(p.read_text(encoding='utf8'))
project=ROOT/'output/组装机_MT8106iP.emtp'
checkpoint=e/'resume-checkpoint.json'
cp=json.loads(checkpoint.read_text(encoding='utf8'))
cp.update(date='2026-10-08',status='active',bytes=project.stat().st_size,page32_source_cached=21,page32_window_saved=True,page32_background_rgb=[192,192,192],page32_ms_saved=(e/'target-032-MS0-built.json').exists(),page32_ms_phase_file=str(p),next='从32页MS当前弹窗短步骤恢复；已读回字段只在同一未关闭弹窗内可跳过；MS保存后再继续其余控件',resume_strategy='原逐控件创建，复杂属性拆短步骤；后续底色以31页192/192/192为准')
checkpoint.write_text(json.dumps(cp,ensure_ascii=False,indent=2),encoding='utf8')
table=['| 已通过阶段/字段 | 实际读回值 | 是否已存入工程 |','|---|---|---|']
for key,records in phase.get('readbacks',{}).items():
 for r in records:table.append(f"| {key} / {r['name']} | `{r['value']}` | {'MS已确认保存' if cp['page32_ms_saved'] else '当前属性弹窗内，尚未最终确认'} |")
note=f'''

### 2026-10-08 详细操作与恢复手册（记录时间 {datetime.now():%H:%M:%S}）

#### 工程和保存状态
- 正本：`{project}`；当前实际大小：{project.stat().st_size} bytes。
- 源工程：`source/组装机2台15工位取消.cmtp`，只读参考，禁止写入源工程。
- 31页：21个控件已保存、目录及地址名称核对通过；最终重开抽查、最新编译尚未完成。
- 32页：21个源控件参数已缓存；空窗口已保存并打开验证，800×500、边框0、关闭宏`[ID:067] 关闭LB142`、背景RGB(192,192,192)。MS保存标记当前为`{cp['page32_ms_saved']}`。
- 当前目标进程31304、主窗句柄37946980只适用于本次会话；下次先snapshot，不可盲用历史句柄。

#### 单个MS的操作顺序
1. 确认目标标题包含`重建.emtp`与`[32 - `，尺寸1848×1281、DPI120；确认当前是否已有“新增 多状态指示灯/多状态切换开关”弹窗。
2. 没有弹窗且目录没有MS_0时，元件页签(373,52)，MS入口(417,88)打开新增；已有弹窗禁止再次点新增。
3. 图片页：按源属性逐个设置CheckBox（源行索引0、2、4），每项写入后原生读回。图库选择“选择开关”，精确选择`Selector_3_Position_Green`，必须确认`状态数 : 3`。
4. 一般属性：先选中目标RadioButton，再核对未选项；然后描述、数据模式、读写同址、松开指令、操作模式、状态数3、循环启用等；每次一个字段。
5. 地址顺序：设备`Siemens S7-1200/S7-1500` → 地址类型`DBn` → 地址`131482` → 偏移量0。设备变更会改变可见字段，不能预先写不存在的偏移量。
6. 图片名称再核对；标签确认不用文字标签（本页源值0）；安全页逐字段比对源缓存，不跳过安全守卫。
7. 确定并放置一次；目录找到唯一MS_0，打开属性 → 轮廓按源X/Y/宽/高逐项写入读回 → 确定 → Ctrl+S。
8. 只有以上完成才生成`target-032-MS0-built.json`；然后才能让原32页批处理跳过MS，继续其余控件。

#### 已通过读回明细
{chr(10).join(table)}

#### 断点文件与恢复命令
- 字段及阶段：`evidence/target-032-MS0-phases.json`。每个成功请求立即写入；成功字段以`readbacks`键为准，不能把仅有stage字段当成功。
- 源缓存：`evidence/source-object-properties/032_MS_0.json`；整体状态：`evidence/resume-checkpoint.json`。
- 同一新增弹窗仍保持打开，图库已选中时，恢复命令：
```powershell
& "C:\\Users\\wei'ke\\.cache\\codex-runtimes\\codex-primary-runtime\\dependencies\\python\\python.exe" .\\tools\\eb_drive_ms_steps.py 32 37946980 --resume-general
```
- 当前逐字段控制器自动跳过已读回字段；此跳过仅在同一未取消/未关闭的属性弹窗中有效。软件重启、取消或新建弹窗后，必须重新核对/归档该阶段文件，不能沿用未保存字段的成功标记。
- 完成MS并保存后再执行`python.exe tools/eb_continue_flows.py 32`；它通过已保存报告跳过MS和已建窗口，依次完成TS/BL/SW/TX、最下层顺序、目录、编译和重开抽查。

#### 报错及修正
- `timed out after 55 seconds`：整段流程含多次控件遍历，超过单请求限制；改为短阶段，失败前成功字段立即写盘。
- `Unchecked radio source mismatch`：逐字段拆分后先验证未选项，而目标默认选中该项；调整为先选目标RadioButton，再验证未选项。
- `Source field absent on target: ('Edit', '偏移量 :')`：设备未选好时字段尚未出现；改为设备和地址之后写偏移量。
- `Unique observed address type item required: DBn`：诊断已观察到DBn条目；改为一次缓存popup子控件、仅取可见匹配、按runtime_id去重。本轮DBn步骤已返回成功（详见字段明细），其余地址字段仍以即时读回为准。
- 图库操作可能超时后已打开弹窗；先snapshot判定当前弹窗，再单独执行gallery，不再重新打开图库或新增MS。

#### 验收与未完成项
最终验收需32页目录21/21、地址名称与源一致、底色192/192/192、最下层一致、编译真实消息、保存后关闭重开7样本抽查。当前只对表中成功字段及已保存窗口负责；不等于32页完成，未执行仿真或PLC下载。后续按同样方法维护断点，不重复创建31页。
'''
for dest in (ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md'):
 with dest.open('a',encoding='utf8') as f:f.write(note)
print(json.dumps({'recorded_fields':len(phase.get('readbacks',{})),'ms_saved':cp['page32_ms_saved'],'project_bytes':cp['bytes']}))
