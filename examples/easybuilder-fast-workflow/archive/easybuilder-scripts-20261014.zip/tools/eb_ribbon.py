"""Observed creation-entry profiles, keyed by actual window DPI."""
import ctypes,time
from eb_object_ui import dialog

def create(root,kind,title):
    if (root.rectangle().width(),root.rectangle().height())!=(1848,1281):raise ValueError('Reviewed work-window dimensions required')
    dpi=ctypes.windll.user32.GetDpiForWindow(root.handle)
    profiles={120:{'tab':(373,52),'BIT':(312,88),'MS':(417,88),'SW':(614,88),'TX':(154,118),'SP':(177,118),'FK':(691,145),'NUM':(985,90)}}
    if dpi not in profiles or kind not in profiles[dpi]:raise ValueError('Unreviewed ribbon DPI or entry')
    profile=profiles[dpi];root.set_focus();root.click_input(coords=profile['tab']);time.sleep(.15);root.click_input(coords=profile[kind])
    return dialog(root.process_id(),title)
