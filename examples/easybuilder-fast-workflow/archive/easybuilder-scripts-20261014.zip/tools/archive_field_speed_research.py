"""Archive measured, read-only field lookup experiments without editing the HMI."""
import json, pathlib, py_compile
ROOT=pathlib.Path(__file__).resolve().parents[1]
bench=json.loads((ROOT/'evidence/native-id-fields-benchmark.json').read_text(encoding='utf8'))
assert all(r['fields_equal'] and r['reopened_equal'] for r in bench['tabs'])
for name in ('eb_native_id_fields.py','eb_fast_fields.py','eb_fast_fields_benchmark.py','eb_uia.py'):
    py_compile.compile(str(ROOT/'tools'/name),doraise=True)
size=(ROOT/'output/组装机_MT8106iP.emtp').stat().st_size
summary=f'''

### 2026-10-11：继续提速——原生字段身份复用实测

本阶段仅对201页已保存TS_1做只读计时，不粘贴、不改字段、不保存工程。工程实际{size}字节，201页仍18/52件、剩34。未做新编译或运行验收。

整件TS_1此前耗时58.2821607秒；该进程native_rows累计11.732秒、typed_children累计9.333秒、properties累计6.478秒，瓶颈包括重复枚举与打开属性。新增tools/eb_native_id_fields.py：首次学习字段class、GetDlgCtrlID及完整父链；每个新属性弹窗重新解析新HWND，唯一匹配才读回，不沿用已销毁窗口句柄。原生字段不支持时保留旧读取回退，不能省略地址和安全核对。

实测一般属性3字段、标签3字段、轮廓4字段共10字段全部与旧方法相等，关闭重开后也全部相等。详见evidence/native-id-fields-benchmark.json和button-native-field-schema.json。计时如下（秒）：
'''
for r in bench['tabs']:
    summary+=f"- {r['tab']}：旧读取{r['old_capture_seconds']:.9f}；首次学习{r['learn_seconds']:.9f}；重开读取{r['reopened_read_seconds']:.9f}；原生字段{r['native_fields']}，回退字段{len(r['fallback_fields'])}。\n"
summary+='''
已排除的路线：tools/eb_fast_fields.py整张UIA BuildCache绑定首次需4～6秒，标签和轮廓比原读取更慢，未推广到生产建件。对应evidence/fast-fields-benchmark.json。新原生ID路线本次旧读取已受到进程/UIA热缓存影响，不能将前后不同批次数字算作整件加速倍数。

复现：项目目录使用现有管理员worker，先确认无batch.lock/未完成弹窗，再调用eb_rebuild_page.call('uia',目标handle,json.dumps({'fast_fields_benchmark':True,'native_ids':True,'build_bit_general':0},ensure_ascii=False))。tools/eb_fast_fields_benchmark.py只打开TS_1属性、读一般/标签/轮廓、取消、重开核对并取消；证据changed=false。Python为C:\\Users\\wei'ke\\.cache\\codex-runtimes\\codex-primary-runtime\\dependencies\\python\\python.exe。模块py_compile通过。

适用边界与下一步：仅验证读取，尚未接入批量生产或证明整件耗时下降；先将已验证的原生字段定位用于同类按钮，写入仍须正确提交业务模型，Qt地址类型、权限及按压时间不在本次10字段覆盖范围。TS_2原点1秒按压/C权限/无权限隐藏适配仍待，试验副本已移除，禁止重复TS_0/TS_1或重跑removed-unverified-preview阶段盲粘贴。保存后的完整必要验证只做一次，已verified且未编辑跳过。方案、脚本及真实证据留在同一目录，下一次从该断点继续。
'''
for path in (ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md'):
    if '### 2026-10-11：继续提速——原生字段身份复用实测' not in path.read_text(encoding='utf8'):
        with path.open('a',encoding='utf8') as f:f.write(summary)
cp=ROOT/'evidence/resume-checkpoint.json'
d=json.loads(cp.read_text(encoding='utf-8-sig'))
d.update(field_speed_research='native-id-fields-read-reopened-verified',field_speed_benchmark='evidence/native-id-fields-benchmark.json',field_speed_production_integrated=False,project_bytes=size,target_project_bytes=size,page201_objects=18,page201_remaining_objects=34,batch_running=False,next_action='Integrate validated native field lookup for same-kind buttons; preserve Qt/security fallback and business-model commit. TS_2 safety adaptation still pending; do not paste removed preview or duplicate TS_0/TS_1.')
cp.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
for path in (ROOT/'README.md',ROOT/'docs/MT8106iP重建-实现记录.md'):
    note='归档脚本首次报`LookupError: unknown encoding: utf8-sig`，已更正为`utf-8-sig`，追加文档改为标题去重后重跑，断点更新成功。'
    if note not in path.read_text(encoding='utf8'):
        with path.open('a',encoding='utf8') as f:f.write('\n'+note+'\n')
print(json.dumps({'bytes':size,'page201':18,'remaining':34,'native_fields':10,'reopened_equal':True,'production_integrated':False,'docs_updated':2},ensure_ascii=False))
