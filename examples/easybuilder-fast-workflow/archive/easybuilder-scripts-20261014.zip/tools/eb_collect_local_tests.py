"""Read and validate local-HMI test pages 48/49; no target edits."""
import json,re
from eb_rebuild_page import ROOT,call
from eb_template_guard import ALLOWED,validate_page

def run():
    call('snapshot')
    ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
    source=[w for w in ws if w['class']=='EasyBuilderPro' and '组装机2台15工位取消.cmtp' in w['title']]
    if len(source)!=1:raise ValueError('One original source required')
    handle=source[0]['handle']
    inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
    report={'pages':{},'ok':False,'target_edited':False}
    path=ROOT/'evidence/local-tests-48-49-source-review.json'
    for page,counts in ((48,(2,8)),(49,(1,8))):
        names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==page)
        call('uia',handle,json.dumps({'page_settings':page,'color_probe':True}))
        for name in names:
            key=re.match(r'^((?:SW|BL)_\d+)\s',name)
            if not key:raise ValueError('Unreviewed local test object')
            cached=ROOT/f'evidence/source-object-properties/{page:03d}_{key[1]}.json'
            if not cached.exists():call('uia',handle,json.dumps({'extract':{'page':page,'object':name}},ensure_ascii=False))
            print(json.dumps({'page':page,'cached':key[1]}),flush=True)
        ALLOWED[page]=counts
        try:
            validate_page(page,names);report['pages'][str(page)]={'objects':len(names),'template_validated':True}
        except Exception as error:
            report['pages'][str(page)]={'objects':len(names),'template_validated':False,'error':str(error)}
            path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8');raise
        path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    report['ok']=True;path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')

if __name__=='__main__':run()
