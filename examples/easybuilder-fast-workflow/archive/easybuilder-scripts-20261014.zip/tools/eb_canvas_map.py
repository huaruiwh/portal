"""Read native cursor coordinates and EB drawing status to calibrate canvas mapping."""
import json,time,re,ctypes
from pywinauto import Desktop,mouse
from eb_object_ui import target
from eb_extract import ROOT

def run(handle,q):
 root,w=target(handle,103);root.set_focus()
 status=[c for c in w.children() if c.element_info.class_name.startswith('EBRibbonStatusBar')]
 if len(status)!=1:raise ValueError('One observed EB status bar required')
 probes=[]
 for x,y in ((900,400),(1000,500)):
  mouse.move(coords=(x,y));time.sleep(.15)
  names=[c.window_text() for c in status[0].descendants(control_type='Text') if c.is_visible()]
  values={k:int(next(re.search(r'^'+k+r'\s*=\s*(-?\d+)',s).group(1) for s in names if re.search(r'^'+k+r'\s*=\s*(-?\d+)',s))) for k in ('X','Y')}
  probes.append({'screen':[x,y],'canvas':values,'status':names})
 sliders=[c for c in status[0].descendants(control_type='Slider') if c.is_visible()]
 slider=[]
 for c in sliders:
  try:slider.append({'min':c.iface_range_value.CurrentMinimum,'max':c.iface_range_value.CurrentMaximum,'value':c.iface_range_value.CurrentValue})
  except Exception as e:slider.append({'error':str(e)})
 (ROOT/'evidence/canvas-map-probe.json').write_text(json.dumps({'probes':probes,'sliders':slider},ensure_ascii=False,indent=2),encoding='utf8')
