"""Validate text exports against the observed macro manager list."""
import hashlib,json,re
from pathlib import Path
root=Path(__file__).resolve().parent.parent
manager=json.loads((root/'evidence'/'source-macro-manager-uia.json').read_text(encoding='utf8'))
expected={int(re.search(r'ID : (\d+)',r['name'])[1]) for r in manager if r['type']=='ListItem'}
rows=[]
for path in (root/'source'/'macros').glob('*.ebm'):
 raw=path.read_bytes()
 code=raw.decode('utf-8-sig')
 mid=int(re.search(r'"id":\s*"(\d+)"',code)[1])
 name=re.search(r'"name":\s*"([^"]+)"',code)[1]
 rows.append({'id':mid,'name':name,'file':str(path.relative_to(root)),
  'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
  'devices':sorted(set(re.findall(r'(?:Get|Set)Data(?:Ex)?\([^,]+,\s*"([^"]+)"',code))),
  'has_main':bool(re.search(r'macro_command\s+main\s*\(',code)),
  'page_values':re.findall(r'\bpage\s*=\s*(\d+)',code)})
actual={r['id'] for r in rows}
report={'expected_count':len(expected),'exported_count':len(rows),
 'missing_ids':sorted(expected-actual),'unexpected_ids':sorted(actual-expected),
 'macros':sorted(rows,key=lambda r:r['id'])}
assert not report['missing_ids'] and not report['unexpected_ids']
(root/'evidence'/'macros-manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in report.items() if k!='macros'},ensure_ascii=False))
