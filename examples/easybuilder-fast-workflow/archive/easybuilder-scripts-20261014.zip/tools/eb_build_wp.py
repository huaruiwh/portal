"""Rebuild half-auto local word-controlled indirect windows in the MT model."""
import json
from eb_extract import ROOT,rows
from eb_object_ui import target,menu,dialog,placed_properties,save,object_item
from eb_native_form import tab,fields,confirm
from eb_layout import geometry
def run(handle,q):
    page,n=int(q['page']),int(q['build_wp'])
    if page!=17 or n not in (0,1):raise ValueError('Unreviewed indirect window')
    source=json.loads((ROOT/'evidence'/'source-object-properties'/f'{page:03d}_WP_{n}.json').read_text(encoding='utf8'))
    g=source['tabs']['一般属性']
    expectations={('ComboBox','类型 :'):'嵌入父窗口',('ComboBox','设备 :'):'Local HMI',('ComboBox',' Down'):'LW',('CheckBox','使用窗口编号偏移量'):0,('ComboBox','开始 :'):'无',('ComboBox','结束 :'):'无'}
    for (typ,name),value in expectations.items():
        if [r['value'] for r in g if r['type']==typ and r['name']==name]!=[value]:raise ValueError('Unsupported window behavior: '+name)
    if any(r.get('value')!=0 for r in source['tabs']['位置'] if r['type']=='CheckBox'):raise ValueError('Dynamic indirect-window layout unsupported')
    root,w=target(handle,page)
    existing=[c for c in w.descendants(control_type='TreeItem') if c.window_text().startswith(f'WP_{n} ')]
    if existing:raise ValueError('Indirect window already present; verify instead of duplicating')
    if not q.get('resume'):
        root.set_focus();root.click_input(coords=(427,63));menu(root,(1384,137),'间接窗口')
    d=dialog(root.process_id(),'新增 间接窗口');tab(d,'一般属性')
    skip=(('ComboBox','类型 :'),('ComboBox','开始 :'),('ComboBox','结束 :'))
    fields(d,g,skip=skip)
    fields(d,[{'type':'CheckBox','name':'窗口控制条','value':0}]);general=rows(d)
    tab(d,'位置');fields(d,source['tabs']['位置'],skip=(('CheckBox','动态位置'),));position=rows(d)
    confirm(d)
    d,name=placed_properties(root,w,f'WP_{n}','间接窗口的属性')
    tab(d,'一般属性');readback=rows(d)
    names={'Static','设备 :',' Down','使用窗口编号偏移量'}
    def selected(rs):return [(r['type'],r['name'],r['value']) for r in rs if r['name'] in names and 'value' in r]
    if selected(readback)!=selected(g):raise ValueError('Created indirect-window general mismatch')
    tab(d,'轮廓');shape=geometry(source);fields(d,[{'type':'Edit','name':k,'value':v} for k,v in shape.items()]);shape_readback=rows(d)
    confirm(d);save(root)
    report={'page':page,'source':source['object'],'target':name,'general':readback,'position':position,'geometry':shape_readback,'style_mapping':'嵌入父窗口 -> 无窗口控制条','saved_requested':True,'offline_embedded_scaling_review_pending':True}
    (ROOT/'evidence'/f'target-{page:03d}-WP{n}-built.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
