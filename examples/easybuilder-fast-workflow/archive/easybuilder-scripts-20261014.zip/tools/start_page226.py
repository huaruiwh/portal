import json,time,os,subprocess,sys
from eb_rebuild_page import ROOT,call
r=ROOT;lock=r/'tools/later-pages-supervisor.lock';wf=r/'evidence/page226-start-workflow.json'
with lock.open('x',encoding='utf8')as f:f.write(json.dumps({'pid':os.getpid(),'task':'page226-after-cache'}))
d={'page':226,'phase':'waiting-source-cache','finished':False}
def record():wf.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
try:
 record()
 while (r/'tools/batch.lock').exists():time.sleep(2)
 cache=json.loads((r/'evidence/page226-cache-workflow.json').read_text(encoding='utf8'))
 if not cache['finished']:raise ValueError('226 source cache failed; inspect before build')
 call('snapshot');ws=json.loads((r/'evidence/windows.json').read_text(encoding='utf8'));src=next(w['handle']for w in ws if '.cmtp'in w['title']);h=next(w['handle']for w in ws if '组装机_MT8106iP.emtp'in w['title'])
 d['phase']='source-settings';record()
 if not (r/'evidence/source-pages-settings/226.json').exists():call('uia',src,json.dumps({'page_settings':226,'color_probe':True}))
 d['phase']='create';record()
 if not (r/'evidence/target-page-226-created.json').exists():call('uia',h,json.dumps({'create_target_page':226}))
 call('uia',h,json.dumps({'open_target_page':226}))
 if not (r/'evidence/scale-890x469/page-226-initial-height.json').exists():call('uia',h,json.dumps({'scale_post200':{'page':226,'mode':'blank_height'},'build_bit_general':0}))
 d['phase']='whole-page-copy';record()
 journal=r/'evidence/page226-whole-page-copy.json'
 if not journal.exists():call('uia',h,json.dumps({'page226_controls':[],'page226_clone':True,'page215_clone':True,'build_bit_general':0}))
 elif json.loads(journal.read_text(encoding='utf8')).get('stage')!='saved-bindings-pending':raise ValueError('226 copy outcome requires real directory inspection; no repeat paste')
 d['phase']='build';record();p=subprocess.run([sys.executable,str(r/'tools/continue_page226.py')],cwd=r)
 if p.returncode:raise ValueError('226 build stopped; inspect workflow')
 d['finished']=True;record()
except Exception as e:
 d['error']=str(e);record();raise
finally:lock.unlink(missing_ok=True)
