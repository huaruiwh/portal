"""MT event-display mapping; explicitly records cMT-only appearance differences."""
import json
from eb_extract import ROOT,rows
from eb_object_ui import target,dialog,placed_properties,save
from eb_native_form import tab,fields,confirm
from eb_layout import geometry
def run(handle,q):
    page=int(q['page']);n=int(q['build_ed'])
    if (page,n)!=(102,0):raise ValueError('Reviewed alarm object only')
    path=ROOT/'evidence/target-102-ED0-built.json'
    if path.exists():raise ValueError('Saved display exists; audit instead of duplicate')
    s=json.loads((ROOT/'evidence/source-object-properties/102_ED_0.json').read_text(encoding='utf8'))
    root,w=target(handle,page)
    if not q.get('resume'):
        from eb_alarm_entry import run as entry
        entry(handle,{'page':page,'alarm_entry':'ED'})
    d=dialog(root.process_id(),'新增 事件显示');record={}
    tab(d,'一般属性');fields(d,[{'type':'ComboBox','name':'模式 :','value':'即时'}]);fields(d,s['tabs']['一般属性']);record['一般属性']=rows(d)
    tab(d,'事件显示')
    fields(d,[{'type':'ComboBox','name':'显示 Down','value':'单击'},{'type':'Edit','name':'显示的类别范围','value':'0'},{'type':'Edit','name':'显示的类别范围','value':'255'},{'type':'CheckBox','name':'透明','value':0},{'type':'CheckBox','name':'启用','value':1}]);record['事件显示']=rows(d)
    tab(d,'排序')
    fields(d,[{'type':'ComboBox','name':k,'value':v} for k,v in [('日期 :','MM/DD/YY'),('时间 :','HH:MM:SS'),('顺序 :','顺序'),('方式 :','时间')]])
    # Source selected visible columns are trigger time and message; target default matches.
    for i in range(1,9):fields(d,[{'type':'CheckBox','name':f'Row {i}, Column 1','value':int(i in (3,6))}])
    record['排序']=rows(d)
    tab(d,'安全');fields(d,s['tabs']['安全']);record['安全']=rows(d)
    tab(d,'图片');fields(d,s['tabs']['图片']);record['图片']=rows(d)
    tab(d,'字体');fields(d,[r for r in s['tabs']['字体'] if r['name'] in ('尺寸 :','斜体')]);record['字体']=rows(d)
    confirm(d);d,name=placed_properties(root,w,'ED_0','事件显示的属性');tab(d,'轮廓')
    fields(d,[{'type':'Edit','name':k,'value':v} for k,v in geometry(s).items()]);record['轮廓']=rows(d);confirm(d);save(root)
    result={'page':page,'source':s['object'],'target':name,'tabs':record,'saved_requested':True,'fully_verified':False,'pending':['cMT水晶风格、元件标题Caption及列标题在MT无同名字段，需外观适配验收','源MM/DD/YYYY在MT选项不可用，当前MM/DD/YY，需确认日期显示适配','源讯息列宽尚需补读','事件登录数据库未验证，不能宣称报警运行完成','事件配色与图库身份需核对']}
    path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
