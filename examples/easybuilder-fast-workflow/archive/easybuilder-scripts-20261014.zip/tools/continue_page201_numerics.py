"""Resume201 numerics serially, skipping verified reports and pasted phases."""
import json,os
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
with lock.open('x',encoding='utf8') as f:f.write(json.dumps({'pid':os.getpid(),'page':201}))
p=ROOT/'evidence/page201-numerics-workflow.json'
d={'page':201,'pid':os.getpid(),'verified':[],'status':'running'}
def persist():p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
try:
 call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
 hs=[w['handle'] for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
 if len(hs)!=1:raise ValueError('Unique current target required')
 for key in ['NE_'+str(i) for i in range(12)]+['ND_'+str(i) for i in range(4)]:
  kind,n=key.split('_');d['current']=key;persist()
  report=ROOT/f'evidence/target-201-{kind}{n}-built.json'
  if not report.exists() or not json.loads(report.read_text(encoding='utf8')).get('saved_reopened_verified'):
   call('uia',hs[0],json.dumps({'first_axis_numeric':key,'build_bit_general':0}))
  d['verified'].append(key);persist();print(json.dumps({'numeric_verified':key,'count':len(d['verified'])}),flush=True)
 d['status']='numerics-saved-other-controls-pending';persist()
except Exception as e:
 d.update(status='needs-recovery',error=str(e));persist();raise
finally:lock.unlink(missing_ok=True)
