import json
from eb_rebuild_page import ROOT,call
q=lambda h,r:call('uia',h,json.dumps(r,ensure_ascii=False))
q(12257672,{'page26_shapes':'repair','page':26,'kind':'BL','n':0,'build_bit_general':0})
q(198514,{'extract':{'page':26,'object':'BL_0 (DB13Bit-248.3)','keep_open':True}})
q(198514,{'page26_shapes':'source-colors','page':26,'kind':'BL','n':0,'build_bit_general':0})
q(12257672,{'page26_shapes':'target-colors','page':26,'kind':'BL','n':0,'build_bit_general':0})
print('BL0 shape/color saved and reopened')
