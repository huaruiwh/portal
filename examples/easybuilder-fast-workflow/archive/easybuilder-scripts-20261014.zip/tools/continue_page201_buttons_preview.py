"""Serial three-button preview; persistent phases prevent duplicate pastes."""
import json,os,time
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
workflow=ROOT/'evidence/page201-buttons-preview-workflow.json'
state={'page':201,'verified':[],'status':'running'}
def persist():workflow.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf8')
with lock.open('x',encoding='utf8')as f:json.dump({'pid':os.getpid(),'page':201,'task':'buttons-preview','start':time.time()},f)
try:
    call('snapshot');windows=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
    targets=[w['handle']for w in windows if w['class']=='EasyBuilderPro'and'组装机_MT8106iP.emtp'in w['title']]
    if len(targets)!=1:raise ValueError('One target project required')
    for n in range(3):
        state['current']=f'TS_{n}';persist()
        call('uia',targets[0],json.dumps({'page201_button':n,'build_bit_general':0},ensure_ascii=False))
        report=json.loads((ROOT/f'evidence/target-201-TS{n}-built.json').read_text(encoding='utf8'))
        if not report.get('saved_reopened_verified'):raise ValueError('Button verification incomplete')
        state['verified'].append(f'TS_{n}');persist()
        print(json.dumps({'key':f'TS_{n}','copy_seconds':report.get('copy_seconds'),'elapsed_seconds':report['elapsed_seconds']},ensure_ascii=True),flush=True)
    state['status']='saved-preview-awaiting-user';persist()
except Exception as error:
    state.update(status='needs-recovery',error=str(error));persist();raise
finally:lock.unlink(missing_ok=True)
