"""Cache only missing213 original property records, serial worker requests."""
import sys,json,re,time
from pathlib import Path
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
with lock.open('x',encoding='utf8') as f:f.write('213 original property cache')
p=ROOT/'evidence/page213-cache-workflow.json';out={'page':213,'cached':[],'finished':False,'source_readonly':True}
try:
 call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'));src=[w for w in ws if '组装机2台15工位取消.cmtp' in w['title'] and w['class']=='EasyBuilderPro']
 if len(src)!=1:raise ValueError('Unique original required')
 inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(x['observed_objects']for x in inv['pages']if x['id']==213)
 for name in names:
  key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)[1];out['current']=key;p.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
  if not (ROOT/f'evidence/source-object-properties/213_{key}.json').exists():call('uia',src[0]['handle'],json.dumps({'extract':{'page':213,'object':name,'basic_only':True}},ensure_ascii=False))
  out['cached'].append(key);p.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps({'cached':len(out['cached']),'total':len(names)}),flush=True)
 out['finished']=True;p.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
except Exception as e:
 out['error']=str(e);p.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');raise
finally:lock.unlink(missing_ok=True)
