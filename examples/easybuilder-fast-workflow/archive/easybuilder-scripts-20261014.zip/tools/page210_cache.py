"""210 source-property cache: repair rename guards, fix source directory dock, then read-only extract.

Run:  python tools/page210_cache.py
Serial worker requests; resumable (existing cache files are skipped, never rewritten).
Reads the pristine original copy only; never saves or edits the source project.
"""
import json,re,sys,time,traceback,shutil,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'tools'))
from eb_rebuild_page import call

PAGE=210
SRC_TITLE='组装机2台15工位取消.cmtp'
TGT_TITLE='组装机_MT8106iP.emtp'
REVIEWED=(1848,1281)
BACKUP=ROOT/'backup/tools-old-name-20261011_220309'
WF=ROOT/'evidence/page210-cache-workflow.json'
STALE='重建.emtp'
FIXED='组装机_MT8106iP.emtp'

def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')

def patch(path,old,new,expect=None):
    f=ROOT/path
    b=f.read_bytes()
    bom=b[:3]==b'\xef\xbb\xbf'
    text=b.decode('utf-8-sig') if bom else b.decode('utf-8')
    n=text.count(old)
    if n==0:return 'no-op'
    if expect is not None and n!=expect:raise ValueError('%s anchor count=%d expected %d; no edit'%(path,n,expect))
    BACKUP.mkdir(parents=True,exist_ok=True)
    dst=BACKUP/(f.name+'.before-rename-guard-fix.bak')
    if not dst.exists():shutil.copy2(f,dst)
    out=text.replace(old,new)
    data=(b'\xef\xbb\xbf'+out.encode('utf-8')) if bom else out.encode('utf-8')
    tmp=f.with_suffix(f.suffix+'.tmp');tmp.write_bytes(data);tmp.replace(f)
    if f.read_bytes()!=data:raise ValueError('%s readback mismatch'%path)
    return 'fixed %d'%n

def repair_rename_guards():
    """The bulk rename missed bare '重建.emtp' target-title guards; without this every target write is refused."""
    return {'eb_uia.py':patch('tools/eb_uia.py',"'%s'"%STALE,"'%s'"%FIXED,expect=5),
            'eb_batch.py':patch('tools/eb_batch.py',"'%s'"%STALE,"'%s'"%FIXED,expect=1),
            'eb_resume32.py':patch('tools/eb_resume32.py',"'%s'"%STALE,"'%s'"%FIXED,expect=1)}

def windows():
    """windows.json carries pid/class; the worker response carries only handle/title/rect."""
    call('snapshot')
    for _ in range(30):
        try:return [w for w in json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8')) if w.get('title')]
        except Exception:time.sleep(.1)
    raise ValueError('windows.json unreadable')

def size_of(w):return (w['rect'][2]-w['rect'][0],w['rect'][3]-w['rect'][1])

def find(ws,title):
    m=[w for w in ws if title in w['title']]
    if len(m)!=1:raise ValueError('Exactly one window required: %s (found %d)'%(title,len(m)))
    return m[0]

def fix_source_directory(src,ws):
    """Re-dock a floating directory panel, then activate the observed directory-tree tab."""
    pid=src['pid']
    floating=[w for w in ws if w['pid']==pid and w['title']=='目录树' and 'MiniFrame' in w.get('class','')]
    docked=0
    if len(floating)==1:
        rid=str(uuid.uuid4())
        q={'id':rid,'action':'click','handle':floating[0]['handle'],'coords':[110,12],'double':True,'wait':0}
        tmp=ROOT/'tools/request.tmp';tmp.write_text(json.dumps(q,ensure_ascii=False),encoding='utf8');tmp.replace(ROOT/'tools/request.json')
        end=time.monotonic()+120
        while time.monotonic()<end:
            try:r=json.loads((ROOT/'evidence/response.json').read_text(encoding='utf8'))
            except Exception:time.sleep(.1);continue
            if r.get('id')==rid:
                if not r.get('ok'):raise ValueError('Redock failed: %s'%r.get('error'))
                break
            time.sleep(.1)
        else:raise ValueError('Redock response missing')
        docked=1
    tab={'ok':None,'error':None}
    try:tab=call('uia',src['handle'],json.dumps({'selector':True,'type':'TabItem','name':'目录树','op':'selecttab'},ensure_ascii=False))
    except Exception as e:tab={'ok':False,'error':str(e)[:300]}
    return {'floating_directory':len(floating),'redocked':docked,'tab_ok':tab.get('ok'),'tab_error':tab.get('error')}

def main():
    lock=ROOT/'tools/batch.lock'
    with lock.open('x',encoding='utf8') as fh:fh.write('210 source cache')
    out={'page':PAGE,'cached':[],'finished':False,'source_readonly':True,'window_calibrated':False}
    try:
        out['rename_guards']=repair_rename_guards();write(WF,out)
        print(json.dumps({'rename_guards':out['rename_guards']},ensure_ascii=False),flush=True)
        ws=windows();src=find(ws,SRC_TITLE);tgt=find(ws,TGT_TITLE)
        print(json.dumps({'src':src['handle'],'src_size':size_of(src),'tgt':tgt['handle'],'tgt_size':size_of(tgt)},ensure_ascii=False),flush=True)
        for w in (src,tgt):
            if size_of(w)!=REVIEWED:
                call('uia',w['handle'],json.dumps({'restore_target_window':True,'reviewed_size':True}))
                print(json.dumps({'restored':w['handle'],'was':size_of(w)},ensure_ascii=False),flush=True)
        ws=windows()
        for w in ws:
            if SRC_TITLE in w['title'] or TGT_TITLE in w['title']:
                if size_of(w)!=REVIEWED:raise ValueError('Reviewed window size required: %s %s'%(w['title'][-26:],size_of(w)))
        out['window_calibrated']=True;write(WF,out)
        src=find(ws,SRC_TITLE)
        out['directory']=fix_source_directory(src,ws);write(WF,out)
        print(json.dumps({'directory':out['directory']},ensure_ascii=False),flush=True)
        inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
        names=next(p['observed_objects'] for p in inv['pages'] if p['id']==PAGE)
        out['total']=len(names);write(WF,out)
        print(json.dumps({'objects':len(names)},ensure_ascii=False),flush=True)
        for name in names:
            key=re.search(r'(?:^|\])\s*([A-Z]+_\d+)',name)[1]
            out['current']=key
            path=ROOT/'evidence/source-object-properties'/('210_%s.json'%key)
            if not path.exists():
                call('uia',src['handle'],json.dumps({'extract':{'page':PAGE,'object':name,'basic_only':True}},ensure_ascii=False))
            if not path.exists():raise ValueError('Extract produced no cache for %s'%name)
            out['cached'].append(key);write(WF,out)
            print(json.dumps({'cached':len(out['cached']),'total':len(names),'key':key},ensure_ascii=False),flush=True)
        out['finished']=True;write(WF,out)
    except Exception as e:
        out['error']=traceback.format_exc();write(WF,out)
        print(json.dumps({'error':str(e)[:900]},ensure_ascii=False),flush=True)
        raise
    finally:
        lock.unlink(missing_ok=True)

if __name__=='__main__':main()
