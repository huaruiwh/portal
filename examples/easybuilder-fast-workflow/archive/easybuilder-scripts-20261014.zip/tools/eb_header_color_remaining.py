import json
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
with lock.open('x'):pass
try:
 call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'));h=next(w['handle'] for w in ws if w['class']=='EasyBuilderPro' and '_MT8106iP_' in w['title'])
 for p,key,idx in [(10,'SP_0',1),(11,'TX_0',0),(11,'SP_0',0),(11,'SP_0',1)]:
  call('uia',h,json.dumps({'open_target_page':p}))
  call('uia',h,json.dumps({'header_color_check':{'page':p,'key':key,'color_index':idx}}));print(p,key,idx,'read',flush=True)
finally:lock.unlink(missing_ok=True)
