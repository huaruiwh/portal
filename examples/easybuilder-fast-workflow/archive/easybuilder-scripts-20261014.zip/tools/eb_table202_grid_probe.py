"""Local-only blue grid projections using actual canvas cursor calibration."""
import json,re,time
from PIL import ImageGrab
from pywinauto import Desktop,mouse
from eb_rebuild_page import ROOT

def run(handle,q):
 root=Desktop(backend='win32').window(handle=handle).wrapper_object()
 if '[202 - ' not in root.window_text():raise ValueError('Exact page202 required')
 side=q['table_grid_probe']
 expected='组装机2台15工位取消.cmtp' if side=='source' else '组装机_MT8106iP.emtp'
 if expected not in root.window_text():raise ValueError('Exact project required')
 root.set_focus();w=Desktop(backend='uia').window(handle=handle).wrapper_object()
 bars=[c for c in w.children() if c.element_info.class_name.startswith('EBRibbonStatusBar')]
 if len(bars)!=1:raise ValueError('One actual status bar required')
 samples=[]
 for x,y in [(900,400),(1000,500)]:
  mouse.move(coords=(x,y));time.sleep(.15)
  texts=[c.window_text() for c in bars[0].descendants(control_type='Text') if c.is_visible()]
  val={k:int(next(re.search(r'^'+k+r'\s*=\s*(-?\d+)',t).group(1) for t in texts if re.search(r'^'+k+r'\s*=\s*(-?\d+)',t))) for k in ['X','Y']}
  samples.append({'screen':[x,y],'canvas':val})
 sx=100/(samples[1]['canvas']['X']-samples[0]['canvas']['X']);sy=100/(samples[1]['canvas']['Y']-samples[0]['canvas']['Y'])
 ox=900-samples[0]['canvas']['X']*sx;oy=400-samples[0]['canvas']['Y']*sy
 # Clear selection at an empty page margin without changing the original.
 mouse.click(coords=(round(ox+880*sx),round(oy+570*sy)));time.sleep(.1)
 box=[round(ox+523*sx)-2,round(oy+71*sy)-2,round(ox+829*sx)+3,round(oy+502*sy)+3]
 image=ImageGrab.grab(bbox=tuple(box)).convert('RGB');ww,hh=image.size
 xc=[0]*ww;yc=[0]*hh
 for y in range(hh):
  for x in range(ww):
   red,green,blue=image.getpixel((x,y))
   if blue>220 and red<30 and green<30:xc[x]+=1;yc[y]+=1
 def centers(counts,threshold,offset,origin,scale):
  groups=[]
  for i,c in enumerate(counts):
   if c>=threshold:
    if groups and i==groups[-1][-1]+1:groups[-1].append(i)
    else:groups.append([i])
  return [round((offset+sum(g)/len(g)-origin)/scale,2) for g in groups]
 result={'side':side,'samples':samples,'scale':[sx,sy],'origin':[ox,oy],'crop':box,'vertical_lines':centers(xc,hh*.65,box[0],ox,sx),'horizontal_lines':centers(yc,ww*.65,box[1],oy,sy),'image_transmitted':False}
 (ROOT/f'evidence/page202-table-grid-{side}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
