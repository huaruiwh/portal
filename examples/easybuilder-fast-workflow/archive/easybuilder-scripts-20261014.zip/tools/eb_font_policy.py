import json,time
from eb_rebuild_page import ROOT
from eb_native_form import tab,fields,typed_children
from eb_live_fields import capture
from pywinauto.controls.win32_controls import ComboBoxWrapper

def apply(d,source,verify_only=False):
 font=json.loads((ROOT/'tools/font-policy.json').read_text(encoding='utf8'))['font'];result={}
 for scope in ('文字/批注','字体','标签'):
  rs=source['tabs'].get(scope,[])
  if not any(r['type']=='ComboBox'and r['name']=='字体 :'for r in rs):continue
  if scope=='标签'and any(r['type']=='CheckBox'and r['name']=='使用文字标签'and r.get('value')==0 for r in rs):continue
  tab(d,scope);cs=[c for c in typed_children(d,'ComboBox')if c.element_info.name=='状态 :']
  states=ComboBoxWrapper(cs[0].handle).item_texts()if len(cs)==1 else [None]
  result[scope]={}
  for state in states:
   if state is not None:ComboBoxWrapper(cs[0].handle).select(state);time.sleep(.1)
   if not verify_only:fields(d,[{'type':'ComboBox','name':'字体 :','value':font}])
   actual=capture(d,[('ComboBox','字体 :')])[0]['value']
   if str(actual).split(' [')[0]!=font:raise ValueError('Standard font readback differs')
   result[scope][str(state)]=actual
 return result
