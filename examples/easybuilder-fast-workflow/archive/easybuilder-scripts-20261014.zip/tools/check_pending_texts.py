import json,os,subprocess,sys
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
with lock.open('x',encoding='utf8') as f:json.dump({'pid':os.getpid(),'task':'read-only text audit'},f)
try:
    call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
    targets=[w for w in ws if w['class']=='EasyBuilderPro' and '组装机_MT8106iP.emtp' in w['title']]
    if len(targets)!=1:raise ValueError('One target required')
    h=targets[0]['handle'];ui=lambda q:call('uia',h,json.dumps(q,ensure_ascii=False))
    report=json.loads((ROOT/'evidence/text-content-audit.json').read_text(encoding='utf8'))
    pending=sorted(set((r['page'],r['object']) for r in report['pending']))
    for page,key in pending:
        ui({'open_target_page':page})
        ui({'text_live':True,'page':page,'key':key,'build_bit_general':0})
        print(f'{page}:{key} literal text read back',flush=True)
    subprocess.run([sys.executable,str(ROOT/'tools/audit_text_content.py')],check=True)
finally:lock.unlink(missing_ok=True)
