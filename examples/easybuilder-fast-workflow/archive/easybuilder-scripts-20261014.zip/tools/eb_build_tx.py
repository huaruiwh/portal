"""Recreate plain static text; adapt cMT multiline alignment name to MT alignment."""
import json
from eb_extract import ROOT,rows
from eb_object_ui import target,dialog,placed_properties,save
from eb_native_form import tab,fields,confirm,commit_text
from eb_layout import geometry
def run(handle,q):
    page,n=int(q['page']),int(q['build_tx'])
    if page in (10,11):
        if n!=0:raise ValueError('Only cached base-page heading allowed')
        inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
        names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==page)
        if len([x for x in names if 'TX_0' in x])!=1:raise ValueError('Base-page heading identity changed')
        if (ROOT/f'evidence/target-{page:03d}-TX0-built.json').exists():raise ValueError('Saved heading exists; audit instead of duplicate')
        current=ROOT/f'evidence/target-page{page}-audit.json'
        if not current.exists() or 'TX_0' not in json.loads(current.read_text(encoding='utf8'))['missing']:raise ValueError('Fresh missing-heading directory evidence required')
    elif page==100:
        if n!=0:raise ValueError('Only reviewed IO heading allowed')
        inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
        names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==100)
        if names!=['[I/O显示] TX_0 (最下层)']:raise ValueError('IO page inventory changed')
    elif page==102:
        if n!=0:raise ValueError('Only cached alarm heading allowed')
        inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
        names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==102)
        if len(names)!=2 or not any('TX_0' in s for s in names) or not any('ED_0' in s for s in names):raise ValueError('Alarm page inventory changed')
        if (ROOT/'evidence/target-102-TX0-built.json').exists():raise ValueError('Saved text exists; audit instead of duplicate')
    elif page==101:
        if n not in range(7):raise ValueError('Only cached instruction text allowed')
        inventory=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'))
        names=next(p['observed_objects'] for p in inventory['pages'] if p['id']==101)
        import re
        if len(names)!=15 or sorted(int(re.search(r'TX_(\d+)',s)[1]) for s in names if 'TX_' in s)!=list(range(7)):raise ValueError('Instruction page inventory changed')
    elif page not in (16,17):
        from eb_flow_model import counts
        if not 0<=n<counts(page)['TX']:raise ValueError('Unreviewed flow text')
    elif not ((page==17 and n==0) or (page==16 and 0<=n<31)):raise ValueError('Unreviewed plain text')
    if page==16 and n>=20:
        audit=json.loads((ROOT/'evidence/target-page16-audit.json').read_text(encoding='utf8'))
        if audit.get('source_count')!=101 or (f'TX_{n}' not in audit['missing'] and not q.get('finish_existing')):raise ValueError('Complete 101-item source and fresh missing text proof required')
        if (ROOT/f'evidence/target-016-TX{n}-built.json').exists():raise ValueError('Saved text exists; no duplicate creation')
    source=json.loads((ROOT/'evidence'/'source-object-properties'/f'{page:03d}_TX_{n}.json').read_text(encoding='utf8'))
    expected=source['tabs']['文字/批注']
    if page==201:
        from eb_adjust_fonts import fitted
        adapted_geometry=[{'type':'Edit','name':k,'value':v}for k,v in geometry(source).items()]
        size,_=fitted(expected,adapted_geometry,page,13)
        expected=[dict(r,value='微软正黑体 Light')if r['name']=='字体 :'and'value'in r else dict(r,value=str(size))if r['name']=='尺寸 :'and'value'in r else r for r in expected]
    for r in expected:
        if r['type']=='CheckBox' and r['name'] in ('使用文字库 ','使用字符串表','仅作为批注使用 (不会显示于 HMI)') and r['value']!=0:raise ValueError('Text library/comment behavior unsupported')
    text=next(r['value'] for r in expected if r['type']=='Edit' and r['name']=='内容')
    for r in source['tabs']['安全']:
        if r['type']=='CheckBox' and r.get('value')!=0:raise ValueError('Text visibility condition requires a separate template')
    if page!=17 and 'colors' not in source:raise ValueError('Exact source text color required')
    root,w=target(handle,page)
    if q.get('finish_existing'):
        if page!=16 or n not in range(20,31):raise ValueError('Only missing page16 text recovery reviewed')
        from eb_object_ui import properties
        d,name=properties(root,w,f'TX_{n}','文字/批注的属性')
        tab(d,'文字/批注');readback=rows(d)
        actual=next(r['value'] for r in readback if r['type']=='Edit' and r['name']=='内容')
        if actual!=text:raise ValueError('Recovery source text mismatch')
        for label,value in source['colors'].items():
            from eb_color_picker import probe
            if probe(d,label)!=value:raise ValueError('Recovery text color mismatch')
        tab(d,'安全');safety=rows(d)
        if [(r['type'],r['name'],r.get('value')) for r in safety if 'value' in r]!=[(r['type'],r['name'],r.get('value')) for r in source['tabs']['安全'] if 'value' in r]:raise ValueError('Recovery text safety mismatch')
        tab(d,'轮廓');shape=geometry(source);fields(d,[{'type':'Edit','name':k,'value':v} for k,v in shape.items()]);shape_readback=rows(d)
        confirm(d);save(root)
        report={'page':page,'source':source['object'],'target':name,'text':readback,'geometry':shape_readback,'safety':safety,'colors':source['colors'],'saved_requested':True,'recovered_existing':True}
        (ROOT/f'evidence/target-{page:03d}-TX{n}-built.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
        return
    if not q.get('resume'):
        from eb_ribbon import create
        create(root,'TX','新增 文字/批注')
    d=dialog(root.process_id(),'新增 文字/批注');tab(d,'文字/批注')
    adapted=[dict(r,name='水平 :') if r['name']=='多行 :' else r for r in expected]
    fields(d,adapted,skip=(('CheckBox','使用字符串表'),('Edit','内容')));commit_text(d,'内容',text)
    colors=source.get('colors',{})
    if colors:
        from eb_color_picker import set_rgb,probe
        for label,value in colors.items():
            set_rgb(d,value,label)
            if probe(d,label)!=value:raise ValueError('Text color mismatch')
    before=rows(d);tab(d,'安全');fields(d,source['tabs']['安全']);safety=rows(d);confirm(d)
    d,name=placed_properties(root,w,f'TX_{n}','文字/批注的属性')
    tab(d,'文字/批注');readback=rows(d)
    actual=next(r['value'] for r in readback if r['type']=='Edit' and r['name']=='内容')
    if actual!=text:raise ValueError('Created static text mismatch')
    tab(d,'轮廓');shape=geometry(source);fields(d,[{'type':'Edit','name':k,'value':v} for k,v in shape.items()]);shape_readback=rows(d)
    confirm(d);save(root)
    report={'page':page,'source':source['object'],'target':name,'text':readback,'geometry':shape_readback,'safety':safety,'colors':colors,'saved_requested':True,'color_review_pending':not bool(colors)}
    (ROOT/'evidence'/f'target-{page:03d}-TX{n}-built.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
