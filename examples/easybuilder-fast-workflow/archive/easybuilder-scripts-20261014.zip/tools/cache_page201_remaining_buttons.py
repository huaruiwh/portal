import json,os,time
from eb_rebuild_page import ROOT,call
lock=ROOT/'tools/batch.lock'
with lock.open('x',encoding='utf8')as f:f.write(json.dumps({'pid':os.getpid(),'task':'source TS9..14'}))
try:
    call('snapshot');ws=json.loads((ROOT/'evidence/windows.json').read_text(encoding='utf8'))
    h=next(w['handle']for w in ws if w['class']=='EasyBuilderPro'and'组装机2台15工位取消.cmtp'in w['title'])
    inv=json.loads((ROOT/'evidence/source-pages-inventory.json').read_text(encoding='utf8'));names=next(p['observed_objects']for p in inv['pages']if p['id']==201)
    for n in range(9,15):
        p=ROOT/f'evidence/source-object-properties/201_TS_{n}.json'
        if not p.exists():
            name=next(v for v in names if v.startswith(f'TS_{n} '))
            call('uia',h,json.dumps({'extract':{'page':201,'object':name}},ensure_ascii=False))
        s=json.loads(p.read_text(encoding='utf8'))
        matches=[]
        for c in range(9):
            v=json.loads((ROOT/f'evidence/source-object-properties/201_TS_{c}.json').read_text(encoding='utf8'))
            if all(v.get(k)==s.get(k)for k in ('picture_identity','state_colors'))and v['tabs']['安全']==s['tabs']['安全']:matches.append(c)
        print(json.dumps({'n':n,'exact_templates':matches,'picture':s.get('picture_identity')},ensure_ascii=True),flush=True)
finally:lock.unlink()

