"""Deterministic vertical adaptation for the 1024x768 main/half-auto pages."""
import re
def geometry(source):
    result={c['name']:c['value'] for c in source['tabs']['轮廓'] if c['type']=='Edit' and c['name'] in ('X :',' Y :',' 宽度 :','高度 :')}
    if source['page'] in (10,11,16,17,100,101,102,103) and not source.get('read_only_target'):
        for key in (' Y :','高度 :'):
            if key in result:result[key]=str(round(int(result[key])*600/768))
        result[' Y :']=str(max(0,int(result[' Y :'])))
        if '高度 :' in result:result['高度 :']=str(max(1,min(int(result['高度 :']),600-int(result[' Y :']))))
        # MT numeric input with the retained 16-point font saves at least 28px.
        # Source NE3 scales to 26px; use its observed persisted minimum.
        if source['page']==16 and source['object'].startswith('NE_3'):
            result['高度 :']=str(max(28,int(result['高度 :'])))
        # With its original 8-point label, BL4 persists at a 16px native floor:
        # an explicit 12px write was saved then reopened as 16px.
        if source['page']==16 and re.search(r'(?:^|\])\s*BL_4(?:\s|$)',source['object']):
            result['高度 :']=str(max(16,int(result['高度 :'])))
        if ' 宽度 :' in result:result[' 宽度 :']=str(max(1,min(int(result[' 宽度 :']),1024-int(result['X :']))))
        if int(result[' Y :'])>=600 or int(result['X :'])>=1024:raise ValueError('Adapted object origin outside target')
    return result
