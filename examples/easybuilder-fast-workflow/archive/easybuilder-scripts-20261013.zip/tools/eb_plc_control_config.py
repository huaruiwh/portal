"""Observe editor-only PLC-control configuration. Never execute PLC actions."""
import json,time,ctypes,subprocess
from pathlib import Path
from pywinauto import Desktop,mouse
from PIL import ImageGrab
ROOT=Path(__file__).resolve().parent.parent

def run(handle,q):
 action=q['plc_control_config']['action']
 if action in ('configure_target_definition','capture_target_definition'):
  dialog=Desktop(backend='uia').window(handle=handle).wrapper_object()
  roots=[w for w in Desktop(backend='win32').windows() if w.process_id()==dialog.process_id()and '组装机_MT8106iP.emtp'in w.window_text()]
  if len(roots)!=1 or dialog.window_text()!='PLC 控制':raise ValueError('Target PLC definition required')
  from eb_extract import rows
  index=int(q['plc_control_config']['index'])
  source=json.loads((ROOT/f'evidence/plc-control-source-{index+1:03d}.json').read_text(encoding='utf8'))['rows']
  if action=='configure_target_definition':
   from eb_native_form import fields
   from eb_live_inventory import clear
   prop=[r for r in source if r['type']=='ComboBox'and r['name']=='属性']
   fields(dialog,prop);clear(handle);time.sleep(.15)
   # Type choice precedes address: switching LB/LW can reset the address editor.
   keys=[('Edit','描述 :'),('ComboBox','设备 :'),('CheckBox','只在指定的窗口打开时才执行'),('ComboBox','触发模式 :'),('ComboBox','宏指令 :'),('ComboBox',' Down'),('Edit','Static')]
   report=[]
   for typ,name in keys:
    selected=[r for r in source if r['type']==typ and r['name']==name]
    if selected:report.extend(fields(dialog,selected));clear(handle)
   remaining=[r for r in source if 'value'in r and (r['type'],r['name'])not in keys and r['name']!='属性']
   if remaining:report.extend(fields(dialog,remaining))
  captured=rows(dialog)
  (ROOT/f'evidence/plc-control-target-{index+1:03d}.json').write_text(json.dumps({'index':index,'rows':captured,'saved':False},ensure_ascii=False,indent=2),encoding='utf8')
  return
 if action=='capture_source_batch':
  manager=Desktop(backend='win32').window(handle=handle).wrapper_object()
  if manager.window_text()!='PLC 控制':raise ValueError('PLC manager required')
  roots=[w for w in Desktop(backend='win32').windows() if w.process_id()==manager.process_id()and '.cmtp'in w.window_text()]
  if len(roots)!=1:raise ValueError('Original project capture only')
  from eb_color_picker import native_window_handles
  from eb_extract import rows
  from eb_page26_shapes import cancel
  lists=manager.descendants(class_name='ListBox');buttons=[b for b in manager.descendants(class_name='Button')if b.window_text()=='设置...']
  if len(lists)!=1 or len(buttons)!=1:raise ValueError('Unique source list/settings required')
  for index in q['plc_control_config']['indices']:
   file=ROOT/f'evidence/plc-control-source-{index+1:03d}.json'
   if file.exists() and 'rows'in json.loads(file.read_text(encoding='utf8')):continue
   manager.set_focus();lists[0].select(index);buttons[0].click_input()
   props=[]
   for _ in range(15):
    props=[h for h in native_window_handles(manager.process_id(),title_match='PLC 控制')if h!=handle]
    if len(props)==1:break
    time.sleep(.1)
   if len(props)!=1:raise ValueError('Unique source definition required')
   dialog=Desktop(backend='uia').window(handle=props[0]).wrapper_object()
   try:
    read=rows(dialog)
    if any('read_error'in row for row in read):raise ValueError('Source definition field read failed')
    data={'index':index,'rows':read,'source_modified':False,'label':lists[0].item_texts()[index]}
    file.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
   finally:cancel(dialog)
  return
 if action=='capture_source_definition':
  dialog=Desktop(backend='uia').window(handle=handle).wrapper_object()
  roots=[w for w in Desktop(backend='win32').windows() if w.process_id()==dialog.process_id()and '.cmtp'in w.window_text()]
  if len(roots)!=1 or dialog.window_text()!='PLC 控制':raise ValueError('Read source PLC properties only')
  from eb_extract import rows
  data={'index':q['plc_control_config']['index'],'rows':rows(dialog),'source_modified':False}
  (ROOT/f"evidence/plc-control-source-{data['index']+1:03d}.json").write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8');return
 if action=='open_source_definition':
  dialog=Desktop(backend='win32').window(handle=handle).wrapper_object()
  if dialog.window_text()!='PLC 控制':raise ValueError('PLC manager required')
  roots=[w for w in Desktop(backend='win32').windows() if w.process_id()==dialog.process_id()and '.cmtp'in w.window_text()]
  if len(roots)!=1:raise ValueError('Read source definitions only')
  lists=dialog.descendants(class_name='ListBox');buttons=[b for b in dialog.descendants(class_name='Button') if b.window_text()=='设置...' and b.is_visible()]
  if len(lists)!=1 or len(buttons)!=1:raise ValueError('Exact manager list/editor action required')
  index=int(q['plc_control_config']['index'])
  if not 0<=index<lists[0].item_count():raise ValueError('Observed row index required')
  dialog.set_focus();lists[0].select(index);buttons[0].click_input();time.sleep(.15);return
 if action=='copy_source_rows':
  dialog=Desktop(backend='win32').window(handle=handle).wrapper_object()
  if dialog.window_text()!='PLC 控制':raise ValueError('Exact PLC-control editor manager required')
  roots=[w for w in Desktop(backend='win32').windows()if w.process_id()==dialog.process_id()and '.cmtp'in w.window_text()]
  if len(roots)!=1:raise ValueError('Original project only for capture')
  lists=dialog.descendants(class_name='ListBox')
  if len(lists)!=1:raise ValueError('Unique source PLC list required')
  control=lists[0];dialog.set_focus();control.set_focus();control.select(0)
  from pywinauto.keyboard import send_keys
  sequence_before=ctypes.windll.user32.GetClipboardSequenceNumber()
  send_keys('^a^c',pause=.04);time.sleep(.2)
  sequence_after=ctypes.windll.user32.GetClipboardSequenceNumber()
  import win32clipboard as clip
  opened=False;formats=[]
  try:
   clip.OpenClipboard(handle);opened=True;fmt=0
   while True:
    fmt=clip.EnumClipboardFormats(fmt)
    if not fmt:break
    try:name=clip.GetClipboardFormatName(fmt)
    except Exception:name=str(fmt)
    formats.append({'id':fmt,'name':name})
  finally:
   if opened:clip.CloseClipboard()
  (ROOT/'evidence/plc-control-clipboard-formats.json').write_text(json.dumps({'count':control.item_count(),'formats':formats,'sequence_before':sequence_before,'sequence_after':sequence_after},ensure_ascii=False,indent=2),encoding='utf8')
  return
 ctypes.windll.user32.SetProcessDPIAware()
 root=Desktop(backend='win32').window(handle=handle).wrapper_object()
 if not any(name in root.window_text()for name in ('组装机2台15工位取消.cmtp','组装机_MT8106iP.emtp')):raise ValueError('Known local editor only')
 if not root.is_enabled():raise ValueError('Editor blocked by modal; inspect actual dialog')
 root.set_focus();r=root.rectangle()
 if ctypes.windll.user32.GetForegroundWindow()!=handle:raise ValueError('Editor foreground required')
 action=q['plc_control_config']['action']
 if action=='observe_ribbon':
  image=ROOT/'evidence/plc-ribbon-local.png';out=ROOT/'evidence/plc-ribbon-ocr.json'
  ImageGrab.grab(bbox=(r.left,r.top,r.right,r.top+190)).save(image)
  code=(ROOT/'tools/Read-LocalImageText.ps1').read_text(encoding='utf8')
  code=code.replace('param([string]$ImagePath,[string]$OutputPath)',"$ImagePath='"+str(image).replace("'","''")+"';$OutputPath='"+str(out).replace("'","''")+"'")
  p=subprocess.run(['C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoProfile','-Command',code],capture_output=True,text=True,timeout=30)
  if p.returncode:raise RuntimeError('Local OCR failed')
  return
 if action=='click_observed':
  box=q['plc_control_config']['box']
  if len(box)!=4 or not(0<=box[0]<box[2]<=r.width() and 0<=box[1]<box[3]<=190):raise ValueError('Observed ribbon rectangle required')
  mouse.click(coords=(r.left+int((box[0]+box[2])/2),r.top+int((box[1]+box[3])/2)));time.sleep(.2);return
 raise ValueError('Unknown PLC-config editor action')
