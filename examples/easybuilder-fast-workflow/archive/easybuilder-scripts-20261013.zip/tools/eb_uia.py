import sys,os,json,time,ctypes
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
LIB=ROOT/'tools'/'python-libs'
sys.path[:0]=[str(LIB),str(LIB/'win32'),str(LIB/'win32'/'lib'),str(LIB/'Pythonwin')]
os.add_dll_directory(str(LIB/'pywin32_system32'))
from pywinauto import Desktop
if len(sys.argv)>2 and sys.argv[2]:
 batch_request=json.loads(sys.argv[2])
 if 'replace_218_numerics' in batch_request:
  from eb_replace_218_numerics import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'worker_timeout_reload' in batch_request:
  from eb_reload_worker import run
  run(batch_request);sys.exit(0)
 if 'table221_grid_probe' in batch_request:
  from eb_table221_grid_probe import run
  batch_request['table_grid_probe']=batch_request['table221_grid_probe']
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page224_controls' in batch_request:
  from eb_page224 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page223_controls' in batch_request:
  from eb_page223 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page226_controls' in batch_request:
  from eb_page226 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'plc_control_config' in batch_request:
  from eb_plc_control_config import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page313_controls' in batch_request:
  from eb_page313 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page302_controls' in batch_request:
  from eb_page302 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page237_controls' in batch_request or batch_request.get('page237_clone'):
  from eb_page237 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page236_controls' in batch_request:
  from eb_page236 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page235_controls' in batch_request:
  from eb_page235 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page232_controls' in batch_request:
  from eb_page232 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page231_controls' in batch_request:
  from eb_page231 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page230_controls' in batch_request:
  from eb_page230 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page229_controls' in batch_request:
  from eb_page229 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page228_controls' in batch_request:
  from eb_page228 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page225_controls' in batch_request:
  from eb_page225 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page222_controls' in batch_request:
  from eb_page222 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page221_controls' in batch_request:
  from eb_page221 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page220_controls' in batch_request:
  from eb_page220 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page219_controls' in batch_request:
  from eb_page219 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page217_controls' in batch_request:
  from eb_page217 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page216_controls' in batch_request:
  from eb_page216 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page215_controls' in batch_request or batch_request.get('page215_clone'):
  from eb_page215 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page214_controls' in batch_request:
  from eb_page214 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page213_controls' in batch_request:
  from eb_page213 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'scale_post200' in batch_request:
  from eb_scale_post200 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 boundary=ROOT/'tools/appearance-queue-boundary.json'
 if boundary.exists() and 'open_target_page' in batch_request:
  boundary_request=json.loads(boundary.read_text(encoding='utf8'))
  if int(batch_request['open_target_page'])==boundary_request['before_page']:
   boundary.unlink()
   raise ValueError('Queue boundary: original lamp gallery review required before extending repair scope')
 if 'flow_vector' in batch_request:
  from eb_flow_vector import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'page26_shapes' in batch_request:
  from eb_page26_shapes import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'bl0_shape' in batch_request:
  from eb_bl0_shape import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'fit_page10_fk' in batch_request:
  from eb_fit_page10_fk import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'verify_page10_fk_geometry' in batch_request:
  from eb_read_page10_fk_geometry import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'header_color_check' in batch_request:
  from eb_header_color_check import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('recover_header_color'):
  from eb_recover_header_color import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'vector_gallery_read' in batch_request:
  from eb_vector_gallery_read import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('source_picture_family'):
  from eb_picture_family import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('probe_page16_picture'):
  from eb_probe_page16_picture import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('page16_alarm_header'):
  from eb_build_page16_alarm_header import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('build_page16_alarm'):
  from eb_build_page16_alarm import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('prepare_page16_alarm'):
  from eb_prepare_page16_alarm import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('fast_fields_benchmark'):
  from eb_fast_fields_benchmark import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page205_controls'in batch_request or batch_request.get('page205_count_probe')or batch_request.get('page205_safety_probe'):
  from eb_page205 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'page203_rewrite'in batch_request:
  from eb_page203_rewrite import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('page203_clone'):
  from eb_page203 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('page201_final_buttons'):
  from eb_page201_final_buttons import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'page201_option_lists'in batch_request:
  from eb_page201_option_lists import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'page201_other_probe'in batch_request:
  from eb_page201_other_probe import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('page201_rectangles'):
  from eb_page201_rectangles import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'page201_font_batch' in batch_request:
  from eb_page201_font_batch import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('page201_vectors'):
  from eb_page201_vectors import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'page201_text_batch' in batch_request:
  from eb_page201_text_batch import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'page201_batch' in batch_request:
  from eb_page201_batch import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'page201_button' in batch_request:
  from eb_page201_buttons import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('copy_selection_benchmark'):
  from eb_copy_selection_benchmark import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('first_axis_numeric'):
  from eb_page201_numeric import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('page208'):
  from eb_page208 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('speed_benchmark'):
  from eb_speed_benchmark import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('apply_existing_original_style'):
  from eb_original_style_existing import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('read_original_style'):
  from eb_extract import run
  run(int(sys.argv[1]),{'extract':batch_request['read_original_style']});sys.exit(0)
 if batch_request.get('prepare_200_style_page'):
  from eb_create_page import run
  run(int(sys.argv[1]),dict(batch_request,create_target_page=int(batch_request['prepare_200_style_page'])));sys.exit(0)
 if batch_request.get('copy_200_style_object'):
  from eb_copy_200_style_object import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('rewrite_page202_copy'):
  from eb_rewrite_page202_copy import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('copy_page200_to202'):
  from eb_copy_page200_to202 import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('inventory_page202_full'):
  from eb_inventory_page202_full import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('inventory_page16_full'):
  from eb_inventory_page16_full import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('trace_slow'):
  import faulthandler
  slow_trace=(ROOT/'evidence/uia-slow-stack.txt').open('w',encoding='utf8')
  faulthandler.dump_traceback_later(20,repeat=True,file=slow_trace)
 if batch_request.get('batch_cache_benchmark'):
  from eb_object_ui import target,properties
  from eb_uia_inventory import descendants
  from eb_native_messages import msg
  root,w=target(int(sys.argv[1]),32)
  d,_=properties(root,w,'BL_2','位状态指示灯/位状态切换开关的属性')
  results=[]
  try:
   for mode in ('lazy','provider_batch'):
    started=time.monotonic()
    cs=d.descendants(control_type='ComboBox',cache_enable=True) if mode=='lazy' else descendants(d,'ComboBox')
    names=[(c.element_info.name,c.element_info.control_type,c.element_info.handle,c.element_info.class_name) for c in cs]
    results.append({'mode':mode,'seconds':round(time.monotonic()-started,3),'count':len(cs),'metadata':names})
   (ROOT/'evidence/batch-cache-benchmark.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8')
  finally:
   buttons=[c for c in descendants(d,'Button') if c.element_info.name=='取消' and c.element_info.visible]
   if len(buttons)!=1:raise ValueError('Read-only benchmark cancel button required')
   msg(buttons[0].handle,245)
  sys.exit(0)
 if batch_request.get('lookup_benchmark'):
  d=Desktop(backend='uia').window(handle=int(sys.argv[1])).wrapper_object()
  if '新增 位状态' not in d.window_text():raise ValueError('Current bit creation dialog required')
  result=[]
  for cached in (False,True):
   started=time.monotonic()
   values=d.descendants(control_type='ComboBox',cache_enable=cached)
   named=[c.element_info.name for c in values]
   result.append({'cache_enable':cached,'seconds':round(time.monotonic()-started,3),'count':len(values)})
  (ROOT/'evidence/lookup-benchmark.json').write_text(json.dumps(result),encoding='utf8')
  sys.exit(0)
 if batch_request.get('read_event_grid'):
  d=Desktop(backend='uia').window(handle=int(sys.argv[1])).wrapper_object()
  if d.window_text()!='事件显示的属性':raise ValueError('Event property required')
  data=[]
  if batch_request.get('scroll_last_source_event_row'):
   roots=[w.window_text() for w in Desktop(backend='win32').windows(visible_only=False) if w.process_id()==d.process_id() and w.class_name()=='EasyBuilderPro']
   if not any('组装机2台15工位取消.cmtp' in t for t in roots):raise ValueError('Source-only grid scroll')
   cells=d.descendants(control_type='DataItem')
   if not cells:raise ValueError('Observed event grid required')
   from pywinauto import mouse
   r=cells[0].parent().rectangle();d.set_focus();mouse.scroll(coords=((r.left+r.right)//2,(r.top+r.bottom)//2),wheel_dist=-4);time.sleep(.2)
  for c in d.descendants(control_type='DataItem'):
   if not c.is_visible():continue
   r={'rect':str(c.rectangle())}
   for iface,fields in (('iface_legacy_iaccessible',('CurrentName','CurrentValue','CurrentDescription','CurrentState')),('iface_grid_item',('CurrentRow','CurrentColumn')),('iface_selection_item',('CurrentIsSelected',))):
    try:
     obj=getattr(c,iface)
     for f in fields:r[f]=getattr(obj,f)
    except Exception:pass
   data.append(r)
  (ROOT/'evidence/event-grid-read.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
  sys.exit(0)
 if 'event_appearance' in batch_request:
  from eb_event_appearance import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('source_history_tab') or batch_request.get('source_event_database') or batch_request.get('target_event_database'):
  root=Desktop(backend='win32').window(handle=int(sys.argv[1])).wrapper_object()
  if ('组装机_MT8106iP.emtp' if batch_request.get('target_event_database') else '组装机2台15工位取消.cmtp') not in root.window_text() or (root.rectangle().width(),root.rectangle().height())!=(1848,1281):raise ValueError('Reviewed project window required')
  root.set_focus();root.click_input(coords=(437,52));time.sleep(.2)
  if batch_request.get('source_event_database') or batch_request.get('target_event_database'):root.click_input(coords=(259,110));time.sleep(.3)
  sys.exit(0)
 if batch_request.get('find_existing_reset_picture'):
  from pywinauto import mouse
  g=Desktop(backend='uia').window(handle=int(sys.argv[1])).wrapper_object()
  if g.window_text()!='图片管理':raise ValueError('Gallery required')
  roots=[w.window_text() for w in Desktop(backend='win32').windows(visible_only=False) if w.process_id()==g.process_id() and w.class_name()=='EasyBuilderPro']
  if not any('组装机_MT8106iP.emtp' in t for t in roots):raise ValueError('Target gallery only')
  g.set_focus();seen=[]
  for attempt in range(10):
   groups=[c for c in g.descendants(control_type='Group',cache_enable=True) if c.is_visible() and c.window_text().isdigit()]
   seen.append([c.window_text() for c in groups])
   wanted=[c for c in groups if c.window_text()=='129']
   if wanted:
    wanted[0].click_input(coords=(60,65));break
   bars=[c for c in g.descendants(control_type='ScrollBar') if c.is_visible()]
   if len(bars)!=1:raise ValueError('Unique gallery scrollbar required')
   r=bars[0].rectangle();mouse.scroll(coords=((r.left+r.right)//2,(r.top+r.bottom)//2),wheel_dist=-24 if max([int(c.window_text()) for c in groups] or [0])<110 else -4);time.sleep(.15)
  (ROOT/'evidence/reset-gallery-search.json').write_text(json.dumps({'seen':seen,'found':bool(wanted)},ensure_ascii=False),encoding='utf8')
  sys.exit(0)
 if batch_request.get('open_existing_reset_picture'):
  from eb_object_ui import target,properties
  from eb_native_form import tab
  root,w=target(int(sys.argv[1]),103)
  d,_=properties(root,w,'TS_0','位状态切换开关/位状态指示灯的属性')
  tab(d,'图片')
  cs=[c for c in d.descendants(control_type='Button') if c.window_text()=='图库...' and c.is_visible()]
  if len(cs)!=2:raise ValueError('Two observed gallery buttons required')
  cs[0].click_input()
  sys.exit(0)
 if batch_request.get('select_original_bitmap_state'):
  g=Desktop(backend='win32').window(handle=int(sys.argv[1])).wrapper_object()
  r=g.rectangle()
  if g.window_text()!='图片管理' or [r.left,r.top,r.right,r.bottom]!=[798,322,1763,1057]:raise ValueError('Reviewed source gallery geometry required')
  roots=[w.window_text() for w in Desktop(backend='win32').windows(visible_only=False) if w.process_id()==g.process_id() and w.class_name()=='EasyBuilderPro']
  if not any('组装机2台15工位取消.cmtp' in t for t in roots):raise ValueError('Source project required')
  g.set_focus();g.click_input(coords=(760,454));time.sleep(.3)
  sys.exit(0)
 if batch_request.get('gallery_probe'):
  g=Desktop(backend='uia').window(handle=int(sys.argv[1])).wrapper_object()
  if g.window_text()!='图片管理':raise ValueError('Observed gallery required')
  entries=[{'name':c.element_info.name,'type':c.element_info.control_type,'rect':[c.rectangle().left,c.rectangle().top,c.rectangle().right,c.rectangle().bottom]} for c in g.descendants(control_type='MenuItem',cache_enable=True) if c.element_info.name]
  (ROOT/'evidence/flat-gallery-state.json').write_text(json.dumps(entries,ensure_ascii=False),encoding='utf8')
  sys.exit(0)
 if batch_request.get('adjust_fonts'):
  from eb_adjust_fonts import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('text_live'):
  from eb_text_live import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('compile_ribbon_ocr'):
  from eb_compile_ocr import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('restart_local_worker'):
  from pywinauto import Desktop
  root=Desktop(backend='win32').window(handle=int(sys.argv[1])).wrapper_object()
  if '组装机_MT8106iP.emtp' not in root.window_text():raise ValueError('Known local task target required')
  import subprocess
  current=json.loads((ROOT/'tools/request.json').read_text(encoding='utf-8-sig'))
  (ROOT/'evidence/response.json').write_text(json.dumps({'id':current['id'],'ok':True,'restart_requested':True}),encoding='utf8')
  subprocess.Popen([sys.executable,str(ROOT/'tools/eb_ui.py'),'worker'],creationflags=subprocess.CREATE_NO_WINDOW)
  sys.exit(0)
 if batch_request.get('fix_copy_filter'):
  from eb_fix_filter import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'rewrite_clone_fast' in batch_request:
  from eb_rewrite_clone_fast import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'rewrite_clone' in batch_request:
  from eb_rewrite_clone import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'clone_page' in batch_request:
  from eb_clone_page import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'sync_existing_rectangle' in batch_request:
  from eb_sync_appearance import rectangle
  rectangle(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'sync_existing_appearance' in batch_request:
  from eb_sync_appearance import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('build_page202_table'):
  from eb_build_page202_table import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('page202_button_colors'):
  from eb_page202_button_colors import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('recolor_page202_fk'):
  from eb_recolor_page202_fk import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('table202_grid_probe'):
  from eb_table202_grid_probe import run
  batch_request['table_grid_probe']=batch_request['table202_grid_probe']
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('adjust_table202_grid'):
  from eb_table202_grid_adjust import run
  batch_request['adjust_table_grid']=True
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('recolor_page200_fk'):
  from eb_recolor_page200_fk import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'build_fk' in batch_request:
  from eb_build_fk import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'build_ed' in batch_request:
  from eb_build_ed import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'event_details' in batch_request:
  from eb_alarm_entry import details
  details(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'alarm_entry' in batch_request:
  from eb_alarm_entry import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'build_ms' in batch_request:
  from eb_build_ms import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'build_gp' in batch_request:
  from eb_build_gp import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'build_rectangle' in batch_request:
  from eb_build_rectangle import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('center_page200_title'):
  from eb_center_page200_title import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('center_page202_headers'):
  from eb_center_page202_headers import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('center_page200_headers'):
  from eb_center_page200_headers import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if batch_request.get('build_page200_table'):
  from eb_build_page200_table import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('table_grid_adjust_probe') or batch_request.get('adjust_table_grid'):
  from eb_table_grid_adjust import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'table_grid_probe' in batch_request:
  from eb_table_grid_probe import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'copy_page202_numeric' in batch_request:
  from eb_copy_page202_numeric import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'copy_page202_lamp' in batch_request:
  from eb_copy_page202_lamp import run
  run(int(sys.argv[1]),batch_request);sys.exit(0)
 if 'copy_page200_numeric' in batch_request:
  from eb_copy_page200_numeric import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('local_popup_ocr'):
  from eb_popup_local_ocr import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('resize_page200_lamps'):
  from eb_resize_page200_lamps import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'copy_page200_lamp' in batch_request:
  from eb_copy_page200_lamp import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('page200_button_colors'):
  from eb_page200_button_colors import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'build_bit_general' in batch_request:
  from eb_build_bit_general import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'build_numeric' in batch_request:
  from eb_build_numeric import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'build_ab' in batch_request:
  from eb_build_ab import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'order_sp' in batch_request:
  from eb_order_sp import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'prepare_vector_ribbon' in batch_request:
  from eb_object_ui import target
  root,_=target(int(sys.argv[1]),101)
  root.set_focus();root.click_input(coords=(373,52))
  if batch_request.get('open'):
   root.click_input(coords=(177,118))
  sys.exit(0)
 if 'build_sp' in batch_request:
  from eb_build_sp import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'fix_ts_labels' in batch_request:
  from eb_fix_ts_labels import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'build_dc' in batch_request:
  from eb_build_dc import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'prepare_complex' in batch_request:
  from eb_prepare_complex import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'build_tx' in batch_request:
  from eb_build_tx import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'build_wp' in batch_request:
  from eb_build_wp import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'finish_bit' in batch_request:
  from eb_finish_bit import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'fix_bl_labels' in batch_request:
  from eb_fix_labels import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('restore_target_window'):
  native=Desktop(backend='win32').window(handle=int(sys.argv[1])).wrapper_object()
  if '组装机_MT8106iP.emtp' not in native.window_text() and '组装机2台15工位取消.cmtp' not in native.window_text():raise ValueError('Reviewed project window only')
  native.restore()
  if batch_request.get('reviewed_size'):
   native.move_window(x=262,y=0,width=1848,height=1281)
   if abs(native.rectangle().width()-1848)>1 or abs(native.rectangle().height()-1281)>1:raise ValueError('Reviewed target size readback mismatch')
  sys.exit(0)
 if 'open_target_page' in batch_request:
  from eb_open_page import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'create_target_page' in batch_request:
  from eb_create_page import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'compile_target' in batch_request:
  from eb_compile_target import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'choose_flat' in batch_request:
  from eb_flat_picture import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'finish_sw' in batch_request:
  from eb_finish_sw import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'target_page_audit' in batch_request:
  from eb_page_audit import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'fix_base_lamp_fit' in batch_request:
  from eb_fix_base_lamp_fit import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'canvas_map' in batch_request:
  from eb_canvas_map import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'probe_canvas_reset' in batch_request:
  from eb_probe_canvas_reset import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'probe_reset_menu' in batch_request:
  from eb_probe_reset_menu import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'finish_user_reset' in batch_request:
  from eb_finish_user_reset import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'finish_base_wp1' in batch_request:
  from eb_finish_base_wp1 import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'finish_base_wp' in batch_request:
  from eb_finish_base_wp import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'copy_base_wp1' in batch_request:
  from eb_copy_base_wp1 import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'copy_base_wp' in batch_request:
  from eb_copy_base_wp import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'copy_user_reset' in batch_request:
  from eb_copy_user_reset import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'build_bl' in batch_request:
  from eb_build_bl import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'build_sw' in batch_request:
  from eb_build_sw import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'target_page_size' in batch_request:
  from eb_target_page import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'page_settings' in batch_request:
  from eb_window import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('table_fix'):
  from eb_table_fix import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('table_columns'):
  from eb_table_columns import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if batch_request.get('move_objects'):
  from eb_move_objects import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'extract_batch' in batch_request:
  from eb_extract import run
  items=batch_request['extract_batch']
  if not 1<=len(items)<=3:raise ValueError('Source extraction batch1..3 only')
  for item in items:run(int(sys.argv[1]),{'extract':item})
  sys.exit(0)
 if 'extract' in batch_request:
  from eb_extract import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'inventory' in batch_request:
  from eb_inventory import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
 if 'batch' in batch_request:
  from eb_batch import run
  run(int(sys.argv[1]),batch_request)
  sys.exit(0)
w=Desktop(backend='uia').window(handle=int(sys.argv[1])).wrapper_object()
req=json.loads(sys.argv[2]) if len(sys.argv)>2 and sys.argv[2] else {}
if req:
 c=w
 if req.get('selector'):
  matches=[v for v in w.descendants(control_type=req['type']) if v.element_info.name==req['name'] and v.is_visible()]
  occurrence=req.get('occurrence',0)
  if ('occurrence' not in req and len(matches)!=1) or len(matches)<=occurrence:raise ValueError('Selector must identify one current control')
  c=matches[occurrence]
 else:
  for i in req.get('path',[]):c=c.children()[i]
 if c.element_info.control_type!=req['type'] or c.element_info.name!=req['name']:
  raise ValueError('UIA selector changed; inspect again')
 op=req['op']
 if op in ('doubleclick','navigate','expand','context','contextselect'):
  ctypes.windll.user32.ShowWindow(int(sys.argv[1]),9)
  w.set_focus();time.sleep(.2)
  if ctypes.windll.user32.GetForegroundWindow()!=int(sys.argv[1]):raise ValueError('UIA input foreground mismatch')
 if op in ('setvalue','selectitem','toggle','commitcombo'):
  titles=[r.window_text() for r in Desktop(backend='win32').windows(visible_only=False) if r.process_id()==w.process_id() and r.class_name()=='EasyBuilderPro']
  browsing_state=op=='selectitem' and req['name']=='状态 :' and req['value'] in ('0','1')
  export_folder=op=='setvalue' and w.window_text()=='浏览文件夹' and req['type']=='Edit' and req['value']==str(ROOT/'source'/'macros')
  export_selection=op=='toggle' and w.window_text()=='导出宏指令' and req['type']=='CheckBox'
  recovered_save=op=='setvalue' and w.window_text()=='另存为' and req['name']=='文件名:' and req['value']==str(ROOT/'output'/'组装机_MT8106iP.emtp') and any('组装机_MT8106iP -' in t for t in titles)
  asset_export=op=='setvalue' and w.window_text()=='另存为' and req['name']=='文件名:' and req['value'] in (str(ROOT/'source'/'assets'/'page16-GP0.png'),str(ROOT/'source'/'assets'/'page103-TS0.dpd'),str(ROOT/'source'/'assets'/'page103-TS0-state1.bmp'),str(ROOT/'source'/'assets'/'source-events-484.xls'))
  if not browsing_state and not export_selection and not export_folder and not recovered_save and not asset_export and not any('组装机_MT8106iP.emtp' in t for t in titles):raise ValueError('Data changes allowed only in target reconstruction project')
 if op=='selectexportall':
  if w.window_text()!='导出宏指令' or req['type']!='List':raise ValueError('Export selection only')
  for item in c.children():
   if item.element_info.control_type=='CheckBox' and item.get_toggle_state()!=1:item.toggle()
 elif op=='hoverprobe':
  if req['type']!='ToolBar' or not c.element_info.class_name.startswith('EBRibbonBar'):
   raise ValueError('Hover probe requires observed EasyBuilder ribbon')
  from pywinauto import mouse
  rect=c.rectangle();points=req['value']
  if not isinstance(points,list) or len(points)>16:raise ValueError('Maximum 16 hover points')
  w.set_focus();observations=[]
  if ctypes.windll.user32.GetForegroundWindow()!=int(sys.argv[1]):raise ValueError('Hover foreground mismatch')
  for dx,dy in points:
   x,y=rect.left+dx,rect.top+dy
   if not (rect.left<=x<rect.right and rect.top<=y<rect.bottom):raise ValueError('Hover outside ribbon')
   mouse.move(coords=(x,y));time.sleep(1.3)
   texts=[]
   for tip in Desktop(backend='uia').windows():
    if tip.process_id()==w.process_id() and tip.element_info.handle!=w.element_info.handle:
     texts.extend([tip.window_text()]+[v.window_text() for v in tip.descendants()])
   observations.append({'point':[x,y],'text':list(dict.fromkeys(t for t in texts if t))})
  (ROOT/'evidence'/'ribbon-hover-probe.json').write_text(json.dumps(observations,ensure_ascii=False,indent=2),encoding='utf8')
 elif op=='selectallfiles':
  if w.window_text()!='导入宏' or req['type']!='List' or req['name']!='项目视图':raise ValueError('Macro file list only')
  multiple=bool(c.iface_selection.CurrentCanSelectMultiple)
  if not multiple:raise ValueError('File dialog does not allow multiple selection')
  from pywinauto.keyboard import send_keys
  items=[item for item in c.children() if item.element_info.control_type=='ListItem' and item.window_text().endswith('.ebm')]
  if not items:raise ValueError('No exposed macro file')
  items[0].select();c.set_focus();send_keys('^a')
  time.sleep(.3)
  selected=c.iface_selection.GetCurrentSelection()
  names=[selected.GetElement(i).CurrentName for i in range(selected.Length)]
  (ROOT/'evidence'/'selected-import-macros.json').write_text(json.dumps(names,ensure_ascii=False,indent=2),encoding='utf8')
  if len(names)!=129 or any(not name.endswith('.ebm') for name in names):raise ValueError('Expected exactly 129 selected .ebm files')
 elif op=='selectlist':
  if req['type']!='ListItem':raise ValueError('selectlist requires ListItem')
  parent=c.parent()
  if parent.element_info.class_name=='ListBox':
   from pywinauto.controls.win32_controls import ListBoxWrapper
   native=ListBoxWrapper(parent.element_info.handle)
   native.select(req['name'])
   if req['name'] not in [native.item_texts()[i] for i in native.selected_indices()]:raise ValueError('List selection readback mismatch')
  else:c.select()
 elif op=='selecttab':
  if req['type']!='TabItem' or not c.is_visible():raise ValueError('Visible observed tab required')
  w.set_focus();c.click_input()
 elif op=='invoke':
  if req['type']=='MenuItem':
   pid=ctypes.c_ulong();ctypes.windll.user32.GetWindowThreadProcessId(ctypes.windll.user32.GetForegroundWindow(),ctypes.byref(pid))
   if pid.value!=w.process_id():raise ValueError('Menu input foreground process mismatch')
   c.click_input()
  else:c.invoke()
 elif op=='clickcontrol':
  if req['type'] not in ('Button','RadioButton') or not c.is_visible() or not c.is_enabled():raise ValueError('Requires enabled visible button')
  if req['type']=='RadioButton':
   titles=[r.window_text() for r in Desktop(backend='win32').windows(visible_only=False) if r.process_id()==w.process_id() and r.class_name()=='EasyBuilderPro']
   if not any('组装机_MT8106iP.emtp' in t for t in titles):raise ValueError('Radio changes only in target project')
  w.set_focus()
  if ctypes.windll.user32.GetForegroundWindow()!=int(sys.argv[1]):raise ValueError('Button foreground mismatch')
  c.click_input()
 elif op=='clickitem':
  if req['type']!='ListItem' or not c.is_visible():raise ValueError('Visible list item required')
  titles=[r.window_text() for r in Desktop(backend='win32').windows(visible_only=False) if r.process_id()==w.process_id() and r.class_name()=='EasyBuilderPro']
  if not any('组装机_MT8106iP.emtp' in t for t in titles):raise ValueError('List changes only in target project')
  c.click_input()
 elif op=='doubleclick':
  if not c.is_visible():raise ValueError('Control must be visible')
  c.double_click_input(coords=(40,c.rectangle().height()//2)) if req["type"]=="TreeItem" else c.double_click_input()
 elif op=='contextselect':
  if not c.is_visible():raise ValueError('Context target must be visible')
  c.click_input(button='right',coords=(40,c.rectangle().height()//2)) if req['type']=='TreeItem' else c.click_input(button='right');time.sleep(.2)
  candidates=[]
  for popup in Desktop(backend='uia').windows():
   if popup.process_id()==w.process_id():
    candidates.extend([item for item in popup.descendants(control_type='MenuItem') if item.window_text()==req['value']])
  if len(candidates)!=1:raise ValueError('Context menu must expose one verified named action')
  candidates[0].click_input();time.sleep(.3)
  (ROOT/'evidence'/'uia.json').write_text('[]',encoding='utf8')
  sys.exit(0)
 elif op=='context':
  if not c.is_visible():raise ValueError('Context target must be visible')
  c.click_input(button='right',coords=(40,c.rectangle().height()//2)) if req['type']=='TreeItem' else c.click_input(button='right')
 elif op=='setvalue':
  if not c.is_visible():raise ValueError('Edit must be visible')
  w.set_focus();c.click_input()
  try:
   if c.element_info.handle and c.element_info.class_name=='Edit':
    from pywinauto.controls.win32_controls import EditWrapper
    EditWrapper(c.element_info.handle).set_edit_text(req['value'])
   else:c.set_edit_text(req['value'])
  except Exception:
   if not c.is_visible():raise ValueError('Keyboard fallback requires visible edit')
   from pywinauto.keyboard import send_keys
   w.set_focus()
   c.set_focus()
   literal=''.join({'{':'{{}','}':'{}}','+':'{+}','^':'{^}','%':'{%}','(':'{(}',')':'{)}'}.get(ch,ch) for ch in req['value'])
   send_keys('^a'+literal,with_spaces=True,pause=.03)
   time.sleep(.2)
  if c.get_value().rstrip('\r\n')!=req['value'].rstrip('\r\n'):
   from pywinauto.keyboard import send_keys
   w.set_focus();c.click_input()
   literal=''.join({'{':'{{}','}':'{}}','+':'{+}','^':'{^}','%':'{%}'}.get(ch,ch) for ch in req['value'])
   send_keys('^a'+literal+'{TAB}',with_spaces=True,pause=.03);time.sleep(.2)
   if c.get_value().rstrip('\r\n')!=req['value'].rstrip('\r\n'):raise ValueError('UIA value readback mismatch after input retry')
 elif op=='commitcombo':
  if req['type']!='ComboBox' or c.element_info.class_name=='ComboBox':raise ValueError('commitcombo requires Qt editable ComboBox')
  edits=[item for item in c.children() if item.element_info.control_type=='Edit']
  if len(edits)!=1:raise ValueError('Requires one observed editable combo child')
  from pywinauto.keyboard import send_keys
  w.set_focus();edits[0].click_input()
  literal=''.join({'{':'{{}','}':'{}}','+':'{+}','^':'{^}','%':'{%}'}.get(ch,ch) for ch in req['value'])
  send_keys('^a'+literal+'{ENTER}',with_spaces=True,pause=.03);time.sleep(.3)
  if c.selected_text()!=req['value']:raise ValueError('Committed combo readback mismatch')
 elif op=='scrollchoice':
  if req['type']!='ComboBox' or req['name']!=' Down' or req['value']!='bottom':raise ValueError('Window selector only')
  from pywinauto import mouse
  rect=c.rectangle()
  for _ in range(4):
   mouse.scroll(coords=((rect.left+rect.right)//2,rect.bottom+60),wheel_dist=-15);time.sleep(.1)
 elif op=='windowchoice':
  if req['type']!='ComboBox' or req['name']!=' Down' or req['value']!='101. 操作说明':raise ValueError('Verified window choice only')
  w.set_focus();rect=c.rectangle();c.click_input(coords=(rect.width()-12,rect.height()//2));time.sleep(.2)
  from pywinauto.keyboard import send_keys
  from pywinauto import mouse
  rect=c.rectangle();mouse.scroll(coords=((rect.left+rect.right)//2,rect.bottom+60),wheel_dist=-15);time.sleep(.2)
  # Selection remains pending until an observed item is clicked and read back.
 elif op=='popupselect':
  if req['type']!='ComboBox' or req['name']!='宏指令 :':raise ValueError('Macro chooser only')
  titles=[r.window_text() for r in Desktop(backend='win32').windows(visible_only=False) if r.process_id()==w.process_id() and r.class_name()=='EasyBuilderPro']
  if not any('组装机_MT8106iP.emtp' in t for t in titles):raise ValueError('Target project only')
  w.set_focus();rect=c.rectangle()
  c.click_input(coords=(rect.width()-12,rect.height()//2));time.sleep(.2)
  popups=[r for r in Desktop(backend='win32').windows() if r.process_id()==w.process_id() and r.window_text()=='设置窗口' and r.is_visible()]
  if len(popups)!=1:raise ValueError('Expected one macro search popup')
  popup=Desktop(backend='uia').window(handle=popups[0].handle).wrapper_object();edits=popup.descendants(control_type='Edit')
  if len(edits)!=1:raise ValueError('Expected one macro search field')
  edits[0].click_input()
  try:edits[0].set_edit_text(req['value'])
  except Exception:
   from pywinauto.keyboard import send_keys
   escaped=''.join('{'+v+'}' if v in '+^%~{}()' else v for v in req['value'])
   send_keys('^a'+escaped,with_spaces=True,pause=.01)
  time.sleep(.2)
  matches=[r for r in popup.descendants(control_type='ListItem') if r.window_text()==req['value'] and r.is_visible()]
  if len(matches)!=1:raise ValueError('Expected unique macro search result')
  matches[0].click_input(double=True);time.sleep(.2)
  from pywinauto.controls.win32_controls import ComboBoxWrapper
  if ComboBoxWrapper(c.element_info.handle).selected_text()!=req['value']:raise ValueError('Macro binding readback mismatch')
 elif op=='comboitems':
  if req['type']!='ComboBox' or c.element_info.class_name!='ComboBox':raise ValueError('Native ComboBox only')
  from pywinauto.controls.win32_controls import ComboBoxWrapper
  (ROOT/'evidence'/'combo-items.json').write_text(json.dumps(ComboBoxWrapper(c.element_info.handle).item_texts(),ensure_ascii=False,indent=2),encoding='utf8')
 elif op=='selectitem':
  if c.element_info.handle and c.element_info.class_name=='ComboBox':
   from pywinauto.controls.win32_controls import ComboBoxWrapper
   native=ComboBoxWrapper(c.element_info.handle)
   if req['value'] not in native.item_texts():
    c.expand();time.sleep(.2)
   native.select(req['value'])
   try:c.collapse()
   except Exception:pass
  else:c.select(req['value'])
 elif op=='toggle':
  if c.get_toggle_state()!=int(req['value']):c.toggle()
 elif op=='expand':
  try:c.expand()
  except Exception:
   from pywinauto.keyboard import send_keys
   if not c.is_visible():raise ValueError('Expand fallback requires visible item')
   c.click_input();send_keys('{RIGHT}');time.sleep(.2)
 elif op=='scroll':
  if req['type']!='Tree' or req['value'] not in (-8,8):raise ValueError('Only tree scroll +/-8 is allowed')
  from pywinauto import mouse
  w.set_focus();r=c.rectangle()
  mouse.scroll(coords=((r.left+r.right)//2,(r.top+r.bottom)//2),wheel_dist=req['value'])
  time.sleep(.4)
 elif op=='navigate':
  if req['type'] not in ('Tree','TreeItem') or req['value'] not in ('{PGDN}','{PGUP}','{HOME}','{END}'):
   raise ValueError('Only tree navigation is allowed')
  if not c.is_visible():raise ValueError('Tree item must be visible')
  from pywinauto.keyboard import send_keys
  c.click_input();send_keys(req['value']);time.sleep(.2)
 elif op=='viewport_start':
  if req['type']!='ScrollBar' or req['name'] not in ('水平滚动条','垂直滚动条') or not c.is_visible():raise ValueError('Observed canvas scrollbar required')
  percent=req.get('value',0)
  if percent not in (0,50):raise ValueError('Reviewed viewport fraction only')
  c.iface_range_value.SetValue(c.iface_range_value.CurrentMinimum+(c.iface_range_value.CurrentMaximum-c.iface_range_value.CurrentMinimum)*percent/100)
 elif op=='read':pass
 else:raise ValueError('Unsupported UIA operation')
 time.sleep(.25)
 if not ctypes.windll.user32.IsWindow(int(sys.argv[1])) or not ctypes.windll.user32.IsWindowVisible(int(sys.argv[1])):
  (ROOT/'evidence'/'uia.json').write_text('[]',encoding='utf8')
  sys.exit(0)
if req.get('summary'):
 value=None
 if op in ('setvalue','read') and req['type']=='Edit':value=c.get_value().rstrip('\r\n')
 elif op in ('selectitem','popupselect','read') and req['type']=='ComboBox':
  from pywinauto.controls.win32_controls import ComboBoxWrapper
  value=ComboBoxWrapper(c.element_info.handle).selected_text() if c.element_info.class_name=='ComboBox' else c.selected_text()
 (ROOT/'evidence'/'last-action-report.json').write_text(json.dumps({'ok':True,'op':op,'name':req['name'],'value':value},ensure_ascii=False),encoding='utf8')
 sys.exit(0)
rows=[];start=time.monotonic()
def walk(c,path,depth):
 if len(rows)>=700 or time.monotonic()-start>15:return
 e=c.element_info
 rect=c.rectangle()
 row={'path':path,'name':e.name,'type':e.control_type,'automation_id':e.automation_id,'class':e.class_name,'handle':e.handle,'visible':c.is_visible(),'enabled':c.is_enabled(),'rect':[rect.left,rect.top,rect.right,rect.bottom]}
 try:
  if e.control_type=='Edit':row['value']=c.get_value()
  elif e.control_type=='ComboBox':
   if e.class_name=='ComboBox' and e.handle:
    from pywinauto.controls.win32_controls import ComboBoxWrapper
    row['selected']=ComboBoxWrapper(e.handle).selected_text()
   else:row['selected']=c.selected_text()
  elif e.control_type=='CheckBox':row['state']=c.get_toggle_state()
 except Exception as exc:row['value_error']=str(exc)
 rows.append(row)
 if depth<11 and row['visible']:
  for i,child in enumerate(c.children()):walk(child,path+[i],depth+1)
walk(w,[],0)
(ROOT/'evidence'/'uia.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')






