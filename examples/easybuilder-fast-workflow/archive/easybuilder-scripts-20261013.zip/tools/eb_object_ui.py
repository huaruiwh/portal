"""Shared observed target-window operations for new complex object builders."""
import time,re,ctypes
from pywinauto import Desktop,mouse
from pywinauto.keyboard import send_keys
from eb_timing import timed
_row_cache={}
def target(handle,page):
    root=Desktop(backend='win32').window(handle=handle).wrapper_object()
    if '组装机_MT8106iP.emtp' not in root.window_text() or f'[{page} - ' not in root.window_text():raise ValueError('Exact target page required')
    r=root.rectangle()
    if abs(r.width()-1848)>1 or abs(r.height()-1281)>1:raise ValueError('Reviewed ribbon layout1848x1281 required')
    if root.is_enabled() and ctypes.windll.user32.GetForegroundWindow()!=root.handle:root.set_focus() # Exact-page title above already verifies the active page.
    return root,Desktop(backend='uia').window(handle=handle).wrapper_object()
def dialog(pid,title,attempts=200):
    for _ in range(attempts):
        ds=[]
        u=ctypes.windll.user32
        callback=ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p)
        @callback
        def visit(h,_):
            observed_pid=ctypes.c_ulong();u.GetWindowThreadProcessId(h,ctypes.byref(observed_pid))
            if observed_pid.value==pid and u.IsWindowVisible(h):
                text=ctypes.create_unicode_buffer(1024);u.GetWindowTextW(h,text,1024)
                if text.value==title:ds.append(int(h))
            return True
        u.EnumWindows(visit,0)
        if len(ds)==1:
            candidate=ds[0];time.sleep(.1)
            if u.IsWindow(candidate) and u.IsWindowVisible(candidate) and u.IsWindowEnabled(candidate):
                return Desktop(backend='uia').window(handle=candidate).wrapper_object()
        time.sleep(.1)
    raise ValueError('Dialog not ready: '+title)
def menu(root,coords,name):
    root.set_focus();root.click_input(coords=coords)
    matches=[]
    for _ in range(12):
        matches=[]
        for win in Desktop(backend='win32').windows():
            if win.process_id()==root.process_id() and win.class_name().startswith('Qt5QWindowPopup') and win.is_visible():
                popup=Desktop(backend='uia').window(handle=win.handle).wrapper_object()
                matches.extend(c for c in popup.descendants(control_type='MenuItem') if c.window_text()==name and c.is_visible())
        if len(matches)==1:break
        time.sleep(.1)
    if len(matches)!=1:raise ValueError('Observed ribbon menu required: '+name)
    matches[0].click_input()
@timed
def object_item(w,key,directory=None):
    from eb_directory import scope
    if directory is None:directory=scope(w)
    cache_key=(w.handle,w.window_text(),key)
    cached=_row_cache.get(cache_key)
    if cached is not None:
        try:
            cached.element_info.set_cache_strategy(False)
            if re.search(r'(?:^|\])\s*'+re.escape(key)+r'(?:\s|$)',cached.element_info.name) and cached.is_visible():
                box=cached.rectangle()
                if 0<box.height()<60:return cached
        except Exception:pass
        _row_cache.pop(cache_key,None)
    pattern=r'(?:^|\])\s*'+re.escape(key)+r'(?:\s|$)'
    matches=[c for c in directory.descendants(control_type='TreeItem',cache_enable=True) if re.search(pattern,c.element_info.name)]
    if not matches:
        # Newly pasted controls usually occupy the bottom: one jump, then the
        # original full search fallback if the exact key is still not exposed.
        trees=[t for t in directory.descendants(control_type='Tree') if t.is_visible()]
        if len(trees)==1:
            vr=trees[0].rectangle()
            mouse.scroll(coords=((vr.left+vr.right)//2,(vr.top+vr.bottom)//2),wheel_dist=-80);time.sleep(.1)
            matches=[c for c in directory.descendants(control_type='TreeItem',cache_enable=True) if re.search(pattern,c.element_info.name)]
    if not matches:
        r=w.rectangle()
        mouse.scroll(coords=(r.left+200,r.bottom-250),wheel_dist=60);time.sleep(.1)
        matches=[c for c in directory.descendants(control_type='TreeItem',cache_enable=True) if re.search(pattern,c.element_info.name)]
    if not matches:
        page=re.search(r'\[(\d+) - ',w.window_text())
        headers=[c for c in directory.descendants(control_type='TreeItem',cache_enable=True) if page and c.element_info.name.startswith(page[1]+' :')]
        exposed=directory.descendants(control_type='TreeItem',cache_enable=True)
        has_objects=any(re.search(r'(?:^|\])\s*[A-Z]{2}_\d+',c.element_info.name) for c in exposed)
        if len(headers)==1 and not has_objects:
            box=headers[0].rectangle()
            if box.height()>0 and r.top+240<=box.top<box.bottom<=r.bottom-50:
                mouse.double_click(coords=(box.left+min(40,box.width()-2),(box.top+box.bottom)//2))
                time.sleep(.2)
            matches=[c for c in directory.descendants(control_type='TreeItem',cache_enable=True) if re.search(pattern,c.element_info.name)]
    if not matches:
        r=w.rectangle()
        for _ in range(12):
            mouse.scroll(coords=(r.left+200,r.bottom-250),wheel_dist=-8);time.sleep(.1)
            matches=[c for c in directory.descendants(control_type='TreeItem',cache_enable=True) if re.search(pattern,c.element_info.name)]
            if matches:break
    if len(matches)!=1:raise ValueError('Unique target object required: '+key)
    return matches[0]
def placed_properties(root,w,key,title):
    root.set_focus();root.click_input(coords=(963,367));send_keys('{ESC}',pause=.01);time.sleep(.15)
    return properties(root,w,key,title)

@timed
def properties(root,w,key,title):
    property_started=time.monotonic();selected_fast=False;candidate=None
    r=root.rectangle()
    from eb_directory import scope
    directory=scope(w)
    trees=[t for t in directory.descendants(control_type='Tree') if t.is_visible()]
    if len(trees)!=1:raise ValueError('Unique target tree viewport required')
    try:
        selected=trees[0].get_selection()
        matching=[info for info in selected if info.control_type=='TreeItem' and re.search(r'(?:^|\])\s*'+re.escape(key)+r'(?:\s|$)',info.name)]
        if len(selected)==len(matching)==1:
            from pywinauto.controls.uiawrapper import UIAWrapper
            candidate=UIAWrapper(matching[0]);selected_fast=True
    except Exception:pass
    for _ in range(8):
        item=candidate if _==0 and candidate is not None else object_item(w,key,directory);box=item.rectangle()
        viewport=trees[0].rectangle()
        if 0<box.height()<60 and max(r.top+240,viewport.top)<=box.top and box.bottom<=min(r.bottom-50,viewport.bottom):break
        mouse.scroll(coords=((viewport.left+viewport.right)//2,(viewport.top+viewport.bottom)//2),wheel_dist=8 if box.top<viewport.top else -8);time.sleep(.1)
    else:raise ValueError('Cannot bring target object into view: '+str((key,box,viewport,r)))
    # box/viewport were read after the last scroll; no intervening mutation.
    if not (0<box.height()<60 and viewport.left<=box.left<box.right<=viewport.right and max(viewport.top,r.top+240)<=box.top<box.bottom<=min(viewport.bottom,r.bottom-50)):
        raise ValueError('Fresh target row outside safe tree viewport')
    name=item.element_info.name
    # Refresh and activate the actual row before each bounded open attempt.
    for attempt in range(3):
        if ctypes.windll.user32.GetForegroundWindow()!=root.handle:root.set_focus()
        if ctypes.windll.user32.GetForegroundWindow()!=root.handle:
            root.click_input(coords=(100,12))
        if ctypes.windll.user32.GetForegroundWindow()!=root.handle:raise ValueError('Target foreground not verified before properties')
        if attempt:
            item=object_item(w,key,directory)
            box=item.rectangle();viewport=trees[0].rectangle()
        if not(viewport.left<=box.left<box.right<=viewport.right and viewport.top<=box.top<box.bottom<=viewport.bottom):raise ValueError('Property row moved outside viewport')
        mouse.double_click(coords=(box.left+min(40,box.width()-2),(box.top+box.bottom)//2))
        try:
            result=dialog(root.process_id(),title,attempts=25)
            import json
            from pathlib import Path
            with (Path(__file__).resolve().parent.parent/'evidence/property-open-detail.jsonl').open('a',encoding='utf8')as log:
                log.write(json.dumps({'key':key,'seconds':round(time.monotonic()-property_started,3),'selected_row_fast':selected_fast,'attempt':attempt+1})+'\n')
            return result,name
        except ValueError as e:
            if not str(e).startswith('Dialog not ready:') or not root.is_enabled():raise
            if attempt==2:raise
            time.sleep(.15)

@timed
def save(root):
    import ctypes
    for _ in range(20):
        if root.is_enabled():break
        time.sleep(.1)
    else:raise ValueError('Target still blocked by a modal dialog; save not sent')
    try:root.set_focus()
    except Exception:root.click_input(coords=(100,12))
    if ctypes.windll.user32.GetForegroundWindow()!=root.handle:
        root.click_input(coords=(100,12))
    if ctypes.windll.user32.GetForegroundWindow()!=root.handle:raise ValueError('Target foreground not verified; save not sent')
    send_keys('^s',pause=.01)
