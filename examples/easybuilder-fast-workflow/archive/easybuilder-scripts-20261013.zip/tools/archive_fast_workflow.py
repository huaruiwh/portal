"""Archive method scripts only. No project, field configuration or credentials."""
import json,re,hashlib,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
REPO=ROOT.parent/'portal'
def main():
 out=REPO/'examples/easybuilder-fast-workflow';(out/'archive').mkdir(parents=True,exist_ok=True)
 files=[p for p in sorted((ROOT/'tools').glob('*.py'))if not p.name.startswith('publish')]
 for p in files:
  if re.search(r'(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_-]{20,}|BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY',p.read_text(encoding='utf-8-sig')):raise ValueError('Credential literal: '+p.name)
 manifest={'date':'2026-10-13','scripts':[{'path':'tools/'+p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in files],'project_files_included':False,'site_configuration_included':False}
 z=out/'archive/easybuilder-scripts-20261013.zip'
 with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED)as archive:
  for p in files:archive.write(p,'tools/'+p.name)
  archive.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
 with zipfile.ZipFile(z)as archive:
  if archive.testzip()is not None:raise ValueError('ZIP validation failed')
 manifest.update(zip_bytes=z.stat().st_size,zip_sha256=hashlib.sha256(z.read_bytes()).hexdigest())
 (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
 (ROOT/'evidence/github-method-archive.json').write_text(json.dumps({'repo':'huaruiwh/portal','scripts':len(files),'zip_bytes':manifest['zip_bytes'],'sha256':manifest['zip_sha256'],'phase':'prepared'},indent=2),encoding='utf8')
 print(json.dumps({'scripts':len(files),'zip_bytes':manifest['zip_bytes'],'sha256':manifest['zip_sha256']}))
if __name__=='__main__':main()
