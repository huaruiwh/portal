"""Bind an existing macro through the observed lazy selector; never run it."""
import time
from pywinauto import Desktop
from pywinauto.controls.win32_controls import ComboBoxWrapper
from eb_native_form import commit_text

def choose(combo,value,pid):
    native=ComboBoxWrapper(combo.handle)
    if native.selected_text()==value:return
    if value in native.item_texts():native.select(value)
    else:
        dialogs=[w for w in Desktop(backend='win32').windows() if w.process_id()==pid and w.window_text()=='设置窗口' and w.is_visible()]
        if len(dialogs)>1:raise ValueError('Ambiguous macro selector recovery')
        if not dialogs:
            box=combo.rectangle();combo.click_input(coords=(box.width()-12,box.height()//2))
        for _ in range(20):
            dialogs=[w for w in Desktop(backend='win32').windows() if w.process_id()==pid and w.window_text()=='设置窗口' and w.is_visible()]
            if len(dialogs)==1:break
            time.sleep(.1)
        if len(dialogs)!=1:raise ValueError('Observed macro search window required')
        d=Desktop(backend='uia').window(handle=dialogs[0].handle).wrapper_object()
        search=value.split(']',1)[1].strip()
        try:commit_text(d,'',search)
        except ValueError as error:
            if not str(error).startswith('Text submission mismatch:'):raise
        for _ in range(15):
            edits=[c for c in d.descendants(control_type='Edit') if c.window_text()=='' and c.is_visible()]
            if len(edits)==1 and edits[0].get_value()==search:break
            time.sleep(.1)
        else:raise ValueError('Macro filter live readback mismatch')
        choices=[c for c in d.descendants(control_type='ListItem') if c.window_text()==value and c.is_visible()]
        if len(choices)!=1:raise ValueError('Exact macro id and name required')
        choices[0].click_input(double=True);time.sleep(.15)
    if native.selected_text()!=value:raise ValueError('Macro binding readback mismatch')
