import json,subprocess,ctypes
from PIL import ImageGrab
from pywinauto import Desktop
from eb_rebuild_page import ROOT
def run(handle,q):
    w=Desktop(backend='win32').window(handle=handle).wrapper_object()
    if '组装机_MT8106iP.emtp' not in w.window_text():raise ValueError('Target only')
    if not w.is_enabled():raise ValueError('Target has an open property dialog; preserve user edits')
    w.set_focus();r=w.rectangle()
    if ctypes.windll.user32.GetForegroundWindow()!=handle:raise ValueError('Target foreground required')
    p=ROOT/'evidence/compile-ribbon-local.png';out=ROOT/'evidence/compile-ribbon-ocr.json'
    ImageGrab.grab(bbox=(r.left,r.top,r.right,r.top+190)).save(p)
    code=(ROOT/'tools/Read-LocalImageText.ps1').read_text(encoding='utf8')
    code=code.replace('param([string]$ImagePath,[string]$OutputPath)',"$ImagePath='"+str(p).replace("'","''")+"';$OutputPath='"+str(out).replace("'","''")+"'")
    result=subprocess.run(['C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe','-NoProfile','-Command',code],capture_output=True,text=True,timeout=30)
    if result.returncode:raise RuntimeError(result.stderr)
    if not out.exists():raise ValueError('OCR output missing; no observation produced')
